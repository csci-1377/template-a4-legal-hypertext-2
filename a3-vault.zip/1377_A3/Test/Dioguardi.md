---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Tonics, Please!
Takeaway: ""
Tags:
  - Pleading
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1944
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Dioguardi v. Durningd
Status: Annotated
Date: 1944-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> Pl writes a complaint himself (a pro se case). He alleges he tried to import a crate of tonics from Milan, Italy that were “of great value,” but it is confiscated by Port of NY customs agency. The facts are not quite clear on how it came into Custom Collector’s hands. He alleges that the defendant sold the merchandise at public custom to another bidder “with my price of $110 and not his price of $120” and that 3 weeks before the sale, two cases of 19 bottles each disappeared. He also says he asked for a refund on the merchandise which was 2/3 paid in Italy which was refused.

> [!note]+ Procedural History and Posture
> USAO moves to dismiss on ground that it fails to list sufficient facts to constitute a cause of action [not named but is a 12(b)(6)]. Granted by court with leave to amend.
> 
> Pl files amended complaint, repeats allegation, and adds that these were medicinal extracts given to Springdale Distilling Company and that “It isn’t so easy to do away with two cases with 37 bottles of one quart. Being protected they can take this chance” and that Def tried to explain loss of two cases by saying they were leaked which could never be true based on how they were bottled.
> 
> Another motion to dismiss on same ground, complaint is again dismissed this time with prejudice.

- Issue: Should the second motion to amend be granted?

> [!note]+ Holding (Clark): Yes, on the basis of benefit of reasonable intendments
> - We no longer have the complicated code system, now all we need is a “short and plain statement with a claim for relief
> - The pleading might have been about theft, or negligence, or something.
> - “giving the plaintiff the benefit of reasonable intendments in his allegations as (we must on this motion)”
> - Disposition: Reversed
