---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Radiator Service Required
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1961
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gray v. American Radiator
Status: Annotated
Date: 1961-01-01
Jurisdiction: Illinois
---
> [!note]+ Facts
> Gray’s water heater explodes and hurts her (presumably in Illinois). She sues Titan and others. Against Titan she claims that it negligently constructed the safety valve that caused her injuries. Titan is a foreign corporation (i.e., not an Illinois based company). It has a registered agent in Ohio on whom process was served. Plaintiff, though, sues Titan in Illinois. Titan appears specially to say no jurisdiction.
> 
> Illinois statute says that “summons may be personally served upon a party outside the State; and that as to nonresidents who have submitted to the jurisdiction of our courts such service has the force and effect of personal service within Illinois…” and that “a nonresident who, either in person or through an agent, commits a tortious act within this State submits to jurisdiction.”

> [!note]+ Procedural History and Posture
> - Circuit court dismisses action for damages

- Issue: (1) whether a tortious act was committed here according to Illinois long-arm statute (2) whether the statute, if so construed, violates due process of law.

> [!note]+ Holding (Klingbiel): (1) Yes, and (2) No
> - Pennoyer Tests
>     - Domicile and Presence don’t apply to companies
>     - Consent and Agent: no, neither of them
> - What does “commits a tortious act within this State” mean?
>     - This could mean either the place of injury or the place of action…
>     - A similar body of law uses the time of injury (choice of law)
>     - Statute of limitations starts clock at injury
>     - Popularly understood sense, injury not separable from tortious act
>     - Administrability problem, other choice would be more expensive (very purposivist)
> - Types of argument about statutory interpretation at play.
> > intent should be determined less from technicalities of definition than from considerations of general purpose and effect
> 
> > test should be concerned more with those substantial elements of convenience and justice presumably contemplated by the legislature.
> - Disposition: Reversed

> [!note]+ Thoughts and Questions
> - Ways to interpret “commits a tortious act”
>     - If you interpret as injury, helps state protect citizens
>     - If you interpret as “last touch” of company, helps attract companies
>         - They can focus their legal efforts on their own jurisdiction














