---
base: "[[Test.base]]"
In-Text Citation: (Allen et al., 2022)
Priority: Recommended
Authors: |-
  Allen, Danielle
  Benkler, Yochai
  Downey, Leah
  Henderson, Rebecca
  Simons, Josh
Title: A Political Economy of Justice
Zotero URI: http://zotero.org/users/4316906/items/XH2X58AS
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Book
Rating: "***"
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=6915374
Full Citation: "Allen, D. et al. (2022) A Political Economy of Justice. Chicago, UNITED STATES: University of Chicago Press. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=6915374 (Accessed: 30 November 2022)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---

> [!note]+ Intro to the Volume
> - New framework for thinking about the economy and well-being
> - Multi-authored work, moving in a cycle of values, diagnosis, prescription, and action to generate iterative policymaking (Safra Seminar Process Circle)

Chapter 6: What’s Wrong with the Prison Industrial Complex?

> [!note]+ Definitions and Assumptions
> - Incarceration: involuntary confinement, enclosed space, hierarchical institutional practice, isolation, custody. Focus on punitive, not pre-trial incarceration. 
> - Capitalism: not inherently unjust, though existing capitalist practices are. 
> - Retribution: not a legitimate public function of incarceration

> [!note]+ The Problem
> - Theories abstract away from the concrete realities of imprisonment

> [!note]+ Davis’ Argument
> - Abolish the prison-industrial complex
> - Prison privatization is a scam
> - Source of the profits is tainted, and profit motivation undermines effective provision of public goods
> - Creates perverse incentives for things like recitivism and longerr prison terms

> [!note]+ Davis’ Flaws
> - The corruption involved in privatization could be perpetuated in public prisons, because both must depend on corrupt officials
> - Imposible/undesireable to prevent profit from suffering. Even ownership profit must be permissable in a not completely socialized country

> [!note]+ Non-Profit Solution
> - Enforcement could remain in the hands of the state (essentially police) while remaining functions done by non-profit employees (like universities and hospitals)
> - Maybe only non-violent prisoners, able to get funding to provide public goods from donation
> - Show how prisons can be justified in the existing, unjust world, under non-ideal conditions (ideally it would be the just state)
> - Don’t know if this is economically or politically feasible, but at least its morally defensible.














