---
base: "[[Test.base]]"
In-Text Citation: (Nickel, 2001)
Priority: Recommended
Authors: Nickel, Philip
Title: Moral Testimony and its Authority
Zotero URI: http://zotero.org/users/4316906/items/P7GYZDC9
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: A person sometimes forms moral beliefs by relying on another person's moral testimony. In this paper I advance a cognitivist normative account of this phenom enon. I argue that for a person's actions to be morally good, they must be based on a rec ognition of the moral reasons bearing on action. Morality requires people to act from an understanding of moral claims, and consequently to have an understanding of moral claims relevant to action. A person sometimes fails to meet this requirement when she relies on another person's moral testimony, and so there are moral limits on such reliance.
Type: Journal Article
Full Citation: Nickel, P. (2001) ‘Moral Testimony and its Authority’, p. 15.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2001
---
