---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Gas Meter Malice
Takeaway: Elemental, not Culpability Mens Rea (Malice is intent or recklessness, not “wickedness”)
Tags:
  - Mens Rea
Category:
  - Crim
Abstract: ""
Page: 163
Type: Case
Rating: "**"
Year: 1957
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Regina v. Cunningham
Status: Annotated
Date: 1957-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Soon to be married man steals gas meter from future mother-in-law’s basement
> - Gas seeps into neighbor’s house, partially asphyxiates
> - Law prohibits “unlawfully and maliciously administer” poison to cause harm

> [!note]+ Procedural History and Posture
> - Jury instruction defines “malicious” as wicked
> - Appealed

- Issue: Was jury instruction on “malicious” improper?

> [!note]+ Holding (Byrne): Yes
> - Maliciousness is either intention or recklessness
> - Disposition: Reversed





















