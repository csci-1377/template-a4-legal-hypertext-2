---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Further
Court: Supreme
Authors: ""
Title: Stateline Motorcycle Accident
Takeaway: When there is a “significant aggregation of contacts” can apply border state law for torts
Tags:
  - Horizontal Choice of Law
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1981
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Allstate v. Hague
Status: Annotated
Date: 1981-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Motorcyclist injured in Wis, but works in Minn (right on border)
> - Insurance policy covers uninsured collision
> - Collision with Minn residents

> [!note]+ Procedural History and Posture
> - Minn SC applies Minn law

- Issue: Did application of Minn law violate Const?

> [!note]+ Holding (Brennan): No
> - Niether Due Process nor Full Faith and Credit violated
> 
> > Minnesota had a <u>significant aggregation of contacts</u> with the parties and the occurrence, creating state interests, such that application of its law was neither arbitrary nor fundamentally unfair.