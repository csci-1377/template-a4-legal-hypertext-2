---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Near-beer
Takeaway: "Intermediate scrutiny for sex discrimination: substantially related to an important state interest"
Tags:
  - EPC
  - IS
Category:
  - Con Law
Abstract: ""
Page: 1343
Type: Case
Rating: "****"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Craig v. Boren
Status: Annotated
Date: 1976-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Near-beer (3.2%) min male age 21, female 18.
> - State claims this is in the interest of traffic safety.

- Issue: Does differential near-beer law violate EPC?

> [!note]+ Holding (Brennan): Yes
> > Providing bread sociological propositions by statistics is a dubious business.
> 
> - This distinction isn’t super relevant
>     - Males are only slightly more likely to drive drunk than females.
>     - This doesn’t really prevent young men from driving drunk effectively.
> - Disposition: 

> [!note]+ Concurrencet (Stevens): Yes, but under a balancing test
> - Eh, there is some evidence in favor of this.
> - But it’s just outweighed by the contrary interests.





















