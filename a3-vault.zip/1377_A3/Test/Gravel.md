---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Pentagon Papers
Takeaway: Court draws arbitrary line between legislative/non-legislative activities.
Tags:
  - SDC
  - PQ
  - NLP
Category:
  - Con Law
Abstract: ""
Page: 601
Type: Case
Rating: "**"
Year: 1972
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gravel v. United States
Status: Annotated
Date: 1972-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Nixon Administration enjoins NYT from publishing Pentagon Papers
> - Senator uses his own staff in a committee to publish the papers
> - Senator defends saying protected under the Speech and Debate Clause
>     - Congress is priveleged from arrest for any speech or debate on floor

- Issue: Is Senator’s publication of pentagon papers protected?

> [!note]+ Holding (White): No
> - This should clearly protect a Senator from speaking on the floor
> - Should also apply to staff because Senators rely on them so heavily
> - BUT we won’t protect publication in a private press
>     - This is weird. A lot of what senators do is talk to the public





















