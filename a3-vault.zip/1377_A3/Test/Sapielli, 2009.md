---
base: "[[Test.base]]"
In-Text Citation: (Sapielli, 2009)
Priority: Further
Authors: Sapielli, Andrew
Title: What to do when you don't know what to do
Zotero URI: http://zotero.org/users/4316906/items/LVGMZLEF
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Book Section
Rating: "***"
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=472377
Full Citation: "Sapielli, A. (2009) ‘What to do when you don’t know what to do’, in Oxford Studies in Metaethics: Volume Four. Oxford, UNITED KINGDOM: Oxford University Press. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=472377 (Accessed: 22 November 2022)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: In Progress
Year*: 2009
---
> [!note]+ Intro
> - Focus on practical comparatives: very few people are comparing moral theories
> - Externalism Problems: We can’t base our actions on the correct normative standards. We must guide our actions by our representations of the world, not the way it actually is.
> - He uses a belief-relative ‘should’
> - Can assess rationality globally or locally, based on all or only a sublset of mental states. 
> - He will focus on local rationality relative to degrees of belief in practical comparatives

> [!note]+ Maximise Expected Objective Value
> - Problem of value difference comparisons
> - But it seems to be the best we have














