---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Parking Garage Attendents
Takeaway: Valet is bailment, lot is license
Tags:
  - License
  - Bailment
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Allen v. Hyatt Regency-Nashville Hotel
Status: Annotated
Date: 1984-01-01
Jurisdiction: Tennessee
---
> [!note]+ Facts
> - P drives car into garage, taking ticket
> - Ticket says no responsibility for loss through fire, theft, collission, etc.
>     - BUT not called to attention of drivers
> - Tickets just given to measure time parked, not identify vehicles
>     - BUT taken by attendent upon leaving
>     - ALTHOUGH attendent sometimes not even there (can leave for free)
> - P returns, car is gone (never found)

> [!note]+ Procedural History and Posture
> - Trial and appellate both find implied bailment contracts

- Issue: Was there a bailment between driver and garage?

> [!note]+ Holding (Harbinson): Yes
> - Doesn’t exist in unattended open lot with coins in meter
> - Does exist in valet situation
> - Here is more like valet (enclosed, indoor, attended, security guard)
> - This was more than mere license of a space
> - Disposition: Affirmed

> [!note]+ Dissent (Drowota): No
> - Casheir was not performing role of bailee
> - Bailment needs knowing/voluntary assumption of sole custody and control (acceptance/delivery): Missing here
>     - No attendent actually took the car (couldn’t move, didn’t know where parked or who belonged to, nor how to reclaim)
>     - Ticket has some weight, if not dispositive
>     - Casheir isn’t even always on duty
