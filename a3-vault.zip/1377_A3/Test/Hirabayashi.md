---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Racist Curfew
Takeaway: Congress can delegate power to impose a “not racially discriminatory” curfew to the military
Tags:
  - 5A
  - Anticanon
  - NDD
  - WP
Category:
  - Con Law
Abstract: ""
Page: 318
Type: Case
Rating: "****"
Year: 1943
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hirabayashi v. United States
Status: Annotated
Date: 1943-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Executive Order 9066 authorized secretary of war to “prescribe military areas, from which any or all persons may be excluded”
> - Military commander imposes 8pm curfew for people of German and Japanese ancestry
> - Hirabayashi intentionally breaks curfew with support of ACLU, turns himself in to challenge the law.

- Issue: 1) Can Congress/Executive impose a curfew over some nationalities? 2) Can they delegate the power to a military commander?

> [!note]+ Holding (Stone): Yes and yes
> > The war power of the national government is ‘the power to wage war successfully’
> 
> - Alternative to this policy was a curfew for all or none
> - Japanese solidarity (in part because of racist laws) have prevented their assimilation with white people.
> - Congress and executive could “reasonably have concluded” that this was the right call. They only need a “rational basis”
> - Counter: This discrimination violates the 5th Amendment
>     - 5A has no EPC
>     - Racial discrimination is prohibited because it’s generally “irrelevant”
> - NDD doesn’t apply to delegation with respect to *war-like emergencies*





















