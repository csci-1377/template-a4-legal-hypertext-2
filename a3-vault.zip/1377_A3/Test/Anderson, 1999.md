---
base: "[[Test.base]]"
DOI: https://doi.org/10.1086/233897
In-Text Citation: (Anderson, 1999)
Priority: Recommended
Authors: Anderson, Elizabeth S.
Title: What Is the Point of Equality?
Zotero URI: https://zotero.org/bmcanally21/items/VYC8HDKQ
Takeaway: ""
Tags: []
Category:
  - Dissertation
  - Normative Analysis
Abstract: ""
Type: Journal Article
URL: https://0-www-journals-uchicago-edu.pugwash.lib.warwick.ac.uk/doi/abs/10.1086/233897
Full Citation: "Anderson, E.S. (1999) ‘What Is the Point of Equality?’, Ethics, 109(2), pp. 287–337. Available at: https://doi.org/10.1086/233897."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1999
---
