---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: "Eelskin Whip: Standing Order"
Takeaway: Silence and inaction can constitute acceptance in regular course of dealing
Tags:
  - Acceptance
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "**"
Year: 1893
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hobbs v. Massasoit Whip Co.
Status: Annotated
Date: 1893-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - P sells eelskins to D 4-5 times
> - P sends them again, D keeps them without returning or paying P
> - D claims they were unsuitable
> - P sues for breach

> [!note]+ Procedural History and Posture
> - Judge instructs jury that if skins are kept by defendant without saying anything to plaintiff, then jury should find for plaintiff.
> - Jury finds for plaintiff

- Issue: Can silence and inaction constitute acceptance?

> [!note]+ Holding (Homes): Yes, in standing orders
> - There was a contract created by their regular actions
> - It isn’t that someone can generally force purchase in absence of return, but that prior actions warrant assumption of standing order.
