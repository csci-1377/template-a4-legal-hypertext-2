---
base: "[[Test.base]]"
In-Text Citation: (Garman, 2009)
Priority: Essential
Authors: Garman, Rita
Title: "Deliberation, Deference, and Discretion: Reflections on Decision Making at the Trial, Appellate, and Supreme Court"
Zotero URI: http://zotero.org/users/4316906/items/IMHAY8DL
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.luc.edu/media/lucedu/law/students/publications/llj/pdfs/garman_deliberation.pdf
Full Citation: "Garman, R. (2009) ‘Deliberation, Deference, and Discretion: Reflections on Decision Making at the Trial, Appellate, and Supreme Court’, Loyola University Law Journal, 4, pp. xiii–xx."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Up Next
Year*: 2009
---
