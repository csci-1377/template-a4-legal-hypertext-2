---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Arresting Mail
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "****"
Year: 1868
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: U.S. v. Kirby
Status: Annotated
Date: 1868-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Law prohibits “knowingly and wilfully” obstructing or retarding passage of mail or mail carrier
> - Farris is a mail carrier on a steamboat
> - Kirby gets warrant for arrest, arrests with a posse “lawfully summoned”

- Issue: Did arrest constitute as obstruction of mail/carrier according to act?

> [!note]+ Holding (Field): No, that would be absurd
> - Knowing and wilful requires knowledge and intent to obstruct
> - Intent is imputed if the act is otherwise unlawful, not if lawful
> - Public servicemembers are exempt from civil process while in duties, but not criminal process
> - Clear Statement Rule for Absurdity:
> 
> > No intention ot extend such exemption should be attributed to Congress unless clearly manifested by its language. <u>All laws should receive a sensible construction</u>. General terms should be so limited in their application as not to lead to injustice, oppression, or an <u>absurd </u>consequence. It will always, therefore, be presumed that the legislature intended exceptions to its language, which would avoid results of this character. The reason of the law in such cases should prevail over the letter.
> 
> - Like Bolognian law that “whoever drew blood in the streets should be punished with the utmost severity”
