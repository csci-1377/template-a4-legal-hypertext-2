---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Party Wall Battle
Takeaway: Injunction even with disproportionate burden for intrusion (with equitable balance)
Tags:
  - Trespass
  - Encroachment
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1895
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pile v. Pedrick
Status: Annotated
Date: 1895-01-01
Jurisdiction: Pennsylvania
---
> [!note]+ Facts
> - Foundation wall encroaches on neighbor’s property (that also has a building) by 1-2 inches
> - Pedrick has windows and Pile wants them removed. Pedrick agrees only if/when Pile builds up to that height
> - Plaintiff wants an injunction and doesn’t grant permission for defendants to enter their land to remove
> - …So defendants need to tear the whole wall and part of the building down.

- Issue: Are injunctions appropriate even when causing disproportionate burden?

> [!note]+ Holding: Yes, thery are
> - Unintentional intrustion here, so hard q (if intentional, it’s easy)
> - We can compensate for damages or compell them to remove
> - We’ll compell to remove, but they both have to pay equally for the removal (disincentive)
> - Potentially a duty-to-mitigate-like thing going on here. Pedrick could have removed the windows, but didn’t.