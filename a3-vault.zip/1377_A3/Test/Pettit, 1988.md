---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/2220266
In-Text Citation: (Pettit, 1988)
Priority: Recommended
Authors: Pettit, Philip
Title: The Consequentialist Can Recognise Rights
Zotero URI: http://zotero.org/users/4316906/items/C3IZUSR4
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://academic.oup.com/pq/article-lookup/doi/10.2307/2220266
Full Citation: "Pettit, P. (1988) ‘The Consequentialist Can Recognise Rights’, The Philosophical Quarterly, 38(150), p. 42. Available at: https://doi.org/10.2307/2220266."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1988
---
> [!note]+ The Nature of Consequentialism
> - Every possible state has an objective value
> - Right option maximizes probable value of consequences
> - We should apply this reasoning when making decisions

> [!note]+ Variations
> 1. Agent-relative consequentialism: people ought to maximize perceived, incomensurable good
> 2. Restricted consequentialism: right rules optimize, right acts conform to rules, do not necessarily optimize
> 3. Restrictive consequentialism: agent neutral, unrestricted, but optimific act might only be accessible with a contrained mode of deliberation

> [!note]+ Rights
> - Considerations others are expected to take into account in dealing with someone
> - 5 P’s: promotional, protective, personalized, privileged, precise
> - Promotional: guarantee consideration in deliberations
> - Protective: guarantee treatment in actions
>     - Personalized: untradable across persons
>         - Complete priority over goal of increasing non-violation generally
>     - Priveleged: complete priority over some other goods
>         - Compatibile with X seeming partial priority to degree K over another goal G
>             - Define X up to K as benign, or BX
>             - That has complete priority over G
>             - So, the complete priority right is to BX?
>     - Precise: not just to some X, but *this* X

> [!note]+ Respecting Rights
> - Must more than just happen to respect
>     1. Not just endorsing institutions that restrict actions
>         1. This would have no moral force for the agent
>     2. Must respect because it is a right, not just incidentally
>     3. (NOT) not just contraints, but criteria of evaluation
>         2. Inherently anti-cosequentialist

> [!note]+ Self-defeating reasoning
> - Examples
>     - Seeking pleasure (incidental)
>     - Spontenaity (fundamental)
> - Elusive and vulnerable forms

> [!note]+ The Argument
> - **Assume rights-holder knows your reasoning form **
>     - Personal: “Every hesitation and reservation will give the game away”
>     - Public: deliberations public knowledge
>     - Generally: risk of exposure will make rarely optimal
>     - Reputation: single infringement will prevent from ever furthering dignity
> - Dignity (or dominion) is calculatively elusive and vulnerable
> - The consequentialist will have reason to impose rights restriction

> [!note]+ Definitions
> - Dignity: preserving dominion over how one fares at others’ hands, not being a pawn in the enterprises of the other