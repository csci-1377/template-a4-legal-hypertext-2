---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: We Don’t Like Lottery Tickets
Takeaway: If a thing crosses state lines, Congress can criminalize it
Tags:
  - CC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "**"
Year: 1903
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Date: 1903-01-01
Jurisdiction: United States
---
