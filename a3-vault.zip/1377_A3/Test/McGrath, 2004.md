---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1520-8583.2004.00026.x
In-Text Citation: (McGrath, 2004)
Priority: Essential
Authors: McGrath, Sarah
Title: Moral Knowledge by Perception
Zotero URI: http://zotero.org/users/4316906/items/5RR59RGS
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://onlinelibrary.wiley.com/doi/10.1111/j.1520-8583.2004.00026.x
Full Citation: "McGrath, S. (2004) ‘Moral Knowledge by Perception 1’, Philosophical Perspectives, 18(1), pp. 209–228. Available at: https://doi.org/10.1111/j.1520-8583.2004.00026.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2004
---
- Q1- *Assuming* that we have moral knowledge, how do we have it?
    - Harman: we know moral hypotheses by inference to the best explanation of our moral judgements
        - No, they might explain the judgements, but that isn’t *why* we know
        - I don’t know a snowball is white because it explains my judgement of whiteness
    - Thompson: we know moral hypotheses by inferring them from the non-moral observations that metaphysically necessitate those moral hypotheses.
        - No, because we can’t move from the necesary to the sufficient. We would need an additional conditional premise.
        - And it doesn’t make sense for the conditional premise to be a priori, because it would need to take into account so many factors
            - **This is about the context dependency of knowledge**
    - This can’t be everything, because it doesn’t explain moral knowledge about particular cases
        - Some must be from perception (higher order perception)
        - Like knowing that wine has hints of oak, though this seems obviously true and is compatible with inferrential knowledge
    - **Instead of making an inference by the best possible explanation, it is fitting into by the best story**
    - Bob and Chuck relationship. Can someone perceive that their relationship is good without inference?
    - Perception doesn’t always lead to knowledge, but it sometimes does
- Q2- Do we in fact have any moral knowledge?
    - Yeah, so long as we put the hard questions to the side it makes perfect sense!