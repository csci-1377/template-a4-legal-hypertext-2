---
base: "[[Test.base]]"
In-Text Citation: (E.D.N.Y, 2010)
Priority: Essential
Court: District
Authors: E.D.N.Y
Title: Skydiving with Nail Polish
Zotero URI: http://zotero.org/users/4316906/items/ZNGDMDJU
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 2010
Full Citation: E.D.N.Y (2010) ‘Zarda v. Altitude Express’.
Last edited: 2026-02-15T22:06:00
Full: Zarda v. Altitude Express
Status: Annotated
Date: 2010-01-01
Year*: 2010
Jurisdiction: E.D.N.Y
---
1. Where would I find the elements of the Complaint that are required in Federal Rule of Civil Procedure 8(a) in this Complaint? 
> [!note]+ **(a) Claim for Relief.** A pleading that states a claim for relief must contain:
> (1) a short and plain statement of the grounds for the court's jurisdiction, unless the court already has jurisdiction and the claim needs no new jurisdictional support; (6)
> 
> (2) a short and plain statement of the claim showing that the pleader is entitled to relief; and (7-33 Rambling, unfocused, also the law 33-54)
> 
> (3) a demand for the relief sought, which may include relief in the alternative or different types of relief. (End, just shotgun)

> [!note]+ **(d) Pleading to Be Concise and Direct; Alternative Statements; Inconsistency.**
> (1) In General. Each allegation must be **simple, concise, and direct.** No technical form is required.
> 
> (2) Alternative Statements of a Claim or Defense. A party may set out 2 or more statements of a claim or defense alternatively or hypothetically, either in a single count or defense or in separate ones. If a party makes alternative statements, the pleading is sufficient if any one of them is sufficient.
> 
> (3) Inconsistent Claims or Defenses. A party may state as many separate claims or defenses as it has, regardless of consistency.

    - **(e) Construing Pleadings.** Pleadings must be construed so as to do justice. (Hmmm…)
2. What is the basic story being told in the Complaint?
    1. That the plaintiff was discriminated against on the basis of sexual orientation, and ultimately let go for that reason
3. How effectively does the Complaint achieve what you perceive to be its goals?
    - Not that well. 
        - Unrelated commentary, character digs, typos (31?)
        - Simple assertion of violations unconnected to facts (35, 39)
        - Demands compensatory damages in excess of court limit?
