---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: KKK Voter Beating
Takeaway: Can punish state and private officials for voter intimidation
Tags:
  - ELC
  - NPC
Category:
  - Con Law
Abstract: ""
Page: 569
Type: Case
Rating: "***"
Year: 1884
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ex Parte Yarborough
Status: Annotated
Date: 1884-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Despite the Court’s hostility to Reconstruction-era legislation, prosecutors persisted in prosecuting members of the KKK for violating the various enforcement acts. Rather than justify the prosecutions under the Fifteenth Amendment, however, which had been foreclosed in *Harris*, they turned to Art. I § 4. Yarborough and seven others were KKK members who intimidated Berry Saunders, a Black man, from voting in a Congressional election in GA, and beat, bruised, and wounded him. The men were convicted of violating various federal laws and brought a habeas petition challenging their confinement.

> [!note]+ Procedural History and Posture
> - 

- Issue: Can A1S4 prosecute election intimidation?

> [!note]+ Holding (Miller): Yes. 
> - Congress has the power, under Art. I § 4, to ensure that federal elections are free from the influence of “violence, of corruption, and of fraud.” If in so doing Congress also regulates a state election, this is okay. 
> - Yarbrough’s argument: The* Civil Rights Cases* clearly state that 14A only reaches state action. Also, when we assaulted these black people to keep them from voting, it was only that we didn’t want them to vote in the presidential election, not the congressional election. Look at the text of Art. I § 4 -- it only applies to elections for Congress.
> - Court disagrees – says Court must have an implied power via the NPC to punish interference with elections. It has to exist. Look at these enumerated powers broadly; Congress isn’t just allowed to tax; it can also create tax collectors/penalties etc. Here, Congress has the power to make T/P/M regulations, so via the NPC it is definitely allowed to create criminal penalties for election interference.
> - Is the right to vote in the Constitution? Yes, implicitly. The right to vote is implied by the text of the Constitution itself. It doesn’t derive from Art. I § 4, but rather Art. I § 2, which creates the House of Representatives and says it “shall be chosen by the people of the several states.”
> - Limits? Not really, according to the Court. Congress can set election regulations, campaign finance laws, etc. Congress can also punish **state** **officials** – and **private citizens** – for failing to comply with federal election regulations.





















