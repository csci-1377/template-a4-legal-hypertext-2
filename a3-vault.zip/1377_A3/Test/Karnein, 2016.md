---
base: "[[Test.base]]"
In-Text Citation: (Karnein, 2016)
Priority: Essential
Authors: Karnein, Anja
Title: Can we Represent Future Generations?
Zotero URI: http://zotero.org/users/4316906/items/6UD6E2BH
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: Is it possible to ‘represent’ future generations in any meaningful sense of the term, given that future generations do not currently exist and thus have no way of selecting representatives or validating their work? This chapter shows that, despite a number of formidable obstacles, something approximating representation may indeed be both feasible and desirable. The chapter proceeds in three steps. First, it spells out the various difficulties and the danger involved in institutionalizing representatives for future generations. Second, it examines newer literature on representation for ways to respond to these difficulties. Since none of the available proposals helps overcome the inherent problems of intergenerational representation, the chapter, third, continues with a suggestion for how to modify a ‘new’ form of representation, namely surrogate representation, to approximate what it would take to give future generations a voice while trying to avoid the inherent danger of doing so.
Type: Book Section
Rating: "***"
URL: https://doi.org/10.1093/acprof:oso/9780198746959.003.0005
Full Citation: "Karnein, A. (2016) ‘Can we Represent Future Generations?’, in I. González-Ricoy and A. Gosseries (eds) Institutions For Future Generations. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/acprof:oso/9780198746959.003.0005."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2016
---
> [!note]+ Intro
> - Not going to focus on where representatives should be or the powers they should have
> - Representation
>     - Formal: authorization and accountability
>     - Substantive: correspondence between 
>         - representatives and their actions 
>         - constituents and their interests/desires

> [!note]+ Difficulties and Dangers
> - Authorization: they can’t elect them
> - Accountability: they can’t vote them out
> - Assymetry: they can’t do anything that affects us
> - Epistemic: we don’t know what they want or how what we do affects them
> - Plurality: they might not agree about what we should do
> - Incenserity: they might just be self-interested and undermine us

> [!note]+ Proposed Solutions
> - Andrew Rehfield: General Theory of Representation
>     - About audience perception, whatever they think
>     - …But maybe they can’t just be entirely arbitrary?
> - Jane Mansbridge: Surrogate Representation
>     - Elected legistlators who represent some group because of a characteristic they have
> - Michal Saward
>     - Include nelected agents who don’t share characteristics (Bono speaking for the poor)
>     - But have to receive validation from proto-consituency at some point (impossible for future)

> [!note]+ Her Solution
> - Judge representatives by 
>     - Principles upon which they make decisions
>     - Procedural mechanisms by which they interpret what the principles mean
> - Have to justify our decisions to the future as if they were present today
> - Levels of representation
>     1. Have formal representatives including novelists, social scientists, and randomly selected citizens
>     2. All those encouraged to consider future generations. 
> - Right now we need the first level to ensure interests are included, but eventually this would be superfluous as interest becomes mainstreamed
> - **So as these representatives become reasonably possible, they become unnecessary**

> [!note]+ Conclusion full text: grapple with this
> This chapter has suggested that there are ways to approximate what it would mean to ‘represent’ future generations that reduce the impact of both the di culties and the danger inherent in any such endeavour. It has proposed that we can do this by sincerely asking which of our policies could be reasonably accepted by future generations if they were present today. This rather formal focus is intended to rule out certain forms of reckless and negligent behaviour towards the future, but it leaves most substantial questions unresolved. These questions would have to be publicly debated by deliberative bodies or assemblies consisting of a variety of people who, from many di erent perspectives, sincerely imagine and deliberate about what future generations’ interests might be and how they may be a ected by our behaviour. One important goal of such deliberations would be to eventually mainstream equal consideration of future generations into the general public discussion. Not only is this morally appropriate (requiring each of us take our intergenerational duties seriously), but having a larger group discuss these issues will also reduce the epistemic di culty to its inevitable core, address the problem of plurality, and provide some protection against the potential danger of using future interests as excuses to further particular agendas of the presently living.














