---
base: "[[Test.base]]"
In-Text Citation: (Wendel, 2024)
Authors: Wendel, W. Bradley
Title: "Philosophical Perspective: The Challenge of Role Morality"
Zotero URI: https://zotero.org/bmcanally21/items/QCUBHDCM
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: The deep structure underlying the criticism of lawyers in moral terms is known as the problem of role-differentiated morality. Lawyers claim to have distinctive obligations and permissions that follow from their professional role. However, without the right kind of relationship between these role-specific duties and the concerns of background “ordinary folks” morality, a profession risks losing legitimacy in the eyes of the society it is intended to serve. For example, it is possible to give too much or too little weight to a professional role. Role morality must always confront the “Eichmann problem”—that is, it is no defense to moral culpability that one was just following orders or being obedient to an authority. Paying attention to the personal dimension of acting in a professional role can help avoid the Eichmann problem.
Type: Book Section
URL: https://doi.org/10.1093/oso/9780197673423.003.0006
Full Citation: "Wendel, W.B. (2024) ‘Philosophical Perspective: The Challenge of Role Morality’, in W.B. Wendel (ed.) Canceling Lawyers: Case Studies of Accountability, Toleration, and Regret. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/oso/9780197673423.003.0006."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> The role is not sealed off from ordinary morality, however. 164.

> Once someone has taken on a professional role, the question, “What should I do in this situation?” should be answered from an insider’s perspective, so to speak. 164. 

> There are certain recurring mistakes that professionals and their critics make regarding the relationship between roles and ordinary morality. The first mistake is to see the role as <u>swallowing up background moral concerns</u>. In its extreme form this is the thoroughly discredited Nuremberg defense of “just following orders,” but a more attractive version of the mistake arises from excessive devotion or attachment to what are genuinely valuable objectives. The second mistake is the converse. It is giving <u>too little weight to the responsibilities of one’s role</u>, such that one acts directly on background moral reasons instead of carrying the obligations of an institutional role, including a public office. The third mistake is a subtle but important one. It comes from <u>giving oneself over entirely to a social role</u>, which results in “bleaching out” one’s personal commitments, relationships, and values.22 Much of the debate in theoretical legal ethics ultimately comes down to the question of the right way to understand the relationship between the roles and background morality. 167. 

> In all of these cases, there are ample grounds, internal to the rules of the game (to use Curtis’s metaphor), for regarding these lawyers as wrongdoers. 179. 

> [Why not “weight”] a simple, quantitative comparison is impossible between disparate ideas like national security and individual rights.  The second concern is that many genuine professional obligations would disappear if we truly engaged in case-by-case balancing of good and bad consequences. 182.