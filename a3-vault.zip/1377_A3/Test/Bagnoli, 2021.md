---
base: "[[Test.base]]"
In-Text Citation: (Bagnoli, 2021)
Priority: Further
Authors: Bagnoli, Carla
Title: Constructivism in Metaethics
Zotero URI: https://zotero.org/bmcanally21/items/XVLFL5EZ
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Document
Rating: "****"
URL: https://plato.stanford.edu/archives/spr2021/entries/constructivism-metaethics/
Full Citation: "Bagnoli, C. (2021) Constructivism in Metaethics, The Stanford Encyclopedia of Philosophy. Available at: https://plato.stanford.edu/archives/spr2021/entries/constructivism-metaethics/ (Accessed: 3 May 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2011
---
> [!note]+ Definition
> - Normative truths are not independent of what rational agents would agree to under idealized conditions a
> - constructivists think that normative concepts, which are deployed in judgments that can be true or false, have a practical function: they name solutions to practical problems, rather than represent features of reality (Korsgaard 2008: 302 ff.).

> [!note]+ Motivation
> - The need for objectivity is practical
> - Alternative to realism and antirealism (subjectivism and relativism)
> - A better way to present what constructivism purports to offer is to say that it claims to be the best candidate for reconciling various tensions among the apparent features of normative truths: their objectivity, our knowledge of them, and their practical significance for us, including the authority they have or claim (Scanlon 2014: 91).
> 
> > For the constructivist, there is an interesting continuity between normative discourse and metaethics.

> [!note]+ Realism
> - Agents are passive recipients of objective values existing prior to, and independently of, our reasoning
> - Fail to show their authority on us as agents, since we would need a desire to be guided by them.
> 
> different definitions of ‘realism’ (e.g., Sayre-McCord 2015; Joyce 2015; Miller 2014). Realists agree that 
> 
> - (a) moral discourse is cognitivist like non-moral discourse, 
> - (b) there are moral properties, such as rightness, 
> - (c) moral properties are sometimes instantiated, and 
> - (d) moral predicates express properties. 
> 
> But there is a disagreement as to whether in order to be a form of realism, a theory must hold a stronger claim that 
> 
> - (e) moral properties are mind-independent. A further division, internal to realism, concerns the commitment to naturalism, which includes the claims that 
>     - (f) moral properties are like any ordinary property and have the same metaphysical status as non-moral properties, whatever that is, and that 
>     - (g) moral assertions express ordinary beliefs regarding the instantiation of these properties. 
> All constructivists share a commitment to naturalism, but reject (e), holding that the instantiation of properties depend on features of our sensibility or rational agency, rather than being mind-independent. In general, constructivism shares with both realist naturalism and antirealism broadly defined the commitment to metaphysical parsimony. This is where it differs from classical and “robust” moral realism (Enoch 2011a).

> [!note]+ Kantian
> - Based on the features of rational agency
> - Reasons for being moral do not spring from interests or desires, but rooted in our nature as rational agents
> - Skepticism about authority of morality only avoided if reasoning is autonomous. Otherwise, there is no response to the question why be moral
> 
> > Reason is autonomous if its authority rests on its proper activity, rather than being derived from elements in the world outside of reason
> 
> - Reason is a ‘self-legislative activity’ (Kant G 4: S2)
> - So the question is, what is the proper activity?
> - Problem is that it assumes we undertake this alone. Deliberating is interpersonal, or we simulate interpersonality
> - Kant develops “not only a constructivist conception of practical reason, but a coherentist account of its authentication” (Rawls 1999: 524; Rawls 2000: 268–273).
> - Also, assumes that value of humanity is the condition of the possibility of all valuing, seemingly realist foundations
> 
> > Standards of reasoning are justified by their function, must be followable by others “it must exhibit patterns that others could discern, and thus it must be law-like” (O’Neill 2015: 4).
> 
> - Fails to account for special bonds and ties we have (Williams, 1981: ch 1 and 2)
> 
> > Korsgaard argues that valuing humanity, where humanity is understood as the capacity for rationality, is the condition of the possibility of valuing anything at all (Korsgaard 1996a: 121–123; Korsgaard 1998: 60–62)
> 
> - Kantian constructivists insist that universal principles of reason are revealed using rational powers.
> - Only by conforming to universal principles do we act as agents
>     - **But why is it this, and not the activity of relating to others?**

> [!note]+ Procedural Realism
> > There are answers to moral questions because there are correct procedures for arriving at them, rather than because there are moral facts independently of those procedures, which those procedures track (Korsgaard 1996a: 36–37, see also Korsgaard 1983: 183)

> [!note]+ Humean
> > Abandon the claim that moral obligations are requirements of practical reason (Street 2012, Velleman 2009: 150-154; Lenman 2010:192
> 
> > Humeans maintain that an ideally coherent Caligula who values torturing people for fun is conceivable. Such a person would have reasons for torturing people, which is just to say that the value of humanity is not a constitutive norm of reasoning (Street 2010: 371; Street 2009, 2012)
> 
> diagnoses of a fictional Caligula whose state of mind is completely coherent but who values torturing people for fun (Street 2010: 371).
> 
> > Street argues that “the substantive content of a given agent’s reasons is a function of his or her particular, contingently given, evaluative starting points” (Street 2010, see also Lenman 2010: 180–181). Consequently, “truth and falsity in the normative domain must always be relativized to a particular practical point of view” (Street 2008a: 224).
> 
> If the constitutive principles of rational agency are logical consistency, or even complete coherence, they are still compatible with the Caligula problem. To get something like respect for others, you need the process to be interpersonal
> 
> The simulation of internal reason is only reliable when it is properly attuned by engaging in the interpersonal process.

> [!note]+ Aristotelian
> - Principles of reason aren’r formal or procedural, but grounded in account of the good life
> - Denies law-like universality, allowing adaption to particular cases.
> - Focuses on transforming our sensibilities into character

> [!note]+ Contractualism
> > Most constructivists about morality hold that the relevant sort of agreement of which moral reasons are the product is best captured in terms of a hypothetical contract (Scanlon 1998; Hill 1989, 2001; Milo 1995).
> 
> > Scanlon’s method of construction is the contractualist formula according to which an act is wrong if its performance under the circumstances would be prohibited by any set of principles that no one could reasonably reject as a basis for informed, unforced, general agreement.
> 
> - The problem is that the process requires and generates a mutual understanding such that the independence of contract is no longer appropriate

> [!note]+ Progress
> - Continuous, progressive, and reflexive process, accounting for development, change, and progress through historical and dialectical dimensions
> - Virtuous circularity
>     - **Or is it a spiral?**
> - (O’Neill 1999: 174, 2002), (O’Neill 1989b: 70–71; Arruda 2016).

> [!note]+ Reliance on Realism
> Kantian constructivism appears to be grounded on the value of moral impartiality, which demands equal respect for persons (Scanlon 1998: 22–33; 287–290; Rawls 1993: 38–54). The worry is that, in the final analysis, constructivism is vacuous because “its test yields results only by presupposing moral views which can only be established independently of it”

> [!note]+ Thoughts
> - If I describe agency as fundamentally interpersonal (go back to Anderson and the straitjacket) I can talk about why innerpersonal coherence is insufficent.
> - Distinction between rationality and agency.
> - Emphasis is inconsistently focused on the cooperative nature of standards of reasoning
> - Humans are self-reflective, capable of viewing ourselves from a detached perspective, but this does not mean a view from nowhere. Is it reflection or interaction that makes room for questions about what to do or believe? 
> - Obsession with principles. They guarantee integrity?
> - For there to be norms, it must be possible to break them. Is it possible to break the norms of interpersonal reasoning while remaining an agent? Yes, if you fail to see your activity as interpersonal reasoning (adopting the It)

> [!note]+ Further Reading
> Constructivists hold that practical reason itself is constructed in the sense that its legitimacy and authority are established by reasoning, rather than by appeal to some facts about the way the world is (O’Neill 1989b; Rawls 2000: 238; O’Neill 2015; Bagnoli 2013b).
> 
> we should rely only on those principles that other rational agents can share. The authority of reason is thus conferred by public communication among free, rational agents, and consists in the fact that the principles that govern our thoughts are neither self-serving nor self-defeating. We find out what these principles say by submitting our claims to free and critical debates, which constitute “the public use of reason” (O’Neill 1989b: 70–71, 206).
> 
> Hegelian variety (Westphal 2013; Rockmore 2016; Laitinen 2016,














