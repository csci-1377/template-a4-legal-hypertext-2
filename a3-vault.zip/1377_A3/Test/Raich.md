---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Weed Bust
Takeaway: Congress can regulate marijuana for personal consumption (example of “economic or commercial”)
Tags:
  - CC
  - NPC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "**"
Year: 2005
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gonzalez v. Raich
Status: Annotated
Date: 2005-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Raich with Monson grows MJ for personal use (legal in CA)
> - Feds raid and destroy plants
> - They sue AG Gonzalez

- Issue: Can Congress regulate marijuana for personal consumption?

> [!note]+ Holding (Stevens): Yes
> - Defer to Congress (rational basis)
> - Distinguish [[Lopez]]: There whole activity regulated (guns in schools) impermissable
> - Here it’s just a particular instance, part of class of activities appropriately regulated

> [!note]+ Concurrence (Scalia): Yes
> - Noneconomic activity may be regulated as an essential part of more general regulation of interstate commerce if “reasonably adapted” (NPC)