---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Chancery
Authors: ""
Title: Leicester Square
Takeaway: Enforce negative covenant in equity
Tags:
  - Covenants
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1848
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Tulk v. Moxhay
Status: Annotated
Date: 1848-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Tulk conveys to Elms with covenants
> - Elms conveys to Moxhay without them
> - Moxhay knows about prior covenants

- Issue: Is the negative covenant enforceable?

> [!note]+ Holding: Yes, otherwise it would be inequitable
> > Nothing would be more inequitable than that the original purchaser should be able to sell the property the next day for a greater price, in consideration of the assignee being allowed to escape from the liability which he had himself undertaken.