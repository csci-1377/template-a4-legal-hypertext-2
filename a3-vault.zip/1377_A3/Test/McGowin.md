---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Sacrificial Bargain
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1935
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Webb v. McGowin
Status: Annotated
Date: 1935-01-01
Jurisdiction: Alabama
---
> [!note]+ Facts
> - Both working at lumber mill
> - Webb was permanently injured in attempt to save McGowin
> - McGowin agrees to pay Webb $15 for the rest of his life
> - He dies, and his estate refuses to keep paying
> - Webb sues

- Issue: Is this contract enforceable?

> [!note]+ Holding: Enforceable, moral obligation constitutes consideration
> - Invents consideration from benefit followed by promise (fictional, equity at play)
> - Gifts aren’t enforceable, but this is different. A benefit was given and some of it accepted, and that helps get to consideration?
