---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Any Reasonable Hypothesis (Circumstantial Evidence)
Takeaway: "(now rejected) placing burden of reasonable theory on defendant "
Tags:
  - Burden of Proof
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "****"
Year: 1992
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Owens v. State
Status: Annotated
Date: 1992-01-01
Jurisdiction: Maryland
---
> [!note]+ Facts
> - Call about “suspicious vehicle”
> - Cops come, find man in car with beer cans, passed out
> - He seems very drunk, refuses blood test
> - Alcohol restriction on his license
> - Arrested and convicted by judge of drunk driving

> [!note]+ Procedural Posture
> - Trial court finds guilty in bench trial
> - Post conviction appeal

- Issue: When is circumstantial evidence alone enough to convict?

> [!note]+ Holding: When there is no reasonable hypothesis of innocence
> - Defense only establishes on private driveway, so not breaking any law to be drunk and driving there.
> - He was either driving there drunk or about to drive away drunk
> - On their own, equally likely (look for a tiebreaker)
> - Not a reasonable hypothesis that he would leave home, get in the car, get drunk, and stay there.
> - Totality of the circumstances are inconsistent with a “reasonable hypothesis of innocence”















