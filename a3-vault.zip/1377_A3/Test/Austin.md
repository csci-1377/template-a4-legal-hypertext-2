---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Radar Part Extortion
Takeaway: Economic duress makes contract violable
Tags:
  - Duress
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1971
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Austin Instrument Inc. v. Loral Corp
Status: Annotated
Date: 1971-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - D makes radars under gov contract
> - P subcontracts to make parts
> - D asks for more parts on a time crunch, offering P contract only for extra parts which are cheaper than competitors
> - P demands contract for all extra parts and price increase on first order upon threat of non-delivery
> - D tries to find alternatives but can’t, agrees to price increase with P

> [!note]+ Procedural History and Posture
> - TC: finds for P, dismisses D counterclaim
>     - D could not show that it couldn’t have supplied from other sources
> - Appeals: Affirms

- Issue: Was contract violable by duress?

> [!note]+ Holding (Fuld): Yes
> - Duress Definition
> > A contract is voidable on the ground of duress when it is established that the party making the claim was forced to agree to it by means of a wrongful threat precluding the exercise of his free will.
> - P and D agree on law, factual dispute
>     1. Was there a threat to withhold goods? Yes
>         1. And this was a real threat: D is gov contracter, needed staggered deliveries
>     2. Could D have gotten goods elsewhere? No
>         - P- D didn’t show couldn’t have gotten goods elsewhere
>         - D- Yeah I did. All ten others on list couldn’t do it in time
> - D is right. Increased price was coerced
> - P- But even so, barred by laches
> - D- No, waited because worried deliveries would stop
> - Disposition: Reversed

> [!note]+ Dissent (Bergan): Not for us to decide
> - This is factual dispute, for TC not us (P arg)