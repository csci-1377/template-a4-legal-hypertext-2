---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: Runciman, David
Title: History of Ideas
Takeaway: ""
Tags: []
Category:
  - Politics
  - History
Abstract: ""
Type: Podcast
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2020
---
# Hobbes

He was not a social contract theorist. For them, there are two stages: first an agreement to become a society, then an agreement to form a government. If that is true, then the society has a contract with the sovereign: it can set terms.

For Hobbes, there can’t be two stages, because then the sovereign isn’t truly sovereign. It is limited by an agreement with the society it represents. Instead, there cannot be a society without a government. Nothing can bind people but the agreement on a decision maker (how about a shared story?). So, the agreement is among the multitude to choose a decision-maker that will choose for them to avoid the war of all against all.

Was trying to find the limits of reason by creating a reasonable foundation to leave most of life to the passions.

# **Wollstonecraft**

Wrote during the French Revolution, traveling there as an English woman to live it.

Thought of the relationship between the sexes as emblematic of the fundamental relation of politics: between reason and feeling.

Distinguished men and women not by their ability in the respective domains, but in the way they are expected to express themselves. Men are taught to dress their feelings as reasonable, women to treat their reasons as mere feelings.

# **Constant**

On the freedoms of the ancients and the moderns

Modern freedom is

- Individual
- Commercial
- Private

Ancient freedom was

- Collective
- Martial
- Public

Part of the problem is that the idea of ancient freedom is so attractive, and modern freedom feels inadequate by comparison. And ancient freedom is essentially impossible now (Ancient freedom only works in small states and requires that we give up things we can’t do without anymore like privacy).

The danger of the modern state is twofold: that we abandon modern liberty because we long for that of the ancients and get neither, and that we settle for purely modern liberty because it is comfortable, thinking we can distance ourselves from politics. You can’t fall for the illusion that politics will just go away if you ignore it. You can never be secure in your modern freedom if you only live the life of a modern.

So the only way to live in the modern world is to combine them: to be left alone requires participation. If you drift away, politics will catch up with you. He says you have to read the newspaper, join clubs and parties, etc.

# **Tocqueville**

Two dangers of democracy, both by tyranny of the majority:

- Populism, or the wild mob rule of riots
- Devolving into the conformity of stagnation

They can feed off each other, because there is some conformity in populism.

Worried that Americans didn’t view their experiment as such because they believed it couldn’t fail because of Providence.

# Gandhi

You can’t separate the means and the ends: the means will always contaminate the ends.

Spiritual approach, holistic in incorporating personal and cosmic, natural and artificial.

Some say he was above politics, but his movement was quintessentially political.

# Weber

State is the institution that successfully claims a monopoly on legitimate violence

# Arendt

Hannah Arendt human condition look at action as story

She is worried about what happens when work becomes cyclical and consumptive

Human creativity through language and storytelling (action) shouldn’t be reduced to work (mechanical creation)

Hannah Arendt wanted to return to a human scale where we can tell stories. But we can tell stories at any scale. We imagine persons.

Action is the space of natality, and have to emancipate ourselves from the cold, calculation of Hobbesian rationalism

She is wrong because he didn’t think we were just machines, he thought we could make an artificial person of the state.

Maybe this is a bad person, who will tell bad stories and side with the other machines. But maybe it is an instrument that we have to fight the machines.

# **Shklar**

Trouble with systems is that they attempt to control too much, to put people into a calculation in order to help or save them that doesn’t end up treating them as fully human, that instrumentalizes them by making their interests means rather than taking them on their own terms. It has an indifference to human beings.

Neitzsche hates hypocrisy more than cruelty, not a misanthrope but thought there was a danger in rejecting who we really are. So it’s better to accept cruelty than to be the Christian hypocrite.

When you dress up contingent choices as matters of principle, you always get blind spots.

The push for transparency is one of the most self-defeating crusades. The demand for greater openness will not lead to a more open society, for everyone, perhaps especially politicians, need to have their own private clubs in secret places. Instead, it will lead to even deeper places and darker secrets.

It is also self-defeating because it will, ultimately, lead to even more hypocrisy. This is because in demanding our public figures to be completely open, honest, and consistent, we demand that they adhere to standards that we ourselves cannot live up to. In rooting out hypocrisy, we make ourselves hypocrites.

Donald Trump was a cruel politician, he was not a hypocrite. He exploited the hatred and suspicion of hypocrisy and defended himself from it by being open about his cruelty.

When we become too preoccupied with the lesser ordinary vices, we lose sight of cruelty.

Twitter is the ultimate anti-cruelty machine that lets in cruelty through the back door. It is full of hypocrisy and perhaps more snobbery than at any other time in history, and the trails occur on a regular basis, but at the same time it is fanatically focused on anti-cruelty.

We should be more tolerant of the other ordinary vices. Not accepting, but tolerant. And focus on institutional hypocrisy over individual hypocrisy. It is less self-defeating and makes sense as a political target.

Ultimately it’s about character, not rules. Be willing to live a double life of a citizen. Be in your tower, then be in the world