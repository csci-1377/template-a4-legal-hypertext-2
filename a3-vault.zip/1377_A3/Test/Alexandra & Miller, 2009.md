---
base: "[[Test.base]]"
DOI: https://doi.org/10.1007/s11017-009-9097-1
In-Text Citation: (Alexandra and Miller, 2009)
Authors: |-
  Alexandra, Andrew
  Miller, Seumas
Title: Ethical theory, “common morality,” and professional obligations
Zotero URI: https://zotero.org/bmcanally21/items/UHTEJ63C
Takeaway: Professionals are part of institutions, so role morality is teleological.
Tags:
  - Bernard Gert
  - Common morality
  - Ethical theory
  - Medical Ethics
  - Professions
  - Role morality
Category:
  - Topics in Law and Philosophy
Abstract: "We have two aims in this paper. The first is negative: to demonstrate the problems in Bernard Gert’s account of common morality, in particular as it applies to professional morality. The second is positive: to suggest a more satisfactory explanation of the moral basis of professional role morality, albeit one that is broadly consistent with Gert’s notion of common morality, but corrects and supplements Gert’s theory. The paper is in three sections. In the first, we sketch the main features of Gert’s account of common morality in general. In the second, we outline Gert’s explanation of the source of professional moral rules and demonstrate its inadequacy. In the third section, we provide an account of our own collectivist needs-based view of the source of the role-moral obligations of many professional roles, including those of health care professionals."
Type: Journal Article
URL: https://doi.org/10.1007/s11017-009-9097-1
Full Citation: "Alexandra, A. and Miller, S. (2009) ‘Ethical theory, “common morality,” and professional obligations’, Theoretical Medicine and Bioethics, 30(1), pp. 69–80. Available at: https://doi.org/10.1007/s11017-009-9097-1."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
---
> A profession is, in the first instance, an occupational grouping, whose members have a common defining end, such as preserving and restoring health in the case of members of the medical profession. But the paradigmatic professions such as medicine and law are more than a group of people who happen to do the same kind of work, in the service of the same end. Such professions in their modern form are institutional entities, oriented to the provision of a specific good to all relevant members of some group. 74. 

> Professional ethics is thus teleological in nature. Professional actions and attitudes are seen as morally good or bad, virtuous or vicious according to whether they help or hinder the realization of this defining end. 75. 

- It’s not just oaths and promises that ground professional obligations, otherwise those who somehow avoid making those oaths yet nonetheless practice the profession and violate them have done no wrong. 76. 

> Professionals are members of institutions. To understand the nature of professional role morality we need to examine the moral basis for the creation of relevant institutions and the consequent institutional moral duties to assist attaching to members of those institutions. 77. 

> To understand the specific content of professional role morality, then, we need to examine the purposes—to meet the aggregated health care needs, in the case of the health care professions which the various professions have been formed to serve, and the way in which professional roles must be constructed in order to achieve those purposes. Of course, one only comes to have a professional role through voluntary action, but the morality that comes with that role is not itself ultimately grounded on the individual’s choice. 80. 