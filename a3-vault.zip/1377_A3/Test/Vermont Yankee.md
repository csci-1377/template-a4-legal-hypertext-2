---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Bad Bazelon! No regulating nuclear regulation!
Takeaway: No Federal common law of administrative procedure
Tags:
  - ArbCap
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1978
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Vermont Yankee
Status: Annotated
Date: 1978-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Atomic Energy Act gives Commisssion broad authority to regulate nuclear energy
> - Commission passes rule deciding not to do formal adjudication for calculating nuclear waste in licensing
> - Instead, they do one single notice and comment process + to decide whether to put weight on the cost of nuclear waste in calculation 
> - They go above and beyond, including oral arguments and written comments following them
> - On person on the stand (Dr. Pitman) gets up and says “Trust us!” but doesn’t get cross-examination (not a formal adjudication)
> - AEC chooses a standardized weight instead of not including at all)
> - Commission decides 1) to grant license to Vermont Yankee power plant and 2) another company

> [!note]+ Procedural History and Posture
> - DC Appeals remands both decisions as arbitrary and capricious
> - They wanted a formal adjudication, also for procedures to be adequate to ensure not ArbCap 
> - Need a record to “ventilate” the issues

- Issue: Was the procedure sufficient to make the rule?

> [!note]+ Holding (Rehnquist): Yes, we can’t add extra procedure
> - No federal common law of administrative procedures
> - Administrations should be free to fashion their own rules absent “extremely compelling circumstances” Otherwise… over-proceduralization
>     - Continual review makes agency constraints unpredictable
>     - No Monday morning quarterbacking
>     - Would conflate procedure and decision quality
> - Policy decisions are not subject to reexamination by courts
> - We can only require procedures as mandated by statute.
> - Disposition: Reversed