---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Rat Poison
Takeaway: Posession of materials with “no lawful purpose” under the circumstances puts question of attempt to jury.
Tags:
  - Attempt
Category:
  - Crim
Abstract: ""
Page: 795
Type: Case
Rating: "**"
Year: 1996
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Reeves
Status: Annotated
Date: 1996-01-01
Jurisdiction: Tennessee
---
> [!note]+ Facts
> - 2 D’s talk on the phone, planning to kill teacher
> - One brings rat poison to school, tells friend, shows poison in purse.
> - Friend tells teacher, teacher sees them leaning over desk with purse
> - Rat poison found in purse

> [!note]+ Procedural History and Posture
> - Found delinquent, appealed
> - Jury found attempt to commit second degree murder. Trial cort affirms, sentenced to Department of Youth Development indefinitely

- Issue: Was evidence of attempt sufficient as a matter of law?

> [!note]+ Holding (Drowota): Yes.
> - Element at issue is what constitutes a  *substantial step.*
> - MPC says posession of material with no lawful purpose shall not be held insufficient as a matter of law (should go to jury)
> - P: yeah, and this went to the jury. They convicted.
> - D: No, Tennessee didn’t include these examples in *its* provision. Follow precedent (Dupuy) instead to hold this is “mere preparation”
>     - Dupuy held abortion provider not guilty after laying out tools on bed but without touching patient.
> - Despite stare decisis concerns, overrule Dupuy in light of new legislation.
> - Disposition: Affirmed.

> [!note]+ Dissent (Birch): No.
> - The “entire course of action” did not corroborate intent to commit murder.
> - Evidence was insufficient as a matter of law.





















