---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Catholic(ish) Schoolteachers
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1979
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: NLRB v. Catholic Bishop of Chicago
Status: Annotated
Date: 1979-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Section 2 of National Labor Relations Act: “employer” includes any person “acting as an agent of an employer” but shall not include (8 exceptions: gov, railroads, labor organizations, etc.)
> - Sectio 8 defines unfair labor practices to include interfering with the right to organize
> - NLRBoard regulates lay faculty at a Catholic high school

- Issues: 1) whether teachers of secular subject in religious schools are within jurisdiction of NLRA and 2) if so, does that violate 1st Amendment?

> [!note]+ Holding (Burger): 1) nope, to avoid 2!
> - We need…
> > clear expression of an affirmative intention” 
> 
> > affirmative intention of Congress clearly expressed
> 
> … that teachers in religious schools should be covered
> - And we don’t have that, so we can avoid Constitutional issue!

> [!note]+ Dissent (Brennan +3): 1) yes, your reading isn’t fairly possible, and your affirmative expression test sucks.
> - The test is ‘fairly possible’ not ‘affirmative expression’
> - Text: Look at expresio unius fam
> - Leg Hist: Hartley bill would have provided exception and didn’t pass