---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Gangrene Toothache
Takeaway: "“Child welfare” as “family policing” "
Tags:
  - Unintentional Homicide
Category:
  - Crim
Abstract: ""
Page: 333
Type: Case
Rating: "**"
Year: 1971
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Williams
Status: Annotated
Date: 1971-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - Ds kids are expressing symptoms of illness
> - Do not take to doctor out of fear that welfare department would take the baby away
> - There is a criminal law that criminalizes ordinary negligence resulting in death

> [!note]+ Procedural History and Posture
> - Jury convicts

- Issue: Were parents negligent in not taking the child to the doctor?

> [!note]+ Holding (Horowitz): Yes
> - Reasonable person would have known that the child would very likely die without medical care.
> 
> (not in holding): long history of removing indigenous children from their families by state agencies, so their concerns were substantiated.
> 
> - Disposition: Affirmed





















