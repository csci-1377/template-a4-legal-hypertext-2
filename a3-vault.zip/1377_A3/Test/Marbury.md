---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: The Court has the final say on constitutionality
Takeaway: Claim to horizontal review
Tags:
  - Judicial Review
  - PQ
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "*****"
Year: 1803
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Marbury v. Madison
Status: Annotated
Date: 1803-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Federalist enforcement of Alien and Sedition Acts deeply unpopular
> - Demolished by Jefferson’s Democratic-Republicans in 1800
> - Organic Act of 1801 permitted appointing “midnight judges” during last days of administration
> - Adams names many judges
> - Marshall seals the letters as secretary of state
> - Madison refuses to deliver them
> - Marbury, an appointee undelivered, sues and requests writ of mandamus

> [!note]+ Procedural History and Posture
> - Marbury brings case directly to Supreme Court
> - Madison doesn’t submit a brief

> [!note]+ Issues
> 1. Does Marbury have a right to the commission?
> 2. Has that right been violated, and do the laws afford him a remedy?
> 3. Is that remedy a mandamus from this court?

> [!note]+ Holding (Marshall): Yes, yes, and no
> - NPC: Power to tax = power to destroy
> 
> > a law repugnant to the constitution is void; and that courts, as well as other departments, are bound by that instrument.
> 
> 1. When commission has been signed, appointment is made, so withholding it violates his right
>     1. Political questions involve discretion
>     2. Legal questions involve obligation/vested rights
> 2. Whenever there is a right, there is a remedy by suit
> 3. No, because we only have appellate jurisdiction for writs of mandamus
>     3. Could have interpreted the statute (Judiciary Act of 1789) to restrict issuance of writs of mandamus to appellate jurisdiction (the natural reading)
>     - So this law is unconstitutional!
>     - And, being unconstitutional, we are not obligated to enforce it
>         - If we had to, there would be no real legislative check
> - Disposition: 