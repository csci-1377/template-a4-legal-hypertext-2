---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Sapolsky, Robert
Title: Behave
Takeaway: ""
Tags: []
Category:
  - Psychology
Abstract: ""
Type: Audiobook
Rating: "*****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2017
---
Amygdala most triggered in four S: fear fight flight and fuck

Prefrontal cortex turns off in normal people during dreaming and orgasm. Lowered activity in psychopaths, and many violent criminals have had damage to it.

The job of the frontal cortex is to help you do the harder thing when it is the right thing.

All fields of explaining human behavior implicitly invoke the others, Neurobiology, studying synaptic responses, involves environmental effects, genetic effects, evolutionary biological effects, etc.

Neurotransmitters only effect the neuron in the other side of the synapse and effects are immediate and short lived

Hormones are released by cells, including neurons, and enter the bloodstream, potentially effecting any cells with receptors, and last for a while/can be slow acting

Nucleotide: A, C, G, or T

Codon: set of three nucleotides (64 possibilities, three of which indicate stop)

Amino Acid: 21 different protein components coded for on average by about 3 codons

Gene: sequence of nucleotides whose codons code for the amino acids that make up a protein

Genome: all the genes in the nucleus of a cell

Alele: variations of mutations that are at equilibrium in a population

RNA copies a gene and is shipped to location in the cell where a protein needs to be made

Crick’s central dogma of life: DNA codes RNA codes protein, so one type of gene codes one type of protein

3 types of mutations:

Point mutation, insertion, and deletion

The redundancy of codons for amino acids, and the redundancy of amino acids that have similar shapes, these mutations don’t always have any effect.

Deletion and insertion mutations can delete/insert long strings of nucleotides, even whole genes.

Stress induced displacement aggression: many species (including humans) lash out when stressed, which reduces stress (giving ulcers helps avoid getting them).

In the hours to days before an action, hormones do not determine for cars behavior. They are very context dependent.

Adolescence is about novelty and risk taking. Larger than expected rewards give a huge increase in the nucleus accumbens activity (dopimanergic activation) and smaller than expected rewards have an adverse effect.

As children age, they increasingly distinguish between harm to objects and harm to people. They are also likely to recommend more similar punishment for intentional and unintentional harm to objects, but not to people.

The most empathetic people are less likely to act pro-socially, given the self-focus that comes with experiencing others pain, and the desire to avoid it. If someone’s distress raises your heart rate, you are less likely to help them than if it lowers it. Being able to remove yourself mentally predicts positive action.

We have evolved to free the frontal cortex from genetic determination: it develops late, influenced most by our experiences, and it seems that there is evolutionary pressure for this, leaving time to “get it right”

When we study at Jean in only one environment, we artificially inflate our assessment of heritability. This is because we do not see how the environment mediates the effect of that gene.

To study whether a trait is inherited, we look at whether genetics sets the average of that trait. For example the number of fingers on your hand is pretty much entirely inherited. By contrast heritability assessors extent to which genetics determines the variation in that trait. Four fingers, this is pretty much not at all. 

Because of gene-environment interactions, it is inappropriate to ask what a gene does. Instead you can ask what a gene does in a given environment. A gene that does one thing in one environment can do an entirely different, or even opposite thing in another environment

Heritability of intelligence is around 70% in those with high socioeconomic status, but only around 10% in those low socioeconomic status. High SES allows genes to fully impact intelligence, while adverse effects of the low SES trump those.

Epigenetic changes due to environmental stimuli in a person can be passed down to a child. This happens through the expression of those at the genetic changes in the sperm or egg cells. It is difficult to assess the impacts of these effects, and evidence indicates they are not very significant, but this essentially partially validates Lamarque. These effects are even called Neo Lamarckian.

Primary values of hunter-gatherer societies: fairness, indirect reciprocity, and avoidance of despotism. Enforced through gossip, largely concerning norm violations of high-status individuals.

Evolution Misconceptions:

Evolution can pre-select for traits that turn out to be useful later

Evolution selects for survival. No, it can actually select for traits that lower life expectancy but increase reproduction.

It selects for greater complexity 

Group selection: individuals don’t really do something “for the good of the species,” but there are positive and negative externalities of behavior making individually maladaptive traits beneficial when shared in a group. Neo-group selection is increased among humans by inter-group conflict leading to parochial altruism.

Levels of selection:

Individual 

Kin

Sexual

Reciprocal altruism

Group

Genotypic (recipe, what is repeated)

Phenotypic (taste of the cake, what is selected for)

We categorize along to independent axes Cohen warmth and competence there are emotions associated with assessments at each corner of this two dimensional scale.

Thinking of the lower class as high warmth, low competence can reinforce the status quo. This involves the trope of the honest poor, giving them the scraps of respect. This pairs the myths of “poor and happy” and “rich and miserable” to keep things stable.

We individuate us and essentialize them. The best way to make us think of a them as an RS is to individuate them.

Lower social economic status = poorer health for every step on the latter. Not healthcare access (persists in universal healthcare countries) not risk/protective factors (1/3 of variability), about psych baggage

Consistent link between low IQ and a subtype of conservatism (RWA, right wing conservatism) that persists after controlling for education and SES. It provides simple answers for those with poor intellectual reasoning. They deal poorly with ambiguity. 

Conservatives start gut and stay gut, liberals start gut and go head, or situational. Both can go head when asked, but liberals have greater motivation to think about the situation because they’re uncomfortable with personal explanations.

People get more conservative when drunk, hungry, tired, etc. They also have a greater fear of death (more con when primed to think of mortality)

Our moral intuitions aren’t either primordial wisdom nor dumbed primal urges. They’re learned automaticity.

Intuitive gut morality is deontological: don’t treat people that way, it’s wrong (amygdala and vmpfc)

Short term reasoning is consequentialist (dlpfc)

long term strategic consequentialism is both, involves thought and feeling experiments

When considering me vs us problems, our intuitions are usually pretty good, since evolutionary/social learning generally align, while the opposite is true of us/them decisions.

Causation vs compulsion is fallback distinction for those who insist on mitigated free will

Is there a way in which one is not able to choose not to be a pedophile but is able to choose not to be a child molester? Yeah. The former is about choosing our set of desires, whereas the latter is about choosing our actions. In acting, the desire to act in character plays a role, and unless that role is so overridden as to constitute compulsion (will think more on that later) a choice has occurred.

A school of thought assigns aptitude and impulse to biology and effort and resistance to free will. This is intuitive, but is it defensible?

Steven Morse writes on the relevance of neurobiology to the law, criticizing its use.

The Punisher’s Brain: The Evolution of Judge and Jury

Religious people are more pro-social to in-group members, but largely when considering punishment or social judgement.

Focusing on a punitive god reduces cheating, a forgiving one increases it.

Greater belief in hell corresponds to lower crime rates more than belief in heaven

Religious primes increase out-group hostility

It’s not spirituality (regular prayer) that predicts support for out-group violence, but regular attendance of religious services does

Inter group contact doesn’t necessarily reduce hostility, but it does when members of the groups have a shared goal and have equal power relationships.

We haven’t evolved to be selfish or altruistic or anything else full stop. We have evolved to do particular things in particular circumstances. Context, context, context.

Arbitrary boundaries can be helpful or hurtful. Just remember that they are arbitrary. Hurtful: ethnic distinctions between hutsis and tutus that founded the Rowandan genocide. Helpful: when they stop a descent into tyranny or violence, when their absence is what leads people, along with the sunk costs of prior action, to commit increasingly horrific acts.

“If this book could be summed up in one phrase, it would be ‘it’s complicated’”: All my favorite books.

“You don’t have to choose between being scientific and being compassionate.”

-last words of the epilogue

From dendritic spines to hillock (beginning of axon) a neuron is an analog system, communicating gradations of charge difference up to the threshold (-40mv) and along axon to terminal it’s a digital system
