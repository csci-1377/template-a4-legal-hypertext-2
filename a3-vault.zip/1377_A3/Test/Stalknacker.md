---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Well, that’s Septic.
Takeaway: Balancing Nuisance Interests
Tags:
  - Nuisance
  - Coase
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hendricks v. Stalnacker
Status: Annotated
Date: 1989-01-01
Jurisdiction: West Virginia
---
> [!note]+ Facts
> - Stalkner dowses for two wells. He drills the first, but it is unclean because the area is strip mined. 
> - Hendrickses buy the property, go to set up septic system, call sanitarian
> - Stalkner calls sanitarian about second well, hears about septic system plan, rushes to get his well drilled.

> [!note]+ Procedural History
> - Hendrickses sue for public nuisance
> - Jury in circuit court finds public nuisance and judge orders well abated, but no damages.

> [!note]+ Nuisance definition
> - “anything which annoys or disturbs the free use of one’s property…
> - Public nuisance at first determined primarily by harm caused
> - Now considers reasonableness of use, considering negligence, recklessness, dangerousness, or intentional malice. 
> - So an interference “is unreasonable when the gravity of the harm outweighs the social value of the activity allleged to cause the harm” 

> [!note]+ Holding
> - Circuit court’s decision is reversed. Action is not intentionally malicious, and scales don’t tip to septic system