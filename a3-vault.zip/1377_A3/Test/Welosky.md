---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Women Aren’t People
Takeaway: ""
Tags:
  - Original Expectations
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1931
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Commonwealth v. Welosky
Status: Annotated
Date: 1931-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - Jury service statute says “a person qualified to vote for representatives to the [state legislature] shall be liable to serve as a juror.”
> - Women get the right to vote

- Issue: Are women “persons qualified to vote” under the statute?

> [!note]+ Holding: No.
> > Statutes are to be interpreted, <u>not alone according to their simple, literal or strict verbal meaning, but in connection with their development, their progression through the legislative body, the history of the times, prior legislation, contemporary customs and conditions and the system of positive law of which they are a part,</u> and in the light of the Constitution and of the common law, to the end that they may be held to cover the subjects presumably within the vision of the Legislature and, on the one hand, be not unduly constricted so as to exclude matter fairly within their scope, and, on the other hand, be <u>not stretched by enlargement of signification to comprehend matters not within the principle and purview on which they were founded when originally framed and their words chosen</u>.
> 
> > No one contemplated the possibility of women becoming so qualified
> > - Expectations originalism
> 
> - Disposition: 
