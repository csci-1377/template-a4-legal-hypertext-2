---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Fox Chase
Takeaway: Intent to control + act of control (posession is presumptive ownership)
Tags:
  - First Posession
  - Custom
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1805
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pierson v. Post
Status: Annotated
Date: 1805-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - Post is chasing a fox with his hounds
> - Pierson comes in and takes it
> - Post sues Pierson

> [!note]+ Procedural History and Posture
> - Trial court finds for Post
> - Pierson appeals
> - Question at issue- did Post acquire property in the fox through pursuit?

> [!note]+ Holding (Tompkins) Pierson was rude, but no legal remedy is available
> - A bunch of thoughts from the ancients
> - No one claims you get it just by chasing it
> - Maybe if he had wounded it seriously, or trapped it
> - Administration arg- we would have lots of litigation

> [!note]+ Dissent (Livingston)
> - Proposed rule- a wild animal can be acquired without bodily touch if the pursuer has a *reasonable prospect* of taking it and intends to use it.
> - “should have been submitted to the arbitration of sportsmen, without poring over Justinian” (role of judges, relative epistemic capabilities
> - Policy- We really need to kill all these foxes, so we should encourage hunting them
> - Times change, so we can’t just rely on ancient precedents (foxes weren’t a problem back then)
> - Decide whichever rule is most rational, not about authority

> [!note]+ Thoughts and Questions
> - This isn’t an efficient means of extermination
> - These citations are unusual

> [!note]+ Class Notes

