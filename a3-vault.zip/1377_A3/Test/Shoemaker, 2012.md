---
base: "[[Test.base]]"
In-Text Citation: (Shoemaker, 2012)
Priority: Recommended
Authors: Shoemaker, David
Title: Blame and Punishment
Zotero URI: http://zotero.org/users/4316906/items/ZMKP83FX
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: Most theorists assume criminal responsibility entails moral responsibility, an assumption allegedly illustrated by the relation between moral and criminal blame, tightly analogous practices presumed to be distinct only in virtue of the responding agents and the specific set of norm violations to which each is a response. The chapter hopes to show why this illustration fails. The chapter first examines what I take to be the most plausible recent account of general blame—T. M. Scanlon’s—to see whether it can account for criminal blame, that is, punishment. The chapter argues that it cannot, given that Scanlon’s critical notion of meaning has no place in criminal blame, despite some seemingly compelling reasons to believe otherwise. The chapter will then try to show why there are actually different conceptions of blame at work in the criminal and moral realms, conceptions arising from fundamentally different aspects and functions of each sort of response.
Type: Book Section
Rating: "****"
URL: https://doi.org/10.1093/acprof:oso/9780199860821.003.0006
Full Citation: "Shoemaker, D. (2012) ‘Blame and Punishment’, in D.J. Coates and N.A. Tognazzini (eds) Blame: Its Nature and Norms. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/acprof:oso/9780199860821.003.0006."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2012
---
Interpersonal and criminal blame are importantly distinct, with only the latter existing in the context of assymetrical power relations sufficient to justify punishment

Interpersonal

- Core value: motives
- Can demand attitudes
- Cannot punish
- Simply an appropriate response to a judgment fo blameworthiness (117)
- Active blame must be a communicative response rendered appropriate by such a judgment
- Suffering is not the function

Criminal

- Core value: harm
- Cannot demand attitudes, only actions
- Allows legitimate sanctioning in the context of assymetrical authority
- Communicating is inseparable from the deliberate causing of suffering (or at least sanctions)













