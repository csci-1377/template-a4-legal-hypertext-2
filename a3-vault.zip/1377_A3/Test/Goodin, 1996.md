---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1467-9248.1996.tb00337.x
In-Text Citation: (Goodin, 1996)
Priority: Further
Authors: Goodin, Robert E.
Title: Enfranchising the Earth, and its Alternatives
Zotero URI: http://zotero.org/users/4316906/items/EMBB9PMQ
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Journal Article
URL: https://0.onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-9248.1996.tb00337.x
Full Citation: "Goodin, R.E. (1996) ‘Enfranchising the Earth, and its Alternatives’, Political Studies, 44(5), pp. 835–849. Available at: https://doi.org/10.1111/j.1467-9248.1996.tb00337.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1996
---
