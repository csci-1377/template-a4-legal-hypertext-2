---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Old Age
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 2004
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: General Dynamiucs Land Systems, Inc. v. Cline
Status: Annotated
Date: 2004-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Age Discrimination Employment Act of 1967 (ADEA) section 621 forbids discrimination “because of an individuals age”. Specifically protects those over 40
> - Collective Bargaining between GDLS and United Auto Workers leads to removal of healthcare for those retiring before 50
> - Group of workers 40-50 sue

> [!note]+ Procedural History and Posture
> - Equal Employment Opportunity Commission claims agreement violates ADEA
> - Sixth Circuit affirms, with one dissent 

> [!note]+ Holding
> - Summary- Age only refers to the old here
>     - Intent- Records of Hearings demonstrate no evidence about complaints discriminating against younger workers
>     - Purpose- Statement of purpose at beginning of statute focuses on elderly
>     - Plain Language- “discrimination on the basis of age” is thought to mean against the elderly
>     - Coherence- Confirmed by cutoff at 40 (enemy of 40 is 30, not 50)
> - Objections/replies- Age means both
>     - It does in some parts of the statute and not others, depending on context. We aren’t seeking the abstract meaning of age, but the contextual meaning of the phrase
> - Disposition- Reversed

> [!note]+ Concurrence/Dissents
> - Scalia Dissent- should have defferred to agency
> - Thomas Dissent- can’t use this “new tool of ‘social history’ to interpret meaning’
> - Statutes often address more than they were originally intended to (civil rights act etc)
