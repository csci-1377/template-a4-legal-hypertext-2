---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Paint the Outside?
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1979
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Flower City Painting Contractors, Inc. v. Gumina Construction Co.
Status: Annotated
Date: 1979-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - Gumina contracts with FIGHT Village for federally funded project under HUD
> - Executive Order 11246 prohibits employment discrimination by government contractors and requires affirmative action to hire minority subcontractors
> - Gumina fulfills part of affirmative action obligation by hiring Flower for $98,500, only $2,500 less than max for painting and decorating budget
> - Flower is a new painting company managed by black personnel, and Gumina knows they are new (first subcontract for this kind of work)
> - Their contract only specifies units they are painting
> - A year after the contract, Flower claims the cost is only for interior painting
> - Gumina says no, it’s also outside
> - They disagree, then Gumina cancels contract
> - Flower sues for breach

> [!note]+ Procedural History and Posture
> - At trial, Gumina says Flower repudiated, Flower says Gumina tried to enlarge scope
> - Court finds contract was for “all surfaces except those specifically excluded” so Flower breached

- Issue: Was there a contract? If so, what did it say?

> [!note]+ Holding (Gurfein): No contract
> - No “meeting of the minds”
> - Two plausible interpretations
> - Ambiguity can be partly resolved through customary practice
> - But that’s not enough, since we need to prove either knows or has reason to know of custom
> - And while there was a custom, Flower would not reasonably know it, because they’re new (and Gumina knew they were new)
> - Disposition: Reversed

> [!note]+ Dissent (Oakes): Yes contract, and for Flower
> - Construe the contract against the drafter
> - And it’s clear Gumina made a mistake and tried to get Flower to change the contract
> - But no mutual mistake, this is just on them.
