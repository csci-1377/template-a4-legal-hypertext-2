---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/1460728x.2024.2341348
In-Text Citation: (Hapla, 2023)
Authors: Hapla, Martin
Title: Consequentialism and problem of role morality in legal ethics
Zotero URI: https://zotero.org/bmcanally21/items/84MQ5VVC
Takeaway: ""
Tags:
  - Utilitarianism
  - Common morality
  - Role morality
  - Confidentiality
  - Consequentialism
  - Legal ethics
  - Legal philosophy
  - The role of a lawyer
Category:
  - Topics in Law and Philosophy
Abstract: One of the frequent philosophical problems of legal ethics is the conflict between common and role morality. This situation is where a lawyer's actions are evaluated differently by these two sets of moral norms. The article seizes on this as a conflict between two conventional moralities that need to be resolved with the help of a justificatory morality and thus an appropriate theory of normative ethics. It offers as a possible response a variant of consequentialism that draws on utilitarianism and brings it closer to pragmatism. This approach seeks to preserve the traditional advantages of utilitarianism, which are minimalist and plausible normative assumptions, and an excellent ability to resolve moral conflicts. At the same time, it takes into account the complex nature of the world in which we live and our epistemic uncertainty, which brings it closer to pragmatism. The author confronts this theory with some existing approaches to resolving the conflict between the common and role morality and tries to show that it is at least as plausible as they are and should have a place among them. Finally, the article concludes with an analysis of the famous case of Alton Logan as its practical application.
Type: Journal Article
URL: https://doi.org/10.1080/1460728x.2024.2341348
Full Citation: "Hapla, M. (2023) ‘Consequentialism and problem of role morality in legal ethics’, Legal Ethics, 26(2), pp. 183–200. Available at: https://doi.org/10.1080/1460728x.2024.2341348."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
---
