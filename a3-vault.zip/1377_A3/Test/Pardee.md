---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Cut it Out, Lumberjack!
Takeaway: Test for injunction over damages
Tags:
  - Equity
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1911
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pardee v. Camden Lumber Co.
Status: Annotated
Date: 1911-01-01
Year*: 1911
Jurisdiction: West Virginia
---
> [!note]+ Facts
> - Camden Lumber is chopping down trees on Pardee’s property. Pardee seeks an injunction rather than compensatory damages.

> [!note]+ Procedural History and Posture
> - Lower court dissolves injunction on basis of McMillan v. Ferrell (only remedy for trespass is damages unless defendent can’t pay)
> - Supreme court (of wva) grants appeal to review the precedent

> [!note]+ Holding
> - When <u>**damages are adequate**</u>
>     - When the item can be replaced and is widely available
> - <u>**When they aren’t**</u>
>     - If value is incomparable or subjective
>     - If the item is rare and hard to replace
>     - If there is repeated intrusion
> - Equity shouldn’t go further than necessary, so we need to be sure law is inadequate
> - It is, because trees are part of the land and their value can’t be measured (but the value of fences or trampled grass or a horse could)
> - The old rule is from when lumber was thought worthless (by whom?)
