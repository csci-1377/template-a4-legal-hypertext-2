---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Unknowingly Automatic
Takeaway: Testing for strict liability
Tags: []
Category:
  - Crim
Abstract: ""
Page: 194
Type: Case
Rating: "***"
Year: 1994
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Staples v. United States
Status: Annotated
Date: 1994-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Staples owns gun that is modified to fire automatically
> - He claims not to know it is so modified
> - Statute reauires registration of a “firearm” with high penalties for non-registration
> - A “firearm” machinegun is one which fires automatically…

> [!note]+ Procedural History and Posture
> - Staples requests jury instruction that gov must prove he knew the gun would fire automatically
> - District court rejects, sentenced to 5 years in prison
> - Appeals affirms

- Issue: Is mens rea an element of the crime?

> [!note]+ Holding (Thomas): Yes
> - This is not a “regulatory” or “public welfare” offense, which the government intended to impose strict liability.
> - We need to be able to distinguish criminal and innocent conduct, and couldn’t subject an innocent gun owner to ten years in prison for not knowing their gun was automatic.

> [!note]+ Dissent (Stevens): No
> - This isn’t a normal gun
> - Lack of knowledge requirement suggests no mens rea component
> - Test for public welfare offenses
>     - (1) they regulate “dangerous or deleterious devices or products or obnoxious waste materials”; 
>     - (2) they “heighten the duties of those in control of particular industries, trades, properties or activities that affect public health, safety or welfare”; and
>     - (3) they “depend on no mental element but consist only of forbidden acts or omissions.”





















