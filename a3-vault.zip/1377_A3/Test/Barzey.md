---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Privy Council
Authors: ""
Title: Repugnant Garage
Takeaway: Construe ambiguous wills to be valid
Tags:
  - Numerus Clausus
  - Estates
  - Ambiguity
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 2002
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Charles v. Barzey
Status: Annotated
Date: 2002-01-01
Jurisdiction: Dominica
---
> [!note]+ Facts
> - Aunt leaves property to niece P and garage/storeroom to nephew D “to be used by him as long as he wishes”

> [!note]+ Procedural History and Posture
> - Trial interprets as giving life estate to nephew
> - Appeals says this is “repugnant to the bequest” (fee simple), reverses

- Issue: What interest, if any, does the nephew have?

> [!note]+ Holding (Hoffman): Life estate! 
> > One first acertains the intentions of the testator and then decides whether it can be given effect. (But not really, because ambiguity in favor of validity)
> 
> - Can’t be any doubt about what testatrix meant
> - Repugnant conditions are just what law can’t allow/accommodate
> - There isn’t any difficulty here. Ambiguous, so construe to be valid.
> - Disposition: Reversed
