---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Fair Housing Protections
Takeaway: "Congress can rationally determine “badges and incidents” of slavery through 13A and 1866 CRA. "
Tags:
  - 13A
Category:
  - Con Law
Abstract: ""
Page: 507
Type: Case
Rating: "**"
Year: 1968
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Jones v. Alfred H. Mayer Co.
Status: Annotated
Date: 1968-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Freedom of Residence Committee in St. Louis helps Joseph Le and Barbara Jo Jones, an interracial couple, sue the Afred H. Mayer company for violating the 1866 Civil Rights Act.

> [!note]+ Procedural History and Posture
> - 

- Issue: Can Congress prohibit private housing discrimination where interstate commerce is unaffected?

> [!note]+ Holding (Steward): Yes
> - 1) the act does bar private discrimination
> > Congress meant exactly what it said.
> 
>     - Not just trying to solve evil of Black Codes
>     - House overrode the President’s veto
> - 2) that is a valid excercise of the Thirteenth Amendment
>     - It’s up to Congress to determine what the badges and incidents of slavery are. 
>     - If the right can’t be excercised, it isn’t the same right.
>     - The measure is “practical freedom”
>     - There is no bar to private enforcement
>     - The end, the maintenance of freedom, is legitimate, so the plainly  means are constitutional





















