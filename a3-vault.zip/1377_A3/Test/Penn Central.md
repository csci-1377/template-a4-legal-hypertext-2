---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Grand Central Air Rights
Takeaway: Ad Hoc Approach to Regulatory Takings
Tags:
  - Historic Preservation
  - Ad Coelum
  - Regulatory Takings
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1978
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Penn Central Transportation Company v. City of New York
Status: Annotated
Date: 1978-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - NY passes landmark preservation law restricting changes to historic buildings but allows transfer of development rights (TDRs) to other parcels nearby owned by same person.
> - P leases air rights above Grand Central for office tower
> - Landmark Preservation Commission denies both plans for tower
> - P sues to invalidate regulation as taking without compensation

- Issue: Is historic preservation a taking?

> [!note]+ Holding (Brennan): No, not even close
> - Landowners almost always lose
> - Ad Hoc Factors (non-dispositive)
>     1. Extent of <u>**dimunition of value**</u> caused by regulation…Denominator? 
>         - Air Rights?
>         - Penn Central Parcel?
>         - Owned Properties in Area?
>     2. Whether regulation <u>**interferes with reasonable investment-backed expectations**</u>
>     3. Nature of government action, in particulat whether it causes <u>**physical invasion**</u> <u>**or**</u> merely adjusts “the <u>**benefits and burdens**</u> of economic life to promote the public good”

> [!note]+ Dissent (Rhenquist): No, look back at Mahon
> - No <u>**Public Nuisance**</u>
> - No <u>**Reciprocity of Advantage**</u>
> - The problem is *singling out* of this property to bear the burden. If it were taxpayers as a whole it would be fine.
> 