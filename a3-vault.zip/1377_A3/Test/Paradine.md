---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: King's Bench
Authors: ""
Title: Prince Rupert Invades
Takeaway: Independent Covenants in Old England
Tags:
  - Leases
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1647
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Paradine v. Jane
Status: Annotated
Date: 1647-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - P leases land to D
> - D doesn’t pay (Prince Rupert has invaded, and he doesn’t have posession)
> - P sues for unpaid rent

- Issue: Is D’s obligation to pay rent contingent on being able to posess?

> [!note]+ Holding: Nope, independent covenants
> - Risk is on the tenant, not the landlord
> - This works because Prince Rupert isn’t working for the landlord