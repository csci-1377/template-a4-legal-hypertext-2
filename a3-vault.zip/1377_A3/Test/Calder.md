---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Effective Libel
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Calder v. Jones
Status: Annotated
Date: 1984-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Lawsuit concerned claims of libel, invasion of privacy, and intentional infliction of emotional harm stemming from an article that appeared in the National Enquirer about the respondent, Shirley Jones. Jones brought the case in California, where she lived and worked, but petitioners resisted, claiming a lack of personal jurisdiction.

> [!note]+ Procedural History and Posture
> - Superior court grants motion to dismiss for lack of PJ due to First Amendment concerns
> - Appeals reverses

- Issue: Is there SIPPJ over defendents who don’t otherwise make contact with the state than action that affects it?

> [!note]+ Holding (Rehnquist): Yes (Effects Test)
> - Each defendent’s contacts are assessed individually, but in light of role directing action at state
> 
> > California is the focal point of both the story and the harm suffered. Jurisdiction over petitioners is therefore proper in California based on the <u>‘effects’</u> of their Florida conduct in California.”
> 
> > “[T]heir (1) <u>intentional, and allegedly tortious, actions</u> were (2) <u>expressly aimed </u>at California. Petitioner South wrote and petitioner Calder edited an article that they knew would have a potentially devastating impact upon respondent. And they (3) <u>knew that the brunt of that injury would be felt by respondent</u> in the State in which she lives and works and in which the *National Enquirer *has its largest circulation. Under the circumstances, petitioners must “reasonably anticipate being haled into court there” to answer for the truth of the statements made in their article. … An individual injured in California need not go to Florida to seek redress from persons who, though remaining in Florida, knowingly cause the injury in California.” ¶ 28
> 
> - (Not in CB) First Amendment considerations do not have any weight in a jurisdictional analysis where “[t]he infusion of such considerations would needlessly complicate an already imprecise inquiry” and that First Amendment concerns are sufficiently and appropriately dealt with through the constitutional limitations on the governing substantive law.
> - **NB**: Don’t think the Effects Test swallows up the PJ jurisprudence. Subsequent case law cuts it back (discussed more in class).
> - Disposition: Affirmed
