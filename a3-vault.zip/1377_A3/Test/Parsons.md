---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Architect Unphased
Takeaway: Test for binding obligor despite voiding condition
Tags:
  - Conditions
  - Traynor
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1965
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Parsons v. Bristol Development Co.
Status: Annotated
Date: 1965-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - Developer D contracts with architect P to design building
> - Contract in 2 phases
>     - 1 is preliminary plans (completed and paid 12k)
>     - 2 is complete plans, conditional on obtaining construction (unobtained, unpaid)
> - D can’t get loans because can’t secure title to land
> - P does most of the work for phase 2, sues to get paid for it

> [!note]+ Procedural History and Posture
> - Lower court finds for D (properly admitting extrinsic evidence)

- Issue: Does failure to obtain loans void obligation to pay?

> [!note]+ Holding (Traynor): Yes
> - Terms of the contract mentioning phase 2 payment all refer back to clause which conditions payment on construction loans
> - When "payment of money is to be made from a specific fund, and not otherwise, the failure of such fund will defeat the right of recovery.” Except
> - "A party who <u>prevents fulfillment</u> of a condition of his own obligation ... cannot rely [869] on such condition to defeat his liability.”
> - <u>Equitable estoppel</u>: if D had induced P’s work by making P believe it had the funds, would be estopped from invoking to contrary in court
> - <u>Notice</u>: If D had failed to notify that he didn’t have the funds, that would reasonably allow reliance damages, but didn’t fail.
> - Disposition: Affirmed