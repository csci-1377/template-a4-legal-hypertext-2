---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Substantial Mailing Event
Takeaway: ""
Tags:
  - Venue
  - 1391b2
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1992
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Bates v. C&S Adjusters, Inc.
Status: Annotated
Date: 1992-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - Bates incurs a debt while a resident of W.D. of Penn. His creditor, a corp with principal place of business in W.D. of Penn refers his account to Adjusters, a collection agency, which does no business in the state of NY. Bates moves to W.D. NY. Adjusters mails the collection notice to Bates’ old Penn address, and the post office forwards it to his new address in NY.
> - Bates sues Adjusters in W.D. NY for violations of Fair Debt Collection Practices Act (federal statute) and seeks statutory damages, costs, attorney’s fees.
> - Adjusters Inc. counterclaims for costs, alleges the action is in bad faith and to harass, and subsequently files a motion to dismiss for improper venue.
> - Bates says this is a 28 U.S.C. § 1391(b)(2) proper venue case – federal question and “substantial part” venue.

> [!note]+ Procedural History and Posture
> - District Court upholds def’s motion to dismiss for improper venue

- Issue: Does WDNY have venue under “substantial part of events”?

> [!note]+ Holding (Newman): Yes
> - A substantial “part of the events or omissions giving rise to the claim occurred” in NY: receipt of collection notice.
> - Not about intention or contacts after clarified statutory language. This isn’t an SMJ contacts test.
> - Broad, purposive interpretation of the statute
> - Disposition: Reversed
