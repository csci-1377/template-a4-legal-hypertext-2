---
base: "[[Test.base]]"
In-Text Citation: (Skinner, 2017)
Priority: Further
Authors: Skinner, Quentin
Title: A Third Concept of Liberty
Zotero URI: http://zotero.org/users/4316906/items/9282DY9C
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Book Section
URL: https://www.taylorfrancis.com/books/9781351560269/chapters/10.4324/9781315091822-13
Full Citation: "Skinner, Q. (2017) ‘A Third Concept of Liberty’, in Miller, D., The Liberty Reader. 1st edn. Edited by D. Miller. Routledge, pp. 243–254. Available at: https://doi.org/10.4324/9781315091822-13."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2017
---
