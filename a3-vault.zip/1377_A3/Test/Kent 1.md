---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Email Chain Settlement
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 2015
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Bridge City Family Medical Clinic v. Kent & Johnson, LLP
Status: Annotated
Date: 2015-01-01
Jurisdiction: Oregon
---
> [!note]+ Facts
> - Kent represents Bridge Medical in arbitration
> - Bridge doesn’t like it, claims malpractice
> - They discuss settlement with malpractice insurer
>     - Bridge originally wants $40,000
>     - Kent starts at $10,000 + Mutual Release
>     - Emails eventually agree on $19,000
>     - Kent sends formal document and mutual release
>     - Bridge doesn’t sign documents
> - Bridge sues
> - Kent files for summary judgment, claiming settlement was reached

> [!note]+ Procedural History and Posture
> - Trial court grants motion, dismisses case

- Issue: Did emails constitute settlement contract? (who made the offer?)

> [!note]+ Holding (Garrett): Yes, they did. (Bridge made offer)
> > Even when it has not been reduced to a formal writing, a valid contract can be created “by [an] offer and its unqualified acceptance.”
> 
> - Plaintiff- We only expressed willingness, and defendant added another term (mutual release) that we don’t want, so no contract
> - Defendant- These were offers, not “statements of intention”. Bridge made a speciic proposal and implicitly accepted the mutual release
>     - Also offer did not say it could be binding until mutually signed, only the release had that contingent
> - Defendants are right. What really happened is that Bridge got cold feet and tried to pull out of a contract.
> - The signing of the release was not an issue of contract formation, but a matter of performance
> - Disposition: Affirmed