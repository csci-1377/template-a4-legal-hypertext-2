---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Spite Building?
Takeaway: Nope, not a nuisance
Tags:
  - Easements
  - Nuisance
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1959
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Fountainbleau Hotel Corp. v. Fort-Five Twenty-Five
Status: Annotated
Date: 1959-01-01
Jurisdiction: Florida
---
> [!note]+ Facts
> - New Fountainbleu building right next to Eden Roc’s will cast a shadow on the Eden Roc’s pool in winter
> - Fountainbleu wall deliberately left windowless (ugly)

> [!note]+ Procedural History and Posture
> - Trial court says new building is injuring the neighbor

- Issue: Is th new Fountainbleu Tower an actionable nuisance?

> [!note]+ Holding: No
> - Not a spite fence, it has real rooms, makes money, etc.
> - Sic utere maxim only applies for legal injury (but what are the legal rights then?)
> - Disposition: Reversed