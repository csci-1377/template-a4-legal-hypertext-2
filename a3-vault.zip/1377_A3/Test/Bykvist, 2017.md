---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phc3.12408
In-Text Citation: (Bykvist, 2017)
Priority: Recommended
Authors: Bykvist, Krister
Title: Moral uncertainty
Zotero URI: http://zotero.org/users/4316906/items/8UPNXCTN
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: What should we do when we are not certain about what we morally should do? There is a long history of theorizing about decision-making under empirical uncertainty, but surprisingly little has been written about the moral uncertainty expressed by this question. Only very recently have philosophers started to systematically address the nature of such uncertainty and its impacts on decision-making. This paper addresses the main problems raised by moral uncertainty and critically examines some proposed solutions.
Type: Journal Article
Rating: "***"
URL: http://0.onlinelibrary.wiley.com/doi/abs/10.1111/phc3.12408
Full Citation: "Bykvist, K. (2017) ‘Moral uncertainty’, Philosophy Compass, 12(3), p. e12408. Available at: https://doi.org/10.1111/phc3.12408."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2017
---
> [!note]+ Intro
> - There are different levels of moral ought
> - You won’t hit an infinite regress because we can only think so many levels up
> - Fetishism accusation assumes a false dichotomy. You can care about the right thing de dicto and de re.

> [!note]+ Problems with Various Approaches
> - My Favorite Theory: Unsensitive to moral risks
> - Intertheoretic Comparisons: can’t be done quantitatively
> - Voting: overly theoretical, and nihilism fucks it up
> - Non-cognitivism: can’t make sense of uncertainty at all. Desires can’t explain degree of uncertainty and importance of considerations













