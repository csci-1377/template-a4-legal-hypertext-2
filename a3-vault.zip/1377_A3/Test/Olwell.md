---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Eggsacting Restitution
Takeaway: No Efficient Theft
Tags:
  - Essentialism
  - Restitution
  - Conversion
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1946
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Olwell & Nye v. Nissen
Status: Annotated
Date: 1946-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - P sells Pugent Sound Egg Packers but keeps egg washing machine, transferring it to storage
> - D takes the machine out of storage and uses it regularly
> - P finds out, waives tort, sues for *in assumpsit *for restitution on unjust enrichment (money saved using machine)

> [!note]+ Procedural History and Posture
> - Trial court awards cost to wash eggs by hand ($10/day)
> - D appeals, that damages should be based on rental value

- Issue: Proper measure of restitution?

> [!note]+ Holding (Mallery): Max(P Loss, D Benefit)
> > The very essence of the nature of proprty is the right to its exclusive use
> 
> - Requires that benefit be “at the expense” of P
> - Sometimes loss and benefit are unequal
> - Then we look to good/bad faith
>     - If good, we take the min 
>     - If bad, we take the max (uncertainty resolved against party that created it)
> - Also limited by complaint (this is no longer true)
> - Disposition: Modified
