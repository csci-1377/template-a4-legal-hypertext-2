---
base: "[[Test.base]]"
In-Text Citation: (Peter, 2021)
Priority: Recommended
Authors: Peter, Fabienne
Title: Truth and Uncertainty in Political Justification
Zotero URI: http://zotero.org/users/4316906/items/UXPZI385
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: Political deliberation and decision-making typically take place in circumstances of substantial uncertainty about what should be done. Some of this uncertainty concerns decision-relevant empirical facts and some of it concerns decision-relevant normative facts. It is widely accepted that uncertainty about empirical facts should make us cautious and that political justification must take such uncertainty into account. Some have argued, however, that uncertainty about empirical and normative facts is not symmetrical, and that normative uncertainty does not demand the same caution. This chapter argues that the argument against symmetry does not work in the political context and that political justification must take normative uncertainty into account.
Type: Book Section
URL: https://academic.oup.com/book/39301/chapter/338890348
Full Citation: "Peter, F. (2021) ‘Truth and Uncertainty in Political Justification’, in Peter, F., Political Epistemology. Oxford University Press, pp. 64–75. Available at: https://doi.org/10.1093/oso/9780192893338.003.0005."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2021
---
