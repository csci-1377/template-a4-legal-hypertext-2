---
base: "[[Test.base]]"
In-Text Citation: (Oberman, 2023)
Priority: Essential
Authors: Oberman, Kieran
Title: Refugees are Just People in Need of Refuge
Zotero URI: http://zotero.org/users/4316906/items/NDTABXJ4
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Rating: "**"
Full Citation: Oberman, K. (2023) ‘Refugees are Just People in Need of Refuge’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
- Thinking about semantic distinctions
    - What does this word mean? (what is a refugee?)
    - What moral property does it describe? (who cas a claim to refuge?)
    - How should we use the term? (what is the best institutional use of the term?)
- The reason your argument goes through is that there isn’t something lost when we 
- The reason we use words is normative. It is a thick ethical term. We use the term refugee to designate someone who has a claim, and 
- “rape victim” vs “refugee” One of these terms is describing a wrong, the other is describing a claim, 
- Normative reason for UN Refugee Convention usage
    - facing harm 
    - State refuses to provide for basic needs 
- Two purposes of a word
    - To say something about what we are describing
    - To say something about us as the describer
- Cutting at the moral joints
    - By degree or kind
    - We use these terms to pick out particular moral salience