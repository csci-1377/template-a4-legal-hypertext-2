---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Suez Detour
Takeaway: Commercial Impracticability Standard
Tags:
  - Impossibility
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1972
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: American Trading & Production Corp. v. Shell International Marine Ltd.
Status: Annotated
Date: 1972-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - P contracts with D to transport cargo from Texas to India for 4 million, rate based on Suez Canal route
> - No explicit condition in the contract saying taking Suez
> - Suez canal closes, P incurs 1.3 million extra costs (1/3 K) and doubles length going around Cape of Good Hope
> - P sues D for additional compensation

> [!note]+ Procedural History and Posture
> - TC dismisses complaint

- Issue: Was transport commercially impracticable, and therefore grounds for additional compensation?

> [!note]+ Holding (Mulligan): No
> - Commercial Impracticability: not technically impossible, but “extreme and unreasonable difficulty”
> - Increased cost was 1/3 contract price, not meeting standard (Mineral Park Land Co. v. Howard was 1,000% K, 33% sure doesn’t seem like it counts)
> - Disposition: Affirmed
