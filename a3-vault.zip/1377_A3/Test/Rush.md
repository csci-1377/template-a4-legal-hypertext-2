---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Motorcycle Double Damage
Takeaway: Shifting from primary rights to T&O test for claim preclusion
Tags:
  - Claim Preclusion
  - Stare Decisis
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1958
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Rush v. City of Maple Heights
Status: Annotated
Date: 1958-01-01
Jurisdiction: Ohio
---
> [!note]+ Facts
> - Motorcyclist injured, successfully claims property damage under negligency by city
> - Then sues for personal injuries from same negligence. 

> [!note]+ Procedural History and Posture
> - Trial court precludes negligence issue, but strikes D’s defense of claim preclusion for personal injury damages on ground that they are of a different kind.
> - Cites Vasu: a car that collides with a truck causing damages to the car. Insurance company pays the car driver for his car property damages and then sues the truck driver to get the money back. The car driver also sues the truck driver to get personal injury damages. The insurance company vs. truck owner (Case 1) for property damages ends in a loss for insurance company. In driver vs. truck (Case 2) for personal injuries, the truck owner says claim preclusion, you can’t split your claim for personal injuries and property damages into two suit.

- Issue: Does judgment for one kind of damages preclude a separate action for another kind from the same act?

> [!note]+ Holding(Herbert): Yes
> - T&O theory, not primary rights theory of “same claim”
> - Why would we bar a separate suit for injuries to arm and a leg, but not to arm and coat?
> - Prevents uneccessary delays, too many suits, encourages completeness
> - Disposition: Reverses

> [!note]+ Concurrence (Stewart): Yes, but we didn’t need to overrule Vasu to do it
> - Basically since this was dictum, I’m fine rejecting it.

> [!note]+ Dissent (Zimmerman): No, stare decisis!
> - We shouldn’t overturn our old rules so easily
> - Implicitly assumes the overrulling decision is not dicta?
