---
base: "[[Test.base]]"
In-Text Citation: (Sangiovanni, 2023)
Priority: Essential
Authors: Sangiovanni, Andrea
Title: Is There a Thing Called Moral Equality
Zotero URI: http://zotero.org/users/4316906/items/S56NY6XJ
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Sangiovanni, A. (2023) ‘Is There a Thing Called Moral Equality’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
> [!note]+ Intro
> - Moral equality: we are all equal in having something that generates significant, basic duties to all
> - But what is that something, who is in the scope, and what duties to we thus owe?
> - Rights-based non-consequentialists and welfare consequentialists are just talking about different things, not different interpretations of the same thing
> - So we shouldn’t talk about moral equality

> [!note]+ Non-consequentialist account
> - What is the property, shared by everyone, making everyone have the same rights?
>     - Must be a binary or range property
> - Problem 1: Based on psychological properties, which vary, so it seems like worth should too
> - Problem 2: Based on some higher-level principle like respect in accordance with degree of certain capacity, which isn’t egalitarian
> - It seems like we are committed to this regardless of finding some property x, so we should ground this commitment in other ways.

> [!note]+ Consequentialist account
> - Cares about welfare interests, so the only ones that count are those that have welfare in the first place.
> - But it is just saying the same interests should be treated the same, so doesn’t get us very far. 

> [!note]+ Role played by moral equality
> - Reducing social inequality
>     - Not based on an equal consideration of interests
>     - Instead about the wrongs of social status hierarchies
>     - Moral status hierarchies does not lead to social status hierarchies, and its rejection does not prevent them
>     - Social status is comparative in a way moral status isn’t
> - Animal ethics
>     - There is no social status hierarchy between animals and humans
>     - Social status is conferred, not posessed














