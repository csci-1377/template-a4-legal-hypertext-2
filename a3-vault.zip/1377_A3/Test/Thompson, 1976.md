---
base: "[[Test.base]]"
In-Text Citation: (Thompson, 1976)
Priority: Essential
Authors: Thompson, Judith Jarvis
Title: Killing, Letting Die, and the Trolley Problem
Zotero URI: http://zotero.org/users/4316906/items/HAEP7CUV
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Document
Rating: "*****"
Full Citation: Thompson, J.J. (1976) ‘Killing, Letting Die, and the Trolley Problem’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1976
---
- When we say “killing is worse than letting die” we can’t mean that for each and every case it is
    - Alfred hates his wife and wants her dead. He puts cleaning fluid in her coffee thereby and kills her.
    - Bert hates his wife and wants her deqd. She mistakenly puts cleaning fluid in her coffee, and he knows this and refuses to give her the antidote
- So why can we turn/deflect the trolley and kill one to save five but not cut up the patient to do so?
> [!note]+ Example
> - Harry is president and can do nothing, letting a bomb hit Manhattan, or he can deflect it onto Worcester
> - Irving is president with the same bomb, but he can’t deflect. Instead, he can launch another bomb on Worcester, killing them and exploding the other bomb harmlessly
> - Seems as if Harry can delfect, but Irving can’t detonate. But really? This isn’t clear to me.
> - What about sending another bomb to glance off like a pool ball, sending the first into space and the second down on Worcester?

    - Can’t be from a Principle of Moral Inertia
    - Perhaps can deflect “if and only if the one has no more claim against the trolley than any of the five.” This is just getting away from utilitarianism.
    - So it isn’t permissible to turn the trolley in *every *case, we just fill in an underdescribed case
> The fact that the one has no more claim than the five does make it permissible for us to deflect the pebble away from the one and towards the five; it does not make it permissible for us to shove the one away, bomb him, etc.

> But a *person* is not something un-owned, to be knocked about in order to bring about a better distribution of something else.

> What matters in these cases in which a threat is to be distributed is whether the agent distributes it by doing something to it, or whether he distributes it by doiung something to a person.