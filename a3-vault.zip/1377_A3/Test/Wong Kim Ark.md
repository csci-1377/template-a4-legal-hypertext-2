---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Returning to SF
Takeaway: "Three Exceptions to Birthright Citizenship (ambassador, enemy, indian). "
Tags:
  - CZC
Category:
  - Con Law
Abstract: ""
Page: 1046
Type: Case
Rating: "**"
Year: 1898
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: US v. Wong Kim Ark
Status: Annotated
Date: 1898-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Wong is born of Chinese parent immigrants
> - Gets a certificate saying he was born there
> - He leaves, tries to come back, is prohibited

> [!note]+ Procedural History and Posture
> - 

- Issue: Is this guy “under the jurisdiction” of the US?

> [!note]+ Holding (Gray): Yep.
> - Existing exclusions
>     - Native Americans born in tribal jurisdictions
>     - Ambassadors
>     - Enemy Invaders
> - BUT many foreign countries have abandoned birthright citizenship!
>     - That doesn’t matter…
> - So aliens residing in the country are “under the jurisdiction” of the US, and American’s abroad are not.





















