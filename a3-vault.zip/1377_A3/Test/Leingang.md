---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Weed Cutting Overhead
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1991
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Leingang v. City of Mandan Weed Board
Status: Annotated
Date: 1991-01-01
Year*: 1991
Jurisdiction: North Dakota
---
> [!note]+ Facts
> - Leingang gets contract for weeds on large lots
> - City gives some large lots to small lots contractor
> - Leingang sues for breach of contract

> [!note]+ Procedural History and Posture
> - Trial court awards damages based on City’s calculation
> - Leingang appeals to Supreme Court

> [!note]+ Arguments
> - Claimants- Leingang asks for damages = contract price - direct costs for those lots
> - Respondents- City offers damages = contract price * general profit margin (implicitly subtracting overhead costs) as calculated by tax returns

> [!note]+ Holding
> - Summary- Compensatory damages for breach = contract cost - direct (variable), not overhead (fixed) costs (since those were still incurred)
> - Disposition- Reversed and remanded

> [!note]+ Thoughts and Questions
> - Why not consider the work he was able to do in the time he would have been doing lots?
>     - Should it matter if he did find work then?
>     - If not included, he gets to make “double use” of overhead costs
>     - Incentive to get other party to breach?
>     - “can recover no more than would have been gained by full performance”
