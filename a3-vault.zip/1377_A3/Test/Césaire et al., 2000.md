---
base: "[[Test.base]]"
In-Text Citation: (Césaire et al., 2000)
Priority: Essential
Authors: |-
  Césaire, Aimé
  Césaire, Aimé
  Kelley, Professor of African-American Studies Robin D G
  Ca(c)Saire, Aima(c)
  C Saire, Aim
  Kelley, Professor of African-American Studies Robin D G
Title: Discourse on Colonialism
Zotero URI: http://zotero.org/users/4316906/items/W8H6FHFF
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This classic work, first published in France in 1955, profoundly influenced the generation of scholars and activists at the forefront of liberation struggles in Africa, Latin America, and the Caribbean. Nearly twenty years later, when published for the first time in English, Discourse on Colonialism inspired a new generation engaged in the Civil Rights and Black Power and anti-war movements. Aim(r) C(r)saire eloquently describes the brutal impact of capitalism and colonialism on both the colonizer and colonized, exposing the contradictions and hypocrisy implicit in western notions of OC progressOCO and OC civilizationOCO upon encountering the OC savageOCO, OC uncultured, OCO or OC primitive.OCO Here, C(r)saire reaffirms African values, identity, and culture, and their relevance, reminding us that OC the relationship between consciousness and reality are extremely complexOC It is equally necessary to decolonize our minds, our inner life, at the same time that we decolonize society.OCO An interview with C(r)saire by the poet Ren(r) Depestre is also included."
Type: Book
Rating: "***"
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=1114598
Full Citation: "Césaire, A. et al. (2000) Discourse on Colonialism. New York, UNITED STATES: Monthly Review Press. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=1114598 (Accessed: 1 March 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2000
---
> [!note]+ Intro
> - Two major problems of Western civilization
>     - Colonial problem
>     - Proletariat
> - What is colonization?
> > Bridgehead in a campaign to civilize barbarism, from which there may emerge at any moment the negation of civilization, pure and simple (40)
> 
>     - Not evangalization, philantrhopic enterprise, project for God, or attempt to extend the rule of law
>     - It is appetite and force
> - Problem isn’t contact
>     - Exchange is oxygen
>     - Colonization is just not the best
>     - …And also not a single human value can come from it
> - Effects
>     - Brutalizes the colonizer, degrades and awakens him to baser instincts
>     - Forces colonizer to see the other man as an animal, tends to transform himself into one
> - Concepts
>     - Negroes are big children
>     - White man’s burden

> [!note]+ What to do
> - Move forward, not return to pre-colonial times
> - Create a new society with all the productivity of modern times and the fraternity of olden days (52)

> [!note]+ Quotes
> > It is not the head of civilization that begins to rot first. It is the heart. (48)
> 
> > persistent bourgeois attempt to reduce the most human problems to comfortable, hollow notions (62) What has become of the bullwhip? … and the taxes… and the martyrs? innocent people murdered?
> 
> > The reader will have been able to judge how seriously one hsould take a thinker, who, while claiming to be dedicated to rigorous logic, sacrifices so willingly to prejudice and wallows so voluptuously in cliches (73)
> 
> > the only class that still has a universal mission, because it suffers in its flesh from all the wrongs of history, from all the universal wrongs: the proletariat (78)

> [!note]+ Questions
> - Don’t we need a solid counterfactual here?

> [!note]+ Thoughts
> - This is a sermon
> - Hypocrisy is of recent date: early colonists weren’t apologists (33)
> - No one protests all this bad stuff (39)
> - Uninformed nostalgia (Aztecs and Incas) 42
> - Societies were all communal, democratic, cooperative, and fraternal (44)
>     - Noble savage my ass
>     - Courteous civilizations (51)
> - Refutes colonial apologists by saying they can’t know what would have been, then makes claims to what would have been (46)
> - Uses dehumanizing, essentializing language of purity and disease to describe the capitalists and burgeoise. Don’t stoop that low (50, 52, 64, 68)














