---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: No Fishing Expeditions
Takeaway: A complaint must be “plausible on its face” (at least in Antitrust)
Tags:
  - Pleading
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 2007
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Bell Atlantic Corp. v. Twombly
Status: Annotated
Date: 2007-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Class action against two largest telecommunications providers
> - Local telephone service subscribers file a class action against the major telephone companies (ILECs) alleging violation of Section 1 of Sherman Antitrust Act by efforts to (1) inhibit growth of local telephone companies (CLECs) and (2) eliminate competition amongst themselves in areas where any one of them dominated. Included in the complaint was Paragraph 51
> - Complaint alleges that…
> > Defendants have entered into a contract, combination or conspiracy to prevent competitive entry in their respective local telephone and/or high speed internet services markets and have agreed not to compete with one another and otherwise allocated customers and markets to one another.

> [!note]+ Procedural History and Posture
> - District court (SDNY) dismisses complaint prior to response because no facts showing <u>conspiracy (agreement to restrain trad</u>e) No demonstration not <u>independent, self-interested conduct: concious parallelism</u> is fine.
> - Second Circuit reverses, arguing wrong standard applied, but includes that plead facts must "include conspiracy among the realm of `plausible' possibilities in order to survive a motion to dismiss," but follow Conley's "no set of facts" doctrine

- Issue: Should the complaint be dismissed for failure to state a claim?

> [!note]+ Holding (Souter): Yes, not plausible
> - Sherman Act section 1 applies only when there was an <u>agreement</u>, tacit or express to restrain trade, not independent action.
> - FRCP 8a2 required “grounds” for claim of relief
> - Count 1) crowding out competitors: all facts are just parallel actions (which are legal) and the assertion of agreement is conclusory
> > [FRCP 8a2 requires <u>more than labels and conclusions</u>, and a formulaic recitation of the elements of a cause of action will not do… 
> 
> > Asking for plausible grounds calls for <u>enough fact to raise a reasonable expectation that discovery will reveal evidence [of claim]</u>
> 
> > Factual allegations must be enough to raise a right to relief above the speculative level”
> - Count 2) not competing on each other’s turf: these companies just seem to be happy to continue behavior from old monopoly rule
> > sparse competition among large firms dominating separate geographical segments of the market could very well signify illegal agreement, but here we have an obvious alternative explanation.
> 
> > we do not require heightened fact pleading of specifics, but only <u>enough facts to state a claim to relief that is plausible on its face</u>.
> 
> > Because the plaintiffs here have not <u>nudged their claims across the line from conceivable to plausible</u>, their complaint must be dismissed.
> 
> Objections and Replies
> 
> 1. OBJ- We can avoid expensive discovery through “careful case managment
>     1. REP- No, we can’t, judges are bad at this, and it’s still expensive
> 2. OBJ- What about Conley’s “No set of facts?”
>     2. REP- This language should be retired, we can’t take it literally. The right standard is that once a claim has been stated adequately, it may be supported by showing any set of facts consistent with the allegations in the complaint. But that does not relieve you from having to state the claim adequately.
> 3. OBJ- FRCP 8 specifically focuses on notice pleading!
>     3. REP- Basically you can’t provide “fair notice” without some specificity/facts to get the “grounds” of the claim
> - Disposition: Reversed

> [!note]+ Dissent (Stevens +Ginsburg): No, it’s legally sufficient?
> - No clear line between facts and conclusions
> - Court regards the complaint as a “fishing expedition”
> - They claimed agreement in three separate places! Not for us to decide that it’s unlikely.
> - Plausibility is inconsistent with FRCP 8, which wants only legal sufficiency
> - Also this is concerningly trans-substantive… might apply to civil rights? (Foreshadowing Iqbal)
> - Conley has been around for 50 years, never questioned, no petitioners or amici have questioned it
> 
> > *Conley's* "no set of facts" formulation permits outright dismissal only when proceeding to discovery or beyond would be futile…. the pleading standard the Federal Rules meant to codify does not require, or even invite, the pleading of facts.
> 
> > It reflects a philosophy that, unlike in the days of code pleading, separating the wheat from the chaff is a task assigned to the pretrial and trial process.
> 
> - Part IV- Just Stevens (you really just like big corporations)