---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Agreement not to Raise Rent
Takeaway: ""
Tags:
  - Modification
  - Legal Duty
  - Consideration
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1936
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Levine v. Blumenthal
Status: Annotated
Date: 1936-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - Rental contract provides for increase, but tenant makes oral agreement to keep renting at the original price “until business improves”
> - They eventually leave, and landlord sues for unpaid rental increase

> [!note]+ Procedural History and Posture
> - Trial court finds for landlord

- Issue: Was the oral alteration to the rental contract binding?

> [!note]+ Holding (Heher): No
> - Something which someone has a legal duty to perform can’t count as consideration
> - No consideration for the alteration: landlord didn’t get anything for agreeing to keep rent lower.
> - Disposition: Affirmed