---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Northern
Authors: ""
Title: Can’t Sell the Team
Takeaway: ""
Tags:
  - LOI
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 2015
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Main Street Baseball, LLC v. Binghamton Mets Baseball Club, Inc.
Status: Annotated
Date: 2015-01-01
Jurisdiction: N.D.N.Y
---
> [!note]+ Facts
> - P is looking to buy D’s baseball team
> - They sign an Letter of Intent (LOI) to buy the team, which included for a 60-day “no shopping” period
> - They can’t agree and D eventually shops around after the 60 days, entering into another LOI
> - P sues for breach, demanding specific performance and injunction against other sale

- Issue: LOI? Injunction?

> [!note]+ Holding (Hurd): Yes, at least to negotiate, and yes, to *sell*
> - Is this a binding LOI?
>     - Maybe to sell, but that’s for a jury to decide, we won’t award specific performance here
> - Elements
>     - Irreparable harm
>     - Balance of interests/equities
>     - Public interest
> - Disposition: Injunction until further notice
