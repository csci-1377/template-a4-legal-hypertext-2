---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/2023833
In-Text Citation: (Frankfurt, 1969)
Priority: Essential
Authors: Frankfurt, Harry G.
Title: Alternate Possibilities and Moral Responsibility
Zotero URI: http://zotero.org/users/4316906/items/YUXPZ7LL
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Journal Article
Rating: "*****"
URL: https://www.jstor.org/stable/2023833
Full Citation: "Frankfurt, H.G. (1969) ‘Alternate Possibilities and Moral Responsibility’, The Journal of Philosophy, 66(23), pp. 829–839. Available at: https://doi.org/10.2307/2023833."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1969
---
The principle of alternate possibilities is demonstrably false

> [!note]+ The Principle
> - that a person is only morally responsible for what he has done only if he could have done otherwise
> - Not true, because a person can do something in circumstances that leave him no alternative because these circumstances may play no role in bringing about that he does it.

> [!note]+ Coersion
> - Not necessarily incompatible with responsibility
> - Jones decides to do something, then is threatened to do it, then does it.
>     - Maybe unaffected by the threat
>     - Or stamped by the threat
>     - Or impressed by it, but prior motives still function in action

> [!note]+ Black
> - Will resort to some means overriding agency if Jones doesn’t act
> - Jones bears the same responsibility as if Black weren’t in the picture because his presence plays no role in the explanation of why he did it

> [!note]+ Quotes
> We often do, to be sure, excuse people for what they have done when they tell us (and we believe them) that they could not have done otherwise. But this is because we assume that what they tell us serves to explain why they did what they did. (837-838)
> 
> If it was causally determined that a person perform a certain action, then it will be true that the person performed it because of those causal determinants (838).
> 
> The principle of alternate possibilities should thus be replaced, in my opinion, by the following principle: a person is not morally responsible for what he has done if he did it only because he could not have done otherwise (838).
> 
> he will not be morally responsible for what he has done if he did it only because he could not have done otherwise, even if what he did was something he really wanted to do (839).














