---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Chancery
Authors: ""
Title: Sophisticated Ambiguity
Takeaway: "Forthright Negotiator Principle: the subjective understanding of one party to a contract may bind the other party when the other party knows or has reason to know of that understanding."
Tags:
  - Ambiguity
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 2007
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United Rentals, Inc. v. RAM Holdings, Inc.
Status: Annotated
Date: 2007-01-01
Jurisdiction: Delaware
---
> [!note]+ Facts
> - Two sophisticated parties in contract with integration clause in dispute
> - Leverage Buyout: RAM is buying out United Rentals and their debt
> - Really Cerberus is, but they use shell companies to avoid liability
> - RAM writes merger agreement with United Rentals for $7 Billion
> - Delay between signing of contract and completing merger
> - What can United Rentals get if the Cerberus pulls out?
>     - Reverse termination fee from Cerberus for $100 million
>     - Equity commitment to RAM holdings for $1.5 billion
> - Cerberus wants to pull out, but recognizes it has to pay at least $100m
> - UH sues parent company (RAM Holdings) to get them to sue Cerberus for equity commitment
> - In one provision of the contract, an equitable remedy is guaranteed
> - In another, says no equitable remedy under certain circumstances
> - Each company argues for their interpretations, court finds more than one reasonable, so ambiguous

- Issue: Is there an equitable remedy for breach?

> [!note]+ Holding: No on summary judgment, it’s ambiguous
> - Extrinsic evidence too muddled to show common understanding
> - Forthright Negotiator Principle: the subjective understanding of one party to a contract may bind the other party when the other party knows or has reason to know of that understanding.
> - Defendent understood it to preclude remedy, and plaintiffs knew or should have known, so failed to meet burden

> [!note]+ Thoughts and Questions
> - Why did this happen? 
>     - The assessed probability is really low at the moment of the contract, so resolving ambiguity might not be worth the deal not going all the way through.
>     - Never enough time to do all the important legal work
>     - Lowest probability contingencies are often left unaddressed
>     - Time is a bigger problem than money in M&A
>         - Can’t get more lawyers because they’re unlikely to agree
