---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: No Third Party? I’m Shocked.
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1978
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Owen Equipment v. Kroger
Status: Annotated
Date: 1978-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Plaintiff, Mrs. Kroger (Iowa), sues Omaha Public Power (Nebraska Corp) for wrongful death of her husband, when steel crane he is walking by comes too close to high tension wire. The Company in turn files a 3rd party complaint (FRCP 14, later in the course) against Owen Equipment alleging that it owned and operated the crane and its negligence was proximate cause of Mr. Kroger’s death. Pl amends her complaint (later in course) to include Owen as defendant, which is allowed. Omaha seeks summary judgment, gets it, and drops out of the case, leaving Owen as the sole defendant.

> [!note]+ Procedural History and Posture
> - At trial, Owen now says its principal place of business is actually in Iowa
>     - (it turns out that the reason was that the Missouri River had a avulsed (changed course) and that doing so moved the boundary for the state moving Owen from Nebraska into Iowa.) 
> - Owen moves for dismissal for lack of SMJ.
> - District court denies motion
> - Court of appeals affirms, in part because Owen had concealed Iowa domicile

- Issue: When getting FSMJ by diversity, can a plaintiff amend claim to include a third-party defendent without any other basis for SMJ?

> [!note]+ Holding (Stewart): No, the court doesn’t have the power
> - USC 1332(a)(1) defines diversity jurisdiction and requires complete diversity.
> - If we allow a case w/o complete diversity to proceed, then it would allow gamesmanship. 
> 
> > To allow the requirement of complete diversity to be circumvented as it was in this case would simply flout the congressional command.
> 
> - Disposition: Reversed
