---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: CFPB Showdown
Takeaway: Modern Structural Analysis
Tags:
  - Removal
  - SOP
Category:
  - LegReg
  - Con Law
Abstract: ""
Page: 720
Type: Case
Rating: "*****"
Year: 2020
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Seila Law LLC v. CFPB
Status: Annotated
Date: 2020-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - CFPB led by single director, authority to regulate “unfair, deceptive, or abusive acts”
> - Cannot be removed except for “innefficiency, negligence, or malfeasance”

- Issue: Is this structure constitutional?

> [!note]+ Holding (Roberts): No
> - Myers governs with only two exceptions
> > The entire “executive Power” belongs to the President alone… The President’s removal power is the rule, not the exception.
> 
>     - Humphrey’s Executor: nonpartisan, multimember commission of experts to perform legislative and judicial, but not “exercise any executive power”
>         - But maybe FTC didn’t meet these criteria even at the time, and it certainly exercises executive power now.
>     - Morrison: inferior officers
> 
> > “Perhaps the most telling indication of [a] severe constitutional problem” with an executive entity “is [a] lack of historical precedent” to support it.
> 
> - CFPB is quintessentially executive, single head, and principal officer (basically unprecedented w/o removal restrictions)
> - We decline to extend the two exceptions, instead sticking with Myers.

> [!note]+ Concurrence/Dissent (Thomas): No, and overrule *Humphrey’s*
> - There is no such thing as quasi-legislative/judicial power allowed by non-delegation but not part of executive power vested in President
> - Congress can’t “create agencies that straddle multiple branches of government”
> 
> > Humphrey’s executioner does not even satisfy it’s own exception

> [!note]+ Dissent (Kagan): Yes, it is.
> - Constitution leaves disagreements about administrative structure up to Pres and Congress. It doesn’t say anything about removal authority
> - Take care clause is about duty, not power
> - Nothing in Humphrey’s turned on organizational features
> - Morrison extended Humphrey’s domain, becoming the rule, not another exception
> - Unclear how a single agency head is harder to control than an independent agency. If anything, it’s the other way around.
> - History: 
>     - Congress has always been deeply divided wrt removal power
>     - CFPB isn’t actually unusual
