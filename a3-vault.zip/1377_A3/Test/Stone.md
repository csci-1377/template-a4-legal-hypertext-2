---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: ""
Takeaway: Police Powers are implicit exception to KC (deferential means-ends test)
Tags:
  - KC
Category:
  - Con Law
Abstract: ""
Page: 998
Type: Case
Rating: "**"
Year: 1880
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Stone v. Mississippi
Status: Annotated
Date: 1880-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Miss charters lottery to fund things from after war
> - Permission to run lottery so long as you pay Miss $1k per year (+ 1/2% profits)

- Issue: Is the abolition of the state lottery charter a KC violation?

> [!note]+ Holding (Waite): No
> - It has to be implicit that the legislature can abolish things
> - Legislatures can’t contract away a future legislature’s police powers.
> - The legislature can *make *promises (charter wasn’t unconstitutional), it just can’t be forced to keep them
> - [[Chinese Exclusion Case]] paraphrases Stone by saying “sovereign always has to be able to repeal the actions of the sovereign”





















