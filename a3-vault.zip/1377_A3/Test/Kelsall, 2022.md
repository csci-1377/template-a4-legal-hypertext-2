---
base: "[[Test.base]]"
In-Text Citation: (Kelsall, 2022)
Priority: Essential
Authors: Kelsall, Joshua
Title: The Rationality of Vaccine Hesitancy
Zotero URI: http://zotero.org/users/4316906/items/8AAGWPN8
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Journal Article
Rating: "**"
Full Citation: Kelsall, J. (2022) ‘The Rationality of Vaccine Hesitancy’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
