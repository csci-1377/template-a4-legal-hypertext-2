---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phc3.12719
In-Text Citation: (Horton, 2021)
Priority: Essential
Authors: Horton, Joe
Title: Partial aggregation in ethics
Zotero URI: http://zotero.org/users/4316906/items/B69IMF8M
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: Is there any number of people you should save from paralysis rather than saving one person from death? Is there any number of people you should save from a migraine rather than saving one person from death? Many people answer ‘yes’ and ‘no’, respectively. The aim of partially aggregative moral views is to capture and justify combinations of intuitions like these. These views contrast with fully aggregative moral views, which imply that the answer to both questions is ‘yes’, and with non‐aggregative moral views, which imply that the answer to both questions is ‘no’. In this article, I review the most natural and inﬂuential ways of developing partially aggregative views and explain the main problems they face.
Type: Journal Article
Rating: "**"
URL: https://onlinelibrary.wiley.com/doi/10.1111/phc3.12719
Full Citation: "Horton, J. (2021) ‘Partial aggregation in ethics’, Philosophy Compass, 16(3). Available at: https://doi.org/10.1111/phc3.12719."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2021
---
> [!note]+ Intro
> - How many people should you save from paralysis over one from death? How about headaches?
>     - Intuitively, it seems like no number for migranes.

> [!note]+ Potential Solutions
> - Minimax Complaint: Always minimize strongest complaint
> - Complete Aggregation: Save some number from headaches (author’s prefered)

> [!note]+ Axiological Partial Aggregation
> - Principles
>     1. We should make things go best, other things equal
>     2. It is worse if sufficiently large number siffer moderately than one person suffers severely
>     3. It is worse if one suffers severely than if any number suffer minorly
> - Challenge 1: Non-Infinite Severity
>     - If this is quantifiable, and severe burden isn’t infinite, then minor can add up and pass it
> - Responses
>     - Stop adding
>     - Add asymptotically
>     - Use multiple scales
> - Challenge 2: Deontic Cycles
>     - Moderate over Severe, Severe over Minor, and Minor over Moderate
>     - Have to deny ‘worse than’ is transitive

> [!note]+ Purely Deontic Partial Aggregation
> - Intro
>     - About aggregating *relevant* claims (ARC), avoiding axioms above
>     - A claim is not relevant if it should be withdrawn in comparison to a larger one
> - Challenges
>     - Doesn’t intuitively apply when you know others are making the same claim as you
>     - Staircase of Contradiction to Deontic Cycle
>         - B (2 of pretty bad) worse than A (one of really bad) C worse than B etc. but could say A worse than Z
>         - Violates the Independence of Irrelevant Alternatives
>     - Counterintuitive Implications of Risk (not discussed)