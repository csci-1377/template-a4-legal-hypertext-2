---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Ripping Off a Greek
Takeaway: A deal’s a deal (no recognition of duress)
Tags:
  - Duress
  - Consideration
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1949
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Batsakis v. Demotsis
Status: Annotated
Date: 1949-01-01
Jurisdiction: Texas
---
> [!note]+ Facts
> - Hitler has invaded Greece, and Greek jews are trying to evacuate
> - P offers D 500,000 Drachma (25 USD) in return for $2,000 USD at 8% interest
> - D accepts, signing statement saying she received 2k USD 
> - P sues D in 1947 for principal and interest

> [!note]+ Procedural History and Posture
> - TC awards $750 principal + interest (calculated present value of 500,000 drachma?)
> - P appeals

- Issue: Does D owe P all 2k + interest?

> [!note]+ Holding (McGill): Yes
> - D- But that’s a completely unfair deal: my client didn’t know the conversion/was under duress at the time.
> - P- But it’s still a binding contract. There was offer, acceptance, and consideration. Also, you don’t know it was a bad deal. Maybe that money, in that context, really was worth that to D
> - There’s no such thing as inadequate consideration. It’s all or nothing.
> - Disposition: Modified
