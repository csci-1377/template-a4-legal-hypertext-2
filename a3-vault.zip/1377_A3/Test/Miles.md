---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Uknowing Oxy Delivery
Takeaway: Mens Rea does not always apply (attendant circumstances, legislative history, and statutory scheme)
Tags:
  - Mens Rea
Category:
  - Crim
Abstract: ""
Page: 183
Type: Case
Rating: "**"
Year: 2017
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Miles
Status: Annotated
Date: 2017-01-01
Jurisdiction: South Carolina
---
> [!note]+ Facts
> - Miles delivers package, apprehended
> - Admits probably drugs in the package, denies knowing what is in it
> - Turns out it’s more than 4 grams of oxy.
> - Statute prohibits *knowingly* possessing “more than four grams” of illegal drugs

> [!note]+ Procedural History and Posture
> - Jury asks the judge whether Miles has to know the kind/amount of drug
> - Trial court instructs the jury that the State did not have to prove Miles knew drugs were oxycodone.

- Issue: Does knowingly apply to the specific type of drugs?

> [!note]+ Holding (Hill): No
> - Supreme Court generally applies “knowingly” to each element, verb, and object of the verbs.
> - But not always. Similar statutes don’t have this distinction. so we shouldn’t here.
> - Legislature can’t have meant the guy to need a chemistry degree or be “Walter White” to be convicted.
> - Caption: Trafficking in illegal drugs is a pretty broad argument
> - Also, consider the rule of lenity. Doesn’t really apply here, the rule not to traffick in drugs is not only clear but “fluorescent.”
> - Disposition: Affirmed





















