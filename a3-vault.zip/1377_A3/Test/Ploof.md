---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Feeling Unmoored
Takeaway: Necessity undermines right to exclude
Tags:
  - Nominalism
  - Trespass
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1908
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ploof v. Putnam
Status: Annotated
Date: 1908-01-01
Jurisdiction: Vermont
---
> [!note]+ Facts
> - Ploofs are in a sloop in a storm on Lake Champlain
> - They are French Canadian, subject to ethnic conflict
> - They “were compelled to” moor on Putnam’s dock
> - Putnam’s servant unmoors the sloop
> - Sloop crashes on the shore, hurting the Ploofs

- Issue: Were the Ploofs trespassing, and if so did Putnam have the right to unmoor them?

> [!note]+ Holding (Munson): No and no: necessity justifies entries on land and interference with personal property
> > One may sacrifice the personal property of another to save his life or the lives of his fellows

> [!note]+ Thoughts and Questions


