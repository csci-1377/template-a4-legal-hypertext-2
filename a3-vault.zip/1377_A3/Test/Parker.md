---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Musical v. Western
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1970
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Parker v. Twentieth Century Fox Film Corp.
Status: Annotated
Date: 1970-01-01
Year*: 1970
Jurisdiction: California
---
> [!note]+ Facts
> - Parker guaranteed income in contract for musical in California
> - Fox cancels musical, offers her a job with the same salary in a Western in Australia
> - Parker refuses the new job, demands contract price for previous role

> [!note]+ Procedural History and Posture
> - Trial court awards Parker contract price on summary judgment
> - Fox appeals

> [!note]+ Arguments
> - Claimants- The new job is worse (Australia, Western), so I didn’t need to take it.
> - Respondents- No, not really, it’s not our fault you didn’t the job.

> [!note]+ Holding
> - Summary- The new job is worse, so Parker should get paid for the old one. 
> > the measure of recovery by a wrongfully discharged employee is the amount of salary agreed upon for the period of service, less the amount which the employer affirmatively proves the employee has earned or with reasonable effort might have earned from other employment… the employee's rejection of or failure to seek other available employment of a different or inferior kind may not be resorted to in order to mitigate damages.
> - Disposition- Upheld

> [!note]+ Concurrence/Dissents
> Dissent- This is a factual issue, so the court shouldn’t have ruled on it through summary judgment

> [!note]+ Thoughts and Questions
> - They didn’t really consider whether she could have (or did) find a different job during the shooting of the first one. How could that have been calculated?
> - This shows why fact-finding should be left to a jury? Would a jury have been better?

> [!note]+ Class Notes
> - Judicial Notice is at issue, something like common knowledge that judges should know, so we don’t need to argue about the matter of fact.
