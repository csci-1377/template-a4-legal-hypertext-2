---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/17449626.2012.705786
In-Text Citation: (Behrens, 2012)
Priority: Essential
Authors: Behrens, Kevin Gary
Title: Moral obligations towards future generations in African thought
Zotero URI: http://zotero.org/users/4316906/items/BTPZ2YG6
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Journal Article
Rating: "***"
URL: http://www.tandfonline.com/doi/abs/10.1080/17449626.2012.705786
Full Citation: "Behrens, K.G. (2012) ‘Moral obligations towards future generations in African thought’, Journal of Global Ethics, 8(2–3), pp. 179–191. Available at: https://doi.org/10.1080/17449626.2012.705786."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2012
---
> [!note]+ Notes
> > [!note]+ Two notions in African thought useful for Western ecophilosophy
> > 1. Environment is a communal resource
> >     1. Land is borrowed
> >     2. Cannot be individually owned
> > 2. We should express gratitude to past generations by helping future ones (indirect, communal reciprocity)
> >     3. This interconnectedness is obvious to many Africans
> >     4. Does not require buying into metaphysical beliefs
> >     5. Trans-generational rights are best seen as communal
> 
> > [!note]+ Problems with extending contemporary moral duties to future generations
> > - Can’t know who they will be
> > - Can’t know wants or needs
> > - They can’t reciprocate
> > - We aren’t motivated to help them
> > - They can’t have rights like we have them
> 
> > [!note]+ The problem of the environment is particularly difficult because it…
> > - Is spatially and temporally dispersed
> > - Requires global cooperation
> > - Fails to engage affective moral judgement, merely dispationate, analytical
> 
> > [!note]+ Terms
> > - Anamnestic solidarity: that of rememberance (not forgetting)
> > - Temporal myopia
> > - The land: environment broadly speaking
> > - Gratitude and gratefulness: the latter need not have an object, potentially conceived of as a virtue
> > - Ubuntu (human-ness)
> > - Ukama (relationality)

> [!note]+ Questions
> - What are non-person, morally considerable entities?
> - What is the threshold of “in good shape” here?
>     - As good as we have it?
>     - Enough to sustain life?
>     - Behrens is almost contractarian in his answer. 
> > No generation could ask of its predecessors more than they should anticipate these basic needs, and try to ensure that they can be fulfilled into the indefinite future.
> - How is our conception affected by our metaphor?
>     - Community, Partnership, Circle, Web, Chain?
> - What is implied by the difference between borrowing and sharing?
>     - Do we need to be in a community with someone we borrow from to see obligations to them?
>     - What would the implications be for property rights if land is borrowed?
>         - Pay some amount if it were “less valuable?” How should we calculate this value?
> - Why is modern Western society different?
>     - Because we, largely, haven’t been on the land very long?
> - Is cultivating an “attitude” enough to give rise to obligations?
>     - This is the problem with applying virtue ethics to society, it struggles to give rise to obligations
>         - We aren’t under an obligation to be good.
>     - If any obligation of indirect reciprocity exists, it is general. 
>         - Hitchhiker, mentor, parents, 
>     - Maybe this isn’t such a barrier. We simply recognize that our moral code arises from ethical views, and that our laws then arise from the code, each at an increasing level of construction.

> [!note]+ Thoughts
> - Behrens almost gets contractarian 
> - Basing obligations to future generations on actions of past ones makes them contingent
>     - Ensures a cycle of virtue or vice, but does not determine which
>     - The fact the land is preserved might not be from stewardship, but simply a lack ability to harm it further
> - The problem of indeterminate individuals isn’t unique to the future, as long as we abandon the notion of a soul
>     - The only thing required for recognizing a trans-temporal self is continuity
>     - We can apply this communally across time like we apply it to an individual across time
> - The connections among generations, like those among individuals, are promarily those of story, not biology. It seems as if we can say that there exists some objective link between us and those around us, but to actually describe it requires describing and creating narratively constituted identities.
>     - If we have a duty of honoring memory, this means we have a duty to form and maintain those narrative bonds that give rise to more substantive commmitments. 
>     - Because generations interlock, they are continuous. 