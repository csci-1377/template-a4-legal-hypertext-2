---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: That’s my Shit!
Takeaway: 24 hours to leave while retaining posession rights
Tags:
  - Posession
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1871
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Haslem v. Lockwood
Status: Annotated
Date: 1871-01-01
Jurisdiction: Connecticut
---
> [!note]+ Facts
> - Haslem pays helpers to gather manure into heaps
> - Lockwood finds the piles and takes them
> - Haslem sues for trover (conversion)

> [!note]+ Procedural History and Posture
> - Trial court finds for Lockwood

- Issue: Does someone who finds worthless property and add value to it have a right to leave it undisturbed to get it later?

> [!note]+ Holding: Yeah, he should. 24 hours seems right
> - There’s a seaweed statute for 24 hours

> [!note]+ Thoughts and Questions
> - Would it matter if he just found something valuable? (Yeah? mixing labor is important)
> - Would it matter if he posted a sign claiming a right? (A bit, but not much. Still constrained by how long it’s reasonable to leave it)
