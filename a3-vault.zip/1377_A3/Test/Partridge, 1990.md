---
base: "[[Test.base]]"
In-Text Citation: (Partridge, 1990)
Priority: Essential
Authors: Partridge, Ernest
Title: On the Rights of Future Generations
Zotero URI: http://zotero.org/users/4316906/items/JEAVIE26
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Partridge, E. (1990) ‘On the Rights of Future Generations’, p. 17.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1990
---
> [!note]+ What are they?
> - Imperfect “duties of benificence”
> - Perfect duties, required *now*
>     - Stringency and urgency
> - Not an expansion of rights like “rights of nature”
> - Grounded in *interests* and *valid claims *of beings which can be said to be harmed *in and of themselves*
> - Entails duties
> - Limited to situations between *inevitability* and *impossibility*
>     - Ought implies can and yet might not

> [!note]+ What characterizes people?
> - Articulate language
> - Self-concept
> - Self-conciousness
> - Time perspectives
> - Hypothetical (practical) thinking
> - Abstract reflection
> - Responsiveness to moral principles
> - In sum “moral agency”

> [!note]+ Differences between actual and future persons
> - Temporal Remoteness
> - Incapacity
> - Non-Actuality
> - Indeterminacy

> [!note]+ Objections
> 1. Re-Population Paradox
>     - Problem: attempts to benefit the future will affect “no one”
>     - Solution: we can be bound *in general*, not just to individuals
> 2. Time-Span Argument
>     - Problem: Time seems to have a discount factor
>     - Solution: No, that was our foresight and capacity to effect, and now both stretch farther. The real discount factor is probability, efficacy, and choice.
>     - Thought: This acknowledges how we are bound it contingent upon our perspective
> 3. No-Claims
>     - Problem: They can’t make claims (to demand or enforce), so can’t have rights
>     - Solution: We act as proxies for things we treat as having legal rights already (kids, coma, etc.) We can all represent posterity like this
>     - Thought: He treats legal rights as the only constructs here. Moral are too. Thus, is his claim empirical or expressivist?
> 4. Non-Actuality
>     - Problem: Rights need to belond to actual, not possible persons
>         - Posterity is “merely imaginary” (potential harems)
>         - Posterity’s rights only apply in their own time (caveman lights)
>     - Solution: 
>         - They are imaginary, but probability is what matters here
>         - This only makes sense looking backward, not forward (cedars of Lebanon) while the issues are still “live”
>         - The fact that they *will* have rights can impose duties now
>         - This is why infants have rights: if they stayed babies, then we would think of them more like pets.
> 5. Indeterminacy
>     - Problem: Rights ascriptions to groups only make sense when we can identify individuals
>     - Solution: No, not really (campsite cleanup)
>         - Takes the form of an “obligation-function”
>             - Galen Pletcher: For any X, if x is a person who wants to camp at this site, then x has a right to a clean campsite
>     - Thoughts: This means duties correspond in some way to rights, but not always directly. So we can have a duty even if the right doesn’t yet exist.

> [!note]+ General Principles
> - Hasty generalization: objections apply to certain kinds of rights, not rights in general
> - So future people have special kinds of rights
> - Active/Passive
>     - Active is right to act in a certain way
>     - Passive is right not to be acted upon in a certain way
> - In Rem/In Personam
>     - In Personam are held against specific persons
>     - In Rem are held against the “world at large”
> - Positive/Negative
>     - Positive is right to another person’s actions
>     - Negative is a right to their omission or forebearance
> - Denotative/Designative
>     - Denotative rights belong to identifyable individuals (in personam duty)
>     - Designative rights belong to to groups (in rem duty)
>         - But could we have in rem duties because of probable corresponding denotative rights? Why do we need to say designative rights actually exist?

> [!note]+ Definitions
> - Respect (Joel Feinberg): to think of him as a potential maker of claims