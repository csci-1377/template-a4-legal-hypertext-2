---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Abortion
Takeaway: "Right to privacy includes abortion: first strict scrutiny."
Tags:
  - SDP
Category:
  - Con Law
Abstract: ""
Page: 121.1
Type: Case
Rating: "***"
Year: 1973
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Roe v. Wade
Status: Annotated
Date: 1973-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Roe (Norma McCorvey) does not want to get prosecuted under a Texas law with an abortion ban
> - Sues to enjoin officer from enforcing the law

> [!note]+ Procedural History and Posture
> - 

- Issue: Does the abortion ban violate sub DP?

> [!note]+ Holding (Blackmun): Yes
> - Fundamental liberty at stake: “a woman’s decision whether or not to terminate her pregnancy” or “right to personal privacy”
> - Weighed against
>     - Preserving and protecting the health of a pregnant woman
>     - Protecting the potentiality of human life
>     - Not right to life of the fetus
> > The word “person,” as used in the 14th Amendment, does not include the unborn
> - This interest becomes “compelling” at viability
>     - First Trimester: No regulation
>     - Second Trimester: Only to protect woman’s health and safety
>     - Third Trimester: To protect “potential life”
>         - This is after viability

> [!note]+ Dissent (Rehnquist): No, this is Lochner all over again.
> - There have been anti-abortion laws on the books for a long time, so how can it be fundamental?

> [!note]+ Dissent (White): No, this is judicial activism
> - This is “an excercise of raw judicial power” and an “improvident and extravagant excercise of the power of judicial review”





















