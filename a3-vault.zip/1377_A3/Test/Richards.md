---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Truck Driver Passenger Release
Takeaway: Example of unconscionable contract with a vague test
Tags:
  - Unconscionability
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1944
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Richards v. Richards
Status: Annotated
Date: 1944-01-01
Jurisdiction: Wisconsin
---
> [!note]+ Facts
> - P is wife of truck driver
> - P signs form to allow ride with him (and also release company from liability)
> - Wife is injured in crash
> - Sues (husband?) for negligence and vicarious liability to company

> [!note]+ Procedural History and Posture
> - Circuit Court: summary judgment for defendant, dismissing complaint with prejudice
> - Court of Appeals: affirms

- Issue: Is the exculpatory contract valid?

> [!note]+ Holding (Abrahamson): No, it’s void against public policy
> - Exculpatory contracts are not favored, but not automatically invalid. This one is invalid for three reasons
>     1. Served two purposes, not clearly distinguished (authorization and release of liability)
>     2. Extremely broad and over-inclusive
>     3. Standardized agreement, little opportunity for negotiation
> - Disposition: Reversed and remanded

> [!note]+ Dissent (Day): Yes, and the majority’s reasons don’t hold up
> - The better test is whether the release covers uncontemplated situations. This one was definitely contemplated (cross out what’s unenforceable)
> - None of the three components are actual legal rules
>     - The two purposes are distinguished
>     - The agreement was broad, but this situation was well within contemplation by parties
>     - We can’t just prohibit standardizing releases, and parties don’t have time for bargaining all the time
> - Administrability and clarity concerns. Unclear how a company could draft a valid release and how we should interpret one