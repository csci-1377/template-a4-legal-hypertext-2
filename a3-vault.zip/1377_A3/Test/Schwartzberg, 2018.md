---
base: "[[Test.base]]"
In-Text Citation: (Schwartzberg, 2018)
Priority: Recommended
Authors: Schwartzberg, Melissa
Title: "Review of Law’s Abnegation: From Law’s Empire to the Administrative State"
Zotero URI: http://zotero.org/users/4316906/items/4D69XNIL
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/26617629
Full Citation: "Schwartzberg, M. (2018) ‘Review of Law’s Abnegation: From Law’s Empire to the Administrative State’, Political Theory, 46(6), pp. 980–986."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2018
---
