---
base: "[[Test.base]]"
DOI: https://doi.org/10.36280/AFPiFS.2019.1.63ENG
In-Text Citation: (Sopiński, 2020)
Priority: Essential
Authors: Sopiński, Michał
Title: Neil McCormick’s Theory of Legal Reasoning and Its Evolution
Zotero URI: http://zotero.org/users/4316906/items/CK4Y8B4I
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: This paper traces, examines and demonstrates Neil MacCormick’s theory of legal reasoning and its evolution. MacCormick’s views shaped gradually, therefore his theory could be divided into two main stages. Thus, a diachronic approach is justified. The aim of this paper is to analyse the difference between the theses of the theory of legal reasoning explained in Legal Reasoning and Legal Theory (1978) and general revisions to this theory marked in Rhetoric and the Rule of Law (2005). According to the author, the most important change in MacCormick’s theory of legal reasoning is the re-examination of the role of deductive reasoning in the process of judicial reasoning. This change leads to extension of the logical aspects of MacCormick’s theory of legal reasoning (legal syllogism) to include rhetorical aspects (argumentative character of law) and ethical aspects (the idea of the rule of law). The evolution of MacCormick’s theory of legal reasoning seems to be a model example of the changes in contemporary philosophy of law.
Type: Journal Article
URL: http://archiwum.ivr.org.pl/2835/neil-mccormicks-theory-of-legal-reasoning-and-its-evolution/
Full Citation: "Sopiński, M. (2020) ‘Neil McCormick’s Theory of Legal Reasoning and Its Evolution’, Archiwum Filozofii Prawa i Filozofii Społecznej [Preprint]. Available at: https://doi.org/10.36280/AFPiFS.2019.1.63ENG."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2020
---
