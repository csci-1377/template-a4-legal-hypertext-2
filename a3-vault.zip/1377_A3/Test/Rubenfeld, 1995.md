---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/797060
In-Text Citation: (Rubenfeld, 1995)
Priority: Recommended
Authors: Rubenfeld, Jed
Title: Reading the Constitution as Spoken
Zotero URI: http://zotero.org/users/4316906/items/8KQPET8Z
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/797060
Full Citation: "Rubenfeld, J. (1995) ‘Reading the Constitution as Spoken’, The Yale Law Journal, 104(5), pp. 1119–1185. Available at: https://doi.org/10.2307/797060."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1995
---
