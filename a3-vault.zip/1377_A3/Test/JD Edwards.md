---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Consultant’s Privelege
Takeaway: Exception to breach induction liability
Tags:
  - Beneficiary
  - Posner
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1999
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: JD Edwards & Co. v. Podany
Status: Annotated
Date: 1999-01-01
Jurisdiction: Seventh Circuit
---
> [!note]+ Facts
> - SNE (Window Manufacturer) contracts with P, JD Edwards, to supply software
> - SNE hires Mercer, which employs D Podany to do “sniff test”
> - D says P contract is a bad idea, instructs to stop paying

> [!note]+ Procedural History and Posture
> - Trial finds for D

- Issue: Does the “consultant’s privelege” protect from inducing breach liability?

> [!note]+ Holding (Posner): No
> - Consultant’s privelege grants qualified immunity
>     - Scope of engagement √
>     - Good faith/Honest advice X (or at least not enough to overrule jury)
>         - Didn’t know much
>         - Stood a lot to gain
>         - Advice was ultimately bad
> - Disposition: Affirmed