---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Plenary Postmaster
Takeaway: "Removal Flows with Appointment (at least for purely executive positions): Unitary Executive Theory"
Tags:
  - Removal
Category:
  - LegReg
  - Con Law
Abstract: ""
Page: 710
Type: Case
Rating: "****"
Year: 1926
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Myers
Status: Annotated
Date: 1926-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Statute says postmasters both appointed and *removed* by pres with Senate advice/consent
> - Pres (really his wife, he had a stroke) fires postmaster without Senate consent
> - Postmaster demands pay until end of his normal term

- Issue: Does pres have plenary removal power? (is Tenure of Office Act unconstitutional?)

> [!note]+ Holding (Taft): Yes
> - Unitary Executive Theory: officers are alter egos of president
> - Text: No express removal provision, but
>     - Vesting clause 
>     - Take Care clause (oath of office)
> - Pragmatism: If we don’t have protection for the president, we get something* horrible*, like Reconstruction.
> - Public Meaning: In England, considered incedental to executive appointment power
> - History (Decision of 1789): Congress @ first session agreed that statutes didn’t need to expressly give pres removal power because implied
> - Emphasis on Hamilton’s general interpretation of executive power
> - Historical Practice: “a contemporaneous legislative exposition of the constitution when the founders of our government and framers of our Constitution were actively participating in government affairs, acquiesced in for a long term of years fixes the construction to be given its provisions”
> - Power of removal is incedent to appointment, not to its advice/consent
> - If Congress were given this power, would have been mentioned

> [!note]+ Dissent (Holmes): No
> - Vesting clause, take care clause are “spider’s webs” inadequate to control.
> - Congress created this office and can abolish it
