---
base: "[[Test.base]]"
In-Text Citation: (Driver, 2005)
Priority: Recommended
Authors: Driver, Julia
Title: Consequentialism and Feminist Ethics
Zotero URI: http://zotero.org/users/4316906/items/ZL5WDVXA
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Driver, J. (2005) ‘Consequentialism and Feminist Ethics’, p. 17.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2005
---
Main Idea: Consequentialism can accomodate partiality

> [!note]+ Differences in feminist ethics
> - concerned with actual relationships between embodied persons
> - impartiality is not fundamental
> - obligations arise through relationships with others
> - a matter of choice about concrete facts, not abstract principles
> - solved through negotiation and communication
> - Special obligations may be due to bonds that may or may not be voluntarily acquired
> - Limited impartiality has an important place in the domestic sphere. 

> [!note]+ The angel of the world
> - From “the angel of the house” (Virginia Wolf)
> - Basically someone who fails to be an individual

> [!note]+ Love and Respect
> - Love is attraction, respect is repulsion
> - Need in balance for a healthy relationship

> [!note]+ Self-sufficiency
> - Praise and blame should only concern what we have control over
>     - Or what we regard ourselves to have control over?
> - We should not depend on others at all
>     - We can’t control what they do, so we want to minimize their influence over our lives
> - We need to thread the needle, avoiding both angel of the world and Schopenhauer’s sterile self-sufficiency