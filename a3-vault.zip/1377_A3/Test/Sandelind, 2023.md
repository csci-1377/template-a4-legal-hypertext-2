---
base: "[[Test.base]]"
In-Text Citation: (Sandelind, 2023)
Priority: Essential
Authors: Sandelind, Clara
Title: Memory and Distributive Epistemic Injustice
Zotero URI: http://zotero.org/users/4316906/items/4A5TMD5A
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Full Citation: Sandelind, C. (2023) ‘Memory and Distributive Epistemic Injustice’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2023
---
