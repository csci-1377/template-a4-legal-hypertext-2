---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Wine Bottle Whack
Takeaway: Intent can be proved from context
Tags:
  - Mens Rea
Category:
  - Crim
Abstract: ""
Page: 165
Type: Case
Rating: "**"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Conley
Status: Annotated
Date: 1989-01-01
Jurisdiction: Illinois
---
> [!note]+ Facts
> - D tries to hit A with wine bottle, ends up hitting V
> - V has broken jaw, missing teeth, “mucosal mouth”

> [!note]+ Procedural History and Posture
> - Charged with aggravated battery: “person who, in committing battery, <u>intentionally </u>or <u>knowingly</u> causes great bodily harm, or permanent disability or disfigurement commits aggravated battery.”
> - Convicted by jury
> - Appealed by D arguing harm wasn’t intended

- Issue: Could reasonable jury have found intent element met?

> [!note]+ Holding (Cerda): Yes
> - D argues…
>     1. No proof there was a permanent disability because he hasn’t proven can no longer do what he could
>     2. No intent to cause serious harm.
> - Intent requires proof beyond a reasonable doubt of either “conscious objective” or “conscious awareness” that the harm was “practically certain to result”
> - Jury can infer this from surrounding circumstances: words, weapon, force
> - Ordinary presumption is intent of natural and probable consequences of acts (overruled by SC)
> - Disposition: Affirmed





















