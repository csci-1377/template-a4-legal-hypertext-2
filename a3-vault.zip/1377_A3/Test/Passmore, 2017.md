---
base: "[[Test.base]]"
In-Text Citation: (Passmore, 2017)
Authors: Passmore, John
Title: “Good Law” vs “Bad Law" Explained
Zotero URI: https://zotero.org/bmcanally21/items/R3GBMJEW
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: Early in your law school career, you will inevitably hear the terms “good law” and “bad law” bandied about without much definition.
Type: Web Page
URL: https://lawschooltoolbox.com/good-law-vs-bad-law-explained/
Full Citation: 'Passmore, J. (2017) “Good Law” vs “Bad Law" Explained, Law School Toolbox®. Available at: https://lawschooltoolbox.com/good-law-vs-bad-law-explained/ (Accessed: 17 November 2024).'
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
---
If a proposition of law from a case is a valid, citable legal proposition in your jurisdiction, it is “good law.” Logically enough, if a proposition from a case is no longer a valid legal proposition, it is “bad law.”