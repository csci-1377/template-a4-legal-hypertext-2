---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Flattening Land
Takeaway: Expectation Damages are Cost of Performance
Tags:
  - Expectation
  - Bad Faith
  - Efficient Breach
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1939
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Groves v. John Wunder Co.
Status: Annotated
Date: 1939-01-01
Jurisdiction: Minnesota
---
> [!note]+ Facts
> Groves has land with gravel, leases to Wunder on condition that it removes the sand and gravel and flattens the lot. 
> 
> Defendent breaches contract deliberately (Great Depression intervenes, no longer profitable to flatten the land)

> [!note]+ Procedural History and Posture
> - Plaintiff awarded $15,000 for breach and appeals, wanting more.

- Issue: Do damages track the difference in value of the land or the cost of specific performance? Basically, what is equivalent to giving someone what they contracted for?

> [!note]+ Holding: 
> - Defendent was acting in bad faith, can’t reward that. Cost of remedying the defect ($60,000) is the proper doctrine. Opposing argument
> - Disposition: New Trial

> [!note]+ Dissent: Was there really bad faith?
> - Not clear that defendnt “willfully and fraudulently” violated the contract. Also damages are for the *value* of performance, not performance itself