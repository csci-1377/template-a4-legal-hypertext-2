---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Replevin for a Cow
Takeaway: ""
Tags:
  - Mistake
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1887
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Sherwood v. Walker
Status: Annotated
Date: 1887-01-01
Jurisdiction: Michigain
---
> [!note]+ Facts
> - D tells P cattle likely barren
> - P decides to buy “Rose 2d of Aberlone”
> - D sends letter
> > “Dear Sir: We confirm sale to you of the cow Rose 2d Aberlone, lot 56 of our catalogue, at five and a half cents per pound, less fifty pounds after shrink. We inclose herewith order on Mr. Graham for the cow. You might leave check with him, or mail to us here, as you prefer.
> - D finds out Rose is with calf
> - P goes to get cow: refuses to deliver!

> [!note]+ Procedural History and Posture
> - Trial court instructs jury irrelevant whether cow was with calf
> - Jury awards P Rose in replevin

- Issue: Who has title to the cow?

> [!note]+ Holding (Morse): D (mutual mistake)
> - First, I admit it’s a close call!
> 
> > a party who has given an apparent consent to a contract of sale may refuse to execute it, or he may avoid it after it has been completed, if the assent was founded, or the contract made, upon the mistake of a material fact
> 
> - But not if it’s just some quality of what’s sold. So it’s about whether the mistake goes to the “whole substance” of the agreement.
> 
> > the mistake was not of the mere quality of the animal, but went to the very nature of the thing. A barren cow is substantially a different creature than a breeding one.
> 
> > The thing sold and bought had in fact no existence.
> 
> - Disposition: Reversed

> [!note]+ Dissent (Sherwood): P (no mistake)
> - No fraud here, nor mistake to invalidate
> - For mutual mistake, at least one party needs to “know” the mistaken fact.
> - Here neither of them knew, just guessed.
> > in all probability they were sterile and would not breed.
> - No terms in contract about sterility
> 
> > both parties were equally ignorant, and as to this each party took his chances.
