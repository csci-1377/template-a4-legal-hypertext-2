---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Old Navy Preachers
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 2006
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Chaplaincy of Full Gospel Churches v. England
Status: Annotated
Date: 2006-01-01
Jurisdiction: D.C. Circuit
---
> [!note]+ Facts
> - Non-liturgical Navy chaplains sue, since only Catholic chaplains are getting held on past 60, asserting Establishment Clause violation
> 
> > [!note]+ Glenn’s
> > Non-liturgical Protestant (Baptist, Evangelical, Pentecostal, and Charismatic Christian) Navy Chaplains (current and former) claim that the Navy has acted in religiously discriminatory fashion in violation of the Constitution’s Establishment Clause in promoting and retaining past age of normal retirement chaplains. In particular, they point to a number of Catholic Chaplains who were retained past age 67 or twice “failed of selection” (“FOS,” i.e., were not promoted) who they claim have been illegally retained. Plaintiffs sought a preliminary injunction that would require the Navy to separate these chaplains immediately.

> [!note]+ Procedural History and Posture
> - District Court denies motion on 1 of 4 elements for preliminary injunction (irreperable harm). No partial summary judgment
> - No jurisdiction on partial summary judgment, so…
> - Issue- Does Establishment Clause violation result in irreperable harm to satisfy element of preliminary injunction?

> [!note]+ Holding
> - Summary- Establishment Clause violations necessarily result in irreperable harm
> - Preliminary Injunction Test: 
>     - (1) a substantial likelihood of success on the merits,
>     - (2) that it would suffer irreparable harm if the injunction were not granted,
>     - (3) that an injunction would not substantially injure other interested parties,
>     - (4) that the public interest would be furthered by the injunction.
> - *Elrod: “the loss of First Amendment freedoms, for even minimal periods of time, unquestionably constitutes irreparable injury.”*
>     - Don’t apply this mechanically, actually consider what’s at stake
>     - Slippery slope argument (if not found, gov can put crosses on lawn and no preliminary injunction)
> - Disposition- Reversed on irreperable harm, remanded for rest of preliminary injunction decision, denial structural injunction affirmed (with snark)

> [!note]+ Thoughts and Questions
> - Appellate review standard? Unless we can say lower court clearly in error
> - Different questions can be 
