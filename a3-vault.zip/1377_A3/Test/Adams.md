---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Trust Fund Baby
Takeaway: Permits spendthrift trusts (can’t be accessed by 3rd parties)
Tags:
  - Trust
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1882
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Broadway National Bank v. Adams
Status: Annotated
Date: 1882-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - Settlor leaves will with 75k trust to brother D, distributing income semi-annually
> - Specifically says income to be “free from interference of creditors, my intention being that the use of said income shall not be anticipated by assignment”
> - P bank tries to get at money in trust to cover D’s debt

- Issue: Are “spendthrift” trusts unreasonable restraints on alienation?

> [!note]+ Holding (Morton): No
> - Rationale by settlor’s intent: if he were still alive, he would choose to make periodic gifts, not a lump-sum payment