---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Corporate Consent
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 2023
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Mallory v. Norfolk Southern Railway Co.
Status: Annotated
Date: 2023-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Robert Mallory worked for Norfolk Southern as a freight-car mechanic for nearly 20 years, first in Ohio, then in Virginia. He alleged that in the course of that work he was exposed to asbestos among other carcinogens. He alleged this exposure caused him to develop cancer and he sued Norfolk Southern
> Mallory resided in Virginia. His complaint alleged that he was exposed to carcinogens in Ohio and Virginia. Meanwhile, the company itself was incorporated in Virginia and had its headquarters there too. Norfolk Southern manages over 2,000 miles of track, operates 11 rail yards, and runs 3 locomotive repair shops in Pennsylvania. There is a Pennsylvania statute that “requires out-of-state companies that register to do business in the Commonwealth to agree to appear in its courts on ‘any cause of action’ against them.” 42 Pa. Cons. Stat. § 5301(a)(2)
> - He sues in Pennsylvania state court.

- Issue: Does Penn have PJ through consent by way of the corporate registration statute?

> [!note]+ Plurality Holding (Gorsuch): Yes
> - We solved this in 1917 (pre-International Shoe)
> - Does *Shoe *change the treatment of consent in that case? No, comparison to *Burnham*.
>     - Shoe is about cases where no consent, this is a traditional basis
>     - Traditional basis is ok because it’s traditional
> - <u>Obj</u>: This sure seems like a mere formality:
> > Under our precedents a variety of “actions of the defendant” that may seem like technicalities nonetheless can “amount to a legal submission to the jurisdiction of a court.
> - Obj: This is just

- Concurrence (Jackson): Waiver solves the problem.

> [!note]+ Concurrence in Part (Alito): Yes, but about Dormant Commerce
> - Due Process Clause is not violated here, but the whole corporate registration scheme may violate the Dormant Commerce Clause. Issue not presented here.
>     - Problem when one states seeks to regulate commerce of another state

> [!note]+ Dissent (Barret): No 
> - Shoe was about correcting the idea that doing business was the PJ test
> 
> > By relabeling their long-arm statutes, States may now manufacture “consent” to personal jurisdiction. Because I would not permit state governments to circumvent constitutional limits so easily, I respectfully dissent.
> 
> - Disputes the treatment of *Burnham* by the plurality.
>     - Pennsylvania used to do this, but have now rejected this, so the tradition test doesn’t work
> - Claims this spells the first step to the end of the Supreme Court’s cabining of *genera*l IPPJ.
>     - May make Daimler and Goodyear obselete. 
>     - 
