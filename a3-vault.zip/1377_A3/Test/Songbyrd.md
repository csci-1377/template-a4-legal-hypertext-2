---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: District
Authors: ""
Title: Adverse Jazz
Takeaway: SOL tolls at time of conversion
Tags:
  - Adverse Posession
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1998
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Songbyrd, Inc. v. Estate of Grossman
Status: Annotated
Date: 1998-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - “Professor Longhair” Byrd records jazz tapes
> - Byrd gives them to his friend Grossman
> - They both die
> - Grossman’s company finds the records and liscences them
> - Byrd’s representatives try to get them back, unsuccessfuly
> - Bearsville sells them to others
> - Byrd’s reps sue

> [!note]+ Procedural History and Posture
> - Bearsville removes to fed court with motion to dismiss on Louisiana’s “SOL”
> - District in Louisiana upholds motion
> - Songbyrd appeals, Fifth circuit reverses and remands
> - District considers personal juruisdiction, concludes lacking, transfers to NY
> - Bearsville files for summary judgment on basis SOL has run out in NY

- Issue: When do we start the clock for SOL for adverse posession of personal property?

> [!note]+ Holding (Homer): At the time of conversion (the liscencing)
> - Doesn’t matter when the person finds out it’s missing
> - But for good-faith purchases, it starts at time of demand
> - Don’t treat it as a continuous wrong (this is how we know it’s AP)

> [!note]+ Thoughts and Questions
> - Basically, this favors theives over good-faith purchasers
