---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Broken Fiduciary Duties
Takeaway: No self-dealing
Tags:
  - Fiduciary Duties
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1977
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Rothko v. Reis
Status: Annotated
Date: 1977-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - D persuades Rothko to write a will naming him and 2 others as executors and leaving them paintings
> - D contracts with gallery to give exclusive right to sell paintings in return for commission 
> - D gets a kick-back by getting on retainer for the gallery etc.
> - P Rothko’s kids sue as breach of fiduciary duty

- Issue: Did these executors breach fiduciary duty?

> [!note]+ Holding (Cooke): Yes
> - In part based on “no further inquiry” rule: there was self-dealing, so its a per-se violation… but it wasn’t direct, so that’s not all.
> - There was a “structural conflict” of interests
> - Damages awarded based on FMV at time of the order, not of sale (even higher) because they sold the paintings too soon.
>     - Potentially to just force them to return the paintings