---
base: "[[Test.base]]"
In-Text Citation: (Feinberg, 2012)
Priority: Essential
Authors: Feinberg, Joel
Title: Psychological Egoism
Zotero URI: http://zotero.org/users/4316906/items/3TVYEFW2
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Book Section
Rating: "****"
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=952128
Full Citation: "Feinberg, J. (2012) ‘Psychological Egoism’, in Ethical Theory: An Anthology. Somerset, UNITED STATES: John Wiley & Sons, Incorporated. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=952128 (Accessed: 9 January 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2012
---
- Psychological, not ethical egoism
- Basically, it doesn’t work out
- Non-empirical and unfalsifiable
- Analytic statements cannot entail synthetic ones
- Paradox of morality: those directly pursuing happiness are least likely to find it
- Terminological shifting: fallacy of the suppressed correlative, committed by making one of a pair of words capture both meanings














