---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Undesireable Threats
Takeaway: ""
Tags:
  - Duress
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1959
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: "Wolf v. Marlton Corp. "
Status: Annotated
Date: 1959-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - P contracts for house from builder D
> - P makes first payment, then wants out, asking for refund
> - D doesn’t want to cancel contract, asks for second payment
> - P refuses
> - D decides not to demand second payment, offers partial refund
> - P threatens D to resell to “undesireable purchaser” if D holds them to contract, demanding larger refund
> - D does not award any refund
> - P sues for breach

> [!note]+ Procedural History and Posture
> - TC ruling about notice, finding for P since no notice given
> - D on appeal- but we gave notice to their lawyer (not allowed in since not raised at trial)

- Issue: Was D’s breach justified by duress?

> [!note]+ Holding (Freund): Yes
> - D- “except for the degree of sophistication, there is no real difference between a threat to cut one’s head off, there, and a threat to cut one’s business head off, here.”
> - P- come on, we weren’t going to cut off his head! There was no physical threat
> - It doesn’t matter what kind of threat it was, the point is D was prevented from “forcing P to comply with the contract” (irony abounds)
> - P- Ok, but it’s not duress if we’re threatening something that’s legal (selling to whoever they wish)
> - D- No, they have to be *wrongful* but could still be lawful
> - Threatening to do something bad for you is very clearly a malicious threat.
> - Disposition: Remanded
>     - TC determine if there was threat
>     - Reasons for D’s breach
>     - If liquidated damages enforceable
