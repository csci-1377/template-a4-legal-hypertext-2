---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: King's Bench
Authors: ""
Title: Silk Mercer Security
Takeaway: "Three kinds of covenants: independent, dependent, conditions precedent (constructive conditions)"
Tags:
  - Conditions
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1773
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Kingston v. Preston
Status: Annotated
Date: 1773-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - P agrees to work as silk mercer for D for two years
>     - then for D to hand off his business into a partnership between P and his nephew, 
>     - and that P would before final deal, get sufficient security to pay D, 
>     - from which D pays P 250/month until down to 4k, then keeps rest.
> - P can’t get security
> - D refuses to sign over business
> - P sues for breach

- Issue: What is relationship between promise of security and of signing over business?

> [!note]+ Holding: Condition Precedent
> - Three kinds of covenants
>     - Mutual Independent- nonperformance doesn’t prevent recovery for breach
>     - Mutual Dependent- must be ready to perform to demand recovery for breach
>     - Conditions Precedent- must actually perform to recover for breach
> - The language here wasn’t explicit, but there is a *constructive* condition here
> 
> > the dependance, or independence, of covenants, was to be collected from the evident sense and meaning of the parties
> 
> - Disposition: For D