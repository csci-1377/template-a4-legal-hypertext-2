---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Levin, Yuval
Title: A Time to Build
Takeaway: ""
Tags: []
Category:
  - Politics
Abstract: ""
Type: Audiobook
Rating: "*****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2020
---
Institutions can be defined as the durable forms of our common life

Problems with institutions:

Insiderism- essentially corruption, when people on the inside use benefits unfairly, not including the outside. The norms corrupting. This has always been around, not particularly bad now

Outsiderism- When the institution doesn’t even propose to create norms or standards for action, providing a platform for celebrity instead of a mold for individuals. They aren’t even asking for our confidence, just our attention. In these degraded institutions, individuals can remain outsiders even when wielding the power of office.

A culture of integrity becomes a culture of celebrity. When the molds melt, the institutions blend together.

The dark side of transparency: removed the inner life of institutions, leaving insiders to think that all they are doing is performing got the outside.

Professions (like law, medicine, education, science, military, etc.) are distinct from other careers because they exist in the context of institutions that shape them and their members. Our respect for the members exists because of the institutional shaping. You are agreeing to become a certain type of person by joining one of these fields, designed to foster integrity. Each has a “temple” that they guard, a code they follow, a larger purpose they serve. Professions have answers to ethical questions about proper action.

Institutions give us human commitments through which we become moral agents.

What institutions do for us:

Constrain our activities

Embody our ideals in practice

Offer a path to belonging and recognition

Legitimate authority

Institutions allow us to ask not just “what do I want?” But “how should I act, given my position?”

Take Two Concepts of Liberty into account: this isn’t an argument for positive liberty, it’s a check on liberty, which may be properly understood negatively.

He argues for positive liberty by providing preconditions for human flourishing that make liberty meaningful.

Institutions slow things down by engendering patience. Short termism is mitigated by context, allowing us to worry without convincing ourselves of an existential crisis. Leads to incrementalism.

Rationality exists in social context, provides processes and heuristics to support cognition.

An institution is something you can dedicate yourself to because it doesn’t ask for unflinching belief (or doesn’t have to). An ideal requires zealotry, and a person unflinching loyalty. And agnosticism unbound by institutions is formless, drifting. Agnostic institutionalism combines these to form something tangible and navigable, part of a story as one of many authors. Institutions give us something real to both judge and love, as they are embodiments of the ideas and forms that are otherwise unattached to reality.

Meritocracy breeds hubris by providing an enlarged sense of self-importance and legitimacy (I passed all the right tests to prove myself!)
