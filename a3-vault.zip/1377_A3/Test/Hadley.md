---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Exchequer
Authors: ""
Title: Cranky? Get Shafted.
Takeaway: ""
Tags:
  - Consequential
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 1854
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hadley v. Baxendale
Status: Annotated
Date: 1854-01-01
Year*: 1854
Jurisdiction: England
---
> [!note]+ Facts
> - Plaintiff’s crank shaft in mill breaks in Gloucester
> - They send it to engineers in Greenwich using defendent’s parcel service
> - They tell them the mill is stopped and the shaft must be sent immediately
> - Defendents delay, so shaft doesn’t get back for a few days, resulting in lost profits of the mill
> - Plaintiff’s sue defendents for lost profits

> [!note]+ Procedural History and Posture
> - Judge leaves case to jury, they find 25 pounds of damages 
> - It gets… appealed?

> [!note]+ Arguments
> - Claimants- You’re responsible for the loss
> - Respondents- Damages are too remote

> [!note]+ Holding
> - Summary- Only damages are those “fairly and reasonably considered”
> > Where two parties have made a contract which one of them has broken, the damages which the other party ought to receive in respect of such breach of contract should be such as may fairly and reasonably be considered either arising naturally, i.e., according to the usual course of things, from such breach of contract itself, or such as may reasonably be supposed to have been in the contemplation of both parties, at the time they made the contract, as the probable result of the breach of it.
> 
>     - And also, given the facts it wasn’t reasonably contemplated
> - Disposition- Remanded to jury with instructions not to consider any damages

> [!note]+ Thoughts and Questions
> - What was jury verdict compared to lost profits?
> - It seems like they are laying out a rule for the jury, then they go and decide the factual question for the jury. That seems weird?

> [!note]+ Class Notes
> - This case was likely because railroads were getting big and railroad lawsuits are constant, judge may have been biased in favor of the industry.
