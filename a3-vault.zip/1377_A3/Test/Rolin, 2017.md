---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/02691728.2017.1346722
In-Text Citation: (Rolin, 2017)
Priority: Further
Authors: Rolin, Kristina
Title: "Scientific Community: A Moral Dimension"
Zotero URI: http://zotero.org/users/4316906/items/26JJENR9
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: I argue that in epistemically well-designed scientific communities, scientists are united by mutual epistemic responsibilities, and epistemic responsibilities are understood not merely as epistemic but also as moral duties. Epistemic responsibilities can be understood as moral duties because they contribute to the well-being of other human beings by showing respect for them, especially in their capacity as knowers. A moral account of epistemically responsible behaviour is needed to supplement accounts that appeal to scientists’ self-interests or personal epistemic goals. This is because neither the self-interest nor the epistemic account can always explain why it is rational for an individual scientist to be epistemically responsible.
Type: Journal Article
URL: https://doi.org/10.1080/02691728.2017.1346722
Full Citation: "Rolin, K. (2017) ‘Scientific Community: A Moral Dimension’, Social Epistemology, 31(5), pp. 468–483. Available at: https://doi.org/10.1080/02691728.2017.1346722."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2017
---
