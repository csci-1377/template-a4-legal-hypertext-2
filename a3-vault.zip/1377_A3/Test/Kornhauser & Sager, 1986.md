---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/796436
In-Text Citation: (Kornhauser and Sager, 1986)
Priority: Recommended
Authors: |-
  Kornhauser, Lewis A.
  Sager, Lawrence G.
Title: Unpacking the Court
Zotero URI: http://zotero.org/users/4316906/items/YTYYXYMA
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/796436?origin=crossref
Full Citation: "Kornhauser, L.A. and Sager, L.G. (1986) ‘Unpacking the Court’, The Yale Law Journal, 96(1), p. 82. Available at: https://doi.org/10.2307/796436."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1986
---
