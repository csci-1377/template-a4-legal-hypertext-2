---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Wills Without Borders
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1958
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hanson v. Denckla
Status: Annotated
Date: 1958-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Argument over who gets what out of a will
> - The trustee has made no contact with Florida, but some interested parties try to sue there.
> 
> > [!note]+ Glenn’s
> > Donner is a rich resident of Penn. She establishes a trust in Delaware, with a Delaware bank as trustee. She retains a lot of power over the trust, gets income during her life and upon her death it goes to whoever she appoints, and she retains power to change appointed beneficiary whenever she wants. She moves to Florida and before her death executes a will leaving most of her estate to two of her daughters. But she designates two of the children of her 3rd daughter, her grandkids, as beneficiaries of the trust assets with the remainder going her estate.
> > 
> > She dies. The two daughters sue in Florida claiming the appointment of beneficiaries was invalid and all the money should go to her estate, and therefore to them.

> [!note]+ Proceedural History and Posture
> - Florida enforces verdict in favor in of daughters

- Issue: Does Florida have SIPPJ over Hanson? (Is the Florida jurisdiction valid?)

> [!note]+ Holding (Warren): No, they don’t
> - Unlike McGee, there was no action by defendant in the state.
> > The <u>unilateral activity</u> of those who claim some relationship with a nonresident defendant cannot satisfy the requirement of contact with the forum... . it is essential that there be come act by which the <u>defendant purposefully avails itself</u> of the privilege of conducting activities within the forum State, thus invoking the benefits of protection of the laws.
> 
>     - BUT she also died there, will is being executed there
>     - ALTHOUGH all the trustee action was in Pennsylvania
>     - BUT the trust kept dealing with her, so was it really different than McGee?
> - PJ vs. Choice of Law
> > (Unlike Choice of Law, responding to Black), does not acquire that jurisdiction by being the "center of gravity" of the controversy, or the most convenient location for litigation. 

> [!note]+ Dissent (Black): Yes, they do!
> - Florida’s interest in adjudicating the dispute.
> 
> > Florida had sufficient interest so that a court with jurisdiction might properly apply Florida law
> 
> - The question is about a Florida statute of wills, and trying the case here wouldn’t offend “traditional notions of fair play and substantial justice.” [[International Shoe]] 

> [!note]+ Thoughts and Questions

