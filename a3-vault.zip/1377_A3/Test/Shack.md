---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Visiting Migrants
Takeaway: Limitation on exclusion for public policy
Tags:
  - Equity
  - Nominalism
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1971
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Shack
Status: Annotated
Date: 1971-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - Shack and Tejeras come to visit migrant farmworkers on Tedesco’s property
> - Tedesco refuses entry and requires they visit with worker wanting to know rights in his presence
> - Summons state trooper who refuses to remove until Tedesco issues a written complaint
> - Tedesco writes formal complaint charging with violations of tresspass statute

> [!note]+ Procedural History and Posture
> - Municipal Court convicts S and T for criminal trespass
> - Appeals Court convicts again de novo
> - Tedesco stops defending upon appeal to SC
> - NJ AG defends the constitutionality of the statute, but not that it applies here

- Issue: Does unauthorized intrusion serving significant public policy and private (non-owner) interests count as tresspass under state law?

> [!note]+ Holding (Weintraub): No, it doesn’t
> > **Property rights serve human values.** They are recognized to that end, and are limited by it… These ends would not be gained if the intended beneficiaries (farmworkers) could be insulated from efforts to reach them. 
> 
> - Equity: Doesn’t matter whether this is an established class, the ques is for “a fair adjustment of the competing needs of the parties” 
> - No need to decide constitutionality, since state law doesn’t count this as trespass
> - Maxim: one should so use his property as not to injure the rights of others.
> - The balance between individualism and social interest depends on ideology and also the physical and social facts of the time and place.
> - Shift from do as owner pleases to stewardship model
> - Federal law supporting migrant workers shows public policy favors their interests
> - Disposition: Reversed

> [!note]+ Thoughts and Questions
> - Compare to [[Steenberg Homes]] Why was there not a public policy interest at play there?
