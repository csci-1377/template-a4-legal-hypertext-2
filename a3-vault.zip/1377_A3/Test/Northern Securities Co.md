---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: ""
Title: ""
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Type: Case
Rating: "**"
Year: 1994
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Northern Securities Co. v. United States
Status: Someday
Date: 1994-01-01
---
> [!note]+ Facts
> - 

> [!note]+ Procedural History and Posture
> - 

- Issue: 

> [!note]+ Holding (): 
> - 
> - Disposition: 

> [!note]+ Concurrence/Dissent (): 
> - 

Great cases like hard cases make bad law. For great cases are called great, not by reason of their importance ... but because of some accident of immediate overwhelming interest which appeals to the feelings and distorts the judgment.



















