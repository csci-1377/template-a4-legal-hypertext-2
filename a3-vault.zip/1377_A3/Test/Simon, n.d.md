---
base: "[[Test.base]]"
In-Text Citation: (Simon, no date)
Authors: Simon, William H
Title: "Role Differentiation and Lawyer's Ethics: A Critique of Some Academic Perspectives"
Zotero URI: https://zotero.org/bmcanally21/items/4MA8VTB8
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Type: Journal Article
Full Citation: "Simon, W.H. (no date) ‘Role Differentiation and Lawyer’s Ethics: A Critique of Some Academic Perspectives’, 23."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> [M]any of the arguments for disclosure are internal to the lawyer's role. They are not arguments about whether a good person can be a good lawyer; they are arguments about what it takes to be a good lawyer. 990.

> George Sharswood, one of the most eminent legal ethicists of the 19th century asserted in his treatise that "[c]ounsel ... are duty bound, to refuse to be concerned for a plaintiff in the pursuit of a demand, which offends his sense of what is just and right.” GEORGE SHARSWOOD, AN ESSAY ON PROFESSIONAL ETHICS 39 (2d ed. 1860).

> the advocate's duty to make any effective non-frivolous argument to a court for a client's position regardless of whether she is personally convinced of its merit. 15 This norm is not controversial within the profession. It represents a minimal departure from ordinary morality. It is grounded in the belief that, by deferring private judgment, the advocate facilitates a more reliable and accountable resolution by the judge.

> Why is the Model Rule that prohibits disclosure of a client's fraudulent plans unless the lawyer has been involved in them better than, say, New York's rule, which permits disclosure regardless of the lawyer's involvement, or New Jersey's which mandates disclosure? 994-95.

> It is a core principle of professional responsibility that lawyers are "officers of the court" or "officers of the legal system ... having special responsibility for the quality of justice." Model Rules. 

> The "zealous advocacy within the bounds of the law" phrase that was so central to the Model Code does not appear in the Model Rules. 1003.



