---
base: "[[Test.base]]"
DOI: https://doi.org/10.1086/233207
In-Text Citation: (Gibbard, 1999)
Priority: Further
Authors: Gibbard, Allan
Title: "Morality as Consistency in Living: Korsgaard's Kantian Lectures"
Zotero URI: http://zotero.org/users/4316906/items/C8B4LNNW
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/10.1086/233207
Full Citation: "Gibbard, A. (1999) ‘Morality as Consistency in Living: Korsgaard’s Kantian Lectures’, Ethics, 110(1), pp. 140–164. Available at: https://doi.org/10.1086/233207."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1999
---
