---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1467-9329.2011.00511.x
In-Text Citation: (Harman, 2011)
Priority: Essential
Authors: Harman, Elizabeth
Title: Does Moral Ignorance Exculpate?
Zotero URI: https://zotero.org/bmcanally21/items/3KASDLF8
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: "Non-moral ignorance can exculpate: if Anne spoons cyanide into Bill's coffee, but thinks she is spooning sugar, then Anne may be blameless for poisoning Bill. Gideon Rosen argues that moral ignorance can also exculpate: if one does not believe that one's action is wrong, and one has not mismanaged one's beliefs, then one is blameless for acting wrongly. On his view, many apparently blameworthy actions are blameless. I discuss several objections to Rosen. I then propose an alternative view on which many agents who act wrongly are blameworthy despite believing they are acting morally permissibly, and despite not having mismanaged their moral beliefs.1"
Type: Journal Article
Rating: "***"
URL: http://0.onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-9329.2011.00511.x
Full Citation: "Harman, E. (2011) ‘Does Moral Ignorance Exculpate?’, Ratio, 24(4), pp. 443–468. Available at: https://doi.org/10.1111/j.1467-9329.2011.00511.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: In Progress
Year*: 2011
---
> [!note]+ Intro
> - Main idea: many agents acting wrongly are blameworthy despite thinking they are acting permissably and not having mismanaged their moral beliefs

> [!note]+ Rosen
> - Wrongful action is only blameworthy if it is a direct case or indirect result of clear-eyed akrasia.
> - So blame can only result from our procedural obligations, and these obligations cannot direct us to know or believe something, because belief is not something that one chooses.
> - Anne spoons cyanide into Bill’s coffee: she is only blameworthy if she is blameworthy for her ignorance.
> - Ancient slaveholders are not blameworthy if they believe it to be right and didn’t fail procedurally in getting an alternate belief (thinks about morality plenty and doesn’t ignore contrary arguments)

> [!note]+ Guerrero
> - It can’t be ignorance, but false belief that exculpates
> - A 50/50 credence in sugar/cyanide does not exculpate. You are still blameworthy for acting under uncertainty even if you are not blameworthy for the ignorance.

> [!note]+ Moody-Adams
> - You can be blameworthy for a false moral belief without violating procedural norms if the false belief arises from *motivated ignorance*
> - **But can’t we just say that not believing as a result of motivated ignorance is a procedural norm?**
> - So you might be violating procedural norms but not aware of your violation, so at least you aren’t acting akratically

> [!note]+ FitzPatrick
> - You can be blameworthy for mismanaging belief even if you don’t know you are and aren’t blameworthy for that ignorance if you could be reasonably expected not to mismanage those beliefs
> - But insists that someone must be mismanaging their beliefs if they believe wrongly when it isn’t a ‘hard case’
> - The problem with this is that moral knowledge isn’t easy to come by, so you might be perfectly responsible about your norms but nevertheless believing deeply falsely. So most cases are hard cases

> [!note]+ Narrower Conclusion
> A person is blameless for acting wrongly if 
> 
> 1. They believe a false claim
> 2. If the claim were true, the action would be permissible
> 3. The false claim did not result from a mismanagement of belief
> 4. The belief is not a case of motivated ignorance

> [!note]+ Harman’s Response
> - We morally ought to believe the moral truths relevant to our actions
> - There does have to be something in your epistemic status that is blameworthy for an action based on a false belief to be blameworthy
> - Beliefs are blameworthy if they involve inadequately caring about what is morally significant
> - These kinds of beliefs are not epistemically justified because they have sufficient evidence that their actions are wrong
> - Even if they do have justified beliefs, they are in positions of moral bad luck that makes them bad people
> - You can be justified in believing the wrong thing, but also be in a position to hold a justified correct belief if you reason in the right way.
> - You can be blameworthy for forgetting or failing to realize something