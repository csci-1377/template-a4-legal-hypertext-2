---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: We all know… WHAT?
Takeaway: Worcester is all but overruled (indian country is part of state)
Tags:
  - SUP
  - ICC
Category:
  - Con Law
Abstract: ""
Page: 47
Type: Case
Rating: "***"
Year: 2022
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Oklahoma v. Castro-Huerta
Status: Annotated
Date: 2022-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Non-indian harms his indian step-daughten on Indian land.

- Issue: Can a State prosecute a non-indian victimizing an indian within indian country?

> [!note]+ Holding (Kavanaugh): Yes
> - Reverse preemption analysis: state can regulate UNLESS federal government preempts.
> - Worcester “rested on a mistaken understanding of the relationship between Indian country and the States”
>     - But he’s citing cases that are largely inapposite





















