---
base: "[[Test.base]]"
In-Text Citation: (Tadros, 2023)
Priority: Essential
Authors: Tadros, Victor
Title: Centrality of Consent
Zotero URI: http://zotero.org/users/4316906/items/5HWU9N7U
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Rating: "****"
Full Citation: Tadros, V. (2023) ‘Centrality of Consent’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
