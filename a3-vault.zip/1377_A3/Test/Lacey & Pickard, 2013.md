---
base: "[[Test.base]]"
In-Text Citation: (Lacey and Pickard, 2013)
Priority: Recommended
Authors: |-
  Lacey, Nicola
  Pickard, Hanna
Title: From the Consulting Room to the Court Room? Taking the Clinical Model of Responsibility Without Blame into the Legal Realm
Zotero URI: http://zotero.org/users/4316906/items/RUKKUP8M
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: "Within contemporary penal philosophy, the view that punishment can only be justified if the offender is a moral agent who is responsible and hence blameworthy for their offence is one of the few areas on which a consensus prevails. In recent literature, this precept is associated with the retributive tradition, in the modern form of 'just deserts'. Turning its back on the rehabilitative ideal, this tradition forges a strong association between the justification of punishment, the attribution of responsible agency in relation to the offence, and the appropriateness of blame. By contrast, effective clinical treatment of disorders of agency employs a conceptual framework in which ideas of responsibility and blameworthiness are clearly separated from what we call 'affective blame': the range of hostile, negative attitudes and emotions that are typical human responses to criminal or immoral conduct. We argue that taking this clinical model of 'responsibility without blame' into the legal realm offers new possibilities. Theoretically, it allows for the reconciliation of the idea of 'just deserts' with a rehabilitative ideal in penal philosophy. Punishment can be reconceived as consequences—typically negative but occasionally not, so long as they are serious and appropriate to the crime and the context—imposed in response to, by reason of, and in proportion to responsibility and blameworthiness, but without the hard treatment and stigma typical of affective blame. Practically, it suggests how sentencing and punishment can better avoid affective blame and instead further rehabilitative and related ends, while yet serving the demands of justice."
Type: Journal Article
URL: https://www.jstor.org/stable/41811764
Full Citation: Lacey, N. and Pickard, H. (2013) ‘From the Consulting Room to the Court Room? Taking the Clinical Model of Responsibility Without Blame into the Legal Realm’, Oxford Journal of Legal Studies, 33(1), pp. 1–29.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2013
---
