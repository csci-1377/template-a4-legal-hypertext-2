---
base: "[[Test.base]]"
In-Text Citation: (Hellman, 2008)
Priority: Essential
Authors: Hellman, Deborah
Title: "Chapter 2: Demeaning and Wrongful Discrimination"
Zotero URI: http://zotero.org/users/4316906/items/BW7ETDHQ
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Book Section
Rating: "***"
Full Citation: "Hellman, D. (2008) ‘Chapter 2: Demeaning and Wrongful Discrimination’, in When is Discrimination Wrong? Harvard University Press."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2008
---
> [!note]+ Intro
> - Distinctions that demean are wrongful
> - Demean: to put down
>     - Expression: severely disrespecting (implying lesser moral worth by social convention)
>     - Power: greater social status, not the effect
>     - History: because it affects meaning and power

> [!note]+ Examples
> - Harrah’s Personal Best Program
>     - Women must wear makeup, men cannot
> - Nursing Home
>     - Only hiring women as aides for a largely female population
> - Personal Advertisement
>     - Man wants a woman who dresses femininely and wears makeup
> - Vacation Rental
>     - Don’t want young boys renting, but fine with older couple

> [!note]+ Historical Context
> - Culture determines meaning through convention
> - But this is also person and context specific. **The coach whose grunt means a lot**
> - Distinguishing on racial grounds carries with it a lot of baggage (badge of infertiority)
> - This is what makes the meaning more likely to be disrespectful

> [!note]+ Upshots
> - This allows us not only to look at whether there is a current practice of discrimination, but looks at its meaning
> - Does not appeal to a comprehensive doctrine (privacy protected in nursing home because it is tied to human flourishing)
> - What marks wrongful from permissable discrimination is a feature of the action itself, offending against the equal moral worth of persons
> - Treats avoiding demeaning treatment as itself a central interest.

> [!note]+ Equality
> - Might think this is really just about baseline respect, and equality has “no moral force”
>     - Might just think that equality emerges from shared fact of personhood
> - But this is empty. The point is that you don’t treat someone as “second-class”, which is inherently comparative

> [!note]+ Justice
> - When a government fails to accord justice to its citizens, it demeans them even when the distinguishing itself might not demean
> - Freckled voting ban demeans freckled people. 
> - **This is just unneccessary**

> [!note]+ Questions
> - Does the white restaurant owner who prevents Michelle Obama from eating at his restaurant demean her? He doesn’t seem to have greater social power. But if heavily context dependent, will struggle to account for broad historical context.
> - What about law with differential driving age for men and women because men poorer decision makers? This seems to demean despite a lack of historical subordination

> [!note]+ Thoughts
> - What **CAN **mark wrongful from permissable discrimination is a feature of the action itself, offending against the equal moral worth of persons.
> - When a government fails to accord justice to its citizens, it demeans them even when the distinguishing itself might not demean
> - This works as a sufficient, but not a necessary condition. Non-demeaning discrimination can be wrongful if it prevents someone from getting what they have a right to (freckled voting ban). Disparate impact is better here
> - Full definition could just say that discrimination is wrongful when it deprives someone of their rights (or central interests)
> - It should be legally banned whenever it violates rights (deprives unjustly)
> - We have a right to dignity, which makes demeaning discrimination wrong













