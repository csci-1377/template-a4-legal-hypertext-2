---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Loaded Gun
Takeaway: Failing Unequivocality Test
Tags:
  - Attempt
Category:
  - Crim
Abstract: ""
Page: 791
Type: Case
Rating: "**"
Year: 1935
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Miller
Status: Annotated
Date: 1935-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - D threatens V
> - Goes into field near V, loads gun, doesn’t raise.
> - V flees, D arrested

> [!note]+ Procedural History and Posture
> - Jury finds D guilty of attempted murder.

- Issue: Was this attempt?

> [!note]+ Holding (Shenk): No
> - This was just preparation: so long as *equivocality* remains… “no one can say with certainty what the intent of the defendant is.”
> - Here, we don’t know whether D intended to shoot or merely demand arrest of V.
> - Disposition: Reversed





















