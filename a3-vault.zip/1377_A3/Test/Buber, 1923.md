---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: "Buber, Martin "
Title: I and Thou
Takeaway: ""
Tags: []
Category:
  - Religion
Abstract: ""
Type: Book
Rating: "*****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1923
---
“The opposition of the two primary words has many names at different times and in different worlds; but in its nameless truth it is inherent in creation.”

“Without It man cannot live. But he who lives with It alone is not a man.”

I cannot exist without thou, and it cannot exist without I. That is why I-thou is the first primary word, and I-it the second primary word.

“Spirit is not in the I, but between I and Thou. It is not like the blood that circulated in you, but like the air in which you breathe.”
