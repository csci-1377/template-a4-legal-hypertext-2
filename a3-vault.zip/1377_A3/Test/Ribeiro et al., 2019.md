---
base: "[[Test.base]]"
DOI: https://doi.org/10.1145/3287560.3287580
In-Text Citation: (Ribeiro et al., 2019)
Priority: Further
Authors: |-
  Ribeiro, Filipe N.
  Saha, Koustuv
  Babaei, Mahmoudreza
  Henrique, Lucas
  Messias, Johnnatan
  Benevenuto, Fabricio
  Goga, Oana
  Gummadi, Krishna P.
  Redmiles, Elissa M.
Title: "On Microtargeting Socially Divisive Ads: A Case Study of Russia-Linked Ad Campaigns on Facebook"
Zotero URI: http://zotero.org/users/4316906/items/M8LNMEFY
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: "Targeted advertising is meant to improve the efficiency of matching advertisers to their customers. However, targeted advertising can also be abused by malicious advertisers to efficiently reach people susceptible to false stories, stoke grievances, and incite social conflict. Since targeted ads are not seen by non-targeted and non-vulnerable people, malicious ads are likely to go unreported and their effects undetected. This work examines a specific case of malicious advertising, exploring the extent to which political ads1 from the Russian Intelligence Research Agency (IRA) run prior to 2016 U.S. elections exploited Facebook's targeted advertising infrastructure to efficiently target ads on divisive or polarizing topics (e.g., immigration, race-based policing) at vulnerable sub-populations. In particular, we do the following: (a) We conduct U.S. census-representative surveys to characterize how users with different political ideologies report, approve, and perceive truth in the content of the IRA ads. Our surveys show that many ads are \"divisive\": they elicit very different reactions from people belonging to different socially salient groups. (b) We characterize how these divisive ads are targeted to sub-populations that feel particularly aggrieved by the status quo. Our findings support existing calls for greater transparency of content and targeting of political ads. (c) We particularly focus on how the Facebook ad API facilitates such targeting. We show how the enormous amount of personal data Facebook aggregates about users and makes available to advertisers enables such malicious targeting."
Type: Conference Paper
URL: https://doi.org/10.1145/3287560.3287580
Full Citation: "Ribeiro, F.N. et al. (2019) ‘On Microtargeting Socially Divisive Ads: A Case Study of Russia-Linked Ad Campaigns on Facebook’, in Proceedings of the Conference on Fairness, Accountability, and Transparency. New York, NY, USA: Association for Computing Machinery (FAT* ’19), pp. 140–149. Available at: https://doi.org/10.1145/3287560.3287580."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2019
---
