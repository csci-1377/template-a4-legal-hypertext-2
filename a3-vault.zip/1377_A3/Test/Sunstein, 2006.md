---
base: "[[Test.base]]"
DOI: https://doi.org/10.3366/epi.2006.3.3.192
In-Text Citation: (Sunstein, 2006)
Priority: Recommended
Authors: Sunstein, Cass R.
Title: Deliberating Groups versus Prediction Markets (or Hayek's Challenge to Habermas)
Zotero URI: http://zotero.org/users/4316906/items/QJ3J234W
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: For multiple reasons, deliberating groups often converge on falsehood rather than truth. Individual errors may be amplified rather than cured. Group members may fall victim to a bad cascade, either informational or reputational. Deliberators may emphasize shared information at the expense of uniquely held information. Finally, group polarization may lead even rational people to unjustified extremism. By contrast, prediction markets often produce accurate results, because they create strong incentives for revelation of privately held knowledge and succeed in aggregating widely dispersed information. The success of prediction markets offers a set of lessons for increasing the likelihood that groups can obtain the information that their members have.
Type: Journal Article
Rating: "***"
URL: https://www.cambridge.org/core/product/identifier/S1742360000000587/type/journal_article
Full Citation: "Sunstein, C.R. (2006) ‘Deliberating Groups versus Prediction Markets (or Hayek’s Challenge to Habermas)’, Episteme, 3(3), pp. 192–213. Available at: https://doi.org/10.3366/epi.2006.3.3.192."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2006
---
