---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: General Tires
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 2011
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Goodyear v. Brown
Status: Annotated
Date: 2011-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Bus accident kills two North Carolina boys in Paris
> - Parents sue Goodyear (based in Ohio) and international subsidiaries for negligence
> - Goodyear consents to IPPJ, subsidiaries contest
> - Subsidiaries do not design, manufacture, or advertize in NC
> 
> > [!note]+ Glenn’s
> > A bus accident outside Paris that took the lives of two 13-year-old boys from North Carolina. Parents filed a suit for wrongful-death damages in the Superior Court of Onslow County, North Carolina, in their capacity as administrators of the boys’ estates. Attributing the accident to a tire (manufactured in Turkey) that failed when its plies separated, the parents alleged negligence in the “design, construction, testing, and inspection” of the tire. They sue as defendants Goodyear USA, an Ohio corporation, and three of its subsidiaries, organized and operating, respectively, in Turkey, France, and Luxembourg. Goodyear USA, which had plants in North Carolina and regularly engaged in commercial activity there, did not contest the North Carolina court’s jurisdiction over it; Goodyear USA’s foreign subsidiaries, however, maintained that North Carolina lacked PJ over them.
> > 
> > In contrast to the parent company, Goodyear USA, which does not contest the North Carolina courts’ personal jurisdiction over it, petitioners are not registered to do business in North Carolina. They have no place of business, employees, or bank accounts in North Carolina. They do not design, manufacture, or advertise their products in North Carolina. And they do not solicit business in North Carolina or themselves sell or ship tires to North Carolina customers. Even so, a small percentage of petitioners’ tires (tens of thousands out of tens of millions manufactured between 2004 and 2007) were distributed within North Carolina by other Goodyear USA affiliates. These tires were typically custom ordered to equip specialized vehicles such as cement mixers, waste haulers, and boat and horse trailers. Petitioners state, and respondents do not here deny, that the type of tire involved in the accident, a Goodyear Regional RHS tire manufactured by Goodyear Turkey, was never distributed in North Carolina.

> [!note]+ Procedural History and Posture
> - Trial court finds GIPPJ for subsidiaries based on “continuous and systematic contacts” with the state and difficulty on plaintiff’s to sue in France.
> 
> > [!note]+ Glenn’s
> > Noted that that the claims neither “related to, nor ... ar[o]se from, [petitioners’] contacts with North Carolina,” therefore treated case as involving only “**general rather than specific jurisdiction**,” which the court recognized required a “higher threshold” showing: A defendant must have “**continuous and systematic contacts**” with the forum.
> > 
> > That threshold was crossed, the court determined, when petitioners placed their tires “in the stream of interstate commerce without any limitation on the extent to which those tires could be sold in North Carolina.”
> > 
> > Nothing in the record, the court observed, indicated that petitioners “took any affirmative action to cause tires which they had manufactured to be shipped into North Carolina.” The court found, however, that tires made by petitioners reached North Carolina as a consequence of a “highly-organized distribution process” involving other Goodyear USA subsidiaries. Goodyear made “no attempt to keep these tires from reaching the North Carolina market.” Indeed, the very tire involved in the accident, the court observed, conformed to tire standards established by the U. S. Department of Transportation and bore markings required for sale in the United States. As further support, the court invoked North Carolina’s “interest in providing a forum in which its citizens are able to seek redress for [their] injuries,” and noted the hardship North Carolina plaintiffs would experience “[were they] required to litigate their claims in France,” a country to which they have no ties.

- Issue: Do subsidiaries have GIPPJ in NC?

> [!note]+ Holding (Ginsburg): No. 
> - This is a lot more like *Helicopteros *that *Perkins*
> > [!note]+ *Perkins v. Benguet* 
> > Sued in Ohio, the defendant in Perkins was a Philippine mining corporation that had ceased activities in the Philippines during World War II. To the extent that the company was conducting any business during and immediately after the Japanese occupation of the Philippines, it was doing so in Ohio: the corporation’s president maintained his office there, kept the company files in that office, and supervised from the Ohio office “the necessarily limited wartime activities of the company.” Although the claim-in-suit did not arise in Ohio, this Court ruled that it would not violate due process for Ohio to adjudicate the controversy.
> 
> > [!note]+ *Helicopteros Nacionales de Colombia, S. A. v. Hall*
> > Survivors of United States citizens who died in a helicopter crash in Peru instituted wrongful-death actions in a Texas state court against the owner and operator of the helicopter, a Colombian corporation. The Colombian corporation had no place of business in Texas and was not licensed to do business there. “Basically, [the company’s] contacts with Texas consisted of sending its chief executive officer to Houston for a contract-negotiation session; accepting into its New York bank account checks drawn on a Houston bank; purchasing helicopters, equipment, and training services from [a Texas enterprise] for substantial sums; and sending personnel to [Texas] for training.” These links to Texas, we determined, did not “constitute the kind of continuous and systematic general business contacts ... found to exist in Perkins,” and were insufficient to support the exercise of jurisdiction over a claim that neither “ar[o]se out of ... no[r] related to” the defendant’s activities in Texas. Helicopteros concluded that “mere purchases [made in the forum State], even if occurring at regular intervals, are not enough to warrant a State’s assertion of [general] jurisdiction over a nonresident corporation in a cause of action not related to those purchase transactions.”
> - Goodyear is “in no sense at hime in North Carolina”
> 
> > A court may assert general jurisdiction over foreign (sister-state or foreign-country) corporations to hear any and all claims against them when their affiliations with the State are so “continuous and systematic” as to render them essentially at home in the forum State.
> 
> > Specific jurisdiction, on the other hand, depends on an “affiliatio[n] between the forum and the underlying controversy,” principally, activity or an occurrence that takes place in the forum State and is therefore subject to the State’s regulation. In contrast to general, all-purpose jurisdiction, specific jurisdiction is confined to adjudication of “issues deriving from, or connected with, the very controversy that establishes jurisdiction.”
> 
> - Disposition: Reversed
