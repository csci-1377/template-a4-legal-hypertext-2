---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Conflicting Employee Definitions
Takeaway: "Outcome isn’t the only test: look at centrality of question to fed court function"
Tags:
  - Vertical Choice of Law
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1958
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Byrd v. Blue Ridge Rural Elec. Cooperative Inc.
Status: Annotated
Date: 1958-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Byrd injured connecting power lines
> - Sues Blue Ridge for negligence in SC federal court in diversity
> - Blue Ridge uses affirmative defense that he was a “statutory employee”
> - SC Supreme Court (Adams v. Davidson) says judges decide whether employee, but Fed court says jury decides that factual question

> [!note]+ Procedural History and Posture
> - Jury decides issue at first
> - Fourth Circuit reverses
> - Supreme Court grants cert, remands…
> - But who decides issue in new trial?

- Issue: Should Fed (jury) or state (judge) rule prevail?

> [!note]+ Holding (Brennan): Fed rule
> - It’s kind of a substance/procedure question (Erie)…
>     - Whether state rule is “<u>bound up</u> with these rights and obligations in such a way that its application in the federal court is required.” 
>     - Or if its “merely a <u>form and mode</u>” of enforcing rights not bound up with them
> - But it’s also about outcomes (Guaranty)…
>     - But fortunately we don’t think the issue is likely enough to turn on the judge/jury question for this to be dispositive
> - Also look to “countervailing considerations”
>     - “<u>Essential characteristic</u>” of federal courts is the judge/jury division of labor
>     - The “influence if not the command” of the Seventh Amendment says jury decides factual questions
>         - Not command because no FQ?
> - Disposition: Judge decides