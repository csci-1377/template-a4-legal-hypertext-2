---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Donation Obligation
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Congregation Kadimah Toras-Moshe v. DeLeo
Status: Annotated
Date: 1989-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - Rabbi visiting DeLeo
> - DeLeo promises to pay $25,000 to library
> - He dies, estate refuses to pay

- Issue: Was there a valid contract?

> [!note]+ Holding (Liacos): No, there is no contract
> - Even promise to name library didn’t constitute consideration because that wasn’t originally part of the bargain
> - DeLeo donates to the rich institution out of gratitude, not bargain
> - Also, we create higher bars for promises before death because they can’t contest when dead
> - They didn’t really rely on the promise because (despite plans to) they didn’t really incur costs on the basis of the promise
