---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Chain of Hyperlinks
Takeaway: No valid terms here reasonably prudent user would not have learned by scrolling
Tags:
  - Binding Arbitration
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 2002
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Specht v. Netscape Communications Corp.
Status: Annotated
Date: 2002-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - SmartDownload offered to enhance Communicator, a NetScape product
> - Both programs monitor information about file download, violating Electronic Communications Privacy Act and Computer Fraud and Abuse Act
> - 5 plaintiffs click “yes” after scrolling through license agreement for Communicator which says agreeing to “binding arbitration in Santa Clara”
> - 4 also downloaded SmartDownload to get Communicator, but no clickwrap for SmartDownload. No agreement or assent (never mentioned or appearing in later experience)
>     - It says you must read “before” aquiring product”. If you don’t read, don’t download
>     - This also requires binding arbitration
> - 1 downloaded using “shareware” could have downloaded without ever seeing SmartDownload license
> - 6th (Specht) never obtained or used SmartDownload, but when those who had it downloaded his WhyWeb files, info intercepted
>     - Def says Specht benefited because SmartDownload helped users get WhyWeb on his site and got commissions (he says he didn’t)

> [!note]+ Procedural History and Posture
> - No one bound by SmartDownload’s terms
> - SDNY denies motion to compel arbitration as arbitrary
> - Stay of court proceedings in arbitration

- Issue: Did plaintiff’s agree to binding arbitration by agreeing to liscense by scrolling?

> [!note]+ Holding (Sotomayor): Nope.
> - Not given “inquiry notice”: Reasonably prudent internet user would not have known or learded of these before downloading
> - So download did not “unambiguously manifest” agreement to arbitration
> - Website owner Specht not required to arbitrate because allegedly benefits (benefit is speculative) Would have to be a direct benefit
> - Unlike ProCD…
>     - No sufficient opportunity to review the terms and return the software
>     - Not confronted with conspicuous, mandatory license every time ran software
> - Disposition: Affirmed