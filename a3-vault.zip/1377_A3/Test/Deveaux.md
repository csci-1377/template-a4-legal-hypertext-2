---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Incorporating Diversity
Takeaway: Corporations also be diverse
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1809
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: The Bank of the United States et al. v. Deveaux et al.
Status: Annotated
Date: 1809-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Corporation made of citizens sues bank

- Issue: Does diversity doctrine include incorporation?

> [!note]+ Holding (Marshall): Yeah, it does
> - Myth of Parity: state and fed courts are equal
> - But… framers were worried they weren’t.
> - Incorporation can’t prevent diversity doctrine
