---
base: "[[Test.base]]"
In-Text Citation: (Moller, 2011)
Priority: Essential
Authors: Moller, D.
Title: Abortion and Moral Risk
Zotero URI: http://zotero.org/users/4316906/items/VDITUDBA
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: It is natural for those with permissive attitudes toward abortion to suppose that, if they have examined all of the arguments they know against abortion and have concluded that they fail, their moral deliberations are at an end. Surprisingly, this is not the case, as I argue. This is because the mere risk that one of those arguments succeeds can generate a moral reason that counts against the act. If this is so, then liberals may be mistaken about the morality of abortion. However, conservatives who claim that considerations of risk rule out abortion in general are mistaken as well. Instead, risk-based considerations generate an important but not necessarily decisive reason to avoid abortion. The more general issue that emerges is how to accommodate fallibilism about practical judgment in our decision-making.
Type: Journal Article
Rating: "***"
URL: https://www.jstor.org/stable/23014824
Full Citation: Moller, D. (2011) ‘Abortion and Moral Risk’, Philosophy, 86(337), pp. 425–443.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2011
---
> [!note]+ Intro
> - How do we accomodate fallibilism about practical judgment in our decision-making?
> - Should we stop deliberating after we have considered all available arguments and decided which we find most compelling?

> [!note]+ We make mistakes
> - Sometimes it seems like we should help strangers, and other times it doesn’t. How do we know what kind of case we are in?
> - It’s not just because people disagree with us that we know this. Instead, the issues are just plain complicated
> - This doesn’t suppose moral realism. We could cash this out in terms of inconsistency between practice, belief, and value, or on constructivist grounds

> [!note]+ We should take into account
> - The possibility of being wrong must give reasons independent of the reasons that we actually are wrong
> - We should sometimes avoid moral risks
> - Frank’s advisory committee: four members say option A is a catastrophe, but most say it’s fine. He should avoid A even if it means more paperwork
> - The important thing is not whether the decision is right or wrong, but whether there is something bad about it independently of whether it is the right choice

> [!note]+ Criteria for assessing permissibility of moral risk
> 1. Likelihood that the action is wrong
> 2. How wrong it would be if it was
> 3. Costs of alternatives
> 4. Level of responsibility for the choice
> 5. Whether the alternatives involve moral risk

> [!note]+ Conclusion
> - Moral assymetries like this are rare. Legislation doesn’t work like this: banning a permissible action is wrong.
> - There is a moral reason to avoid abortion
> - Second-level reasoning has a place in decision-making














