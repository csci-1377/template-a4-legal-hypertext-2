---
base: "[[Test.base]]"
In-Text Citation: (Williams, 1973)
Priority: Essential
Authors: ""
Title: Egoism and Altruism
Zotero URI: http://zotero.org/users/4316906/items/WSIBZLGQ
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: "I shall be concerned with issues of egoism as against morality, and with the question whether there are any rational considerations by which an egoist who is resistant to moral claims could, under the unlikely assumption that he was prepared to listen, be persuaded to be less resistant to them. The discussion is all about antagonism between egoism and morality, and does not say anything, or imply much, about the proper place of egoistic concerns within morality. That is in many ways a more important subject, but I find it necessary to get clear about this one first.I have placed the issue in terms of ‘morality’, but the title refers to altruism. I take altruism, in the sense I intend, to be a necessary feature of a morality. It follows that a principle to the effect that everyone ought exclusively to pursue his own interests – the principle of what is rather quaintly called ‘ethical egoism’ – would not constitute a morality or be a moral principle. There perhaps could be such a principle, and I shall refer to it occasionally, but it will, in my use of the terms, stand in contrast to morality. That remark is not meant to be much more than an announcement of terminology, and is not intended to be worth arguing about. However, I think there is a point in using the terminology in this way: it helps to emphasise what I take to be one basic and universal function of morality."
Type: Book Section
Rating: "***"
URL: https://www.cambridge.org/core/books/problems-of-the-self/egoism-and-altruism/DD3060814DEC12FB29ACCB4F61C7594C
Full Citation: "Williams, B. (ed.) (1973) ‘Egoism and Altruism’, in Problems of the Self: Philosophical Papers 1956–1972. Cambridge: Cambridge University Press, pp. 250–265. Available at: https://doi.org/10.1017/CBO9780511621253.017."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1973
---
- Egoism vs morality
- Morality → altruism
- Altruism
    - general disposition to regard the interests of others
    - Does not imply sympathy
- Egoism
    - Rejects, or is uninterested in the interests of others
    - Concern solely with one’s own interests
    - Defined by the edge of altruism, not its own definition
    - How attractive does he end up being?














