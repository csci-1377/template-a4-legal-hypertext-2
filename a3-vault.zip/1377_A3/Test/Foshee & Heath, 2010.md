---
base: "[[Test.base]]"
In-Text Citation: (Foshee and Heath, 2010)
Priority: Further
Authors: |-
  Foshee, Andrew W.
  Heath, Will C.
Title: "Between Absolutism and Relativism: The Economist's Search for a Middle Ground"
Zotero URI: http://zotero.org/users/4316906/items/EXDFQ5G6
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: Clarence Ayres wished to avoid moral relativism or agnosticism in the social sciences, yet he also rejected what he called the "transcendental" epistemology of classical philosophy, an epistemology grounded in the desire to know absolute or ultimate truths. He wanted to find a middle ground between absolutism and relativism by separating "technology" from "ceremony," and by replacing the ends/means dichotomy with an ends/means continuum. This paper examines his articulation of the issues, and in this context also examines the work of two more recent theorists, Gary Becker and Richard Posner. We conclude that Ayres' epistemological middle ground remains elusive.
Type: Journal Article
URL: https://www.jstor.org/stable/20778715
Full Citation: "Foshee, A.W. and Heath, W.C. (2010) ‘Between Absolutism and Relativism: The Economist’s Search for a Middle Ground’, Journal of Economic Issues, 44(3), pp. 819–829."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2010
---
