---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Mandatory State vs Discretionary FRCP Damages
Takeaway: Example of 2-part Hanna test
Tags:
  - Vertical Choice of Law
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Burlington Northern Railway Co. v. Woods
Status: Annotated
Date: 1987-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - P employee sues D employer in diversity in Alabama
> - P wins, D appeals, but loses
> - Alabama law applies 10% penalty to losing appelant
> - FRCP 38 makes damage awards discretionary

- Issue: Apply state’s 10% penalty or FRCP’s discretion?

> [!note]+ Holding (Marshall): FRCP
> - Step 1) Applicable (direct collision)?
>     - Yes, FRCP directly grants discretion for frivolous appeals, where state law offers no discretion (auto 10% penalty)
> - Step 2) Valid?
>     - Yes, “regulates matters which can reasonably be classified as procedural”
> > affects only the process of enforcing litigants' rights, and not the rights themselves.