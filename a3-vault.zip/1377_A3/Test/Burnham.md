---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: "Tag: You’re Divorced"
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1990
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Burnham v. Superior Court
Status: Annotated
Date: 1990-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Burnhams agree to divorce based on “irreconcilable differences”
> - Mrs. Burnham moves to CA with kids
> - Mr. Burnham files in NJ on grounds of “desertion” but doesn’t serve her with process
> - She tries to get him to change grounds, when unsuccessful, sues for divorce in CA
> - He goes to visit the kids, is served with process in California
> - He goes back to NJ, special appearance in CA to quash service of process by claiming no PJ

> [!note]+ Procedural History and Posture
> - Superior court denies motion
> - Court of appeals denies mandamus relief

- Issue: Does California have IPPJ over nonresident tagged there? 

> [!note]+ Holding (Scalia): Yes
> for 4 Justices (Part I to II-C) and 3 Justices (Parts II-D and III)
> 
> - Do *Shoe* and its progeny apply to the traditional basis of presence/tag/transitory jurisdiction? NO
> - I-IIC) The relevant question: What was the understanding in 1868, when 14th amendment was adopted?
>     - Relation of *Shoe* to *Pennoyer,* expansion vs. contraction (recall *Pennoyer*’s two propositions). *Shoe* standard “was developed by *analogy* to physical presence, it would be perverse to say it could now be turned against that “touchstone of jurisdiction.”
> - IID) Defendent takes *Schafer *out of context (we meant *absent* defendant)
> > *Schafer*: *All *assertions of state-court jurisdiction must be evaluated according to the standards set forth in *International Shoe* and its progeny.
> - III) Attack on Brennan who wants “contemporary notions of due process” to be the test. 
>     - Most of his fairness analysis just doesn’t work. 
>         - Benefits test applies even after someone returns, but that’s not what we do
>     - What is compeling is “reasonable expectation,” but…
> > By formulating it as a "reasonable expectation" JUSTICE BRENNAN makes that seem like a "fairness" factor; but in reality, of course, it is just tradition masquerading as "fairness.” (Pointing to circularity)
> 
>     - Also, we shouldn’t be freewheeling on fairness as unelected justices (the People vs. the Court)
> - Disposition: Affirmed

> [!note]+ Concurrence (Brennan): Yes, but based on fairness
> - Tradition is relevant, but not everything.
> - Reciprocity gets us here: he took the sweet, so better take the bitter. 
> - “[A]ll rules of jurisdiction, even ancient ones, must satisfy contemporary notions of due process.”
> - If all that mattered was historical pedigree this rule would be in trouble.
> 