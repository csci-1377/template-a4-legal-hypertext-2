---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Dogs and Rabbits
Takeaway: Injunction for repeated trespass
Tags:
  - Equity
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1936
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Baker v. Howard County Hunt
Status: Annotated
Date: 1936-01-01
Jurisdiction: Maryland
---
> [!note]+ Facts
> - Baker has rabbits
> - Howard County Hunt Club comes by with hounds every so often
> - But then he’s doing Lamarckian experiments on rabbits, and the dogs bother them, then bite his wife’s hand
> - They write a letter saying they’ll stop, but don’t, and one time Baker shoots some dogs when they’re attacking his chickens
> - Baker sues for trespass, asking for injunction

> [!note]+ Procedural History and Posture
> - Trial court dismisses injunction

- Issue: Does equity provide an injunction as remidy for repeated trespass that seriously interferes with enjoyment of land?

> [!note]+ Holding (Offutt): Yes
> - Injunction appropriate because…
>     - Law no adequate relief (Injuries were intangible)
>     - Defendant manifents intention to persist (expense of prosecuting numerous actions, either one many times or many trespassers)
>         - Part of a single course of action (link trespasses, more like continuous)
>     - Clean hands is important
> - No adequate relief at law
> - Rights of fox hunters subordinate to those of land owners
> - Trespass law has evolved, here’s where it’s at:
>     - No trespass by *reputable *dogs (no reason to believe likely to inflict harm)
>     - Liable if knows or should know will probably damage
>     - Or when there are a bunch, because duh.
> - No clean hands because of shooting? No, the dogs were attacking his chickens!
> - Disposition: Reversed
