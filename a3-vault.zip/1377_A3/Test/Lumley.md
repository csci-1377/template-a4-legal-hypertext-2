---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: King's Bench
Authors: ""
Title: Specific Opera Performance
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1852
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lumley v. Wagner
Status: Annotated
Date: 1852-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Lumley contracts with Wagner to sing at Her Majesty’s Theatre for three months
> - Contract includes a clause not to sing elsewhere
> - Wagner gets an offer from Gye to sing at Covent Garden
> - Wagner goes to sing there
> - Lumley sues, requesting specific performance of the contract

- Issue: Can a court order specific performance of a labor contract?

> [!note]+ Holding (Lord St. Leonards): No, but it can enforce the clause to prohibit work elsewhere
> > Wherever this Court has not proper jurisdiction to enforce specific performance, it operates to bind men's consciences, as far as they can be bound, to a true and literal performance of their agreements ; and it will not suffer them to depart from their contracts at their pleasure, leaving the party with whom they have contracted to the mere chance of any damages which a jury may give.
> 
> - Strong norm against affirmative specific performance for personal services

> [!note]+ Thoughts and Questions 
> - Ultimately hypocritical: he’s doing this to get the person to sing, and he knows it.
