---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Plane Old Scottish Inconvenience
Takeaway: "Two Steps: Alternate Forum, Gulf Oil Balancing"
Tags:
  - Forum Non Conveniens
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1981
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Piper Aircraft Co. v. Reyno
Status: Annotated
Date: 1981-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Pilot and five passengers killed in plane crash in Scotland
> - Plane made in Penn by Piper, propellers in Ohio by Hertzall
> - Reyno (Cal lawyer’s secretary) becomes administratrix for passenggers, suing Piper and Hertzall in US
> - Strict liability for tort in US, but not Scotland
> 
> > [!note]+ Glenn’s
> > A Scottish pilot and 5 Scottish passengers are killed when a small plane crashes in Scotland. All the next of kin and heirs are Scottish too. There are no eyewitnesses to the accident.
> > 
> > The plane crashed while under the control of Scottish air traffic control. But the aircraft was made in Pennsylvania, by Piper, with propellers made in Ohio by Hartzell. The plane was owned and registered by Air Navigation, a British company, and operated by McDonald, a Scottish company that was incorporated in Britain. The wreckage is now in Britain.
> > 
> > A preliminary investigation suggested that the propeller caused the crash, but a later Review Board adversary hearing found no evidence of mechanical problems and suggested pilot error.
> > 
> > <u>Proceedings</u>: In comes a California lawyer. He gets his secretary, Reyno, appointed administratrix of the 5 passengers’ estates and sues only Piper and Hartzell in a wrongful death action in California state trial court claiming negligence and strict liability theories. These same 5 survivors represented by Reyno also sue separately in the United Kingdom against the other defendants (Air Navigation, McDonald, and the Pilot’s estate). Removal, transfer.

> [!note]+ Procedural History and Posture
> - P Filed in Cal state court
> - D Removed to fed Cal district court
> - P moves to transfer to Penn district court
> - D moves to dismiss for lack of PJ or transfer
> - Court quashes service for Cal district
> - P re-serves in Penn
> - D moves to dismiss for forum non conveniens
> 
> > [!note]+ District Court: grants motion to dismiss 
> > - Don’t consider less favorable law in Scotland
> > - Private Interest of litigants: Favor Scotland
> >     - Plaintiff’s choice of forum little weight since P represents foreign citizens taking advantage of US law
> >     - Connections with Scotland “overwhelming”
> >     - Separate suit is already in Scotland, better to combine
> > - Public interest: Favor Dismissal
> >     - Penn law would apply to Piper, Scottish to Hartzell, confusing for jury
> >     - Enormously costly/time consuming
> >     - Scottish interest in outcome
> 
> > [!note]+ 3rd Circuit: Reverses
> > - Automatically bar forum non conveniens with less favorable law in alternate forum (Scotland)
> > - But also they abused *Gulf Oil *discretion
> >     - Plaintiff’s choice of forum still substantial weight, even if foreign
> >     - Private Interest: Not Proven Scotland
> >         - No real help by seeing topography
> >         - Impleader of 3rd party defendants not relevant
> >     - Public Interest: Ohio or Penn, not Scotland
> >         - Too much emphasis on Scottish law
> >         - Not clear we would even have to apply it

- Issue: How to apply forum balancing test?

> [!note]+ Holding (Marshall): 1) Is there alternate forum? 2) *Gulf Oil*
> > [!note]+ 1st Step: Is there an alternate forum? (less favorable law doesn’t automatically bar dismissal)
> > - Safety Valve: Choice of law only at play when other forum’s remedy is “so clearly inadequate or unsatisfactory that it is no remedy at all”
> >     - In this case, the problem is really that there is not actually an alternate forum.
> > - Less favorable law does not automatically bar dismissal, shouldn’t even be given substantial weight
> >     - Otherwise, would rarely operate (plaintiff picks forum in large part for choice of law)
> >     - Also, analysis would become very difficult
> >     - Only give weight when 
> >     - Here, that is not the case.
> 
> > [!note]+ 2nd Step: Gulf Oil Balancing (district court correctly applied)
> > - Standard of review high, this whole thing is discretionary
> > - Private Interests
> >     - Appropriate to consider foreignness of plaintiff (to forum)
> >     - Impleader for 3rd party defendants is relevant
> > - Public Interests
> >     - Even without choice of law, Scotland has the strongest interest in the litigation
> 
> - Disposition: Reversed
