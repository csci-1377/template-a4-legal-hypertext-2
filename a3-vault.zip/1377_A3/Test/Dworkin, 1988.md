---
base: "[[Test.base]]"
In-Text Citation: (Dworkin, 1988)
Priority: Essential
Authors: Dworkin, Ronald
Title: "Law’s Empire:"
Zotero URI: https://zotero.org/bmcanally21/items/N5Y3224I
Takeaway: ""
Tags: []
Category:
  - Dissertation
  - Normative Analysis
Abstract: ""
Type: Book
Rating: "*****"
Full Citation: "Dworkin, R. (1988) Law’s Empire: Cambridge, MA: Belknap Press."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1988
---
> [!note]+ Preface
> > [!note]+ Structure
> > > [!note]+ Motivation
> > > - “We live in and by the law. It makes us what we are.”
> > > - We are bound by the law and argue about it even when the text is silent
> > 
> > > [!note]+ Thesis
> > > - Legal reasoning is an exercise in constructive interpretation
> > > - Our law consists in the best justification of our legal practices as a whole
> > > - The narrative story that makes of these practices the best they can be
> > > - Interpretation is construction of the law in an attempt to make it the best it can be
> > > - Employs reason and imagination
> > 
> > > [!note]+ Positivism
> > > - Cannot understand the obligation to find right answers in complex cases and defer to precedent
> > > - Thinks there cannot be right answers in complex cases, only different ones
> > 
> > > [!note]+ Response
> > > - There are right answers to be created, even if not to be proven to all as acceptable
> > > - This is about morality, not metaphysics
> > 
> > > [!note]+ Other Views and Thinkers
> > > - Views
> > >     - Soft positivism
> > >     - Economic theory of law
> > >     - Critical legals studies
> > >     - Passive and “Framer’s Intention” theories
> > > - People
> > >     - John Finnis
> > >     - HLA Hart
> > >     - Neil MacCormick
> > >     - Joseph Raz
> 
> > [!note]+ Thoughts
> > - Can’t the question of what the law is from the outside be seperable from what it is from the inside? Something like what we cannot help but take it to be, or even should take it to be, as its subjects and authors.
> > - There can’t be a right answer to a complex legal question viewed from the external perspective because the resources available run out. But there can be from within, that which has the best reasons behind it, which must make use of the norms of the practice.
> > - Keep an eye out for how this blurs the lines between morality and law, perhaps failing to see not only facts, but constraining norms that arise within the practice. 
> > - So maybe even Dworkin’s judge is insufficiently internal, adopting the internal fact of normativity but not the norms themselves. This is perhaps why his theory gives judges too much discretion/leeway?
> 
> > [!note]+ Further Reading
> > - A Matter of Principle
> > - Taking Rights Seriously

> [!note]+ Chapter 1: What is Law?
> Law is an argumentative practice about both empirical facts and the grounds of law, and other theories (semantic theories) fail because they fail to recognize this
> 
> > [!note]+ Intro
> > - Our courts are our most important and most misunderstood state institution
> > - Law has a moral dimension (judge must decide not just who gets what, but who behaved well). So the law matters.
> > - Then, because the law often becomes what judges say it is, judicial decisions matter
> > - So it matters what they think the law is.
> > - And they disagree, so it matters what kinkd of disagreement they are having.
> >     - Empirical (what happened)
> >     - Law 
> >         - Empirical (Whatever disagreement remains once grounds are agreed to)
> >         - Theoretical (Disagreement in grounds)
> >     - Political morality and fidelity (stick by an unjust verdict?)
> >         - What the public thinks is happening, but rarely actually live.
> 
> > [!note]+ Plain Fact View
> > - Some reject theoretical disagreement as an illusion
> > - Disagreement must rest on an empirical mistake, so some must be disobeying or ignoring the law
> > 
> > > [!note]+ Popular version
> > > - Judges should always follow the law rather than improve it (Bad if you bend)
> > > - Or they should always improve it (bad if you uphold injustice)
> > 
> > > [!note]+ Academic version
> > > - Law can be silent, but then there is no law. The question is what to do when the law runs out.
> > > - Here there are no right answers, only different ones
> > > - Approach cautiously, democratically, or adventurously
> > > - Radically, law is almost always vague, so there is never really law, only rhetoric.
> > 
> > - The more we learn, the more we move from layman’s trust that law is everywhere to cynics conviction it is nowhere.
> 
> > [!note]+ Internal and External
> > - External (sociologist, historian) how are judges influenced by class etc?
> > - Internal (practicioner) practical questions of how to move forward as a member of the practice
> > - Both essential, include each other
> > - Some say it’s all external. This fails to see law as an argumentative practice with no account of good or bad argument, so fails even by the external standard unless everyone is lying or incompetent.
> 
> > [!note]+ Cases
> > > [!note]+ Elmer:
> > > - Murdered grandfather for will money. Statute does not mention this as an exception clause. Should he get the money?
> > > - Gray- Literal interpretation, words in acontextual meaning
> > > - Earl- Focus also on legislature’s intentions and general principles of law for broad coherence
> > 
> > > [!note]+ Snail Darter
> > > - Endagered species act lets secretary of interior block construction to protect habitats. Conservationists find the snail darter, a tiny fish, will be wiped out if the TVA dam goes through. Construction on the dam halts, goes to the Court.
> > > - Burger says we should keep it halted (like Gray)
> > > - Powell says we should look to common sense (kind of like Earl)
> > 
> > > [!note]+ McLoughlin
> > > - Woman suffers emotional trauma from seeing family in the hospital after a car crash. Past awards have only been made to those closer to the crime scene.
> > >     - Question of whether and how much to adhere to precedent.
> > >         - Either distinguish the case or make a policy claim if not
> > 
> > - About the proper grounds of the law, not morality or repair
> > - So two kinds of “statute”: the physical entity and the law created by enacting it.
> > - Legal interpretation is like literary interpetation then, finding out the “real” statute
> 
> > [!note]+ Semantic Theories
> > - Some supporting plain fact view say it is because the meaning of “law” must depend on specific criteria, which lawyers actually agree on, and anyone challenging these must be self-contradictory. 
> > - Positivist: Historical events
> >     - Austin- Sovereign command 
> >     - Hart- Acceptance of a rule of recognition by the community
> > - Natural Law: Moral facts
> >     - Extreme: law and justice coincide
> >     - Moderate: sometimes look to morality in ambiguous cases
> > - Realism: Instrumental and predictive rules
> >     - Dramatic skepticism: no such thing as law, or only a matter of what the judge had for lunch.
> 
> > [!note]+ Why do we argue, then?
> > - Fingers-crossed: to systematically keep truth from people so they aren’t disolusioned or angered
> >     - But it is hard to see why this would be necessary or successful
> >     - And there is no evidence that this is what is happening
> > - Sophisticated: there is core and penumbral disagreement, and we can disagree about borderline cases
> >     - But borderline semantic quarrel is silly (is Buckingham Palace a house) and an issue of repair/fidelity, not the law
> >     - And there is core disagreement, which doesn’t make sense here. It wouldn’t really be disagreement, but talking past each other
> > - This must be wrong. Law is not a “grotesque joke”
> > - We don’t need to insist on it in order to resist nihilism about the law.
> 
> > [!note]+ Questions
> > - Do we really need to let judges judge morality, saying who behaved well?
> 
> > [!note]+ Thoughts
> > - Egoism is an analogue here. Some insist, without any positive evidence, that we act altruistically or internally to the law. There is no evidence for this, and in fact, most people seem to really care/take law seriously.
> 
> > [!note]+ Second Read
> > > [!note]+ Stakes
> > > - It matters how judges decide cases
> > > - Matters what they think the law is
> > > - Matters what disagreement they are having (3)
> > > - Offer “new” statements of law as reporting what the law already is (6)
> > 
> > > [!note]+ Positivism
> > > - Theoretical disagreement is an illusion (7)
> > > - Law is always a matter of social and historical fact, not morality, sometimes discover no law
> > > - Really over morality and fidelity/repair, not law
> > > - Proceed cautiously, democratically, adventurously? (9)
> > > - Rule of recognition that finds actual agreement
> > > - “Law is a flourishing practice, and though it may well be flawed, even fundamentally, it is not a grotesque joke” (44)
> > 
> > > [!note]+ Social Discussion
> > > - “Nor do I discuss the practical politics of adjudication, the compromises judges must sometimes accept, stating the law in a somewhat different way than they think most accurate in order to attract the votes of other judges, for instance. I am concerned with the issue of law, not with the reasons judges may have for tempering their statements of what it is. (12)
> > > - Brown- “Unanimity was purchased by an opinion… that was in many ways a compromise” (if inconsistent, plessy overruled, and with all deliberate speed)
> > 
> > > [!note]+ Argumentative Practice (Internal point of view)
> > > - Every actor in the practice understands that what it permits or requires depends on the truth of certain propositions that are given sense only by and within the practice; the pracrtice consists in large part in deploying and arguing about these propositions. (13)
> > > - the historian cannot understand law as an argumentative social practice, even enough to reject it as deceptive, until he has a participant’s understanding, until he has his own sense of what counts as a good or bad argument within that practice. We need a social theory of law, but it must be jurisprudential for just that reason (14)
> > > - Disagreement is not just about the margins, but about the core (43)
> > 
> > > [!note]+ Statutes
> > > - Physical entity (letter) or law created (statute) (16)
> > > - Disagree about how to construct the “real” poem from the text (17)
> > > - Forms part of a larger intellectual system, the law as a whole, it should be constructed so as to make that larger system coherent in principle (but does each judge need to try to do that?)
> > 
> > > [!note]+ Starting with disagreement on panels
> > > - Snail darter case: about “how judges should decide what law is made by a particular text enacted by congress when the congressmen had the kind of beliefs and intentions both justices agreed they had in this instance.”
> > 
> > > [!note]+ Precedent
> > > - Strict- obliges judges to follow earlier decisions “even if they believe those decisions to have been wrong” (24)
> > > - Relaxed- “some weight to past decisions, must follow unless he thinks them sufficiently wrong to outweigh the initial presumption in their favor” (25)
> > 
> > > [!note]+ Realism as a semantic theory
> > > - Lawyers commonly predict that judges will make mistakes about the law, or judges to state a view then a hope or expectation that it will change (37)

> [!note]+ Chapter 2: Interpretive Concepts
> > [!note]+ Intro
> > - Semanticists? say we can only argue sensibly if we follow the same criteria for adjudicating claims (only borderline, no pivotal disagreement)
> > - But much disagreement is theoretical, so the semantic account falls short
> 
> > [!note]+ Interpretive attitude
> > - This practice has value/purpose
> > - What is involved is sensitive to this purpose
> > - When we adopt both, value and content are entangled
> > - And we can create a concept of interpretation, which again is an act of interpretation
> 
> > [!note]+ Kinds of Interpretation
> > - Conversational (subjective?)
> > - Creative (intersubjective?)
> > - Scientific (objective?)
> >     - No, because we are creating explanations, which have their own standards of assessment.
> > - Creative interpretation is essentially purposive, and since it is more than just trying to determine another’s purpose, it is constructive (trying to make it the best example of a form)
> > - Conversation and scientific interpretation are also ultimately like this, since they involve invoking principles about the best constructions of someone’s speech or data. 
> 
> > [!note]+ Intention
> > - Not just a concious mental state
> > - Something we must apply, which is not neutral or purely historical
> > - But what else can we find in purpose other than historical intention?
> 
> > [!note]+ Objection
> > - But all you’re trying to do in conversation is figure out someone’s intention, and the same is true of law
> > - Intention still invokes construction
> > - Deciding that is our standard at all is itself an act of construction
> > - A focus on intention depends upon a prior claim about where value lies. 
> > - And conversation isn’t the right view, because this is more than just what people mean
> > - No, because an argumentative practice can’t just be a claim about what other interpreters think. 
> > - To critique the practice, one must join it, making claims competitive with those of others.
> 
> > [!note]+ Stages of Interpretation
> > - Preinterpretive (content of practice identified)
> > - Interpretive (impose purpose)
> > - Postinterpretive (new understanding of what practice “really” requires)
> > - Actually less deliberate and structured
> 
> > [!note]+ Convictions Needed
> > 1. What counts as the practice
> > 2. How close a justification must fit the features of the practice
> > 3. What features would actually show the practice in the best light
> > - 2 and 3 need to be distinct, otherwise no invention/interpretation distinction
> 
> > [!note]+ Concept vs Conception
> > - Concept is the plateau of shared agreement within which controversy can be identified
> > - Conception is the controversial claim about what makes the concept the best it can be
> 
> > [!note]+ Paradigms
> > - Play a central role in disagreement about conceptions, but not semantic, since no one has complete authority
> 
> > [!note]+ Relationship to Reflective Equilibrium
> > - Rawls seeks equilibrium between judgments and theory
> > - Dworkin looking for equilibrium between justification and requirements of a practice.
> 
> > [!note]+ Objectivity and Skepticism
> > - How can we think one interpretive view is better than another when they contradict?
> > - Objectivity
> >     - Used to distinguish moral/interpretive claims from reports of taste. To say that we can argue about it, not about any metaphysical status
> > - Internal Skepticism: within the enterprise of interpretation
> >     - Local- That interpretation is wrong
> >     - Global- All interpretations are wrong
> > - External Skepticism: outside or about the enterprise
> >     - A metaphysical theory that these opinions are not part of the “fabric of the universe”
> >     - Can’t provide any threat to the practice
> > - Disguise
> >     - Many claim to be making external skeptical arguments with the force of the internal, but really they are just making internal arguments, so the metaphysical arguments are of no use
> 
> > [!note]+ Second Read
> > > [!note]+ Interpretive Attitude
> > > - When members of communities disagree about what they actually require in concrete circumstances
> > > - Genuine not because they agree about the the criteria for deciding when claims are sound, but because the interpretations are directed toward the same objects or events
> > > 1. Assumption that the practice has value
> > > 2. Requirements of the practice are sensitive to its point
> > > - So people try to impose meaning on the institution
> > > - Interpretation of this kind is essentially about purposes, not just causes.
> > > - But purposes at play are not those of some author, but of the interpreter (52)
> > > - “Creative interpretation, on the constructive view, is a matter of interaction between purpose and object” (52) Not between persons?
> > 
> > > [!note]+ Individual v social
> > > - “Each citizen, we might say, is trying to discover his own intention in maintaining and participating in that practice… Description of social interpretation as a conversation with oneself… (58)
> > > - Each of the participants in a social practice must distinguish between trying to decide what other members of his community think the practice requires and trying to decide, for himself, what it really requires. … social scientist must “give up his methodological individualism” and use the methods his subjects use in forming their own opinions about what courtesy really requires. He must, that is, *join* the practice he proposes to understand… (64)
> > > - (Note 15?)
> > > - “Even if we assume that the community is a distinct person with opinions and convictions of its own, a group consciousness of some sort, that assumption only adds to the story a further person whose opinions an interpreter must judge and contest, not simply discover and report. He must still distinguish, that is, between the opinion the group consciousness has about what courtesy requires, which he thinks he can discover by reflecting on its distinct motives and purposes, and what he, the interpreter, thinks courtesy really requires. He still needs a kind of interpretive method he can use to test that entity’s judgment once discovered, and this method cannot be a matter of conversation with that entity or anything else.” (65)
> > >     - Yes, it can. But conversation not to report, but to construct as best they can.
> > 
> > > [!note]+ Morality and Construction- Pg 80+
> > > - Moral language is statements within, rather than about morality
> > > - “Objective” beliefs most of us have are moral, not metaphysical
> > > - *We* do not say (nor can we understand anyone who does say) that interpretation is like physics or that moral values are “out there” or can be proved… The practices of interpretation and morality give these claims all the meaning they need or could have (83)
> > 
> > > [!note]+ Originalism
> > > - Argument on 61
> > > 

> [!note]+ Chapter 3: Jurisprudence Revisited
> When we understand interpretation, then we can use legal language flexibly and in context to signify both a preinterpretive assessment of the data to be assessed and an postinterpetive judgment about what is “really” law according to a given conception
> 
> > [!note]+ Intro
> > - Centripetal forces (bringing convergence)
> >     - Paradigms
> >     - Precedent 
> >     - General intellectual environment
> >     - Conservative education
> > - Centrifugal forces
> >     - Rival traditions and ideologies
> >     - Changing times
> >     - Not bad, otherwise practice would lose meaning and life
> > - This interpretive life of law lets us believe what judges say
> > - Also means that there is no sharp line between legal theory and legal practice (judge’s opinions are pieces of legal philosophy)
> 
> > [!note]+ Stages of Process
> > - Preinterpretive agreement about what is part of the practice under assessment, but this contingent, local, and atheoretical.
> > - Doesn’t mean that we need some definition of a legal system is necessarily.
> > - No paradigm is definitionally part of the practice
> > - A central concept is usefull, but not necessary
> 
> > [!note]+ Dworkin’s Concept of Law
> > - That which guides and constrains the power of government as licensed or required by rights and responsibilities flowing from past political decisions about when collective force is justified
> > - Justice: Best theory of moral and political rights
> > - Law Restated: Which rights justify collective force because of past political decisions
> > - Or: Justifies *in principle *the use of collective power against citizens or groups
> > - Different from traditional values and true justice because its content depends on both.
> > - So the positivism/natural law debate is between different political theories about how justice should figure into their opinions about what legal rights have been created by past decisions
> 
> > [!note]+ Conceptions of Law
> > > [!note]+ Answer 3 Questions
> > > 1. Is the link between law (flowing from past decisions) and coersion justified?
> > > 2. What is the point of this connection?
> > > 3. What notion of consistency with these decisions best serves that purpose?
> > 
> > > [!note]+ Conventionalism
> > > 1. Yes!
> > > 2. Predictability and procedural fairness
> > > 3. Only matters to avoid explicit contradiction (when ambiguous, just look forward)
> > 
> > > [!note]+ Pragmatism
> > > 1. No
> > > 2. See above
> > > 3. None, just do what you think is best. Legal rights don’t exist, but act like they do if it’s useful.
> > > - Only defeated when we include political philosophy in our argument
> > >     - **But why should we include political philosophy in legal argument?**
> > 
> > > [!note]+ Integrity
> > > - Yes!
> > > - Not just predictability and procedural fairness, but “a kind of equality among citizens”
> > > - Not just in explicit cases, but also principles underlying past decisions
> > 
> > - No matter what, these will have implications for other more general concerns in political morality and even metaphysics, even if not realized.
> 
> > [!note]+ Skepticism and Wicked Law
> > - Start with the interpretive judgment of system-level local skepticism (this legal system has no “real” law, as in it has no normative force)
> > - Compatible with recognizing the existence of law as a preinterpretive matter (a strand in the Wittgensteinian rope)
> > - Semantic theories deny this flexibility between preinterpretive and interpretive judgments, insisting that we either include or exclude wicked legal systems in our definition of law.
> > - This insistence is unnecessary and dangerous, and is not a conceptual question, but rather one at the level of competing conceptions
> 
> > [!note]+ Grounds and Force of Law
> > - Grounds: circumstances upon which the truth of legal propostions depend
> > - Force: relative power of true legal propositions to justify coersion
> > - Legal theories must consider each
> >     - Conceptions only consider grounds, so don’t really tell us how anyone should behave
> >     - But this doesn’t mean they are not at all political. They just underdetermine what judges should do
> >     - Theories of civil disobedience tell us about force, not grounds
> 
> > [!note]+ Thoughts
> > - He plugs Neurath on 111!

> [!note]+ Chapter 4: Conventionalism
> Conventionalism does not either fit our current practice (because, paradoxically, judges actually pay more attention to the law in hard cases than conventionalism prescribes) nor does it justify it, since the aims of balancing protecting expectation with flexibility are better served by pragmatism.
> 
> > [!note]+ Intro
> > - Slogan: the law is the law
> > - Attitude: the force of law should only attach to explicit conventions everyone agrees on. Respect and enforce these conventions, and only these, as law. In hard cases, the right decision is left open, so be honest that you are just using discretion.
> > - Positivism: similar, but conventionalism does not insist on the incoherence of rival views, only their wrongness. It admits what it is.
> > - Positive Component: follow the law, don’t make new law in its place
> > - Negative Component: Use extralegal standards when you have to and be honest about it.
> 
> > [!note]+ Appeal
> > - Why is past politics decisive of present action? only when it depends on plain facts available to all
> > - Compatible with employing one’s own political or moral convictions as little as possible and deferring to legislature or populat will in ambiguous cases (but doesn’t require this)
> 
> > [!note]+ Fit
> > > [!note]+ Do we really have these conventions?
> > > - Apparently, in ordinary experience (most of us see the bottom of the iceberg, where things are not even in court but just settled as laws)
> > > - But upon closer inspection it can’t make sense of legal disagreement, which is actually most of the practice of law (especially appellate law)
> > > - Underdetermines how much and what kind of agreement is required
> > 
> > > [!note]+ Strict
> > > - relies on explicit extension, or what (almost) everyone agrees to and acceots as part of the convention
> > > - restrictive and weak conception of law, claims that there are often “gaps” in the law.
> > 
> > > [!note]+ Soft
> > > - relies on implicit extension, or the best interpretation of the convention, even if there is disagreement
> > > - Can always find a more abstract explicit consensus from which to argue for a controversial implicit interpretation
> > > - everyone can be a soft conventionalist then, so it isn’t really conventionalism at all, but immature integrity
> > 
> > > [!note]+ Consistency
> > > - In strategy
> > >     - how to fit with prior law to make good law, like any lawmaker must consider
> > > - In principle
> > >     - Standards have to express a single and comprehensive vision of justice… Really?
> > >     - People are entitled to a principled extension of past decisions even when judges disagree
> > > - Can only insist on consistency in principle if that itself were an explicit convention
> > 
> > > [!note]+ Failure of fit
> > > - Only looks to sources of law for evidence of best extralegal directive (popular will or legislative intent) or constistency in strategy, not in principle. 
> > > - The more that the practice consists of real controvery, the less that conventionalism can serve as an effective guard against extralegal argument.
> > > - Fails to fit because judges pay more attention to conventional sources (statutes and precedent) conventionalism allows them to. Can’t make sense of a legal obligation in hard cases. 
> > 
> > > [!note]+ Convention and consensus
> > > - Even when we do agree, it is a matter of shared conviction at least partially
> > > - We don’t think we need substantive reasons for accepting conventions, and if we want to change them, the argument must occur outside the practice (changing the rules of chess)
> > > - But we argue about even settled practices within the law, so clear distinction about arguments about and within rules as would be needed.
> > > - Some things may simply be accepted as convention (or axiom) but the point is we don’t need anything to be. We at least assume most things can be futther justified.
> 
> > [!note]+ Justification
> > - Is the ideal balance of protected expectation important and best served by conventionalism?
> > - First, surprise isn’t in principle unfair, and conventionalism doesn’t best protect against it. That would be unilateralism (defendent wins if ambiguous. This is the case in criminal, but not civil law)
> > - Convention: when we follow a rule primarily because others follow it, and it is more important that we have a rule than what it is.
> > - Conviction: when we follow a rule primarily because we think it is right, regardless of whether others follow.
> > - So it has to instead insist on this balance between reliance and flexibility needed for coordination of action. Since it matters sometimes what the rule is, then when no institution has decided one way or another, the courts should decide what rule is best.
> > - But… pragmatism might actually achieves this balance better (if you think judges reason well) because they can change a rule if inefficient or unjust. So conventionalism fails to justify the practice as well
> 
> > [!note]+ Questions
> > - How does this make sense of the fact that judicial discretion does have the force of law and contributes to precedent?
> > - Can we accept that as a member of an institution it is not our role to work from base principles? Does this mean that we can treat most things as convention most of the time, or at least give weight to prior reasoning in individual cases?
> 
> > [!note]+ Thoughts
> > - Integrity looks to make precedents morally sounder in retrospect, and some principles can be a part of the law because of their moral appeal. Or regard as law what morality suggests to be the best justification of past decisions. Isn’t that dangerous?
> > - Collective reasoning plays a role here. Because if you have to reason alone you really are stuck as Hercules, but if we can reason together than precedent can have additional force. Panels of judges are the best example of collective reason. 
> > - This interpersonal reasoning thing grounds public reason considerations.
> > - Law as integrity “rejects the divorce between law and politics” (128) and I want to secure or insure that. How?
> > - Maybe this allows us to not bracket moral and political considerations, but have them factor in somehow prior to individual judicial reasoning? 
> > - Is consistency inherently monistic? (134)

> [!note]+ Chapter 5: Pragmatism and Personification
> Pragmatism provides a more compelling conception of law than conventionalism, but struggles to fit the current practice. “As-if” rights would need to be some kind of “noble lie”, and it isn’t clear that these would be worth it. Pragmatism can justify the practice well unless we see an intrinsic value in treating like cases alike, or integrity in legislation and adjudication. This follows from personifying the community as a collective agent, which judges represent, and which must then speak with “one voice”. If we accept personification and therefore integrity, then pragmatism fails.
> 
> > [!note]+ Description
> > - Pragmatism is to realism as conventionalism is to positivism. It does not rely on any semantic claims, but is an interpretive conception, more powerful than conventionalism
> > - Skeptical attitude toward the ability of past decisions to justify coercive power. 
> > - Consistency with past legislative or judicial decisions does not, in principle, contribute to the virtue of present ones.
> > - Judges should decide and act on their own views.
> > - There are no legal rights, but judges can act *as if* there are in a “noble lie” to help serve long-term interests.
> 
> > [!note]+ Fit
> > - Might look a lot like what we have.
> > - The question of what rule to make and how to decide the individual case are not necessarily, but are practically related because applying rules retrospectively get people to anticipate and act in accordance with whatever rules they think judges will implement. So judges will often act as if they are “discovering” law that was already there.
> > - Can it explain judge’s obsession with the “true” force of a statute or precedent? Only if we assume noble-lie reasons, which seems neither necessary nor effective. 
> > - Can be rescued only by procrustean machinery, requiring epicycles to explain as-if rights in practice. So it needs a damn good justification to make those worthwhile.
> 
> > [!note]+ Justification
> > - Rejects legal, but not moral or political rights, and may create as-if legal rights in pursuit of the others.
> > - Is the idea of legal rights even attractive? Why is it not just fetishizing doctrinal elegance, a slave to coherence for its own sake.
> > - If judicial controversy is inevitable, why shouldn’t it be about what really matters, injustice? How can that be unjust? How can consistency in principle be valueable, especially when it is uncertain what consistency requires? 
> > - Because it follows from a group obligation of integrity (see below). If this is true, then pragmatism must be rejected.
> 
> > [!note]+ Political Virtues
> > - Fairness: procedures to distribute political power in the right way (usually equally among citizens)
> > - Justice: What decisions existing powers should make.
> > - Procedural Due Process: correct procedures for judging whether someone violated the law
> > - Integrity: the government must speak with one voice to act in a principled and coherent manner
> >     - Take the state or community as a moral agent with a single, coherent set of principles
> >     - This provides a general, nonstrategic argument for legal rights
> >     - The life of the law as we know it
> >     - In legislation: the law should be coherent in principle
> >     - In adjudication: we should see and enforce it as coherent
> 
> > [!note]+ Personification
> > - Not some spooky metaphysics (168)
> >     - No collective point of view, interest, welfare, or other analogues to the individual
> > - Responsibilities that cannot be reduced to individual claims.
> > - No point if not connected to judgments about how real people must act. 
> > - Blame doesn’t carry from the group to the individual, but responsibility does.
> > - What allows political officials to have responsibilities we can’t explain in individual morality. Judges myst be impartial because they are acting as agents of the community
> > - Group responsibility is logically prior to individual responsibility in these cases.
> 
> > [!note]+ Quotes
> > > In hard cases judges must make controversial judgments of political morality whichever conception of law they hold (163)
> 
> > [!note]+ Thoughts
> > - Integrity, as described, is opposed to hypocrisy, maybe look to Shklar to ask about the importance of hypocrisy? Makes us ignore cruelty? (168)

> [!note]+ Chapter 6: Integrity
> Integrity is the best conception of law because it both fits and justifies the practice. It fits our practice because judges do seem to be searching for coherent principles underlying statutes and precedent, and it justifies it by supporting state legitimacy through communal obligation. We need to see integrity as important in the law to adopt the perspective of the group coherently, and therefore have corresponding associative obligations.
> 
> > [!note]+ Intro
> > - Integrity: an ideal independent of fairness and justice, and can conflict with both
> > - Legislative integrity: make the law morally coherent
> > - Adjudicative: see and treat it as coherent
> 
> > [!note]+ Fit: Checkerboard/Internal Compromises
> > - inconsistency in principle among the acts of the state personified: a Solomonic compromise
> > - Fairness and justice cannot explain why this is wrong
> > - Integrity rejects this, saying compromises must be external to the system, compromising about what system of justice to adopt, not adopting a compromized scheme of justice
> > - This doesn’t mean that they are always wrong, as justice sometimes outweighs these concerns, where fixing some injustice at the cost of integrity is worth it.
> > - Examples: 
> >     - Three-fifths compromise
> >     - Equal protection clause outlaws internal compromises
> >     - Abortion: not an issue that it’s up to the states inherently, but there is a question os whether that deference is coherent with nationalization of other rights
> 
> > [!note]+ Justification
> > - State personified not by metaphysics but morals: because the practices of viewing it this way ought to be protected.
> > - Accepting integrity allows the formation of a form of community which…
> >     - Promotes the moral authority of the state
> >     - Protects against partiality and deceit
> >     - Improves efficiency in law 
> >     - Promotes collective authorship of the law
> >     - Expand the role of individual citizens
> >     - Fuses their moral and political lives
> 
> > [!note]+ Legitimacy and Political Obligation
> > - Obligation is necessary but not sufficient to justify coersion
> > - Legitimacy: if the constitutional structure and practices are such that citizens have a general obligation to obey political decisions
> > - Other Arguments
> >     - Tacit Consent
> >         - Based on a social contract
> >         - Can’t be binding unless given freely
> >         - Poor candidate here
> >     - Duty to be Just
> >         - Is univeralistic, can’t explain obligation to a particular state
> >     - Fair Play
> >         - Assumes we can incur obligations by receiving what we aren’t looking for and would reject if we could
> >         - Or turns on a nonexistent counterfactual to see how we would “otherwise” have been
> 
> > [!note]+ Communal/Associative Obligation
> > - Usually seen as based in emotional bonds
> > - Smacks of nationalism and racism, so we avoid generally
> > - Doesn’t require choice to generate, but is sensitive to reciprocity in interpretation
> > - Four Criteria of  True Community
> >     - Special- hold distinctly within the group
> >     - Personal- run directly from each member to each other
> >     - Concern- pervasive and genuine
> >     - Equality- must think everyone is equally worthy
> > - Objection: it doesn’t solve the problem but evades it
> >     - It does ask us to either deny associative obligation or show why political obligation can’t be associative
> 
> > [!note]+ Conflicts with Justice
> > - Within group: from a defective, although sincere, concept of equal concern
> > - Between group: tribalism and aggression
> > - Interpretation will help to read some injustices as not “really” part of the practice, but it will not do so for all of them. 
> > - 
> 
> > [!note]+ Models of Community
> > - What must a political society be like to genrate a true community?
> > - De Facto Accident
> >     - Might be because they are selfish or universally altruistic
> >     - Violates first condition: no special concern
> > - Rulebook
> >     - Rules define obligations, not principles underlying them
> >     - Conventionalism assumes this, rejecting integrity
> >     - Has special, personalized obligation but no pervasive concern. Allows one to game the system
> >     - Thinks of politics as a kind of game
> > - Principle
> >     - The promise that the law will be chosen, changed, developed, and interpreted in an overall principled way.
> >     - Allows claiming moral legitimacy in the name of fraternity
> >     - Requires a shared understanding that we are governed by principles, not just rules, so we can have rights even if not formally identified or declared
> >     - Works with all four conditions: a special, personal, pervasive concern that “tends toward equality”
> 
> > [!note]+ Adjudication
> > - Judges must treat teh system as respecting a coherent set of principles, interpreting the standards to find implicit ones between and beneath the explicit
> > - Integrity doesn’t completely determine what judges should do: perhaps one should lie or resign in extreme cases.
> 
> > [!note]+ Consistency
> > - Consistency: repeating past decisions closely or precisely
> > - Integrity: both more and less
> > - Too conservative: No, it encourages a judge to be wide-ranging and imaginative in his search for coherence with fundamental principle.
> > - Integrity provides less room for practical arguments than pragmatism
> > - Some distinction between principle and policy allows integrity to also be narrower than consistency, but it isn’t clear why.
> 
> > [!note]+ Quotes
> > > If we can understand our practices as appropriate to the model of principle, we can support the legitimacy of our institutions, and the political obligations they assume, as a matter of fraternity, and we should therefore strive to improve our institutions in that direction (215).
> > 
> > > Integrity is a more dynamic and radical standart than it first seemed, because it encourages a judge to be wide-ranging and imaginative in his search for coherence with fundamental principle (220).
> 
> > [!note]+ Thoughts
> > Write on page 189

> [!note]+ Chapter 7: Integrity in Law
> What judges are doing when they interpret the law is trying to view contemporary legal practice as an unfolding narrative and making their decisions consistent with that narrative to make the law the best it can be from the perspective of political morality. This is like what a single author of a chain novel would do, with no clear separation between finding and inventing law, or between his role as critic and author.
> 
> > [!note]+ Intro
> > - Conventionalism: backward looking
> > - Pragmatism: forward looking
> > - These are interpretations, but not programs of interpretation. They do not ask a judge to interpret the law in individual cases.
> > - Integrity: both, law is an unfolding narrative. 
> > - No distinction between finding and inventing law. A judge is doing both and neither
> > - Grounds of law: whatever follows from the best constructive interpretation of legal practice
> > - History: matters only to achieve horizontal consistency to justify the actions of past politicians for a story worth telling now.
> 
> > [!note]+ The Chain Novel
> > - Imposing purpose over a text through creative interpretation
> > - Judges are working as both authors and critics in constructing a chain novel
> > - Tested on dimensions of fit and justification
> > - Leaves open that no interpretation will fit completely, and even that none will fit sufficiently for a coherent enterprise
> > - Or more than one can fit, in which case he needs to decide which is best. These will be matters of judgment
> >     - Formal (textual coherence)
> >     - Substantive (aesthetic)
> > - No distinction between interpretation and authorship
> > - Neither a free nor a constrained judgment because both are one’s own convictions. They just have to be sufficiently independent to check each other or otherwise constitute bad fairth or self-deception
> > - The decisions are not about departure from the novel since there is no “real” novel that can be discovered independent from a process of interpretation.
> 
> > [!note]+ Hercules
> > - An imaginary judge of superhuman intellectual power and patience
> > - His answers are not definitive of law as integrity. Integrity consists in an approach, in questions rather than answers
> > - Must make decisions on grounds of principle, not policy.
> > - First assesses fit as a threshold, then some combination of fit and justification to find the best.
> > - Real judges can only imitate Hercules in a limited way
> > - The question of whether to articulate an unstated principle is one of political morality
> > - Directly engaging moral and political convictions, treating all principles followed in the past as provisional
> 
> > [!note]+ Local Priority
> > - Compartmentalization is a prominent feature of legal practice.
> > - Law as integrity condemns this in general spirit but must recognize it and fit the practice 
> > - Match popular opinion and promote predictability a
> 
> > [!note]+ Neutrality
> > - Objection: never rely on one’s personal convictions, only use morally neutral means
> > - But the argument rests on political premises. So it’s not about whether political morality is relevant, but which principles are sound
> > - So why isn’t integrity giving out in some hard cases for something like natural law theory? Because integrity isn’t just about common principles, but the best common principles
> 
> > [!note]+ Skepticism
> > - No one can be objectively right in hard cases
> > - External: because right answers are not “out there”
> > - Internal: because our practice is too contradictory, even with a department of law, so generate a coherent interpretation.
> > - Mistakes competition of principles for their contradiction. When principles can, but don’t necessarily, conflict, we just need a sch
> 
> > [!note]+ Critical Legal Studies
> > - People making skeptical claims about legal practices.
> > - Claim to be “demystifying” law and demonstrating how it reflects ideology and power.
> > - Opposed to economic approach to law
> > - Resembles legal realism, but makes an internal rather than external skeptical claim.
> > - Can be useful to Hercules, to see that nothing guarantees a coherent interpretation, but also nothing necessarily prevents one.
> > - The burden is not to come up with a skeptical interpretation that fits at least as well as a non-skeptical one, but showing that the skeptical account is the only one available.
> > - It is important, because we should be asking whether and how judges can improve the law while respecting the virtues of fraternity and integrity, but the point should not be to show law at its worst. 
> 
> > [!note]+ Quotes
> > > law as integrity consists in an approach, in questions rather than answers (239)
> > 
> > > He can allow the scope of his interpretation to fan out from the cases immediately in point to cases in the same general area or department of law, and then still farther, as far as seems promising (245)
> 
> > [!note]+ Thoughts
> > - If you take seriously being only one of many authors, than you accept that you should not always interpret law as a whole in each case.
> > - Confuses justice de re and de dicto on 249. If you recongize that justice may not be what you think it is, then you are not necessarily compromising justice when you adopt a position of epistemic humility in deferring to the judgments of other judges. 
> > - Epistemic reasons can count as reasons to adopt compartmentalization of the law. Law as integrity can’t make sense of this practice without an acknowledgment of individual fallibility and the process of interpersonal reasoning.
> > - Thinks on most cases it is possible to see when one adheres to this method and when another judge has not as an undefended empirical claim.
> > - Dworkin ignores the question of when and how we might need to constrain our interpretation in a given case because our political convictions tell us to.
> > - Compatible with liberalism because it can endorse neutrality toward conceptions of the good in politics without neutrality about principles of justice, because that is a principle of justice.

> [!note]+ Chapter 8: The Common Law
> The economic theory of law assigns duties and corresponding rights to maximize the wealth of the community. It works generally to fit our practice, but cannot justify it. Instead, an egalitarian principle when abstract rights conflict better fits and justifies the practice of common law.
> 
> > [!note]+ Economic Theory of Common Law
> > - Principle: People should always act in whatever way will be financially least expensive for the community as a whole (maximize communal wealth)
> > - This means that, if transaction costs are zero, it doesn’t matter how they allocate torts (it matters to the parties, but not the community, since the parties will transact efficiently)
> > - But since they aren’t ever zero, the legislator should choose the rule that will get the parties to transact as they would if the costs were $0
> > - Reasonableness principle comes from the desire to lower time spent calculating relative costs
> > - Fit: works pretty well, meets the threshold requirement
> > - Justification
> >     - doesn’t deploy a general scheme of moral responsibility
> >     - academic elaboration reveals the true nature of a theory, and on this it fails: it is wrong in principle, even if generating reasonable practice
> >     - Increasing wealth doesn’t improve the community, and it also isn’t a great proxy for utilitarian maximization
> 
> > [!note]+ Egalitarian Theory of Common Law
> > - We have a duty to treat others’t interests equally to ours when our abstract legal rights conflict
> >     - Permissive when deciding how to use clearly assigned property rights
> >     - Strict/egalitarian in deciding *what *the scheme has assigned them
> > - This is because our government, as the community personified, has this duty. The government sets up a property scheme within which we have personal discretion but about which we are bound by the law.
> > - Conceptions of Equality
> >     - Libertarian: natural rights
> >     - Welfare-based: most commonly utilitarian
> >     - Material: even wealth throughout lives
> >     - Resources: basically equality of opportunity?
> > - Welfare and material compete with private choices, but libertarian and resource do not (resource so long as we ignore Nozick’s rights of giving money)
> > - On resource account (Dworkin’s preferred) compare financial costs because they are a proxy for interests when wealth is the same (but not if resources are and they now have different wealth because of choices!)
> > - So this really only works in the abstract because (for some reason) we should assume the average person has equal wealth?
> > - Accepts complete aggregation of interests in calculation most of the time
> > - Treat these as one-off interactions because a back-and-forth tradeoff will only work for a small number of people.
> 
> > [!note]+ Decisions of the Legislature
> > - Should, on the whole, strive for regulating property to bring people closer as equals under the best conception
> > - But they don’t have to do this in every decision, and can otherwise pursue the general interest for policy reasons in particular circumstances.
> > - But once the legislature has chose, these legal rights then extend by principle into cases not yet decided. Adjudication must occur between equals.
> 
> > [!note]+ Thoughts
> > - So judges have to assume a scheme of equality interpreted best on the whole and assume whatever follows from that. Whatever this conception is will inevitably be controversial, why do we think judges are entitled to to that kind of reasoning?
> > - Though this applies to common law, and not apparently statutes.

> [!note]+ Chapter 9: Statutes
> “Speakers’ meaning” theories of law ultimately collapse into law as integrity, since in order to answer the questions necessary to determine whose intention and what kind of intention matters one must inevitably commit to one or another controversial position, and conversational interpretation becomes constructive when this happens.
> 
> > [!note]+ Speakers Meaning (Hermes)
> > > [!note]+ Basics
> > > - Statutes should be interpreted according to the legislators’ intent
> > > - Democratic principles insist on this
> > > - Judges must respect legislative history as evidence of the mental states of legislators
> > > - Proper interpretation is conversational, not constructive
> > 
> > > [!note]+ Important questions
> > > > [!note]+ Which people are legislators? (Who are the authors of a statute?)
> > > > - Private citizens who sent letters? Lobbyists?
> > > > - Subsequent generations who didn’t amend it?
> > > > - Speker’s meaning can’t answer this question, so choice must be independent of it and sensitive to his own convictions.
> > > 
> > > > [!note]+ How can we discover their intentions?
> > > > - Sometimes we can’t, but this is the least of our problems
> > > > - What mental states constitute intention?
> > > > - Hopes can be for all the wrong reasons, and are too internal and personal.
> > > > - Expectations/predictions also can’t be right, both because they can be for bad reasons and because it creates an infinite regress for judges trying to determine what someone else predicted they would do.
> > > 
> > > > [!note]+ When they differ, how should we combine them?
> > > > - Majority, plurality, representative legislator?
> > > > - Once again, a matter of personal judgment
> > 
> > > [!note]+ Counterfactual mental states
> > > - What would x have intended if they had thought of the problem?
> > > - Can’t be what they would have hoped for/expected for the reasons above
> > > - Also can’t be whether they would have voted for an amendment specifying the issue (both the content and circumstances of the amendment are underdetermined, with *any* content/circumstances forming too low a bar and *every* set too high of one. 
> > > - So the choice of counterfactual is similarly arbitrary and controversial
> > 
> > > [!note]+ Convictions
> > > - The ultimate solution to how to resolve intention: those convictions that would justify the vote.
> > > - Avoids counterfactuals and mental states
> > > - Need not be perfectly coherent. Before conflicts of hopes and expectations didn’t matter, but now they do. 
> > > - Once these are directed not at a single legislature but an institution, the principel of looking for intention just becomes adjudicative integrity.
> > > - Hermes becomes Hercules’ twin
> 
> > [!note]+ Integrity (Hercules)
> > > [!note]+ Basics
> > > - Similar for statutes as common law, except Congress is a prior author in the chain of law, and the role it to continue to develop the statutory scheme Congress began.
> > > - A statute’s purpose is the upshot of integrity
> > > - Intention is not a matter of mental states, nor could it be, since institutions don’t have minds, but constructive interpretations can be directed toward the record of institutions and practices as well as individuals.
> > 
> > > [!note]+ Principle and Policy
> > > - Policy matters. But not just for a substantive outcome. Trying to find the best justification of a past legislative event
> > > 
> > > > Account must justify the story as a whole, not just its ending 
> > > 
> > > - Sensitive not only to convictions about justice and wise policy, but integrity and fairness and proceedural due process
> > > - Convictions about fairness can place obstacles between his own preferences and judgments about what is best to do.
> > 
> > > [!note]+ Legislative History
> > > - Similar to explanations of why one made a promise: should be treated as acts of the state personified, but reports what a promise performs. Should not be taken as an infallible report. It can be innaccurate in a way that a promise can’t be.
> > > - Community of principle sees legislation as grounded in deeper principles, and the practice of explanations confirms this. 
> > > - But this force grows weaker with the passing of time. And later Congressional statements should also be taken into consideration
> > > - Not a choice between the dead but legitimate hand of the past and the illicit charm of progress. 
> > > - There is no canonical moment, and there are no exclusively priveleged “framers,”
> > > - Hercules interprets history in motion, because the sotry he must make as good as it can be is the whole story through his decision and beyond. Does not amend out-of-date statutes, but recognizes what they have since become.
> > 
> > > [!note]+ Clear Language
> > > - There is no difference in kind between the method of easy and hard cases. 
> > > - Unclear might be from an ambiguous, vague, or abstract word, or alternately from an apparent conflict with underlying principles of the law. 
> > > - Unclearness is the result, rather than the occasion of interpreting statutes
> > > - A statuete’s vagueness or ambiguity will only be troublesome when there is doubt about what makes the statute best on grounds of integrity.
> > > - So there is no “easy-case” problem. When the answers are obvious, we are simply unaware of the theoretical work we are doing.
> 
> > [!note]+ Quotes
> > > He must rely on his own judgment in answering these questions, of course, not because he thinks his opinions are automatically right, but because no one can properly answer any question except by relying at the deepest level on what he himself believes (314).
> > 
> > > He (the legislator) treats the document, not himself or any other person, as the author of the message he agrees to send (322).
> > 
> > > Nothing counts as someone’s conviction unless he recognizes that what actually follows from it depends on what is in fact true, not what he thinks is true (331).
> > > - Carries this distinction to normative facts on 333
> > 
> > > A judge must ultimately rely on his own opinions in developing and applying a theory about how to read a statute. He cannot, without circularity, remit any part of the task to the legislature whose enactments he will use his theory to understand (334). 
> > 
> > > His own political convictions… are the only ones he has (334). 
> > 
> > > He must ask himself whether it is better for legislators to reach the right result even when their constituents think it very much the wrong one (340)
> > > - Skips over the de re/de dicto distinction
> 
> > [!note]+ Thoughts
> > - NA stuff on page 318, asking who are the authors of a statute
> > - Does acting on principle and with integrity require acting from one’s own convictions? (329)
> > - Statements of convictions being transparent to subsititution (332). Something follows from this, but not sure exactly what.
> > - Can’t make sense of things like compartmentalization because assumes internal reasoning is all that is available to judges.
> 
> > [!note]+ Further Reading
> > - Wittgenstein: Dworkin really seems to like him.

> [!note]+ Chapter 10: The Constitution
> Law as integrity leads to neither judicial activism nor passivism, since the former fails to see convictions of fairness and fit as restrictions on justice and the latter must assume conventionalism, which we have rejected. 
> 
> The project of constitutional interpretation is where political morality must factor most broadly into a judge’s decision.
> 
> > [!note]+ Intro
> > - The court wasn’t necessarily the interpreter of the Constitution, Marbury v Madison took care of that
> > - But since it has historically been established that the Court has these powers, the question is just how they should be excersised
> > - Relevant Questions
> >     - What parts of the Constitution should they enforce? Even the most political stuff?
> >     - What standard should they set? Plainly wrong, on balance whatever they would prefer?
> >     - What test should they use to decide what meets these criteria?
> 
> > [!note]+ Liberal and Conservative 
> > - Can’t just be a question of fidelity to the oath
> > - Really two dimensions: fit and substance
> >     - Fit- How closely should decisions conform with past decisions and intentions
> >     - Substance- What is the character of his convictions about justice
> > - Sometimes seen as interpretivist and noninterpretivist, but this is misleading
> > - The great debates of constitutional method are within interpretation, not about its relevance
> 
> > [!note]+ Opacity
> > - basically whether their is a distinction between de re and de dicto
> > - Commitment is transparent
> > - Knowledge is opaque
> > - In taking rights seriously pg 134 and A Matter of Principle Chaprer 2
> 
> > [!note]+ Historicism
> > - Can’t be conventionalism, because we have no explicit convention where framers’ concrete intentions fix consititutional law.
> > - Can’t be speaker’s meaning, which collapses inevitably into law as integrity as seen from Hermes
> > - Must be that contitutional story is better when read exactly as the political statements in original legislative debates declare.
> > - An argument of fairness won’t really work, because majoritarian institutions won’t be able to effectively secure individual rights
> > - An argument from integrity will acknowledge the weakening relevance of statutes and legislative debates over time, because new chapters have since been added to the story.
> > - An argument from stability is the best we can do, which in its weak form says the constitution is better if relying heavily on the concrete opinions of its authors
> > - This only works in “rules of the road” cases, but many constitutional cases are those where the rule chosen is more important than choosing a rule.
> > - Can’t take individual rights seriously, because can’t accept them as forming a coherent conception of justice
> 
> > [!note]+ Activism and Passivism
> > > [!note]+ Muddles the answes to three questions
> > > - Enactment: who should make a constitution?
> > > - Jurisdictional: which institution, has the authority to decide what the constitution requires?
> > > - Legal: What does the constitution require?
> > 
> > > [!note]+ Passivism
> > > - Passivists need to answer the third question, but try to avoid it by focusing on the first two.
> > > - Passivism can rest on conventionalism, answering the third question by saying rights only arise from explicit conventions
> > > - It can also rest on skepticism, insisting that no theories of justice or equality can be better than others. But then they can’t insist thar fairness requires deference to democratic institutions, since that too rests on a theory of justice or fairness.
> > > - Fit- Not very well, since many decisions have pretty clearly declared rights that hadn’t been recognized before. But maybe it can count those as mistakes and meet the threshold of fit
> > > - Justification- Must claim legislatures will come up with better theories of what rights require than courts. This seems unlikely, since legislators are subject to majority rule.
> > > - So has to rest on fairness, and this is about deference to stable, abstract features of national political culture, not transient political majorities.
> > 
> > > [!note]+ Activism
> > > - Virulent form of legal pragmatism
> > > - Condemned by law as integrity
> > > - Not integrity, because integrity will not substitute his judgment for the legislature’s when he thinks the issue is about policy, not principle.
> 
> > [!note]+ Interpeting the Constitution
> > - Convictions about justice and policy are constrained by the text of a statute, fairness, and integrity
> > - Different from ordinary statutes
> >     - Foundational of other law
> >     - Justification is drawn from political theory broadly speaking
> > - Not “Natural Law”
> >     - Constitution is only what the best theory of abstract justice and fairness would produce through ideal theory
> > - Not a Tyrant
> >     - Not trying to cheat the public of its democratic power
> >     - When he intervenes, he does this in service of his most concientious judgment about what democracy really is and what the Constitution, parent and guardian of democracy, really means.
> 
> > [!note]+ Equal Protection Clause
> > - Must call for the concept of equality, not any particular conception
> > - Rival Views for Brown
> >     - Suspect Classifications: check distinctions when we think people’s preferences aren’t counted equally
> >         - So discriminating on the basis of race is sometimes ok
> >     - Banned Categories: Just can’t distinguish based on certain groups
> >         - The Constitution is color-blind
> >     - Banned Sources: Some preferences, like prejudice, shouldn’t be counted
> >         - Find out what legislation would be justified had tainted preferences not been counted
> >             - (Or any preferences arising from those tainted preferences, like the shop owner prefering to keep things segregated out of a concern for safety when others act out of prejudice?)
> >         - Distinguishes between affirmative action and discrimination
> > - Would have rejected the first, but not decided between the second two in Brown
> > - Remedy is also important, because the point of constitutional adjudication is not just to name rights but secure them
> > - Principle of Remedy: Judges have a duty to enforce constitutional rights up to the point at which enforcement ceases to be in the interests of those the rights are supposed to protect (392).
> > - In Bakke, would have selected Banned Sources over Categories
> > - Because the Constitution has explicitly and repeatedly rejected the principle that people must never be treated differently in virtue of properties beyond their control.
> > - Racial discrimination that disadvantages blacks is unjust, not because people cannot choose their race, but because discrimination expresses prejudice.
> 
> > [!note]+ Quotes
> > > Every concientious judge, in either of the supposed camps, is an interpetivist in the broadest sense: each tries to impose the best interpretation on our constitutional structure and practice, to see these, all things considered, in the best light they can bear. (360)
> > 
> > > We should be suspicious of any portmanteau, a priori, single-mindied interpretive strategy for deciding what a constitution is (379)
> > > - But we should also be suspicious of a completely broad ranging, interpretive strategy relying only on one’s own convictions.
> > 
> > > Lawyers are always philosophers, because jurisprudence is part of any lawyer’s account of what the law is, even when the jurisprudence is undistinguished and mechanical. In constitutional theory philosophy is closer to the surface of the argument and, if the theory is good, explicit in it. (380)
> > 
> > > An actual justice must sometimes adjust what hw believes to be right as a matter of principle, and therefore as a matter of law, in order to gain the votes of other justices and to make their joint decison sufficiently acceptible to the community so that it can continue to act in the spirit of a community at a constitutional level. We use Hercules to abstract away from these practical issues, as any sound analysis must, so that we can see the compromises actual justices think necessary as compromises with the law (381). 
> > > - Damn. Just accepts absolutely no role for reasoning with others.
> > 
> > > [Hercules is no Tyrant]. But if Hercules had renounced the responsibility I described, which includes the responsibility to decide what he must on **his own conviction** about his nation’s character, he would have been a traitor not a hero of judicial restraint. (399)
> 
> > [!note]+ Thoughts
> > - Conventionalism and Pragmatism are interpretations, but the methods aren’t interpreting. They say that all the interpretation should happen before taking up a particular case, that this means legal reasoning on particular cases should be formulaically restrained.
> > - But we could have a middle position, arguing why law, in its best light, calls for something other than a judge engaging in this wide-ranging process of construction in each individual endeavor of interpretation.
> > - Something about simultaneous co-authorship in method. It’s weird that he doesn’t think about interpersonal legal reasoning at all. Other contributions serve exclusively as inputs into a process of legal reasoning.
> > - Judicial conventions are only ever relevant as objects of judgments of fit, and have no weight beyond that. But collective reasoning requires that norms are adopted as part of the practice to be following any collective enterprise.
> > - Interpersonal reasoning might address the concern of whether judges should “be philosophers”. The concern is that they are only constrained by their own convictions, and that, since intelligence is not truth-seeking but convincing, might fool themselves.
> > - The author of an opinion whrites on behalf of the court, and what they decide is decided with one voice.
> 
> > [!note]+ Further Reading
> > - Ely, Democracy and Distrust: A theory of judicial review (1980) - Justices need to enforce fairness considerations, because those are about what democracy is, which can’t be decided by democracy itself.

> [!note]+ Chapter 11: Law Beyond Law
> Distinguishing between inclusive and pure integrity allows law as integrity to be consistent with the principle that “law works itself pure” or that we can, at least in principle, improve the law. Also, some grand sweeping statements to conclude.
> 
> > [!note]+ Institutional Constraints
> > - Strict Docrines of Precedent
> >     - Requiring some judges to follow the past decisions of other judges even when they think these are mistaken) 
> > - Legislative Supremacy
> >     - Thinking the legislature should change the law does not affect what the law actually is
> > - Local Priority
> >     - Consistency within a local department should take precedence over broad consistency with base convictions of fairness and justice
> > - Any successful general interpretation of our legal practice must recognize these institutional constraints.
> >     - **But only as objects, not as methods?**
> > - Set up as integrity of the process somehow checking substantive integrity
> > - Understand these as matters of proceedural due process primarily upholding stability, which misses the point.
> 
> > [!note]+ Inclusive Integrity
> > - Gives effect to statutes that pull away from substantive coherence and follows institutional constraints that stand in the way of broader consistency in order to fit the law as it is.
> 
> > [!note]+ Pure Integrity
> > - Ideal theory of just law
> > - This is the “law beyond the law”
> > - Seen from the perspective of no institution in particular
> > - Optimism about what the law can be, looking to utopian theory
> > - Suggests a path forward towards the beacon/horizon of the ideal by “establishing a shadow of the future it celebrates”
> > - Proposes to show how law can develop in a particular direction of justice while preserving integrity stage by stage.
> > - Utopian legal politicians are chain novelists with epics in mind, part of the law’s story because these arguments remind the profession of the pressure of law beyond law.
> 
> > [!note]+ What is Law Again?
> > > Law is an interpretive concept
> > 
> > > General theories of law are general interpretations of our own judical practice.
> > 
> > > Integrity does not enforce itself: judgment is required.
> > 
> > - The question has to be which interpretation is the best it can be from the point of view of political morality
> > 
> > > Law’s empire is defined by attitude, not territory or power or process.
> > 
> > - We have to embody this attitude, not just in appellate courts, but in our ordinary lives
> > 
> > > Though judges must have the last word, it is not for that reason the best word
> 
> > [!note]+ Quotes
> > > Strict doctrines of precedent, the practices of legislative history, and local priority are largely, though in different ways, matters of procedureal due process because they encourage citizens to rely on doctrinal pronouncements and assumptions that it would be wrong to betray in judging them after the fact (405).
> > > - Just kind of misses the point about institutional structures.
> > > - If this is what they are, then so good warning in a dissenting opinion removes the reason to keep adhering to them (last endnote of the book).
> > 
> > > The courts are the capitals of law’s empire, and judges are its princies, but not its seers and prophets. It falls to philosophers, if they are willing, to work out law’s ambitions for itself, the purer form of law within and beyond the law we have (407).
> > 
> > > Every decision in a hard case is a vote for one of law’s dreams (410).
> > > - For idealists, perhaps. This is exactly the kind of philosopher a judge should not be.
> > 
> > > It is a protestant attitude that makes each citizen responsible for imagining what his society’s public commitments to principle are, and what these commitments require in new circumstances (413). 
> > 
> > > Law’s attitude is constructive: it aims, in the interpretive spirit, to lay principle over practice to show the best route to a better future, a fraternal attitude, an expression of how we are united in community though divided in project, interest, and conviction. That is, anyway, what law is for us: for the people we want to be and the community we aim to have (413). 
> 
> > [!note]+ Thoughts
> > - Maybe what judges should not be isn’t philosophers exactly but those pursuing pure integrity. Avoid a vision of the horizon of integrity, focus on evanda rather than ideals.
> > - Asking what interpretation is the best it can be must include the question of how that interpetation is arrived at. And acknowledging fallibility must allow for the possibility that it is not by individually determining the answer.


