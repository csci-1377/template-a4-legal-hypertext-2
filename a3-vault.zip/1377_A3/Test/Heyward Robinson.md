---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Excavation Inseparability
Takeaway: Logical relationship test for compulsory counterclaims
Tags:
  - Joinder
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1970
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: US v. Heyward-Robinson Co.
Status: Annotated
Date: 1970-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - D’Angostino is excavation subcontractor for two of Heywards’s construction jobs, one for the Navy and the other for Stelma Inc.
> - D’Angostino sues for breach on Navy job, Heyward counterclaims on both jobs
> - Jury finds Heyward owes D’Angostino 40k and D’Angostino owes Heyward 63k for counterclaims
> 
> > [!note]+ Glenn’s
> > D’Agostino and Heyward are both construction companies involved in constructing a naval submarine base and a non-federal job for Stelma, Inc. D’Agostino sues Heyward and its surety, Maryland Casualty Company for payments due under the navy job under the Miller Act, a federal statute.
> > 
> > Heyward denies it owes anything and counterclaims against D’Agostino for overpayments and extra costs on both the Navy Job and the Stelma Job.
> > In reply, D’Agostino denies liability on Hewyard’s counterclaims and itself adds a counterclaim against Hewyard for monies due on the Stelma job. One trial for all of the above.
> > 
> > At trial D’Agostino claims that Heyward had breached its subcontracts on both jobs by failing to make progress payments and that Heyward owed it substantial sums on both jobs. Heyward claims D’Agostino breached both contracts by allowing its compensation and employee liability insurance to lapse, that Heyward terminated both subcontracts on Oct 19, 1965, and that D’Agostino was liable for overpayments and costs of completion on both.
> > 
> > To the jury was submitted the issue whether Heyward had breached prior to Oct 19, 1965, when Heyward terminated the contracts. This was submitted as a special question. The jury found that Heyward had breached before that date.
> > 
> > At some point, D’Agostino amended its complaint to claim quantum meruit (value of performance done) for work performed on both jobs. That question is also submitted by special question to the jury, which finds that Heyward owes D’Agostino for both job $63,988.36, and judgment is entered for that amount.

> [!note]+ Procedural History and Posture
> - Heyward says no jurisdiction over counterclaim on Stelma because permissive, not compulsory (no SMJ, original or supplementary)
> - Note: SMJ challenges can be raised at any time

- Issue: Is the counterclaim compulsory or permissive (and, therefore, is there supplemental SMJ under 1367a)?

> [!note]+ Holding (Van Pelt Bryan): Compulsory: test is logical relation and list of what that includes)
> - No original SMJ for Stelma since both NY companies (no diversity) and no FQ
> - But there is supplemental, since that’s same as compulsory test, which is based on T&O, and Transaction is defined broadly (<u>logical relation</u>)
> - The contracts meet this test here
>     - Same parties
>     - Same type of work
>     - Payment was in lump sum for both
>     - Single insurance policy covered both
>     - Contract relation
>         - Heyward could terminate both if there was breach in either
>         - Ability to apply damages from one to payments on other
> - Disposition: Affirmed

> [!note]+ Concurrence (Friendly): Permissive (but still get supplemental SMJ)
> - Lens of preclusion- You have to do a counterfactual: if they had asserted one without the other, would you block them from bringing the other case?
> - Distinguishing factual from legal relationship
>     - So what about all those facts? Those are all coincidences.
>     - **But** what about the provision calling a breach of one same as breach of the other
>         - That was boilerplate
>         - Also, this didn’t factor into the actual case
>     - **But **the payments weren’t separated out
>         - This argument only came up at the trial, not the pleadings stage.
> - At that time, no 1367a, so can still get supplemental SMJ without compulsory counterclaim
> - It’s not the same T&O, but still the same CNOF?
> 