---
base: "[[Test.base]]"
In-Text Citation: (Srinivasan and Simpson, 2022)
Priority: Essential
Authors: |-
  Srinivasan, Amia
  Simpson, Robert
Title: No Platforming
Zotero URI: http://zotero.org/users/4316906/items/SLI5Y8E5
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Srinivasan, A. and Simpson, R. (2022) ‘No Platforming’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
> [!note]+ Intro
> - No platforming: “blocking, or attempting to block, an individual from speaking at a university because of her expressed moral or political views.”
> - From anti-fascist student protests in the UK in the 1970s, similar to disinvitation in the US
> - Now it is used to ban people who seem reasonable and sincere
> - Taken to be at odds with liberalism
> - But there are arguments for it compatible with liberalism

> [!note]+ Other Arguments
> - Reject liberalism
>     - Focus on negative individual liberty
>     - Insistence on public/private distinction
>     - Idealization of the public square
> - Harm Principle
>     - Agree there is a prima facie right to free speech
>     - Can be overridden to prevent serious harm
>     - Issue is whether there was really a threat of violence
>     - Have to determine which harms justify regulation
>     - Then distinguish influence, persuasion, and incitement
>     - Does a feeling of intimidation have to be reasonable?
>     - Does harmful influence have to be forseeable or intended?
>     - Too many controversial stances, likely won’t resolve the issue

> [!note]+ Their Argument
> - A university is a specialized, technical institution for the purpose of teaching and research
> - Pursuit of knowledge demands an inequality of the status of ideas
> - Content-based speech discrtimination is a regular practice
> - Based on disciplinary virtues of methodological care
> - Post: Self governance requires
>     - that everyone should be at liberty to participate in the public discourse that underpins democratic decisions
>     - that everyone should have access to the knowledge and information necessary for well-informed judgements about how we ought to be governed
>     - We need free speech for the first, and academic independence for the other
> - The norm here is one of independence from outside influence
> - So no platforming someone unqualifed can be justified in this way, while no platforming an expert because of external political pressure is unjustified
> - It matters how they are disinvited as well, whether by other experts or admin without consulting
> - This applies even to things like commencement addresses and student societies because they are connected to this culture
> - The problem is that the requirements of expertise are themselves contested, both within and between departments (accepting different things as up for discussion)
> - More radical view that students could be in a good position to no platform because they aren’t entrenched in the norms of the department as much.
> - Conclusion: we have more important threats to freedom of expression on campus than student no platforming (corporate sponsorship, private grants, government research agendas)














