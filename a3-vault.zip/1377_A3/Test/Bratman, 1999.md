---
base: "[[Test.base]]"
In-Text Citation: (Bratman, 1999)
Priority: Recommended
Authors: Bratman, Michael E.
Title: "Faces of Intention: Selected Essays on Intention and Agency"
Zotero URI: http://zotero.org/users/4316906/items/TGVPRTJZ
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This collection of essays by one of the most prominent and internationally respected philosophers of action theory is concerned with deepening our understanding of the notion of intention. In Bratman's view, when we settle on a plan for action we are committing ourselves to future conduct in ways that help support important forms of coordination and organization both within the life of the agent and interpersonally. These essays enrich that account of commitment involved in intending, and explore its implications for our understanding of temptation and self-control, shared intention and shared cooperative activity, and moral responsibility. The essays offer extensive discussions of related views by, among others, Donald Davidson, Hector-Neri Castañeda, Christine Korsgaard, Harry Frankfurt, and P. F. Strawson. This collection will be a valuable resource for a wide range of philosophers and their students.
Type: Book
URL: https://www.cambridge.org/core/books/faces-of-intention/29C09E3967EE9CD91E512366697156E6
Full Citation: "Bratman, M.E. (1999) Faces of Intention: Selected Essays on Intention and Agency. Cambridge: Cambridge University Press (Cambridge Studies in Philosophy). Available at: https://doi.org/10.1017/CBO9780511625190."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1999
---
