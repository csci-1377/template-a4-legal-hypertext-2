---
base: "[[Test.base]]"
In-Text Citation: (Buchanan, 2009)
Priority: Further
Authors: Buchanan, Allen
Title: "Philosophy and Public Policy: A Role for Social Moral Epistemology"
Zotero URI: http://zotero.org/users/4316906/items/W7A438GM
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: Part 1 of this essay argues that one of the most important contributions of philosophers to sound public policy may be to combat the influence of bad Philosophy (which includes, but is not limited to, bad Philosophy produced by accredited academic philosophers). Part 2 argues that the conventional conception of Practical Ethics (CPE) that philosophers bring to issues of public policy is defective because it fails to take seriously the phenomenon of the subversion of morality, the role of false factual beliefs in this subversion, and the vulnerability to the exploitation of our moral powers that our social-epistemic dependency entails. Given the serious risks of the subversion of morality through the propagation of false factual beliefs, CPE's near exclusive emphasis on identifying sound moral principles greatly constrains its potential contribution to the Negative Task of Practical Ethics, the endeavour to reduce the incidence of the most grievously wrong behaviour. Practical ethicists should focus more on the ethics of believing, and develop a more sophisticated conception of the moral and epistemic virtues of individuals and of institutions, one that includes protective meta-virtues, whose function it is to guard us against the more frequent and predictable subversions of morality, including those subversions that are facilitated by the processes of belief-formation that our social institutions and practices foster.
Type: Journal Article
URL: https://www.jstor.org/stable/24355876
Full Citation: "Buchanan, A. (2009) ‘Philosophy and Public Policy: A Role for Social Moral Epistemology’, Journal of Applied Philosophy, 26(3), pp. 276–290."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2009
---
