---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Highway Drinking Age
Takeaway: Five part test (focus on b, c, e) for contingent state funding (lots of ways to avoid coersion)
Tags:
  - GWC
  - States' Rights
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "****"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: South Dakota v. Dole
Status: Annotated
Date: 1987-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 18th Amendment insitutes prohibition, 21st repeals
> - Congress enacts Minimum Drinking Age Act 1984
> - Withholds federal highway funds from states that fail to raise the drinking age to 21
> - South Dakota sues Dole, secretary of transportation, claiming regulation is unconstitutional as an excercise of spending power

- Issue: Can Congress regulate highways with its spending power?

> [!note]+ Holding (Rehnquist): Yes
> - Doesn’t need to be enumerated for valid spending
> - Limited by
>     1. must be in pursuit of “the general welfare” (defer to Congress) (doesn’t come up)
>     2. Must unambiguously enable states to knowingly participate
>         1. Avoiding creation of dependency or reliance
>     3. Illegitimate if unrelated to federal interest in particular projects (reasonably calculated)
>         2. Prevent large leverage for pretext
>     4. Other constitutional provision that might bar conditional grants (also doesn’t come up)
>         - Less exacting than what can’t be regulated directly
>         - Just can’t induce states to engage in unconstitutional activities
>     5. Must not be so coercive that “pressure turns into compulsion”
>         - Here only a relatively small percentage of highway funds is contingent (5%)