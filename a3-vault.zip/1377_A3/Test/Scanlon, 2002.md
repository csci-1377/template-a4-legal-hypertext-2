---
base: "[[Test.base]]"
In-Text Citation: (Scanlon, 2002)
Priority: Recommended
Authors: Scanlon, T. M.
Title: Rawls on Justification
Zotero URI: http://zotero.org/users/4316906/items/GMYSUWDX
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Book Section
Rating: "***"
URL: https://www.cambridge.org/core/product/identifier/CBO9780511998850A007/type/book_part
Full Citation: "Scanlon, T.M. (2002) ‘Rawls on Justification’, in S. Freeman (ed.) The Cambridge Companion to Rawls. 1st edn. Cambridge University Press, pp. 139–167. Available at: https://doi.org/10.1017/CCOL0521651670.004."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2002
---
> [!note]+ Rawls ُ Three ideas of justification
> - Reflective equilibrium
>     - Inductive
> - Derivation of principles (Original Position)
>     - Deductive
> - Public Reason
>     - Vague, restrictive

> [!note]+ Two Kinds of Justification
> - Person: view held for reasons reasonably taken to be good and sufficient
> - Principle: is supported by good and sufficient reasons (without regard to a lack of info etc)
> - (Is there a third, community, where we can say we are justified in holding principle?)
> - A person can be justified in holding an unjustified principle

> [!note]+ Reflective Equilibrium
> - Not clear what kind of justification is involved
> - Process continues indefinitely

> [!note]+ Considered Judgements
> - Conditions
>     - Aware of relevant facts
>     - Able to concentrate
>     - Does not stand to gain or lose
> - Way judgement is held
>     - Confident
>     - Stable over time
>     - Intuitive (not requiring principles to get to)
> - Can Include…
>     - Rawls in *Outline* defines as grounded, for actual cases
>     - In *Theory* says judgements with supporting reasons
>     - In Presidential Address says can include all levels of generality
>         - (How is this not just principles in disguise?)
> - Reasons
>     - Appropriate to ask for and give reasons
>     - This is what makes them judgements, and why they are open to revision

> [!note]+ Descriptive Aim
> - Brackets question of moral truth
> - Characterizes conceptions held by specific group
> - Considered judgements because
>     - Most accurate representation of our sensibility
>     - Rule out factors interfering with capacity
>     - Rule in accurate portrayal of sensibility
> - Seems merely to paint portraits of possible conceptions, not to justify them
>     - (Unless there is normative force in saying that this one is *ours*)

> [!note]+ Deliberative Aim
> - Method for figuring out what we *should * believe about justice
> - Considered judgements because 
>     - most likely to be correct
>     - Rule out what is unreliable
>     - Rule in what we have best reasons to be true

> [!note]+ External Commitments
> - Morality has no controversial empirical or metaphysical presuppositions
>     - So not connected to claims about psychology or rational choice
>     - (If it doesn’t, why give a fuck about it?)
>     - But also crucial that it has authority in reasonable person (which entangles it)
> - What is controversial is practical, not theoretical

> [!note]+ Process
> - Person whose considered judgements are in question has to be involved
> - Something we must each carry out for ourselves
> - (Second does not follow from the first. What follows is that we have to *participate)*

> [!note]+ Charge of Conservatism
> - Lacks the independence to give it real critical/justificatory force
> - Conservative as opposed to what?
> - If includes all, then vacuous?
>     - It isn’t, because it rejects that we could exclude any considered judgements or include any unconsidered
> - (Great! This is Neurath’s boat thing. What other kind of independence could we possibly have?)
> - (This is why it is fundamentally unlike science and necessarily conservative)

> [!note]+ Charge of Relativism
> - If others perfectly applying method can get to different results, then do we have to say they are both equally justified?
> - No, we ask if their inputs were as good, and if their process was, and this process of comparison can change my own
>     - (This is why relativism is too early or too late. This is an important part of the process though!)
> - The fact that RE could lead to a result that calls objectivity into question is a necessary consequence of not begging the question against skepticism

> [!note]+ Public Reason
> - Stability: When institutions are just, people have reason to help maintain them and develop a corresponding sense of justice
> - Also need stability for the right reasons, not just force or indoctrination
> - This might be inconsistent with reasonable pluralism
>     - Differing comprehensive views (meaning of life, freedom, good life, religious and secular)
> - Alternative solution in Political Liberalism, through idea of overlapping consensus
> - But can only apply to constitutional essentials because basic and do not have opportunity for contestation
> - That this is possible appeals not really to the possible comprehensive views, but rather reasonable persons
> - Reasonable persons will only accept conception that does not depend on a particular comprehensive view, because that would require force to ensure
> - (This would seem to exlude a whole bunch of people)

> [!note]+ Quotes
> it is crucial to morality that it also be a method of reasoning about what to do that all reasonable individuals have good reason to regard as authoritative and normally overriding. (147)
> 
> This is in my view the best interpretation of Rawls’s sometimes seemingly conflicting remarks about the method of reflective equilibrium. Moreover, it seems to me that this method, properly understood, is in fact the best way of making up one’s mind about moral matters and about many other subjects. Indeed, it is the only defensible method: apparent alternatives to it are illusory. (149)
> 