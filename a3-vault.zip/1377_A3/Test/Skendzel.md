---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Pseudo-Mortgage
Takeaway: Land sales contracts treated as equitable mortgages
Tags:
  - Mortgages
  - Liquidated Damages
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1973
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Skendzel v. Marshall
Status: Annotated
Date: 1973-01-01
Jurisdiction: Indiana
---
> [!note]+ Facts
> - Land contract includes forfeiture provision (liquidated damages clause) allowing vendor to keep prior payments 
> - D doesn’t make payments
> - P sues seeking enforcment of forfeiture

> [!note]+ Procedural History and Posture
> - D wins at trial
> - Appeals reverses, finding no waiver of forfeiture

- Issue: Is forfeiture provision enforceable?

> [!note]+ Holding (Hunter): No
> - Numerus Clausus issue: this should be a mortgage (where payments build equity) but it isn’t.
> - If this were mortgage, we wouldn’t allow a forfeiture (equity abhors forfeitures)
> - So we’ll call it an “equitable mortgage”
> - Damages must be reasonable proportion of loss suffered
> - Disposition: Reversed

> [!note]+ Concurrence (Prentice): No, but think about vendor more
> - Majority doesn’t take vendors contracting rights seriously enough