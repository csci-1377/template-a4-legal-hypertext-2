---
base: "[[Test.base]]"
In-Text Citation: (Scanlon, 2014)
Priority: Recommended
Authors: Scanlon, T M
Title: "Lecture 4: Epistemology and Determinateness"
Zotero URI: http://zotero.org/users/4316906/items/AXEW2BMP
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: There is no problem about knowledge of normative truths, or mathematical truths, arising from a di culty about how we could be in touch with facts about these subjects. Ideally, the possibility of such knowledge could be explained by an overall account of the subject in question, in its own terms. Such an account would also support the idea that statements about this subject have determinate truth values independent of us. The chapter defends the method of re ective equilibrium as a way of arriving at such an account. It concludes that we are unlikely to obtain an overall account of reasons for action, in particular that constructivist accounts of this domain are not likely to succeed.
Type: Book Section
Rating: "***"
Full Citation: "Scanlon, T.M. (2014) ‘Lecture 4: Epistemology and Determinateness’, in Being Realistic About Reasons. Oxford University Press."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2014
---
