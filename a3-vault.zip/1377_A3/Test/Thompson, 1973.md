---
base: "[[Test.base]]"
In-Text Citation: (Thompson, 1973)
Priority: Essential
Authors: Thompson, Judith Jarvis
Title: Preferential Hiring
Zotero URI: http://zotero.org/users/4316906/items/CGTXSUGN
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Thompson, J.J. (1973) ‘Preferential Hiring’, Philosophy & Public Affairs, 2(4), pp. 364–384.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1973
---
> [!note]+ Qualification
> - Academic indicators might be skewed by prejudice
> - Easily rationalized when thinking the candidate “isn’t serious”
> - We could say race or gender is itself a qualification
>     - Because x learns better from x’s: might have bad outcomes (if we hire whites because whites learn better frim them) and seems untrue
>     - Or we are looking for role models (**or people that help us feel welcome): **seems true, but will sidestep

> [!note]+ Private Universities
> - No problem: no stranger has a right to what is yours to dispose of (I can my give apples to whoever I want)
> - Some reasons might be morally bad, like racial animus, but don’t raise rights concerns (unless you harm or gratuitiously hurt)
> - You can also obligate yourself by your words (like advertising first come first served)
> - But, in reality, no university is wholly private

> [!note]+ Public Universities
> - Principle: Every owner of a jointly owned property has a right to either an equal chance at, or an equal share in, any benefit which that property generates
> - This right is overriden if deprived justly and violated if deprived unjustly
> - So we can only override if there is a conflicting more stringent right or great benefit at stake? 
> - No, we can make exceptions to the principle above, just not arbitrarily (gratitude to Smith so giving priority)

> [!note]+ Debts from Past Wrongs
> - To whom are they owed?
> - Do *we* really owe them?
> - Even if we don’t owe anything from justice, we might out of decency

> [!note]+ Imposing Burdens
> - The white male applicant is not asked to give up something to make amends, and certainly not something he has a right to, but is made to accept a burden
> - But this is appropriate, because jobs are the right form of compensation for the harm

> [!note]+ Discrimination
> - Seems like the definition implies injustice
> - If it seems like there is just discrimination here, we can…
>     - Say that it isn’t discriminating
>     - Try to change the meaning
>     - Avoid the phrase altogether 

> [!note]+ Questions
> - What is a pure benefit in this case? even money seems impure (372)
> - Who has the authority to make the exceptions to the principle? 

> [!note]+ Takeaways/Ideas
> - Only applies when not really tipping the scales (no legitimate assumption of diminished competancy). This is when it helps with advancing interests, not hindering them.
>     - Not clear that it is advancing the interests of the underrepresented applicant
> - Doesn’t discuss account of bias (to counteract skewed perception, both one’s own and that created by the system.
> - University can make it plain that they are prepared to allow racial identity to outweigh academic qualification (CMC has done this)
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
