---
base: "[[Test.base]]"
DOI: https://doi.org/10.15779/Z38C43K
In-Text Citation: (Kornhauser and Sager, 1993)
Priority: Essential
Authors: ""
Title: "The One and the Many: Adjudication in Collegial Courts"
Zotero URI: http://zotero.org/users/4316906/items/IZMTQMQH
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
Full Citation: "Kornhauser, L.A. and Sager, L.G. (eds) (1993) ‘The One and the Many: Adjudication in Collegial Courts’, California Law Review [Preprint]. Available at: https://doi.org/10.15779/Z38C43K."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1993
---
