---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Urban Dilution
Takeaway: One Person, One Vote (using Carr)
Tags:
  - ELC
  - PQ
Category:
  - Con Law
Abstract: ""
Page: 575
Type: Case
Rating: "***"
Year: 1964
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Wesberry v. Sanders
Status: Annotated
Date: 1964-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> After *Yarbrough*, Congress continued to regulate electoral districts as it had before the case, imposing equal population and compactness requirements on Congressional districts. But in the early 20th century, Congress failed to reapportion districts and in 1929 decided to no longer require states to adhere to any compactness/equal population requirements. As urban populations boomed, apportionment became more uneven – urban districts had 2-3x + the population of rural districts.  In *Colegrove*, the Court said (in plurality) that this was a PQ. The question returned to the Court in *Wesberry*. 

- Issue: Does unequal voting district populations violate EPC?

> [!note]+ Holding (Black): Yes, not a PQ
> - The Constitution has the plain objective of making equal representation for equal numbers of people the fundamental goal for the House of Representatives.
> - This is not a PQ, because Art. I § 2 says Congress shall be elected “by the people,” and the Court can interpret this language to mean “one person-one vote.” When you segregate districts into unevenly apportioned chunks, it violates Art. I § 2.
> - “By the people” does not necessarily mean “districts of equal size.” Why does the Court read it this way? **Fairness**. Court sees unfair practices in states and wants to deal with the problem; Court doesn’t trust Congress. (Bowie: This is why the Court intervenes in every case – because it doesn’t trust Congress).
> - Why Court intervention? The 435 people in the House have all won elections; they are winners of the status quo. It would be irrational for them to want to change the rules that led to their victory. Court invokes **historical practice** of Congress legislating to mandate one-person-one-vote (a century earlier) to come to this conclusion.
> 
> > No right is more precious in a free country thanthat of having a voice in the election.






















