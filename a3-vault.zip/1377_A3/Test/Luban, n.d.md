---
base: "[[Test.base]]"
In-Text Citation: (Luban, no date)
Authors: Luban, David
Title: "Freedom and Constraint in Legal Ethics: Some Mid-course Corrections to Lawyers and Justice"
Zotero URI: https://zotero.org/bmcanally21/items/IB9M3JYK
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Type: Journal Article
Full Citation: "Luban, D. (no date) ‘Freedom and Constraint in Legal Ethics: Some Mid-course Corrections to Lawyers and Justice’."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> the weight of professional obligations is finite, bounded above by the weighted product of the worth of the institution, the centrality of the professional role to that institution, and the importance to that role of a putative professional duty. 427. 

> even deontological duties are often prima facie rather than absolute; they can be overridden in exceptional cases.

> The point is that the marginal harms to the system that result from violating one's professional duty typically are slight in a single case. On the other side of the ledger, the marginal benefits of following common morality rather than professional duty may be great. Thus, when common morality clashes with role morality the exceptional cases in which the duty must be overridden simply devour the duty itself; role morality usually loses.

> consequentialists give priority to the goodness of outcomes ("the good") while deontologists emphasize the rightness of actions independently of outcomes ("the right").' 2