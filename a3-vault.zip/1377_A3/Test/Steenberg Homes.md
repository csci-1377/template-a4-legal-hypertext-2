---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: House Tracks in the Snow
Takeaway: Liability for Harmless Trespass (Essentialism)
Tags:
  - Trespass
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1997
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Jacque v. Steenberg Homes, Inc.
Status: Annotated
Date: 1997-01-01
Year*: 1997
Jurisdiction: Wisconsin
---

> [!note]+ Facts
> - Who: Harvey and Lois Jaques
> - What: Refused dragging a mobile home across their land
> - When: February 15, 1994
> - Where: Wilke’s Lake near Schleswig, Wisconsin
> - Why: Steenberg used a bobcat and hauled the home anyway

> [!note]+ Procedural History and Posture
> - Jury awarded $1 in nominal damages and $100,000 in punitive
> - Circuit court set aside punitive damages
> - Court of appeals affirmed, could not reinstate because precedent bound it to no punitive from only nominal (need compensatory)

> [!note]+ Relief Sought
> Punitive damages

> [!note]+ Issues
> 1. Whether nominal damages for intentional trespass support a punitive award, if so…
> 2. Whether the law should apply to Steenberg or only prospectively
> 3. Whether the $100,000 in punitive damages awarded by the jury is excessive

> [!note]+ Strongest P Argument
> - McWilliams “damages as a punishment to the defendent to make an example”
> - Individual interests to exclude (lots of SC precedent)
>     - What is lost is not harm to land, but to the right to exclude
>     - It is *actual harm*, even if it can’t be measured in dollars
>     - Also, repeat trespass can “ripen into adverse posession”
> - Societal interest in system of property and “preserving integrity of legal system”
>     - Helps to prevent citizen justice
>     - What else is to stop this from becoming regular policy if more profitable?

> [!note]+ Strongest D Argument
> - Barnard v Cohen, 1917- No to punitive with only nominal (society has no interest in deterring unlawful but harmless conduct)

> [!note]+ Holding
> - When nominal damages awarded in cases of intentional trespass, punitive damages may be awarded at the jury’s discretion. It also applies retrospectively, and is not excessive

> [!note]+ General Notes
> - Only intent required is to go onto the land, not that they knew belonged to someone else
> - Strict liability: no inquiry into balance of interests between parties (not the same for personal property)
> - Adverse posession is only in cases where permission isn’t given

> [!note]+ Thoughts
> - These arguments for land rights are circular. What matters most is settled expectations, but right to roam would work just as well.

> [!note]+ Questions
> - Land as an extension of body in personal autonomy rights?
> - Could Steenberg have claimed necessity since road was largely impassable?
> - Are we sure the damages aren’t excessive?