---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Repeat Rapist
Takeaway: The death penalty for rape violates the 8th Amendment
Tags:
  - 8A
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "**"
Year: 1977
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Coker v. Georgia
Status: Annotated
Date: 1977-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Georgia law says rape, if committed with aggravating factor, can be sentenced with death. Jury can not impose death if they find mitigating circumstances.
> - Coker breaks into home, batters husband, rapes wife, kidnaps her
> - Coker convicted of rape and sentenced to death

- Issue: Is the dealth penalty for rape disproportionate?

> [!note]+ Holding (White): Yes
> > Now settled that the death penalty is not invariably cruel and unusual punishment within the meaning of the 8th Amendment
> 
> > punishment is “excessive” and unconstitutional if it 
> > (1) makes no measurable contribution to acceptable goals of punishment and hence is nothing more than the purposeless and needless imposition of pain and suffering; or 
> > 
> > (2) is grossly out of proportion to the severity of the crime.
> 
> - Public Attitude: Georgia is the only state that still holds the death penalty for rape

- Concurrence (Brennan and Marshall): The death penalty is always cruel and unusual

> [!note]+ Concurrence/Dissent (Powell): Not always
> - Minimalism: no need to decide whole issue

> [!note]+ Dissent (Burger): No, not here.
> - Maybe for a first-timer, but this is a repeat rapist.
> 