---
base: "[[Test.base]]"
In-Text Citation: (Tadros, 2011)
Priority: Essential
Authors: Tadros, Victor
Title: "The Ends of Harm: The Moral Foundations of Criminal Law"
Zotero URI: http://zotero.org/users/4316906/items/E97I3FYH
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Book
Rating: "*****"
URL: http://www.oxfordscholarship.com/view/10.1093/acprof:oso/9780199554423.001.0001/acprof-9780199554423
Full Citation: "Tadros, V. (2011) The Ends of HarmThe Moral Foundations of Criminal Law. Oxford University Press. Available at: https://doi.org/10.1093/acprof:oso/9780199554423.001.0001."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2011
---
> [!note]+ ### Introduction
> > [!note]+ Summary
> > - Punishment is bad: costly, intentional harm
> > - Current practices are defective. 
> > - The right solution is instrumentalist: for general deterance
> > - This is based on the duties offenders incur because of their wrongful actions
> >     - Recognition- that what they did is wrong
> >     - Remedy- protect against future harm
> >     - Permission to harm someone in pursuit of a goal depends on the enforceable duties they have
> 
> > [!note]+ Method
> > - Non-contractualist: agreement is not fundamental
> > - Try to provide an argument
> > - When we can’t, appeal to intuitions of implications
> >     - Helps articulate principles
> >     - Encourages seeking satisfactory arguments
> >     - Open’s mind to accepting argument
> > - Criteria of Examples
> >     - Realistic
> >     - Clean (removing alternate explanations of intuition)
> >     - Don’t worry about realism too much. Science fiction proves that… “our moral capacities are not disabled in imaginative contexts that are unfamiliar or even paradoxical” (8)
> 
> > [!note]+ Outline
> > > [!note]+ Retributivism
> > > - Def- a) that the suffering of offenders is good because deserved; and b) that the state has a right to bring about deserved suffering. (9)
> > > - Recognition rather than the bad feeling we ought to aim at (10)
> > > - We can aim at recognition without conflicting with liberalism because recognition of public justice, legitimate aim to secure proper attitute towards just institutions
> > > - We shouldn’t use state resources to ensure goods are advanced
> > 
> > > [!note]+ Communication
> > > - Only modest contribution
> > > - Can’t justify costs
> > 
> > > [!note]+ Duty
> > > - Focus on crime prevention: good aimed at is security
> > > - Founded on significance of choice: we endorse the principle that provides people with a better opportunity to avoid being harmed
> > > - We harm culpable attackers to ensure they fulfil their responsibilities under these principles
> > > - Duty of the state to punish grounded in duty to rescue each other from harm at minimal cost
> > > - Proportionality and liberal limits flow from the duty view of state punishment

> [!note]+ ### Chapter 3: Recognition and Choice
> “it is recognition rather than suffering that we ought to aim at.” (59)
> 
> We don’t have to choose between retributivism and consequentialism
> 
> > [!note]+ The racist murderer
> > - Owes something to others, a burdensome obligation
> > - Something deficient if they do not feel bad
> 
> > [!note]+ Judgment and Affect
> > - “in people who are psychologically ordinary, the negative affective dimension of these emotions is almost inevitably caused by their valuable judgemental dimension.” 46
> > - Guilt
> >     - Anxiety
> >     - Frustration- craving to turn back the clock
> >     - How can this be good? **Because it makes you a responsive member of a community**
> >     - Only the judgments are valuable
> >     - GardnerL an emotional response may be fitting 
> 
> > [!note]+ Duty and Choice
> > - When wrongdoers do not suffer, we think they will have failed to fulfill a duty they incurred in virtue of their wrongdoing.
> > - Distinction between duties and the value of their content
> >     - In vindicating the idea that wrongdoers have a duty to bear a cost, we need not appeal to the intrinsic value of them bearing that cost. For in many other cases, we may think that a person has a duty to do something that is costly to them and nevertheless recognize that it is a bad thing that they must bear that cost (52)
> > - We don’t just care about quality and quantity of harm, but sensitivity to choice. 
> > - Without affecting the badness of the harm, opportunity to avoid affects what it is permissible to do 
> 
> > [!note]+ Right and Good
> > - Rightness/wrongness distinct from quality of outcomes. Can seek intrinsic appropriateness without seeking value.
> 
> > [!note]+ Thoughts
> > - Not clear suffering is always bad: especially cases where it is voluntarily undertaken as meaningful
> > - Tadros wants direct individual explanations

> [!note]+ ### Chapter 4: Against Desert
> Recognition and hoice better explains permissibility of punishment than desert
> 
> > [!note]+ Desert
> > - Best conception of free will rests on the compatibility of choice with determinism (compatibiliam) (63)
> > - uses citizens as a means to pursue an impersonal good on retributivist grounds
> > - Too vague to motivate any particular institutional arrangement (67)
> 
> > [!note]+ Retributivism
> > - H L A Hart’s marvellous rendition of this objection, retributivists appear to believe in ‘a mysterious piece of moral alchemy in which the combination of the two evils of moral wickedness and suffering are transmuted into good’.
> > - Foot in the door: it is appropriate to feel guilty when one has committed wrongm, and one suffers if feeling guilty
> 
> > [!note]+ Definitions
> > - Blame: involves the judgment that the person blamed behaved wrongfully
> > - Control: two senses, causation and compatibilism (65)
> 
> > [!note]+ Examples
> > - Two children growing up to commit a wrong
> > - Heroism: aren’t you lucky!
> 
> > [!note]+ Supporting Communication
> > - communicative theorists argue, we must focus on the action of making wrongdoers suffer rather than the outcome that wrongdoers suffer. (72)
> 
> > [!note]+ Objections
> > - Don’t expect justification to be entirely intrinsic We don’t try to justify democracy based on the value of voting… 72
> 
> > [!note]+ Liberalism
> > - We may reject the idea that the state must remain neutral about the good whilst denying that it is always permitted to coerce its citizens to pursue the good (81)
> 
> > [!note]+ Better Retributivism
> > - The state is charged with protecting the rights of its citizens. When a person violates those rights, the state has failed to do what it is responsible for doing. And it owes a response to the victim of crime, and perhaps to others, in virtue of this failure. We might then attempt to develop a view that shows that a fitting response for the state to make to the violation of the rights of one of its citizens is to impose punishment on the offender(84)
> > - Legitimacy: grounded in the restricted set of duties that the state has to protect the rights of citizens and respond to violations of those rights (85)
> > - It is true that the state has an obligation to respond to violations of the rights of its citizens. But the natural response that it should make is twofold: to communicate condemnation for violation of the rights, and to enforce the duties that offenders incur as a result of violating the rights of its citizens. (87)
> 
> > [!note]+ Thoughts
> > Desert is an objective evaluation of the criminal, whereas proper response is about the state
> > 
> > Difference between Moore’s blameworthiness and the judgment that we ought to censure.
> > 
> > Tadros focused on fair distributions rather than appropriate responses. Those to whom we distribute are not participants (71)
> > 
> > Pain is the cleanest form of suffering. Why not use that?
> 
> > [!note]+ Quotes
> 

> [!note]+ ### Chapter 5: The Limits of Communication
> > [!note]+ Initial Plausibility
> > - invites the state to treat defendants and offenders in a humane way, as responsible citizens who can understand and respond to the norms of the political community, rather than as non-responsible threats to be contained and coerced. (89)
> 
> > [!note]+ Questions
> > - First, are the aims of communication legitimate and significant aims for the state to pursue?
> > - Secondly, are those aims likely to be achieved through communication? 
> > - Thirdly, can the pursuit of those aims justify the costs that will be incurred in bringing them about? 
> > - Fourthly, is this method of pursuing those aims better, all things considered, than the alternative methods through which we might aim at the same thing? (90)
> 
> > [!note]+ Support
> > - When possible, we ought to condemn someone only if we have held her accountable through a proper communicative process that provides her with her own communicative opportunities.
> > - Compensation for harm is not the same thing as response to being wronging (95)
> > - Focus on the reparation of civic relationships
> 
> > [!note]+ Duff’s Suffering
> > - Provides conditions for adequate judgment about wrongdoing
> > - Constitutive of successful apology must be burdensome
> > - Maybe good in itself?
> 
> > [!note]+ Thoughtcrime
> > - the victim of the crime, and perhaps the community more broadly, has a right that the offender alters the judgements that led him to do wrong. (91)
> > - When one person wrongs another, their judgments are no longer private.
> 
> > [!note]+ Limitations
> > - Suppresses protection
> > - It isn’t obvious why condemning the offender is required for affirmation of the moral significance of the victim (92)
> > - The harm of punishment can’t be anything more than instrumentally valuable
> > - Punishment is unlikely to achieve recognition in offenders
> > - Can’t be an apology, because how fave value if we suspect incensere?
> > - surely an apology can have value only if there is good reason to think that it is sincere. (101)
> > - If burden is just convention, then it’s barbaric
> > - It must be shown that there is no less burdensome alternative than punishment to secure recognition. (108)
> > - It is difficult to believe that suffering is a constitutive component of censure. The imposition of suffering is better seen as a technique through which we censure. If that is true, its value is instrumental rather than intrinsic. The question, then, is whether suffering is a necessary instrument of censure. That will be so only if we have no adequate alternative. I doubt that it is true that we could not devise an adequate alternative. Why can we not communicate censure adequately without imposing suffering on offenders? As Scanlon memorably puts it ‘insofar as expression is our aim, we could just as well “say it with flowers” or, perhaps more appropriately, with weeds’. (103)

> [!note]+ ### Chapter 6: Defending the Means Principle
> > [!note]+ Intro
> > - Exploring deterrance to justify punishment. Does this conflict with non-consequentialism?
> >     - Well, why would it? do we really care *how *we are harmed, or just that we are harmed?
> > - Means Principle: “It is not permissible to pursue the good where others will be used as a means to achieve that good.”
> 
> > [!note]+ Potenital (worse) Solutions
> > - Doctrine of Double Effect (about mental states)
> > - Stronger constraint on harming than allowing harm (Foot/Thompson)
> >     - Child in front of a bus, can refuse to give a hand to save five. If this seems more like fat man, then Foot can’t be right
> > - Agent-relative restrictions (Kagan/Gardner)
> >     - Maybe the fact that *I * harm one person as a means ought to have special significance
> >     - Agent focuses on the wrong thing, inwardly on purity rather than outwardly on good or harm
> >     - Also, might conclude worse to harm a flower than allow five to be harmed
> > - Doctrine of Actions and Omissions (worse to harm than to fail to save)
> > - Quality of Action
> >     - If harming as a means is worse  *qua action* than as a side effect, then we have reason to harm one person as a means if it prevents the harming of a greater number as a means
> >     - Then there is no general constraint against treating as a means
> 
> > [!note]+ The Right Answer
> > - As humans, we are capable of determinign what ends to set for ourselves by determining value. Wrong to compel to act for a an end she is permitted to reject for herself
> > 
> > > We each have a *status* such that are are not to be harmed as a means for the sake of the greater good.
> > 
> > - If I could treat you as a means to prevent others from being treated that way, then *each of us would be available *to be treated as a means
> > - Objects, not persons, may be used to pursue goals
> > - When some violate this, we do not *endorse* it when we refuse to prevent it by treating someone else as a means. They do not lose their status, and we uphold their status by recognizing this
> > 
> > > What matters most is *having * a certain moral status. Whether others respect that status matters much less.
> > 
> > - If we permit the one person to be harmed to save five, we would appear to minimize the actions that show lack of respect, but really, they would no longer *have* the status of not being harmed.
> >     - Or, at least, we would fail to recognize that status
> > 
> > > At the heart of the moral person is not only the derire to produce or prevent certain actions or outcomes: those that are in accordance with our moral status. We also must show respect for our moral status by endorsing and living by the principles that are consistent with our having that status.
> > 
> > - Victims of a crime have not lost their moral status. They do not need it restored, but affirmed.
> 
> > [!note]+ Restrictions on the Means Principle
> > - Some claim must be either inviolable or nonexistent, but there is a principled way to distinguish
> > - Not just about the magnitude of harm prevented, but the relationship between it and what is asked of the person being used
> > - Permissible if the person themselves have an (enforceable?) duty to pursue that good/avert the threat
> > - Enforceable determined by likelihood of eddectiveness, harms imposed, how important it is the person acts for a good reason, etc.
> >     - (Staircase of enforceability: enforceable duty to enforce the duty to…)
> > - Permissibility of using as a means does not depend on whether they are concious
> 
> > [!note]+ Common Source
> > - Both concerned with the extent to which we are required to accept that we must bear some cost for others
> > - The scope of our duties is constrained by the importance of our ability to shape our own lives in pursuit of things we value

> [!note]+ ### Further Reading
> - ‘The Logic of Excuses and the Rationality of Emotions’ (2009) 43 Journal of Value Inquiry 315 at 330.
> Gardner, for example, argues that an emotional response to an event may be fitting and yet completely lack intrinsic or instrumental value.7
> G Sher In Praise of Blame (Oxford: OUP, 2006
> T M Scanlon Moral Dimensions: Permissibility, Meaning, Blame (Cambridge, Mass.: Harvard UP, 2008) ch.4.