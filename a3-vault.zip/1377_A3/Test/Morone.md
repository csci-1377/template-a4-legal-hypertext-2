---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Domestic Services Contracts
Takeaway: ""
Tags:
  - Definiteness
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1980
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Morone v. Morone
Status: Annotated
Date: 1980-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - P and D are unmarried living together
> - P does the house work, D earns money
> - They agree D "would support, maintain and provide for P in accordance with his earning capacity and that D further agreed on his part to take care of P and do right by her” 
> - P alleges D is not holding up his end of the bargain and sues for breach

> [!note]+ Procedural History and Posture
> - Trial court finds no implied contract, and finds oral contract invalid

- Issue: Was there an enforceable contract for domestic services?

> [!note]+ Holding (Meyer): Yes, but only by oral agreement
> - No implied contract because no method for specifying vagueness
> - Also, because the deal of marriage is so bad we couldn’t enforce it as employment, ironic because this means she couldn’t win
> - But oral agreement is no less enforceable because cohabitating
> - Disposition: Modified, to plaintiff

> [!note]+ Dissent (Jones): No, even oral agreement too vague
> - What does “do right by her” even mean?
> - It can’t just be evenly splitting earnings! She doesn’t even make money!
