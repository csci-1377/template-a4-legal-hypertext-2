---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Loud Disco Music
Takeaway: Constructive Eviction Doctrine
Tags:
  - Leases
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1977
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Blackett v. Olanoff
Status: Annotated
Date: 1977-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - P Landlord rents to D and a nearby cocktail lounge
> - Clause in cocktail lounge lease requires low noise
> - D asks P to control noise, P refuses, D vacates
> - P sues for unpaid rent, D defends arguing constructive eviction

- Issue: Were tenants constructively evicted?

> [!note]+ Holding (Wilkins): Yes
> - Deprivation of <u>**“quiet enjoyment”**</u> for a <u>**substantial time**</u> flowing from <u>**natural consequences**</u> of landlord’s actions/inactions (including obligations on other lease
> - <u>**No intent to evict**</u> required, it’s conduct that matters
> - <u>**Unclear if D has to vacate**</u> to claim constructive 