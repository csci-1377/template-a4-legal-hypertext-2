---
base: "[[Test.base]]"
DOI: https://doi.org/10.2139/ssrn.205228
In-Text Citation: (Rubenstein, 2000)
Priority: Essential
Authors: Rubenstein, William B.
Title: The Myth of Superiority
Zotero URI: http://zotero.org/users/4316906/items/VCHFV7L8
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Journal Article
Rating: "****"
URL: http://www.ssrn.com/abstract=205228
Year: 1999
Full Citation: "Rubenstein, W.B. (2000) ‘The Myth of Superiority’, SSRN Electronic Journal [Preprint]. Available at: https://doi.org/10.2139/ssrn.205228."
Last edited: 2026-02-15T22:06:00
Full: Rubenstein, 2000
Status: Annotated
Date: 1999-01-01
Year*: 2000
---
- Summary- Basically, there are structural factors in favor of state courts sometimes, too (especially in gay rights issues). Don’t always assume fed is better.

> [!note]+ Areas Observing
> - Sodomy laws, family law, sexual orientation discrimination

> [!note]+ Technical Competence
> - More experience in family law
> - Day to day experiences can help, not just hurt

> [!note]+ Psychological Set
> - Likely more familiar with gay people
> - Not concerned about federalism question
> - Sheer quantity means opportunity for “exceptional positions” is greater

> [!note]+ Majoritarian Pressures
> - Might favor gay rights when important voting block
> - Also, life tenure leads to older judges

> [!note]+ Qualifications
> - State courts certainly aren’t uniformly better
> - This might just have more to do with political ideology
> - Or civil liberties (staunch individualist, fed receptive) v civil rights (oppressed social groups, states receptive)