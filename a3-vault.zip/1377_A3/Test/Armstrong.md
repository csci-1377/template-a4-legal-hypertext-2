---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Rubber Refiner Reliance
Takeaway: ""
Tags:
  - Learned Hand
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1949
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: L. Albert & Son v. Armstrong Rubber Co.
Status: Annotated
Date: 1949-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - Albert sells Armstrong for “refiners” to recondition old rubber
> - During WWII (severe rubber shortage)
> - Albert delivers two of them, two others are late
> - Armstrong refuses receipt of all of them (no one wants rubber anymore after the war), claims breach
> - Armstrong uses a part from one of them, a motor
> - Albert sues Armstrong for value and interest of motor
> - Armstrong counterclaims for foundation for refiners as reliance damages

> [!note]+ Procedural History and Posture
> - Judge dismisses most of it (no breach)
> - But he rules for Albert regarding the motor, without interest
> - Both sides appeal
>     - Albert for interest
>     - Armstrong for reliance damages

- Issue: Interest on damages? Reliance damages?

> [!note]+ Holding (Learned Hand): 
> - Interest- Yes, when value determinate
> > when the value of goods can be "ascertained with reasonable certainty as of a definite time," interest should be recovered.
> - Reliance- Yes, but capped at expectation (burden on defendent to prove loss)
>     - Not for loss of profits, but 
> > the only difference is between allowing the promisee to recover what he has paid to the promisor and what he has paid to others
> 
> > put the peril of the answer upon that party who by his wrong has made the issue relevant to the rights of the other.
> - Disposition- Modified

> [!note]+ Thoughts and Questions
> - 
