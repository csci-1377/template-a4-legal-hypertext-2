---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Divorcing Your Attorney
Takeaway: Limit restitution to contract price if all that’s left is payment
Tags:
  - Restitution
  - Substantial Performance
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1954
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Oliver v. Campbell
Status: Annotated
Date: 1954-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - Oliver signs contract to represent Campbell for $850
> - He represents him through a long trial, his services worth $10,000
> - Campbell pays him $450, then refuses to keep paying him at nearly the end
> - Campbell dies
> - Oliver sues breach (and quantum meruit?)

> [!note]+ Procedural History and Posture
> - Trial court says fair value is $5,000, but Oliver gets nothing because services were covered by contract

- Issue: What is a contractor entitled to when principle has breached?

> [!note]+ Holding (Carter): Limit restitution to contract price if all that’s left is payment
> > (if the contractor has completed part of the contract) He may 
> > 1. treat the contract as rescinded and may recover upon a quantum meruit so far as he has performed; 
> > 2. or he may keep the contract alive, for the benefit of both parties, being at all times ready and able to perform; 
> > 3. or he may treat the repudiation as putting an end to the contract for all purposes of performance, and sue for the profits he would have realized if he had not been prevented from performing.' “
> 
> - If defendent’s other performance is left, then all of the above
> - But if all that’s left is defendent’s payment, then only 3

> [!note]+ Dissent (Schauer): But contract wasn’t complete
> - Court misapplies its own rule
> - Contract was not complete (anticipated reverse on appeal)
> - Repudiated by Campbell, so entitled to fair value

> [!note]+ Questions
> - Why is fair value calculated at the other attorney’s price? What if that’s a ripoff, or he is a better attorney?
