---
base: "[[Test.base]]"
In-Text Citation: (Stemplowska and Swift, 2012)
Priority: Essential
Authors: |-
  Stemplowska, Zofia
  Swift, Adam
Title: Ideal and Nonideal Theory
Zotero URI: http://zotero.org/users/4316906/items/FJLHSAA7
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This article begins by setting out Rawls's conception and defense of ideal theory as a necessary precursor to the kind of nonideal theory that can guide action in the real world. It then evaluates the critique of those, such as Amartya Sen, who insist that knowing what an ideally just society would look like is simply not helpful for that purpose. Having also addressed the complaint that the Rawlsian approach is ideological, and hence worse than useless, the discussion broadens out to compass the more wide-ranging critique of mainstream contemporary political philosophy leveled by so-called political realists. It then turns to Cohen's very different objection—that Rawls's ideal theory of justice is too tailored to empirical circumstance. It concludes with an attempt to identify the variety of different things that might be conceived as nonideal theory. Ideal theory may be understood in many different ways, but nonideal theory fares little better.
Type: Book Section
Rating: "***"
URL: https://doi.org/10.1093/oxfordhb/9780195376692.013.0020
Full Citation: "Stemplowska, Z. and Swift, A. (2012) ‘Ideal and Nonideal Theory’, in D. Estlund (ed.) The Oxford Handbook of Political Philosophy. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/oxfordhb/9780195376692.013.0020."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2012
---
> [!note]+ Intro
> - Ideal theory criticized as useless, unrealistic, naive, utopian, ideological, dangerous
> - Ideal: can reference perfection, impossibility, standard
> - Theory: can reference a method and its product
> - Political Philosophy: practical and epistemic aims. What to do and how to understand

> [!note]+ Ideal Theory
> - Strict Compliance
>     - Rawls: strict nonheroic compliance
> - Favorable Circumstances
>     - Rawls: realistically practicable/realistic utopia, not best possible
> - Why? 
>     - Rawls
>         - Target: helps us figure out what to aim at
>         - Urgency: Figure out what’s worse by how far it is from perfect justice
>     - Simmons
>         - How do we know if it is real progress?
>         - We need to have an idea of how a short-term improvement relates to a long-term goal
> - Why Not?
>     - Sen: neither necessary nor sufficient
>         - Not necessarily useful either
>     - Political theory is comparative, not transcendental

> [!note]+ Nonideal Theory
> - Partial Compliance
> - Unfavorable Circumstances
> - Some say should also be concrete, determinate recommendations (engage in, or at least with, or at least readable to social scientists)
> - Practical and epistemic aims
> - This is social science, not philosophy
> - Action guiding can be on many levels: new concepts, overton window, framework, direction, marching orders
> - Maybe we should be more focused on actions of individuals

> [!note]+ Metatheory
> - GA Cohen: rules of regulation are specified in ideal theory, but these should not be confused with fundamental normative principles free from empirical facts

> [!note]+ Dissertation Thought
> One line of argument worries specically about the application to political conduct of moral or ethical theories developed for individuals in abstraction from distinctively political concerns. Politics, on this view, should not be seen as just another sphere of activity to which such theories can be applied, and in whose terms political agency can be evaluated, but as requiring distinct kinds of conduct, with their own norms. But the speci city of “the political” is in fact a key issue within liberal political philosophy itself. Rawls, for example, explicitly denies that his theory of justice should be understood as “applied moral philosophy,” precisely because “[p]olitical philosophy has its own distinctive features and problems” (2001, 14), and his claims about the continuity, or otherwise, between the reasons that can or should guide individuals in their private and in their public or political lives have commanded a good deal of attention.
> 

> [!note]+ Second Reading
> > [!note]+ Concepts
> > - Two features of ideal theory: strict compliance and favorable circumstances (375)
> > - The defense of ideal theory as a way of looking at potential long-term trade-offs is confused. We do not need to think of a substantive notion of justice in order to recognize that the evanda we are faced with conflict and to assess the trade-offs inevitably involved in those conflicts.
> > 
> > > [!note]+ Target and urgency role (376)
> > > - First, it identi es the objective at which nonideal theory ought to aim and thereby gives nonideal theory its ultimate target (the target role). As Rawls puts it, “until the ideal is identi ed ... nonideal theory lacks an objective, an aim, by reference to which its queries can be answered” (1999b, 90). In its target role, then, ideal theory helps nonideal theory answer the question: “What shall we do here and now given the ideal end point that we want to reach?” (376)
> > > - Second, ideal theory helps us assess the urgency of injustice we face in the real, nonideal world (the urgency role). For Rawls, the most grievous injustices are “identified by the extent of the deviation from perfect justice” (1999a, 216). In its urgency role, then, ideal theory helps nonideal theory answer the question: “Which of the injustices we face here and now are the most urgent?” (376)
> > 
> > > [!note]+ Sen
> > > > “[t]he characterization of spotless justice does not entail any delineation whatever of how diverse departures from spotlessness can be compared and ranked” (2006, 220; cf 2009, 99) and “[t]he possibility of having an identi ably perfect alternative does not indicate that it is necessary, or indeed useful, to refer to it in judging the relative merits of two other alternatives” (2009, 102). (377)
> > > 
> > > > Nonideal theory involves a comparative approach—we need to compare the justice of the di erent options within the feasible set—rather than a transcendental approach, which would involve the assessment of those options in the light of the picture of justice generated under the idealized assumptions. To climb the highest mountain within range, we do not need to know that Everest is the highest mountain in the world but which mountains are within range and how to compare them to each other. (377)
> > 
> > > [!note]+ Simmons
> > > In mountaineering, the climber who myopically takes immediate gains in height wherever she can is less likely to reach the summit than the one who plans her route carefully. The immediate gains do indeed take her higher—with respect to altitude she is closer to the top—but they may also be taking her away from her goal. The same is true of normative ideals. To eliminate an injustice in the world is surely to make the world more just, but it could also be to take us further away from, not closer toward, the achievement of a just society.
> 
> > [!note]+ Quotes
> > > the term ideal theory has also been used to stand for apparently useless, unrealistic, naïve, utopian—perhaps even ideological or dangerous (373)
> > 
> > > We might think of political philosophy as seeking to tell us what the values that apply to the political sphere are and what they require. But that formulation is ambiguous. It can be given a practical reading, whereby its aim is to identify what actions need to be undertaken to promote, to respect, or fully to realize the values in question, or it can be interpreted epistemically, whereby the goal is systematic knowledge or understanding of the values (374)
> > 
> > > Because most of the debate about the relevance or utility of ideal theory has taken place among those who accept the practical aim, we focus on that. (374)
> > 
> > > Rawls was talking speci cally about justice, and much of the subsequent literature has focused on the value, or otherwise, of ideal theory in relation to that particular ideal. Our discussion follows suit, but of course other normative concepts, such as equality, democracy, or legitimacy might also be thought of as ideals, and, because the merits or demerits of ideal theories of (or “ideal theorizing” about) those concepts might be rather di erent, we address the issues at an appropriate level of generality. (374)
> > 
> > > Rawls limits how far the assumptions can, in fact, depart from the constraints of the real word. For ideal theory must, as he explains, stay within the realm of what is “realistically practicable” (2001, 13); even if it delineates a distant vision, it must remain a “realistic utopia” (1999b, 11–12). (376)
> > 
> > > The assumption of strict compliance is really, then, the assumption of strict nonheroic compliance.
> > 
> > > Rawls’s answer is that ideal theory is a necessary precursor to nonideal theory. It provides “the only basis for the systematic grasp of these more pressing problems” (1999a, 8). (376)
> > 
> > > As we have seen, it’s precisely because ideal theory does not immediately translate into such recommendations and evaluative criteria that nonideal theory is needed; it fills the gap, as it were, between the theoretical ideal and political reality. (380)
> > > - This assumes that ideal theory can be any kind of starting point or source.
> > 
> > > One line of argument worries speci cally about the application to political conduct of moral or ethical theories developed for individuals in abstraction from distinctively political concerns. Politics, on this view, should not be seen as just another sphere of activity to which such theories can be applied, and in whose terms political agency can be evaluated, but as requiring distinct kinds of conduct, with their own norms. (381)
> > 
> > > For Cohen, justice is a philosophical ideal truths about which can be identi ed by careful re ection on intuition; whether, how, and to what extent, it can or even should be realized in the world, given that it con icts with other values, are all separate and further questions. For Rawls, justice has a “social” or “problem-solving” role; its identi cation involves all things considered judgments about the relative importance of di erent kinds of value, and facts about human nature properly enter into the formulation even of our ideal theory of justice. (384)
> > 
> > > as long as the goal it posits is indeed a realistic utopia, then that kind of theory should not be regarded as an optional extra; the intellectual resources devoted to it are not self-indulgent or wasteful. We need to know the goal before we can form an all-things-considered evaluation of transitional steps in its direction; immediate improvements may take us take us further away from our target, in which case we will face di cult trade-o s. Though there are issues about our ability to map possible futures well enough for this kind of consideration to have great weight, though the likelihood of achieving the goal is a very di erent matter from its possibility, and though it might be argued that we already know enough about the goal to be able to assess whether immediate steps are unambiguously steps in its direction, this defense of ideal theory as setting the target is compelling. (386)
> > 
> > > the idea that useless knowledge, whether in mathematics or political philosophy, has no value is deeply implausible. Perhaps learning in what ways the full realization of an ideal such as democracy or equality is beyond our reach tells us simply what we have reason to regret, and perhaps regret will make us sad. But sadness is a small price to pay for enlightenment. (387)
> > 
> > 
> > 













