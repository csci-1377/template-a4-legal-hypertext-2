---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Biased Business Owner
Takeaway: Judge must solicit affirmative commitment to impartiality to refuse to strike juror for cause.
Tags:
  - Jury Trial
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 2001
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Thompson v. Altheimer & Gray
Status: Annotated
Date: 2001-04-19
Jurisdiction: Seventh Circuit
---
> [!note]+ Facts
> The plaintiff brought suit against her employer under Title VII of the Civil Rights Act of 1964, charging racial discrimination. The case was tried, the jury returned a verdict for the defendant, and the plaintiff appealed, arguing that a juror named Leiter should have been struck for cause. She had already used her three peremptory challenges at that point.
> 
> During *voir dire*, the judge asked the venire members whether “there is something about this kind of lawsuit for money damages that would start any of you leaning for or against a particular party?” Leiter raised her hand and explained that she has “been an owner of a couple of businesses and am currently an owner of a business, and I feel that as an employer and owner of a business that will definitely sway my judgment in this case.” The judge asked her whether “if I instructed you as to what the law is that you would be able to apply the law recognizing that you are a business owner?” To which she replied, “I think my experience will cloud my judgment, but I can do my best.” The judge then permitted the lawyers to also ask questions of the prospective jurors. Thompson’s lawyer asked several:
> 
> - “[Y]ou said earlier that you were concerned that your position as a business owner may cloud your judgment. Can you tell me how?” Leiter replied, “I am constantly faced with people that want various benefits or different positions in the company [what Thompson was seeking from her employer, the defendant, Altheimer & Gray] or better contacts or, you know, a myriad of issues that employers face on a regular basis, and I have to decide whether or not that person should get them.”
> - “[Are you concerned] that if somebody doesn’t get them [benefits sought from their employer] they’re going to sue you?” Leiter answered, “Of course.”
> - “[Do] you believe that people file lawsuits just because they don’t get something they want?” Leiter answered, “I believe there are some people that do.”
> - “Are you concerned that that might cloud your judgment in this case?” Leiter said, “I think I bring a lot of background to this case, and I can’t say that it’s not going to cloud my judgment. I can try to be as fair as I can, as I do every day.”
> 
> That was the end of Leiter’s *voir dire*. After refusing to strike her for cause (despite urging by the plaintiff’s lawyer), and releasing the jurors who had not been selected for the jury (the defendant had also exercised its three peremptory challenges, none overlapping with the plaintiff’s), the judge asked the eight remaining jurors, that is, the jurors selected to hear the case, whether they would follow his instructions on the law even if theydidn’t agree with them and whether they would be able to suspend judgment until they had heard all the evidence. The question was asked to the jurors at large and all either nodded their heads or said yes.
> 
> Case results in a verdict for the employer-defendant. Plaintiff moves for a new trial.

- Issue: Did judge abuse discretion in failing to strike Leiter for Cause?

> [!note]+ Holding (Posner): Yes
> - What significance (if any) is the fact that she used her 3 peremptory challenges before getting to Leiter?
>     - No significance. Question of whether should be stricken for cause is not related to peremptory challenges
> - Standard of review for trial judge’s decision? (abuse of discretion)
> - Bias is not Baysian Prior: Must be irrational or unshakeable
>     - Can hold an indubitable belief unshakeably
> - The question isn’t really about her beliefs, but whether they would prevent her from being fair
> - Didn’t say *couldn’t* be fair, but that she would try to be. Is that enough?
> - The problem is that the judge didn’t push enough on whether priors were also bias.
> 
> > When a prospective juror manifests a prior belief that is both material and *contestable* (for, to repeat an earlier point, it is not bias to cling to a belief that no rational person would question), it is thejudge’s duty to determine whether the juror is capable of suspending that belief for the duration of the trial. When as in this case the record contains no assurances that the belief is ‘shakable,’ that the prospective juror can exercise a judgment unclouded by that belief, the verdict cannot stand. [...] ‘When a juror is unable to state that she will serve fairly and impartially despite being asked repeatedly for such assurances, we can have no confidence that the juror will ‘lay aside’ her biases or her prejudicial personal experiences and render a fair and impartial verdict.’ *United States v. Gonzalez, supra,* 214 F.3d at 1114. That’s this case.” [CB ¶20] Missing are those "<u>unwavering affirmations of impartiality</u>" that permitted the district judge in *United States v. Garcia,* 936 F.2d 648, 653 (2d Cir.1991), to find the challenged juror unbiased.
> 
> - Disposition: 