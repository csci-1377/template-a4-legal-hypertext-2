---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phc3.12398
In-Text Citation: (Rowland, 2017)
Priority: Recommended
Authors: Rowland, Richard
Title: The Epistemology of Moral Disagreement
Zotero URI: http://zotero.org/users/4316906/items/NAIIBPW2
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: This article is about the implications of a conciliatory view about the epistemology of peer disagreement for our moral beliefs. Many have endorsed a conciliatory view about the epistemology of peer disagreement according to which if we find ourselves in a disagreement about some matter with another whom we should judge to be our epistemic peer on that matter, we must revise our judgment about that matter. This article focuses on three issues about the implications of conciliationism for our moral beliefs. The first is whether there is an asymmetry between the implications of conciliationism for the epistemic status of our moral beliefs and the implications of conciliationism for the epistemic status of our non‐moral beliefs; for instance, some have argued that conciliationism leads to epistemological moral skepticism but not to epistemological nonmoral skepticism. The second is what the implications of conciliationism are for the epistemic status of particular moral beliefs. The third is whether conciliationism's impact on the epistemic status of our moral beliefs has practical implications.
Type: Journal Article
URL: https://onlinelibrary.wiley.com/doi/10.1111/phc3.12398
Full Citation: "Rowland, R. (2017) ‘The Epistemology of Moral Disagreement’, Philosophy Compass, 12(2), p. e12398. Available at: https://doi.org/10.1111/phc3.12398."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2017
---
