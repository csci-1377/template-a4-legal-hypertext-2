---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Deluded Donation
Takeaway: Charitable gift can be redirected if original intent is impossible
Tags:
  - Cy Pres
  - Gifts
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1949
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Wilber v. Owens
Status: Annotated
Date: 1949-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - Man dies without relatives, writes elaborate will establishing a trust to publish his writings
> - But the writings are really bad
> - Executor asks to reform trust funds to general charitable purposes by Princeton

- Issue: Can we redirect the funds?

> [!note]+ Holding (Heher): Yes
> 1. Settlor has charitable Intent
>     - Settlor believes trust has a public benefit
>     - AND that belief is rational and doesn’t’ violate law or principles of morality.
> 2. specific charitable intent is impossible, problematic by changed circumstances, or violates public policy
>     - The writings were “irrational, unintelligible, and of no scientific or other value”
> 
> **NOTE**: The Restatement loosens up cy pres to include wastefulness.