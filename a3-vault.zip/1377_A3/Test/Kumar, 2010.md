---
base: "[[Test.base]]"
In-Text Citation: (Kumar, 2010)
Priority: Essential
Authors: Kumar
Title: Contractualism
Zotero URI: http://zotero.org/users/4316906/items/7VJBC8NG
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Kumar (2010) ‘Contractualism’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2010
---
> [!note]+ Intro
> - Name is misleading: from tradition of Rousseau and Kant, not Hobbes
> - A person morally wrongs another by treating him in a way whose permissibility is not justifiable to him on grounds he cannot reasonably reject.
> 
> > For a principle to be justifiable to others on grounds a person cannot reasonably reject is for that principle to be one that he has reason to *authorize *or *license* others to be guided by in their practical deliberations (494)
> > - (This actually makes the standard seem rather weak. Does it have to be *overriding *reason?)
> 
> > For to be guided by principles that others authorize, or license, one to be guided by is to recognize others in one’s practical thought as rationally self-governing creatures
> > - Kant: dignity of a human being lies in the fact that he or she stands to the moral law as both subject and legislator

> [!note]+ Two goals
> - Alternative to consequentialism
> - Nature of moral motivation: moral knowlwdge is not esoteric, but something anyone with reason can access and should consider important
> > What moves one is the appeal of an ideal moral community in which individuals stand in relation to one another of *mutual recognition* living on terms of “unity with one’s fellow creatures”

> [!note]+ What Respect Requires
> - Generally, we think valuing something means promoting it
>     - Friendship?
>         - We don’t just think we should bring about lots and lots of frienships
>     - Human Life?
>         - Requires “a recongition, in one’s practical thinking, of other human beings as creatures who have reasons for wanting to live and for having their lives go better, and who have a capacity to both assess reasons and justifications and select among the various ways there is reason to want life to go, enabling them to live actively self-governed lives (Scanlon 1998: 103-7)
>             - (This is guarantee of consideration, not treatment. What if these conflict for different groups, or there is no principle no one can reasonably reject in a given situation?)
>             - This is a form of perspective taking, which is good

> [!note]+ Reasons and Principles
> - Principle is not just a stable rule
> - Complex understanding made of reasons
> - Understanding obligation of a promise is understanding how your situation has changed after undertaking one, and what you now have reasons to do 

> [!note]+ Hypothetical vs Actual
> - Characterization of valid principles is the object of hypothetical, rather than actual agreement between all persons
>     - (Why do we focus on agreement? Many of our identies we don’t agree to, and decisions of groups we don’t agree with, but the point is that we participated

> [!note]+ Reductionist Critique
> - This is nothing more than caring that conduct be *justified*
> - Misses the mark: it is justified because it is justifiable

> [!note]+ Standpoints
> - Assess principles by considering implications from different individual standpoints 
> - Standpoints could, but need not, aptly characterize some actual person’s point of view
> - Focus is not in implications for actual people

> [!note]+ Individualist Resteiction
> - Only implications of a principle that are releant to its assessment are those that could be appealed to from a certain standpointas implications of the proposed principle for a person being able to live his or her life
> - Rules out impersonal consequentialist considerations
> - (Shouldn’t we be able to adopt communal standpoints too, but only insofar as they are held by the actual people involved?)

> [!note]+ Veto
> - Seriously negative implications for a certain standpoint alone does not warrant the conclusion that it is reasonably rejectionable from that standpoint.
> - If all the other principles are worse, then this can’t be rejected
> - (Why insist on principles as the right point of assessment here? Seems like it just allows you to get a lot in through the back door)

> [!note]+ The question, not the answer
> - What actually is reasonably objectionable is up to debate. 
> - We can definitely reasonably reject a principle that doesn’t take into account everyone’s interests, but that’s pretty much it
> - So this doesn’t help resolve moral disagreements, just lay out there terms.

> [!note]+ Aggregation
> - Reason you can’t kill one to save five is because one has stronger reasons not to be killed than the others have to want the organs
> - This makes the principle non-aggregative: it doesn’t matter how many individuals are involved
> - What decides how you will proceed in a dillema is the first claim on one side not balanced by an equally weighty claim on the other.
> - What do we do when one person has a marginally more weighty claim than 1,000 others?