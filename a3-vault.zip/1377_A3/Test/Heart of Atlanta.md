---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: “Involuntarily Serving” Black Clientele
Takeaway: Discrimination in public accomodations can be appropriately regulated under the Commerce Clause (intrastate and interstate customers) (not 13A)
Tags:
  - CC
  - 13A
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 1964
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Heart of Atlanta Motel v. United States
Status: Annotated
Date: 1964-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Moreton Rolleston doesn’t want to integrate his motel after the 1964 Civil Rights Act
> - Challenges act as beyond CC and also violating 13th Amendment as “involuntary servitude” to serve Black people.

- Issue: The Constitutionality of the 1964 Civil Rights Act as applied to these facts…

> [!note]+ Holding (Clark): Yes
> - Civil Rights Cases inapposite: they did not limit to enterprises having “direct and substantial effect” on interstate commerce
> - Also, the facts have changed since then. People are more integrated.
> - Discrimination by hotels and motels impedes interstate commerce by discouraging travel
> - And we can even ban discrimination against intrastate customers through NPC
> - Test: whether activity is “commerce which concerns more States than one” and there is a real and substantial relation to a national interest (no coercive test)
> - Pretext: Doesn’t matter that what is being regulated is also a moral and social wrong (commerce still gives power over it)
> - Power includes activities that “might have” a harmful effect
> - It’s up to Congress what means to remove














