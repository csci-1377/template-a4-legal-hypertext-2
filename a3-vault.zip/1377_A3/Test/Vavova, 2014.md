---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phpe.12049
In-Text Citation: (Vavova, 2014)
Priority: Essential
Authors: Vavova, Katia
Title: Moral Disagreement and Moral Skepticism
Zotero URI: http://zotero.org/users/4316906/items/ZDGTZMLP
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://onlinelibrary.wiley.com/doi/10.1111/phpe.12049
Full Citation: "Vavova, K. (2014) ‘Moral Disagreement and Moral Skepticism’, Philosophical Perspectives, 28(1), pp. 302–333. Available at: https://doi.org/10.1111/phpe.12049."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2014
---
Defends Consolationism as not requiring implausible moral skepticism 

> [!note]+ Consolationism
> - Correct response to peer disagreement is agnosticism
> - Disagreement sometimes provides defeating evidence
> - If you can’t judge peerhood, you aren’t validated, conciliationism is just silent on the issue of what you should do.

> [!note]+ Epistemic peers
> - How much to decrease confidence depends on how close to peers you take me to be and how confident you are in that judgment
> - There might be a lot who disagree, but fewer you take to be peers, and even fewer you are confident are peers.
> - Numbers matter: if you know percent of your peers that agree, then you have wider grounds for assessment.

> [!note]+ Disagreement
> - Often non-moral in origin, or not really peer disagreement (they go too deep)
> - The less common ground you share, the less significant the disagreement
> - Biggest upshot here is for moral philosophers, who seem to have good reasons to be agnostic about their own views, since they have good reasons to think that those who disagree with them deeply are still their peers
> - Possible is not as significant as actual

> [!note]+ Independence
> - To evaluate the epistemic credentials of another person’s belief you disagree with to see if you should change your belief, you can’t rely on your belief or the reasoning behind it.
> - To avoid question-begging dismissals
> - Limits grounds to dismiss the others’ opinion, but also evidence of epistemic peerhood.

> [!note]+ Non-moral examples
> - Restaurant: With a friend with an equally good track record at adding up the bill, and you get to different answers. What now?
> - Stoplight: with another traffic cop with equally good eyesight and track record, and you disagree on going through the light.
> - **The correct response here is engagement! Disagreement should be the beginning of the process**

> [!note]+ Skepticism
> - Compatible with realism, so not the same as relativism or nihilism

> [!note]+ Burden of Proof
> - Here it isn’t that you have to think they *aren’t* your peer, just don’t have reasons they are.
> - You need to have good independent reasons to think they are your peer, not just no independent reasons to think they aren’t
> - It is easier to justify a belief than it is to provide non-question-begging justification of the belief to a skeptic

> [!note]+ Scope
> - Silent on the issue of what you should do when met with non-peer disagreement. But just because consolationism is doesn’t mean rationality is
> - **Might have to do with reasons to form true vs avoid false beliefs**
