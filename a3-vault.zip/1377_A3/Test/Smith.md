---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: The Use of Use
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "****"
Year: 1993
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Smith v. United States
Status: Annotated
Date: 1993-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Smith goes to buy cocaine, and has a MAC-10 firearm
> - His acquaintance, Hoag, puts him in contact with “pawn shop” dealer (actually officer)
> - Smith offers gun, asks for 2 oz cocaine in return
> - Smith arrested, minimum sentence for knowing “use” of a “machinegun”  “during and in relation to… a drug trafficking crime” is 30 years (18 USC 924c1)

> [!note]+ Procedural History and Posture
> - Grand jury in Florida indicts 
> - Petitioner appeals (affirmed?)

- Issue: Does “use” of a firearm include use as item of barter?

> [!note]+ Holding (O’Connor): Yes, it does
> - Uses the dictionary as the authority
> - Not too broad, since is during “and in relation to” (facilitates or furthers the crime)
> - Under 924d1, uses of firearm include in interstate transfer, sale, etc.
> - We should interpret the term the same way in both parts of the statute
> - Rule of lenity is basically just a final tipping point
> - Purpose: ‘can be converted instantaneously from currency to cannon’
> - Disposition- Affirmed?

> [!note]+ Dissent (Scalia): No, it doesn’t
> - This means “to use for its intended purposes”
> - Distinction between how a word *can* be used and how it is *ordinarily* used.
> - The term originally referred only to crime of violence. Why wouldn’t this carry over once drug trafficking crime is added?
> - At least it’s ambigous, so the rule of lenity should apply

> [!note]+ Thoughts and Questions
> - Dictionaries are rarely consulted in the drafting process
> - Judges can pick and choose their dictionaries
> - Linguistic claims are often couched as “obvious”, moving directly to intuitive appeal
