---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: Irons, Peter
Title: The History of the Supreme Court
Takeaway: ""
Tags: []
Category:
  - Politics
Abstract: ""
Type: Audiobook
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2013
---
What makes a great justice

- Length of tenure
- Engagement with the great issues of their time
- Literary style
- An awareness that hard cases do not allow easy decisions