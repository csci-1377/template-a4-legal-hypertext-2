---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Reasons to Hesitate
Takeaway: Multifactor Test
Tags:
  - PQ
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "****"
Year: 1962
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Baker v. Carr
Status: Annotated
Date: 1962-01-01
Jurisdiction: United States
---
> [!note]+ Holding (Brennan): One or more of the following…
> - A textually demonstrable constitutional commitment of the issue to a coordinate political department; or
> - A lack of judicially discoverable and manageable standards for resolving it; or
> - The impossibility of deciding without an initial policy determination of a kind clearly for nonjudicial discretion; or
> - The impossibility of a court’s undertaking independent resolution without expressing lack of the respect due coordinate branches of government; or
> - An unusual need for unquestioning adherence to a political decision already made; or
> - The potentiality of embarrassment from multifarious pronouncements by various departments on one question.





















