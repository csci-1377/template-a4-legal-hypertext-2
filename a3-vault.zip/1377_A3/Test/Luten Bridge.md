---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Still Building Bridge
Takeaway: You don’t get reliance for work after notified of repudiation
Tags:
  - Reliance
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1929
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Rockingham County v. Luten Bridge Co.
Status: Annotated
Date: 1929-01-01
Jurisdiction: Fourth Circuit
---
> [!note]+ Facts
> - Rockingham County contracts for bridge from Luten, cancels (claiming invalid contract) before construction begins.

> [!note]+ Procedural History and Posture
> - Departed commisioners file answer admitting liability of full costs, District court admits answer, excludes evidence of alert prior to construction, and awards plaintiff judgment.

- Issue: Does performer get reliance for actions after breach?

> [!note]+ Holding (): 
> - First answer from departed commissioners is not the answer of the county. You get full profit on the overall deal, but no costs after notification of repudiation of the contract. And if you aren’t sure, you need to halt progress because you won’t be compensated in the interrim.