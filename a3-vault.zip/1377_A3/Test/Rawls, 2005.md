---
base: "[[Test.base]]"
In-Text Citation: (Rawls, 2005)
Priority: Recommended
Authors: Rawls, John
Title: Political Liberalism (p274 f12)
Zotero URI: http://zotero.org/users/4316906/items/W5BSRERS
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Rawls, J. (2005) ‘Political Liberalism (p274 f12)’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2005
---
> [!note]+ Political Liberalism (p274 f12) and Brief Restatement (s49)
> - Stipulate that must wish all previous generations to have followed same just savings principle
> - Allows removal of stipulation of interest in care for descendents
> - Supports legitimate complaints against predecessors and expectations of successors
> - Supports inheretence and bequest taxation at the receiver’s end
>     - But only to prevent wealth accumulation, not fundraising
> - Income taxation can be avoided, shifting to expenditure taxation
> - Proposes contant marginal rate (why?)