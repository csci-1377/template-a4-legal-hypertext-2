---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Ground Clearing Promises
Takeaway: ""
Tags:
  - Definiteness
  - Promisory Estoppel
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1965
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Wheeler v. White
Status: Annotated
Date: 1965-01-01
Jurisdiction: Texas
---
> [!note]+ Facts
> - D signs contract for loan for building if P gives him profits from rent of building
>     - But it didn’t say how to compute interest etc. (details needed for K)
> - P clears land to build
> - D says no loan
> - P sues for breach, then if contract not definite enough, promissory estoppel

> [!note]+ Procedural History and Posture
> - Trial court dismisses
> - Appeals affirms

- Issue: What, if any, are damages for promissory estoppel?

> [!note]+ Holding (Smith): Reliance
> > The binding thread which runs through the cases applying promissory estoppel is the existence of promises designedly made to influence the conduct of the promisee, tacitly encouraging the conduct, which conduct, although not necessarily constituting any actual performance of the contract itself, is something that must be done by the promisee before he could begin to perform, and was a fact known to the promisor.
> 
> - It’s defensive because it “estops a promisor from denying the enforceability of the promise”
>     - Paralell to equitable estoppel preventing defense inconsistent with prior court statement
> - Reliance is the right measure of damages: no contract, so no expectation
> - Disposition: Reversed and remanded on promissory estoppel

> [!note]+ Concurrence (Greenhill): Yeah, but it’s a K
> - Contract is not definite enough for specific performance, but is for damages
>     - Really? Is that why specific performance is a higher bar?
