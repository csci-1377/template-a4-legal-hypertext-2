---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/1467-9973.00163
In-Text Citation: (Jaggar, 2000)
Priority: Further
Authors: Jaggar, Alison M.
Title: "Ethics Naturalized: Feminism's Contribution to Moral Epistemology"
Zotero URI: http://zotero.org/users/4316906/items/G6QRFKBV
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: A survey of Western feminist ethics over the past thirty years reveals considerable diversity; nonetheless, much recent work in this area is characterized by its adoption of a naturalistic approach. Such an approach is similar to that found in contemporary naturalized epistemology and philosophy of science, yet feminist naturalism has a unique focus. This paper explains what feminist naturalism can contribute to moral philosophy, both by critiquing moral concepts that obscure or rationalize women’s subordination and by paying attention to real-life practices of moral inquiry, including those used by women.
Type: Journal Article
URL: https://onlinelibrary.wiley.com/doi/10.1111/1467-9973.00163
Full Citation: "Jaggar, A.M. (2000) ‘Ethics Naturalized: Feminism’s Contribution to Moral Epistemology’, Metaphilosophy, 31(5), pp. 452–468. Available at: https://doi.org/10.1111/1467-9973.00163."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2000
---

> [!note]+ Intro/Conclusion
> - Intro to Feminist philosophy: basic commitment to uncovering and correcting whatever male biases may exist in mainstream philosophical traditions, to overcome the overt and covert devaluation of women and whatever has been associated culturally with the feminine.
> - Conclusion: we should have many more, and more diverse, moral agents within moral philosophy

> [!note]+ Western Canon
> > Pretentions to think from all perspectives are no more than disingenuous rhetorical devices that philosophers utilize to claim unwarranted false authority for their own opinions.
> 
> - Focus on rationality has subordinated women
> - Defined issues with salience to women as outside morality
> - Public/private distinction and gendered connotation
> - Rawls: objective moral judgements only possible in the public domain, regulated by rights and justice
> - Tries to treat ethics as a realm of its own, attempts to transcend
> - Universal actually reflects the particular modern, Western, burgeois, and masculine perspective which is biased against women
> 
> > As Walker has observed, Western moral philosophy has tended to conceptualize moral rationality in highly idealized terms that are far removed from daily life and thought. It has invoked ideals of rationality, universality, impersonality, detatchment, dispassion, neutrality, and transcendence, and it has aspired toevaluate actions and practices from a postulated “moral point of view” often explicated metaphorically in terms such asa a god’s eye view, the perspective of an ideal observer or an archangel, an Archimedean point, or a view from nowhere. In order to attain this moral point of view, Western philosophers have recommended intellectual strategies such as envisioning the Form of the Good, appealing to divine commands or natural laws, invoking the categorical imperative or ineffable intuitions, inquiring into the logic of moral language, thinking like an archangel or behind a veil of ignorance, and discoursing in ideal speech situations.

> [!note]+ Responses
> > Because all agents are limited and fallible, feminists generally conceptualize moral rationality as a process that is collaborative rather than individual and its conclusions as partial, situated, and provisional rather than universal or absolute.
> 
> > determination to inquire into the empirical conditions of real discourses. Feminist moral philosophers thus explore explicitly nonideal speech situations marked inevitably by misunderstanding, uncertainty, unreason, and inequality…identify norms of discursive practices that may increase the reliability of dialogues whose participants inevitably differ in knowledge, culture, and power.
> 
> - Official commitment to sex equality has been taken to require a denial of the differences between men and women
>     - Led to formal gender neutrality but practical gender bias
> - 1960’s feminist slogan “the personal is political”
>     - Principles of justice should be applied to the private areas like the home
> - Women can think like men
>     - Devalued culturally feminine forms of thinking
>     - Focus on justice in relationships can ignore other moral values associated with the feminine
>     - Focus on women’s rights can disregard dimension that cannot be comprehended on those terms
> - Relational instead of autonomous subject, focus on care
>     - Potentially unable to address problems with large numbers of people who aren’t known personally
> - Focus on reason/emotion dichotomy as symbolically gendered
>     - Look at Mary Wallstonecraft
> - Reject realism in the objectivist sense of postulating a determinate anf mind-independent moral reality
>     - Internal realism where truth is not only discovered but also constructed

> [!note]+ Naturalism
> - Abandons the idea of a first philosophy
> - Advocates multidisciplinary approaches to  understanding ethics
> - Views texts as culturally specific sets of texts and practices produced by individuals inhabiting particular social locations
> - Doesn’t start with abstract concepts or general analysis but the real and tangible
> - Does not reject all idealization and collapse entirely into the descriptive
> - Investigate methodological norms, so must know who “we” are and what “our” best practice of inquiry is
> - Quine: there is no place outside the physical world where we can stand to assess our knowledge of it

> [!note]+ Carol Gillian
> - Claimed men have justice perspective, women have care
> - Empirical claims questionable, turns out many men, especially lower class and men of color, also thought in terms of care

> [!note]+ Her concerning claims
> - We cannot put ourselves in others’ shoes
> - epistemically incoherent, mystifying, and authoritarian
> 
> > any method of moral reasoning that requires moral agents to think from others’ perspectives is impossible in principle…cannot enable anyone, even a philosopher, to attain a universal moral standpoint that entirely transcends the particularities of his or her socially located perspectives.














