---
base: "[[Test.base]]"
In-Text Citation: (Meskin, 2008)
Priority: Recommended
Authors: Meskin, Aaron
Title: Authorship
Zotero URI: http://zotero.org/users/4316906/items/SQYG4NBK
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: "The Routledge Companion to Philosophy and Film is the first comprehensive volume to explore the main themes, topics, thinkers and issues in philosophy and film. The Companion features sixty specially commissioned chapters from international scholars and is divided into four clear parts: * issues and concepts * authors and trends * genres * film as philosophy. Part one is a comprehensive section examining key concepts, including chapters on acting, censorship, character, depiction, ethics, genre, interpretation, narrative, reception and spectatorship and style. Part two covers authors and scholars of film and significant theories Part three examines genres such as documentary, experimental cinema, horror, comedy and tragedy. Part four includes chapters on key directors such as Tarkovsky, Bergman and Terrence Malick and on particular films including Memento. Each chapter includes a section of annotated further reading and is cross-referenced to related entries. The Routledge Companion to Philosophy and Film is essential reading for anyone interested in philosophy of film, aesthetics and film and cinema studies."
Type: Book Section
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=366342
Full Citation: "Meskin, A. (2008) ‘Authorship’, in P. Livingston and C. Plantinga (eds) The Routledge Companion to Philosophy and Film. London, UNITED KINGDOM: Taylor & Francis Group. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=366342 (Accessed: 2 May 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2008
---
