---
base: "[[Test.base]]"
In-Text Citation: (Scheffler, 2013)
Priority: Essential
Authors: Scheffler, Samuel
Title: The Afterlife
Zotero URI: http://zotero.org/users/4316906/items/NMFK3554
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Document
Rating: "****"
Full Citation: Scheffler, S. (2013) ‘The Afterlife’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2013
---
> [!note]+ Personal
> - I will (and others) live on after my body dies
> - Asuages fear of death
> - Promises reunion with loved ones
> - Provides redemption and understanding of injustice
> - Things are pointless if there is no cosmic leger
> - **Assumes the continuation and flourishing of the social world**
> - Dangerous, might make people not care about the disappearance of the earth

> [!note]+ Collective
> - Others will live on after I die

> [!note]+ Value
> - Related to caring, mattering, and being important
> - Not just believing something is valueable, rather syndrome of interrelated attitudes
> - Doxastic, deliberative, motivational, and emotional dimensions
> - Context-dependent emotions
> - Dispostion attitude is merited
> - Treat considerations as reasons for action
> - **Remember to make this kind of thing explicit, defining terms and saying what I will and won’t distinguish between (especially literature, story, and narrative)**
> - To value is to see reasons for preserving or extending over time
> - This is a diachronic phenomenon
> - Involves emotional vulnerability to fate
> - A way of trying to control time, to resist transitoriness
> - **This is what storytelling is, to weave connection between an otherwise constant, endless stream of the present**
> - Frankfurt: A life without value is ‘wanton,’ an agent who is not a person because his actions simply reflect first order desires, indifferent to evaluating them
>     - Can they even be said to be an agent at all?

> [!note]+ We
> - ‘wait and see’ claim
> - How much? As much as I can get away with
> - But assuming no one who believes in a personal afterlife 
> - **I bet I can expand this by showing the way the conception of a personal afterlife implies a collective one, and the care about the collective earthly as well**

> [!note]+ Earth is destroyed a month after your death
> - Probably won’t be indifferent
>     - Reasons to engage, emotional investment, and belief in worth of our activities might weaken
>     - Particularly things that take a long time to complete or affect people over a long period of time, like political activism, research, improving institutions
>     - Creative projects that depend on a future audience
>     - Participation in tradition to sustain values and practices over time
>     - Promoting the survival of certain groups
> - Non-experientialist (care about more than just our experiences)
> - Non-consequentialist (care about more than just the balance of pleasure and pain)
> - Conservative (we want the things we value to continue on after us)
> - In a way, we care about humanity’s survival more than our own

> [!note]+ Conceiving of the future
> - Not as blank eternity of non-existence, but continuing social world were we retain a social identity
> - Not just for people with children
> - Survival of the group allows us to “think that if, contrary to fact, one did survive, one would remain socially at home in the world”
>     - **This seems really wrong. It’s not that it’s counterfactually individualistic, it’s that story goes on**

> [!note]+ Conceiving of ourselves
> - We can think of ourselves as custodians of values in a tradition with those who will share them
> - **Is it about sharing the values or having continuity?**

> [!note]+ What are we doing?
> >  attempt to defend and extend the coherence and integrity of our selves and our values over time
> 
> - No, it’s agent-driven continuity, not coherence or integrity
> 
> > Like the biblical Moses denied access to the Promised Land, we stand gazing through the lens of shared values and history toward a future we will not enter.
> 
> > James’s speculations invite us to consider the possibility that out conception of a “human life as a whole” relies on an implicit understanding of such a life as itself occupying a place in an ongoing human history, in a temporally extended chain of lives and generations

> [!note]+ Infertility
> - Would still be horrific without catastrophic suffering
> - Would care about the particularistic traditions dying out, but also humanity as a whole
> - This shows us the limits of our egoism
> - **This is the difference between caring about stories and caring about story**

> [!note]+ Humans or persons?
> - Maybe about the survival of people who share our values and seek to perpetuate our traditions and way of life
> - But important that people should survive even if they change things
> - Other intelligent beings might not provide us with a “personalized relation to the future”
> - **It’s about continuity, not similarity, and this can be shown through thought experiments**

> [!note]+ Dependancy
> - Attitudinal: what matters *to us* is that we are confident in the existence of the afterlife
> - Evaluative: things are actually valueable only if there is an afterlife
> - Justificatory: we are justified in or ther is good reason to valuing these things only if there is an afterlife
> - Not everything is dependent (pain, friendship, etc.)

> [!note]+ Games
> - We like creating little bubbles of value, valuing things we don’t really care about and forgetting the rest for a while
> 
> > it can come as a relief to pretend that things matter when they don’t

> [!note]+ Limits of Individualism
> - Much valuing has a social content or form and implicit collective dimension
> - Assumes that human life matters and will continue
> - We need humanity to have a future for the concept of *mattering* to make sense
> - We over-estimate our independence and self-sufficiency
> - Wouldn’t choose to live as last man on earth
> - Would choose to cut one’s life short for continued survival of humanity
> - Not unsuspected altruism, just limits of individualism

> [!note]+ Moral Duties?
> - No, since they aren’t aimed at overriding our concerns for ourselves
> - Not burdensome obligations but welcome opportunities
> - **Basically, reason-giving obligations don’t feel moral**