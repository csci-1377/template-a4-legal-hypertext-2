---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Liquidating Marble
Takeaway: ""
Tags:
  - Liquidated Damages
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 1885
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Muldoon v. Lynch
Status: Annotated
Date: 1885-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - Lynch contracts for a marble tomb from Muldoon
> - A clause in the contract states forfeiture of $10 per day if late
> - It’s two years late

- Issue: Is the forfeiture a penalty or liquidated damages

> [!note]+ Holding (Myrick): Penalty, not enforceable!
> - Liquidated damages are compensatory, this clearly isn’t
> - LD is for when damages are difficult to calculate
> - The penalty here would be disproportionate to actual damages
