---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Tractor Light Foresight
Takeaway: ""
Tags:
  - Consequential
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1944
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lamkins v. International Harvester Co.
Status: Annotated
Date: 1944-01-01
Year*: 1944
Jurisdiction: Arkansas
---
> [!note]+ Facts
> - Lamkins buys a tractor and some other things from Harvesters, letting them know he wants lights for the tractor
> - They get delivered late, and without lights or a starter. They eventually offer to install the lights on their property
> - Lamkins is late on his payments, so refuses to take the tractor in
> - Harvesters sues him for (late payments?)
> - Lamkins can’t farm his soybeans at night, so he sues them for incedentals for $10 per night he can’t use the tractor
> - Harvesters puts the lights on the tractor

> [!note]+ Procedural History and Posture
> > The trial court held that the facts presented by the record were not sufficient to justify submission of the question to the jury and directed a verdict against appellant. (motion to dismiss?
> 
> - Lamkins appeals

> [!note]+ Holding
> - Summary- It’s not only “reasonably contemplated” from Hadley, but…
> > such knowledge `must be brought home to the party sought to be charged under such circumstances that he must know that the person he contracts with **reasonably believes that he accepts the contract** with the special condition attached to it.'
> 
>     - Basically, high bar for assuming large incedentals
> - Disposition- Affirmed

> [!note]+ Thoughts and Questions
> - What is the standard here? Could no reasonable jury have found this test to have been met?
> - Sure seems like a lot of factual judgments

> [!note]+ Class Notes

