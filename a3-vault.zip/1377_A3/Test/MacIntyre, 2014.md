---
base: "[[Test.base]]"
In-Text Citation: (MacIntyre, 2014)
Authors: MacIntyre
Title: 15. The Virtues, the Unity of a Human Life and the Concept of a Tradition
Zotero URI: https://zotero.org/bmcanally21/items/EIDYDLLL
Takeaway: ""
Tags: []
Category:
  - Ethics
  - Topics in Law and Philosophy
Abstract: ""
Full Citation: MacIntyre (2014) ‘15. The Virtues, the Unity of a Human Life and the Concept of a Tradition’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> man is . . . essentially a story-telling animal. 216.

> I can only answer the question 'What am I to do?' if I can answer the prior question 'Of what story or stories do I find myself a part?’ 216.

> narrative concept of selfhood. 217.

> The virtues therefore are to be understood as those dispositions which will not only sustain practices and enable us to achieve the goods internal to practices, but which will also sustain us in the relevant kind of quest for the good, by enabling us to overcome the harms, dangers, temptations and distractions which we encounter, and which will furnish us with in­ creasing self-knowledge and increasing knowledge of the good. 219.

> What the good life is for a fifth-century Athenian general will not be the same as what it was for a medieval nun or a seventeenth-century farmer. But it is not just that dif­ferent individuals live in different social circumstances; it is also that we all approach our own circumstances as bearers of a particular social iden­tity. I am someone's son or daughter, someone else's cousin or uncle; I am a citizen of this or that city, a member of this or that guild or <u>profession</u>; I belong to this clan, that tribe, this nation. Hence what is good for me has to be the good for one who inhabits these roles. As such, I inherit from the past of my family, my city, my tribe, my nation, a variety of debts, inheritances, rightful expectations and obligations. These constitute the given of my life, my moral starting point. This is in pan what gives my life its own moral particularity. 220.

> Notice also that the fact that the self has to find its moral identity in and through its membership in communities such as those of the family, the neighborhood, the city and the tribe does not entail that the self has to accept the moral limitations of the particularity of those forms of com­munity. Without those moral particularities to begin from there would never be anywhere to begin; but it is in moving forward from such par­ticularity that the search for the good, for the universal, consists. 221.

> Moreover when a tradition is in good order it is always partially constituted by an argument about the goods the pur­suit of which gives to that tradition its particular point and purpose. So when an institution — a university, say, or a farm, or a hospital-is the bearer of a tradition of practice or practices, its common life will be partly, but in a centrally important way, constituted by a continuous argu­ment as to what a university is and ought to be or what good farming is or what good medicine is. . . . A living tradition then is an historically extended, socially embodied argument, and an argument precisely in part about the goods which con­stitute that tradition. 222.

> [Virtues sustain traditions] To recognize this is of course also to recognize the existence of an additional virtue, one whose importance is perhaps most obvious when it is least present, the virtue of having an adequate sense of the traditions to which one belongs or which confront one. This virtue is not to be confused with any form of conservative antiquarianism; I am not praising those who choose the conventional conservative role of *laudator temporis acti*. It is rather the case that an adequate sense of tradition manifests itself in a grasp of those future possibilities which the past has made available to the present. 223. 
> - We must understand our story
> - Tradition is argument

> It has often been suggested-by J. L. Austin, for example -that either we can admit the existence of rival and contingently incompatible goods which make incompatible claims to our practical allegiance or we can be­lieve in some determinate conception of the good life for man, but that these are mutually exclusive alternatives. No one can consistently hold 224 both these views. What this contention is blind to is that there may be better or worse ways for individuals to live through the tragic confronta­tion of good with good. . . . For the tragic protagonist cannot do everything that he or she ought to do. This 'ought', unlike Kant's, does not imply 'can'. Yet it is clear that the moral task of the tragic protagonist may be per­ formed better or worse, independently of the choice between alternatives that he or she makes -ex hypothesi he or she has no right choice to make. The tragic protagonist may behave heroically or unheroically, generously or ungenerously, gracefully or gracelessly, prudently or imprudently. To perform his or her task better rather than worse will be to do both what is better for him or her qua individual and qua parent or child or qua citizen or <u>member of a profession</u>, or perhaps qua some or all of these. 223-24.
