---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Optician Restrictions
Takeaway: The Rational Basis Test is easy to pass.
Tags:
  - EPC
  - RBT
Category:
  - Con Law
Abstract: ""
Page: 1218
Type: Case
Rating: "**"
Year: 1955
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Williamson v. Lee Optical of Oklahoma, Inc.
Status: Annotated
Date: 1955-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Oklahoma law requires opticians to get prescriptions to fit lenses.
> - Optician challenges constitutionality of law

> [!note]+ Procedural History and Posture
> - District Court holds law unconstitutional

- Issue: Does optician restriction deny equal protection?

> [!note]+ Holding (Douglas): No
> - For the legislature, not the courts, to balance advantages and disadvantages of the new requirement.
> 
> > The law need not be in every respect logically consistent with its aims to be constitutional.
> 
> > The prohibition of the Equal Protection Clause goes no further than the <u>invidiuous discrimination</u>.
> 
> > For protection against abuse by legislatures the people must resort to the polls, not the courts. 
> 
> - Disposition: Reversed





















