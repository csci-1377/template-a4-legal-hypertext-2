---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Sheep Grazing
Takeaway: Can’t Exclude Co-tenants (ouster)
Tags:
  - Ouster
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gillmor v. Gillmor
Status: Annotated
Date: 1984-01-01
Jurisdiction: Utah
---
> [!note]+ Facts
> - Land goes 50/50 to two brothers in will
> - Ps are 2 sons of brother 1
> - D is son of brother 2
> - P sues D for exclusive use (ouster)

> [!note]+ Procedural History and Posture
> - TC finds ouster

- Issue: What constitutes Ouster

> [!note]+ Holding (Stewart): Refusing Demand for Use
> - Not about waste: they can both use as much as they want, so long as they allow other to
> - Exclusive use isn’t ouster, but pushing out or refusing entry is, any act that <u>necessarily excludes</u>
> - Objections/replies: 
> - Disposition: 
