---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: No More Bussing
Takeaway: Remedying the effects of past intentional discrimination (by court order) is a compelling interest. Not doing it yourself.
Tags:
  - SS
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1401
Type: Case
Rating: "**"
Year: 2007
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Parents Involved in Community Schools v. Seattle School District No. 1
Status: Annotated
Date: 2007-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 2 voluntary desegregation programs in Seattle and Louisville
> - Louisville subject to a court-ordered desegregation program
> - Then when the court said you’re good, they kept it up.
> - Seattle never had de jure school segregation, but adopted bussing program anyway.

- Issue: Do these bussing programs violate EPC?

> [!note]+ Holding (Roberts): Yes.
> - If there was a court-identified violation that’s one thing, but here there wasn’t.
> - Local governments can only fix problems that 
> - Also, diversity isn’t a <u>compelling interest</u> in elementary schools.
>     - Race isn’t part of a “broader effort to achieve” diversity
> - This is not narrowly tailored
>     - Only use race after other race-neutral programs have failed.
> 
> > The way to stop discriminating on the basis of race is to stop discriminating on the basis of race.

> [!note]+ Concurrence (Kennedy): Yeah. Be sneaky about it.
> - Discriminate by other means, if possible. This doesn’t “tell students” they’re being considered by race.
> 1. Race-neutral approaches (use proxies, like neighborhood)
> 2. Generalized race-based approaches
> 3. Race of individual students





















