---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Crashing the (Third) Party
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Finley v. United States
Status: Annotated
Date: 1989-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Pl’s husband and two kids are killed when their plane strikes a power line on its approach to city-run airfield in San Diego. She sues Federal Aviation Administration (FAA) claiming that it was negligent in way it managed its runway lights, then amends complaint to include state law tort claims against San Diego and utility company.

> [!note]+ Procedural History and Posture
> - District Court allows amended complaint
> - Circuit Court reverses

- Issue: Should amending a complaint to include only state-law claims against a non-diverse third party be allowed?

> [!note]+ Holding (Scalia): No
> - Statutory Authorization
>     -  Federal Torts Claims Act (FTCA), 28 USC § 1346(b), confers jurisdiction over “civil actions on claims *against the United States*.”
>     - Not “claims with the US as one of many parties…”
> - For pendent parties we are going to be stricter, clear statement rule.
> > a grant of jurisdiction over claims involving particular parties does not itself confer jurisdiction over additional claims by or against different parties.
> - Objection: But here we can only bring as a single suit in federal court
>     - Yes, but that’s just not enough
> - Objection: But the joinder can’t defeat the jurisdiction of the case!
>     - If you mean the case against the US yeah, but the question is whether there is an ability to add another party.
>     - FRCP “explicitly provide that they “shall not be construed to extend . . . the jurisdiction of the United States district courts”
> - Disposition: Affirmed

> [!note]+ Concurrence/Dissent (Stevens): 
> - In *Aldinger* we had an explicit rejection of jurisdiction in the form of § 1983 exclusions of municipalities; here we have we are talking just about Congressional silence.
