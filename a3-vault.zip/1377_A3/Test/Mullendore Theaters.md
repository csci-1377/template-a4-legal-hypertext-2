---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Chain of Interest Transfer
Takeaway: Criteria for touch and concern to run with the land
Tags:
  - Leases
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Mullendore Theatres v. Growth Realty Investors Co.
Status: Annotated
Date: 1984-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - OG T gives 22k security deposit to OG L w/promise to return in 10 years
> - T assigns interest to P, security deposit reduced to 6k
> - OG L assigns to L2, L2 defaults, interest taken by D
> - D sells to city of Tacoma, indemnifies for 6k deposit, P agrees to release city but retain right to collect from D
> - P sues D for return of deposit
> - D argues doesn’t run with the land

- Issue: Does security deposit run with the land?

> [!note]+ Holding (Worswick): No
> - Must be “so related to the land as to enhance the value and confer a benefit upon it” 
> - And funds must be restricted to “the benefit of the property”
> - Not restricted to property benefit here because not required to use deposit for repairs or maintenence nor transfer it to successors
> - Disposition: 

> [!note]+ Concurrence/Dissent (): 
> - 