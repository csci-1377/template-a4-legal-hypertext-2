---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Regan Replay
Takeaway: Use FRCP if it’s there, twin aims analysis
Tags:
  - Vertical Choice of Law
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 1965
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hanna v. Plumer
Status: Annotated
Date: 1965-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Mass rule says service of process on dead guy has to be on will executor
> - Fed rule says service can be on the spouse.
> - Bu the time P realises, 
> 
> Ohio Pl sues the estate of a deceased MA defendant in MA federal court for negligence causing a car crash in South Carolina. Massachusetts had a provision [Mass. Gen. Laws Ch. 197 § 9] saying that in actions against an estate, you must make in-hand, personal delivery service to the executor of the estate within one year of filing complaint.
> 
> The Pl does not do what Mass law says, and instead serves the executor’s wife at the executor’s home in compliance with the FRCP service of process rules.
> 
> By the time the issue gets litigated, they are outside the MA 1 year SOL period, so if the MA rule applies, the action is dead.

> [!note]+ Procedural History and Posture
> - District court for D, use state rule (Ragan, Guaranty)
> - Appeals affirms “substantive rather than a proceedural matter” (Erie)

- Issue: Service of process in diversity suits by state law or FRCP

> [!note]+ Holding (Warren): FRCP
> - General: Twin Aims Analysis
> > "Outcome-determination" analysis was never [467] intended to serve as a talisman… cannot be read without reference to the <u>twin aims</u> of the *Erie* rule:  
> > 1. discouragement of forum-shopping and 
> > 2. avoidance of inequitable administration of the laws.
> >     1. (Does the gamesmanship that would result bother us?)
> 
>     - “Though choice of the federal or state rule will at this point have a marked effect upon the outcome of the litigation, the difference between the two rules would be <u>of scant, if any, relevance to the choice of a forum</u>” [¶28]
> - Specific: When you have an FRCP
>     - When you get Congress’ blessing, you have more power
>     - Whenever you've got a <u>**valid**</u> FRCP that is <u>**applicable**</u>, it trumps.
> > The Erie rule has never been invoked to void a Federal Rule…*Erie* and its offspring cast no doubt on the long-recognized power of Congress to prescribe housekeeping rules for federal courts even though some of those rules will inevitably differ from comparable state rules… 
> 
> > not that *Erie* commanded displacement of a Federal Rule by an inconsistent state rule, but rather that the scope of the Federal Rule was not as broad as the losing party urged, and therefore, there being no Federal Rule which covered the point in dispute, *Erie* commanded the enforcement of state law.
> 
>     - On **validity**, look to Rules Enabling Act, 28 U.S.C. § 2072 (and the Constitution)
>     - Never been one held to be invalid
>     - Ask yourself: does it “really regulateprocedure: the judicial process for enforcing rights and duties recognized by substantive law and for justly administering remedy and redress for disregard or infraction of them.” [quoting *Sibbach v. Wilson*, S. Ct. (1941)].
> *Rules Enabling Act: *28 U.S.C. § 2072 (discussed on Day 1 of course)
>     1. The Supreme Court shall have the power to prescribe <u>general rules of practice and procedure and rules of evidence</u> for cases in the United States district courts (including proceedings before magistrate judges thereof) and courts of appeals.
>     2. Such rules <u>shall not abridge, enlarge or modify any substantive right.</u> All laws in conflict with such rules shall be of no further force or effect after such rules have taken effect.
> - The REA is only power that Congress has given the Court is to promulgate rules of procedure, and it is prevented from doing anything that “abridges, enlarges, or modifies a substantive right.”
> - For the constitutional provision for a federal court system… carries with it rules…which, <u>though falling within the uncertain area between substance and procedure, are rationally capable of classification as either.</u>” [¶33]
> - On **applicability**, we’ll discuss *Walker* and *Stewart*
> - Apply to this case…Is the FRCP valid and applicable? Yes and Yes!
> > To hold that a Federal Rule of Civil Procedure must cease to function whenever it alters the mode of enforcing state-created rights would be to disembowel [474] either the Constitution's grant of power over federal procedure or Congress' attempt to exercise that power in the Enabling Act.[[17]](https://opencasebook.org/casebooks/9188-civil-procedure-2023/resources/9.2.1.9-hanna-v-plumer/#%5B17%5D) Rule 4 (d) (1) is valid and controls the instant case.
> - Disposition: Reversed

> [!note]+ Concurrence (Harlan): Yes, but for base principles
> - Critique of “<u>arguably procedural, </u><u>*ergo *</u><u>constitutional</u>”: basically swings back to over-simplified Erie, missing insights from Guaranty. We can’t really do outcome-determinative, but something like…
> - Standard-Like Test: “if the choice of rule would s<u>ubstantially affect those primary decisions respecting human conduct</u> which our constitutional system leaves to state regulation.”
> - <u>Ragan </u>wrongly decided: <u>contrary to clear FRCP rule</u>, in that case would not have affected primary decisions…
> - Again, here the intent of the statute is not deeply frustrated, aka doesn’t really affect primary decision, so side with Court.