---
base: "[[Test.base]]"
In-Text Citation: (Parry, 2022)
Priority: Essential
Authors: Parry, Jonathan
Title: Why Paternalism Is Wrong (When It Is Wrong) Draft v3.2.pdf
Zotero URI: http://zotero.org/users/4316906/items/GCAIXNV7
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Parry, J. (2022) ‘Why Paternalism Is Wrong (When It Is Wrong) Draft v3.2.pdf’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
- Targets of intervention have, by refusing beneficent intervention, rendered their good morally unavailable for the purpose of justifying interference.
- Competency
    - Most cases where there is assumed lack (coersion or inability)
    - Concern of question-begging nature of this determination (no one could competently choose a gallon-sized soda)
- Refusal
    - Most cases there isn’t an active refusal, because most people simply are unaware or unconsulted
    - Hypothetical agreement (if their confusion were resolved, after intervention would be glad
- Competency question also presents a problem for autonomy, but neither seems to present a problem for insult
- Seems as if these both undermine 
- Interesting cases are the ones where no one has explicitly refused anything. The question is where the default should be for intervention (not ok unless someone explicitly consents on one end, always ok unless someone explicitly rejects on the other)
- Means paternalism: get you to take a better route to achieving goals you already have
- Ends paternalism: trying to get you to adopt new ends

- The solution here is that there is no unique wrong of paternalism because of the relationship between the interference and the good. 
    - Giving amphetamines to Adam and Patrick before they enter a test
        - Case 1: Adam has ADHD, refuses the benefit
        - Case 2: Adam will get a puppy
    - 
