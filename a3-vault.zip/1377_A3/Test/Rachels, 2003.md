---
base: "[[Test.base]]"
In-Text Citation: (Rachels, 2003)
Priority: Recommended
Authors: Rachels, James
Title: Psychological Egoism
Zotero URI: http://zotero.org/users/4316906/items/IC4935R9
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Journal Article
Full Citation: Rachels, J. (2003) ‘Psychological Egoism’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2003
---
