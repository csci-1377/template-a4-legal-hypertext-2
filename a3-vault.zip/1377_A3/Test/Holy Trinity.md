---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Immigrant Preacher
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "****"
Year: 1892
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Church of the Holy Trinity v. United States
Status: Annotated
Date: 1892-01-01
Year*: 1892
Jurisdiction: United States
---
> [!note]+ Parties
> - US Church
> - US prosecutor

> [!note]+ Facts
> - Church contracts with a UK pastor to come preach for a bit
> - US claims forbidden by an act forbidding importation of aliens under contract to perform “labor or service of any kind”
> - Case is brought against the minister
> - Congress amends the statute to make an exception for clergy (1891)

> [!note]+ Holding (Brewer)
> - The act clearly bans the preacher on its face (makes specific exceptions, preachers aren’t among them)
> - But canon: a thing may be within the letter of the statute and yet not within the statute, because not within its spirit or the intention of its makers.
> - Title- About labor, not work of the mind
> - Purpose- To address exploitative labor contracts which undermine US workers.
> - Legislative History- a committee expects it will only be interpreted to include manual labor, so they don’t amend the language.
> - Religiosity- No purpose against religion can be imputed to any legislation, because America is a religious nation.
> 
> > General language is broad enough to reach cases and acts which the the whole history and life of the country affirm could not have been intentionally legislated against.
> 
> > The act, although within the letter, is not within the intention of the legislature, and therefore cannot be within the statute.

> [!note]+ Notes/Questions
> - Canon of Purposivism: Mischief rule, design statute to solve a problem.
> - Canon of Conservativism: Statutory purposes and meaning should be inferred in light of deeply held backhground values.
> - Strong Purposivism v Plain meaning in 18-1900s
> - Nuanced purposivism late 1900s, about what purpose “ought to be attributed to the statute”
> - New Textualism (focused on the legislative compromise), Scalia et al
