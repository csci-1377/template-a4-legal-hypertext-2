---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Can’t stop Voter Suppresion
Takeaway: We can’t provide an equitable remedy to this giant constitutional violation.
Tags:
  - 15A
Category:
  - Con Law
Abstract: ""
Page: 520
Type: Case
Rating: "***"
Year: 1903
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Giles v. Harris
Status: Annotated
Date: 1903-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Giles, literate black janitor activist in Montgomery
> - State using discretionary tests to reduce black turnout in Alabama from 180,000 to 3,000
> - Giles invokes KKK Act (§1983) to say his constitutional rights are being violated.

- Issue: Can we grant relief for this clear 15A violation?

> [!note]+ Holding (Holmes): No.
> - It is “impossible” for us to grant the equitable relief asked for
> - We don’t normally remedy “political wrongs”
> - If we grant the remedy, then it legitimizes the system (all or nothing)
>     - We don’t want to make you part of the fraud that you’re alleging.
> - But we can’t take down the system (can’t do all)
>     - We would have to supervise the voting system.
> 
> > The great mass of the white population intends to keep the blacks from voting.
> 
> - So we do nothing.
> - But other branches, please do something!

> [!note]+ Dissent (Brewer): Yes. It’s simple.
> - Giles was deprived of his constitutional rights.
> - He should vote in the coming injunction.
> - We can issue an injunction for that.





















