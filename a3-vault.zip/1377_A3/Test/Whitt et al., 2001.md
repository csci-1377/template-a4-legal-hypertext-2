---
base: "[[Test.base]]"
In-Text Citation: (Whitt et al., 2001)
Priority: Essential
Authors: |-
  Whitt, Laurie Anne
  Roberts, Mere
  Norman, Waerte
  Grieves, Vicki
Title: Indigenous Perspectives
Zotero URI: http://zotero.org/users/4316906/items/TEZJWCGC
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Book Section
Rating: "***"
URL: https://onlinelibrary.wiley.com/doi/10.1002/9780470751664.ch1
Full Citation: "Whitt, L.A. et al. (2001) ‘Indigenous Perspectives’, in D. Jamieson (ed.) A Companion to Environmental Philosophy. Malden, Massachusetts, USA: Blackwell Publishers Inc., pp. 3–20. Available at: https://doi.org/10.1002/9780470751664.ch1."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2001
---
> [!note]+ Genealogy 
> - whakapapa in Maori
> - Provides stories of origins and bind through time
> - Defines knowing oneself and others through stories
> - Individuals cannot appear within it without thereby assuming relational ties to all others within the geneology
> - It is simply not possible to exist outside a geneology
> - Geneologically embedded individuals are bound, and answerable, to one another
> - Need not confine themselves to the human
> - Stories of temporal and spatial belonging
> - way of passing through or being with ancestors

> [!note]+ Ownership
> - Reciprocal, like “my mother” belonging goes both ways

> [!note]+ Respect
> - most widely shared moral principle among indigenous peoples
> - “wish-to-be-appreciated”
> - simple awareness of relatedness may ground respect

> [!note]+ Knowledge
> - Presentational, related to circumstances around it
> - Can’t be “relocated” but is “dislocated”
> - Cannot practice religion anywhere