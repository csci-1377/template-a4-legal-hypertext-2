---
base: "[[Test.base]]"
In-Text Citation: (Donagan and Paul, 2023)
Priority: Recommended
Authors: |-
  Donagan, Alan
  Paul, Kegan
Title: Shared Intention
Zotero URI: http://zotero.org/users/4316906/items/N22NAS9T
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Full Citation: Donagan, A. and Paul, K. (2023) ‘Shared Intention’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2023
---
