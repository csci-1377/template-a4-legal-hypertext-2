---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Peeping Tom
Takeaway: "Statutes can be unconstitutionally vague or overbroad: this one is neither."
Tags:
  - Interpretation
Category:
  - Crim
Abstract: ""
Page: 109
Type: Case
Rating: "**"
Year: 1978
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: In Re Banks
Status: Annotated
Date: 1978-01-01
Jurisdiction: North Carolina
---
> [!note]+ Facts
> - Peeping Tom Law: “Secretly peeping into room occupied by female person.—Any person who shall peep secretly into any room occupied by a female person shall be guilty of a misdemeanor and upon conviction shall be fined or imprisoned in the discretion of the court.”

> [!note]+ Procedural History and Posture
> - Trial court finds law unconstitutional

- Issue: Is the Peeping Tom statute unconstitutional?

> [!note]+ Holding (Moore): No
> - Criminal statutes must be interpreted narrowly, but with evil they were designed to address in mind
> - Not too vague: In this case, prohibits wrongful spying into a room with the intent of violating a female’s legitimate expectation of privacy.
> - Not overbroad: does not prohibit legitimate conduct when interpreted narrowly.





















