---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Stabbing Your Son
Takeaway: Actus reus implies voluntarity (a spasm is not an act)
Tags:
  - Actus Reus
Category:
  - Crim
Abstract: ""
Page: 137
Type: Case
Rating: "**"
Year: 1971
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Utter
Status: Annotated
Date: 1971-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - Former infantryman stabs son
> - Claims it was a “conditioned response”

> [!note]+ Procedural History and Posture
> - Psychiatrist testifies that this was a “conditioned response” AKA nonvoluntary.
> - Issue withheld from jury at trial on grounds it was a “temporary insanity” defense.

- Issue: Does an act need to be voluntary?

> [!note]+ Holding (Farris): Yes
> > A spasm is not an act
> 
> - Actus reus implies voluntarity
> - Disposition: Affirmed (insufficient evidence presented to jury to find the issue of fact)




















