---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Diseased Chicken Sales
Takeaway: Congress can regulate what has a “direct” but not an “indirect” effect on interstate commerce
Tags:
  - CC
  - Industry
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 1935
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ALA Schechter Poultry Corp. v. United States
Status: Annotated
Date: 1935-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Schechter Corporation sells diseased poultry, cuts costs
> - NIRA permits industry regulations by private entities
> - Federal prosecutors convict Schechter brothers of violating code

> [!note]+ Procedural History and Posture
> - Appellate court agrees this is valid excercise of Commerce Clause

- Issue: Can Congress create industry codes that regulate slaughter and sale within a state?

> [!note]+ Holding (Hughes): No
> - Transactions were not “in” interstate commerce
>     - The “voyage” ended when they arrived at the slaughterhouse
> - That’s fine, so long as they *directly* affect it
> - The criterion is the effect, not the source of the injury
> - The direct/indirect distinction is well-established (really?)
> - Here it’s just indirect
> - Basically, just a protection of big industry