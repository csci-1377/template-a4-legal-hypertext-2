---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Railroad Price Ceiling
Takeaway: You can sue an officer in their official capacity for unconstitutional acts.
Tags:
  - A3
  - 11A
Category:
  - Con Law
Abstract: ""
Page: 919
Type: Case
Rating: "****"
Year: 1908
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ex parte Young
Status: Annotated
Date: 1908-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Railroad shareholders sue AG of Minnesota to enjoin enforcement of statute setting railroad rates. Court issues injunction, Young ignores, court holds in contempt. He challenges with habeas motion, ends up in SC

> [!note]+ Procedural History and Posture
> - 

- Issue: Does 11A bar suit against officer? Is this “really” against a state?

> [!note]+ Holding (Peckham): Nope!
> - The “fiction”: a state official who acts unconstitutionally is an individual, not a state. If it’s unconsitutional, he is stripped of representative character. 
> - Exception: doesn’t apply to courts!
> - Counter
>     - They were authorized to do this! 
>         - Yeah, but doesn’t matter. The officer sued has a personal stake.
>     - This limits the discretion of the officer!
>         - Not really, they’re just stopped from doing something they have no right to do.
> - Functionalism: the “alternate remedy” of disobedience takes too long, and in the meantime property might be taken without DP.
> - Cf. “under color”: tension with *Monroe- *unconstitutional action by official is state action according to 14th Amendment but not attributable to state under 11th. 
> - Cause of action: he is a state actor, so using 1983, Bivens, etc.





















