---
base: "[[Test.base]]"
In-Text Citation: (McDowell, 1985)
Priority: Essential
Authors: McDowell, John
Title: Values and Secondary Qualities
Zotero URI: http://zotero.org/users/4316906/items/L4H3G9YY
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Document
Rating: "**"
Full Citation: McDowell, J. (1985) ‘Values and Secondary Qualities’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1985
---
> [!note]+ Intro
> - Primary Quality: a trait that can be understood independent of perceptual appearance
> - Focusing on primary qualities might diagnose a projective error leading to an error theory
> - Secondary quality: a property that can only be understood in terms of perceptual experience (like redness)
>     - This can be objective when we say that the quality is there to be experienced independently of any given experience of it.
> - If we look at secondary qualities, we can accept a kind of realism

> [!note]+ Complications
> - Values aren’t just secondary qualities, because they are not just things which tend to elicit the appropriate attitudes but those that merit them.
> - So something like being frightening. We make sense of fear as being a response to objects that merit it or some defective response that is a misfiring of an intelligible one.
> - Then the capacity to certify values as real is the same creative, case-specific capacity required to discern values in the first place.














