---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Liquidating Oil Barons
Takeaway: ""
Tags:
  - Liquidated Damages
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Yokey v. Horn
Status: Annotated
Date: 1989-01-01
Jurisdiction: Seventh Circuit
---
> [!note]+ Facts
> - Yokey and horn are partners in an oil business, then things go bad
> - Yokey and Horn settle, agreeing not to participate in any further litigation against each other
> - This agreement includes a liquidated damages clause, setting a minimum of $50,000 + fees
> - Horn contacts Schrock, and Schrock sues Yokey.
> - Horn gives a deposition in the case
> - Yokey sues horn for breach of contract.

> [!note]+ Procedural History and Posture
> - District court finds Horn liable to Yokey for $50,000

- Issue: Is this big breach clause liquidated damages or a penalty?

> [!note]+ Holding (Wood): It’s liquidated damages, so enforceable.
> - Did horn voluntarily participate in litigation? Yes.
> - Is the agreement against public policy? No, and even if it did,that doesn’t make it unenforceable.
> 
> > [!note]+ Is it a penalty, not liquidated damages? No. It’s enforceable.
> > Has to be reasonable either when contract was made or at time of breach
> > 
> > And it has to be hard to measure.
> > 
> > But if i*t is clear that no loss at all has occurred, a provision fixing a substantial sum as damages is unenforceable.*
> 
> - What losses did Yokey actually suffer?
>     - Horn probably would have been subpoena’d anyway, and her testimony didn’t do much in the case, but could have…
>     - Hurt Yokey’s reputation
> - Disposition- Affirmed
