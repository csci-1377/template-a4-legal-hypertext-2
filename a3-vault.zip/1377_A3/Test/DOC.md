---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Census Pretext
Takeaway: First use of ArbCap review based on pretext
Tags:
  - ArbCap
Category:
  - LegReg
Abstract: ""
Page: 563
Type: Case
Rating: "***"
Year: 2019
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Department of Commerce v. New York
Status: Annotated
Date: 2019-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Constitution requires census
> - Congress delegates the responsibility to conduct the census to the Secretary of Commerce
> - Secretary of Commerce wants to add citizenship question on the census
> - His own department does an expert analysis showing this will make the census less accurate by reducing response rates
> - Claims to add the question to “help the DOJ more effectively enforce the Voting Rights Act”
> - Because of public statements to contrary, lower court grants discovery to get extra info
>     - Turns out he reaches out to everyone trying to get it on there.
>     - Eventually calls up the AG, asking to get it removed
>     - The AG says ok, I recommend removing it…

- Issue: Was the decision to add a citizenship question arbitrary and capricious?

> [!note]+ Holding (Roberts): Yes, because the stated reasons were pretextual
> - The stated reasons would have been enough, but…
> 
> > Evidence tells a story that does not match the explanation the Secretary gave for his decisions

> [!note]+ Concurrence/Dissent (Breyer): Yes, because the stated reasons were insufficient
> > Where all available evidence indicates that one option is better than the other, it is unreasonable to choose the worse option without explanation”

> [!note]+ Concurrence/Dissent (Thomas): No, we should limit analysis to stated reasons
> > Opening a Pandora’s box of pretext-based challenges in administrative law.
> 
> - Creates strong incentives to second-guess and burden agencies with depositions etc.