---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Misleading Merger Statements
Takeaway: Offensive collateral estoppel is up to district court discretion (multi-factor test)
Tags:
  - Issue Preclusion
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1979
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Parklane Hoisery Co. v. Shore
Status: Annotated
Date: 1979-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Case 1: SEC v. Parklane, alleging that a proxy statement Parklane had issued was materially false and misleading. Sought injunctive relief. Four-day trial leads to conclusion that the statement was false and misleading and entry of a declaratory judgment.
> 
> Case 2: Shore et al. v. Parklane, Class action alleging that Parklane had issued a materially false and misleading proxy statement in connection with a merger. Sought damages, rescission of merger, recovery of costs. Pls move for partial summary judgment against Parklane, claiming issue preclusion on the issue of whether statement was materially false and misleading. Parklane objects saying issue preclusion here would deprive them of their 7th Amendment jury trial right.

> [!note]+ Procedural History and Posture
> - District Court: denies the partial SJ on the ground of issue preclusion, saying doing so would deprive Parklane of 7th Amendment rights
> - 2nd Cir: Reverses

- Issue: Offensive Collateral Estoppel?

> [!note]+ Holding (Stewart): Up to district court discretion
> - Not the same efficiency (judicial economy) gains in offensive like defensive (discourages joinder rather than encouraging it)
> - Unfair to Def
>     - Forces defense in small issues because they might preclude important defenses in other cases
>     - Might conflict with other more favorable rulings
>     - Might prevent use of new procedural opportunities not available in first case
> - So don’t prevent, but leave up to district court discretion
> > The general rule should be that in cases where a plaintiff could easily have joined in the earlier action or where, either for the reasons discussed above or for other reasons, the application of offensive estoppel would be unfair to a defendant, a trial judge should not allow the use of offensive collateral estoppel.
> - Here, it’s not unfair
>     - P could not have joined earlier case
>     - D had every incentive to defend earlier
>     - Not inconsisten with prior decision
>     - No new procedural opportunities available here (because a jury trial isn’t important)
> - Disposition: Affirmed

> [!note]+ Dissent (Rehnquist): No, not fair, even here!
> - Unfair because no jury trial in first case (important procedural opportunity)
> - Won’t really save money because still need a jury to decide damages
> - More likely to coerce settlments in agency enforcement actions because alternative cripples D
