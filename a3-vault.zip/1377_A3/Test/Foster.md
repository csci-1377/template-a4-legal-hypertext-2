---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Deathbed Instructions to Husband
Takeaway: Constructive Delivery for Gifts?
Tags:
  - Gifts
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1955
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Foster v. Reiss
Status: Annotated
Date: 1955-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - Wife leaves separated husband kind of living in same house $1 in will
> - Writes letter before surger with instructions to get misc items/money around house and keep some
> - Husband gets letter, claims to talk to wife after surgery
> - Everyone else says she’s just comatose, then dies
> - Executrix of wife’s will sues husband for conversion

> [!note]+ Procedural History and Posture
> - Trial court finds for P (no delivery, no gift)
> - Appeals reverses

- Issue: Was there “delivery”?

> [!note]+ Holding (Vanderbilt): Nope! (Formalism)
> > Here there was no delivery of any kind whatsoever.
> 
> - Disagree with appeals that donee already had posession, so delivery was unnecessary (lived in different part of house)
> - If he had retrieved and reported and she <u>*ratified*</u>, that might be enough, but didn’t happen here.
> - Disposition: Reversed

> [!note]+ Dissent (Jacobs): Delivery requirement is absurd (Contextualism)
> > Difficult to believe that our law would require such wholly ritualistic ceremony.
