---
base: "[[Test.base]]"
In-Text Citation: (Pereboom, 2012)
Priority: Recommended
Authors: Pereboom, Derk
Title: Free Will Skepticism, Blame, and Obligation
Zotero URI: http://zotero.org/users/4316906/items/2T45GVYZ
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: The book argues we are not free in the sense required for moral responsibility that involves basic desert, but that a conception of life without this type of free will would not be devastating to morality or to our sense of meaning in life, and in certain respects it may even be beneficial. This chapter sets out a notion of blame and its place in the moral life consistent with a denial of the sort of free will required for moral responsibility in the basic desert sense, and the chapter specifies the respect in which this sort of blame requires that its target have an ability to do otherwise.
Type: Book Section
URL: https://doi.org/10.1093/acprof:oso/9780199860821.003.0010
Full Citation: "Pereboom, D. (2012) ‘Free Will Skepticism, Blame, and Obligation’, in D.J. Coates and N.A. Tognazzini (eds) Blame: Its Nature and Norms. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/acprof:oso/9780199860821.003.0010."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2012
---
