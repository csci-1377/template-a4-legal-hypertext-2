---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Strike Stricken
Takeaway: Three Categories for Executive Power
Tags:
  - A2
Category:
  - Con Law
Abstract: ""
Page: 793
Type: Case
Rating: "*****"
Year: 1952
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Youngstown Sheet & Tube Co. v. Sawyer
Status: Annotated
Date: 1952-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Laws
>     - Anti-Strike Act of 1943 allows president to seize and operate industries (not extended after WWII)
>     - Taft-Hartley Act of 1947: Can petition federal court to enjoin a strike for 80 days, pending an impartial study
>     - Defense Production Act of 1950: Allows President to support collective action through UN
> - Events
>     - Steel industry couldn’t strike during WWII, but now they can and do.
>     - Truman orders secretary of commerce to seize nation’s steel mills (they raise wages but prohibit striking).
>     - Asks Congress to ratify or countermand, but they say nothing.
>     - Youngstown, among other large steel companies, sues to regain control over steel mills.

- Issue: Can President Seize Stell Industries?

> [!note]+ Holding (Black): Nope, Congress was Silent.
> - Power has to come from Statute or Constitution
>     - Statute: neither express nor implied
>     - Constitution: definitely not expressed…
> - Implied Constitutional Power…
>     - Commander-in-Chief: no, this isn’t the “theater of war” (distinguishing from the Korean War itself)
>     - Take Care: but there is no law to execute here!
> - Ok, other Presidents have done this in the past, but let’s not look too closely at that.

> [!note]+ Concurrence (Frankfurter): No, Congress Rejected This.
> - Taft-Hartley Act voted down this kind of power.

> [!note]+ Concurrence (Douglas): No, but the President is still important!
> - The president can’t *make laws*, but can still do a lot.

> [!note]+ Concurrence (Jackson): No, **Three Categories of Presidential Action**
> - First, difference between executive branch lawyer and a judge.
> 1. Express or Implied Authorization from Congress: “Maximum”
>     - President’s Powers + Congress
> 2. Absence of Congressional Grant or Denial of Authority: “Zone of Twilight”
>     - “Depends on imperatives of events and contemporary imponderables rather than abstract theories of law”
> 3. Against Express or Implied Will of Congress: “Lowest Ebb”
>     - President’s Powers - Congress
>     - Example: [[Myers]] 
>     - Sometimes the President can actually counter Congressional authority.
> - Basically, Congress rejected this (Cat 3), so we would have to rule the statute unconstitutional to uphold the power
>     - Vesting Clause? No way!
>     - Commander in Chief? Hell no!
>     - Take Care? Absolutely absurd!
>     - Nothing in Article II that analogizes this to *Myers*, where we would have to strike down the law. 
> 
> > Indulge some latitude of interpretation for changing times… give to the enumerated powers the scope and elasticity afforded by what seem to be reasonable, practical implications instead of the rigidity dictated by a doctrinaire textualism.
> 
> > [rejecting] necessity knows no law.
> 
> > Gap exists between the President’s paper powers and his real powers.

> [!note]+ Dissent (Vinson): Yes! (What Youngstown often stands for)
> - Historical Practice: Presidents have been doing this for a long time (Emancipation Proclamation!)
> - Congressional Intent: Defense Production Act authorizes this: Congress’s policy is to get production going so we can win!
> - No “messenger-boy” concept of the Office [of the President]
> - “Extraordinary powers” should be considered in light of “extraordinary times”
> - Truman explicitly invited Congressional Input





















