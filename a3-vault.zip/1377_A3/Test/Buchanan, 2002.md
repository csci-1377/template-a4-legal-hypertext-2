---
base: "[[Test.base]]"
DOI: https://doi.org/10.1017/S0265052502192065
In-Text Citation: (Buchanan, 2002)
Priority: Essential
Authors: Buchanan, Allen
Title: Social Moral Epistemology
Zotero URI: http://zotero.org/users/4316906/items/QAAFN6NN
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: The distinctive aim of applied ethics is to provide guidance as to how we ought to act, as individuals and as shapers of social policies. In this essay, I argue that applied ethics as currently practiced is inadequate and ought to be transformed to incorporate what I shall call social moral epistemology. This is a branch of social epistemology, the study of the social practices and institutions that promote (or impede) the formation, preservation, and transmission of true beliefs. For example, social epistemologists critically evaluate the comparative advantages of adversarial versus inquisitorial criminal proceedings as mechanisms for the discovery of truth. [PUBLICATION ABSTRACT]
Type: Journal Article
URL: https://www.proquest.com/docview/205289291/abstract/69D1DE7B90D5460CPQ/1
Full Citation: "Buchanan, A. (2002) ‘Social Moral Epistemology’, Social Philosophy & Policy, 19(2), pp. 126–152. Available at: https://doi.org/10.1017/S0265052502192065."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Up Next
Year*: 2002
---
