---
base: "[[Test.base]]"
In-Text Citation: (Murphy, 2011)
Priority: Recommended
Authors: Murphy, Susan P.
Title: Special Obligations
Zotero URI: http://zotero.org/users/4316906/items/UAD3MZNF
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Book Section
URL: https://doi.org/10.1007/978-1-4020-9160-5_390
Full Citation: "Murphy, S.P. (2011) ‘Special Obligations’, in D.K. Chatterjee (ed.) Encyclopedia of Global Justice. Dordrecht: Springer Netherlands, pp. 1027–1032. Available at: https://doi.org/10.1007/978-1-4020-9160-5_390."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2011
---
