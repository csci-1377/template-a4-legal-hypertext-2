---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1351-0487.2005.00414.x
In-Text Citation: (Thompson, 2005)
Priority: Essential
Authors: Thompson, Dennis F.
Title: "Democracy in Time: Popular Sovereignty and Temporal Representation"
Zotero URI: http://zotero.org/users/4316906/items/GAIKKK3J
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Journal Article
Rating: "**"
URL: http://0.onlinelibrary.wiley.com/doi/abs/10.1111/j.1351-0487.2005.00414.x
Full Citation: "Thompson, D.F. (2005) ‘Democracy in Time: Popular Sovereignty and Temporal Representation’, Constellations, 12(2), pp. 245–261. Available at: https://doi.org/10.1111/j.1351-0487.2005.00414.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2005
---
> [!note]+ Intro
> - Popular sovereignty ambiguous
>     - Spatially: local or national?
>     - Temporally: **past**, present or future?
> - Reasons we should care about future sovereignty
>     - Irreversable harms (environmental and political)
> - Principle: permit only those constraints necessary to make a sovereign at any time competent to express a judgment
>     - **What about those necessary to make a sovereign at all, and those that enable greater ability (constitutive rules)**
>     - Two forms: enough and as good, or maximize up to the point it decreases our own sovereignty
>     - Representatives are just trustees of the democratic process, not all the interests of future citizens

> [!note]+ How we can constrain
> - Current majorities leave open the possibility of change to other forms of democracy, including those that alter the definition of the majority **so protect the right of the future to ignore the rights of the future?**
> - Indirect constraints: decisions that influence future capacity (contracts, debts, treaties, etc) **but what about those decisions that create capacities?**
> - Direct contraints: supermajority requirements
>     - Constitutional amendments: make ratification less demanding or let a longer majority ratify
>     - Legislative: no filibuster
>     - Redistricting: use an independent commisions

> [!note]+ Ways to represent the future
> - Tribunate (without any political ambitions
> - Independent commision for electoral regulation
> - Posterity impact statements
> - Democratic balance sheets
> - Contingency trust funds
> - Constitutional Conventions
> - Extra-governmental organizations (parties, international agreements and NGOs)






