---
base: "[[Test.base]]"
In-Text Citation: (Ripstein, 2003)
Priority: Recommended
Authors: Ripstein, Arthur
Title: Review of Punishment, Communication, and Community
Zotero URI: http://zotero.org/users/4316906/items/XNMW58B2
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://www.jstor.org/stable/3542882
Full Citation: Ripstein, A. (2003) ‘Review of Punishment, Communication, and Community’, The Philosophical Quarterly (1950-), 53(211), pp. 310–313.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2003
---
Duff says punishment is an occasion where the community speaks to one of its members about a moral wrong that person has done.

Secular penance can’t justify punishment

> [!note]+ Basic Ideas
> - Punishment is addressed to moral wrongdoing
> - It is essentially communicative
> - It is only warrented in which the perpetrator is a member of the community

> [!note]+ Community
> - Provides fundamental goods to its members
> - Owes inclusion to its members
> - Must have standing to impose punishment, does not follow from prohibitio or wrongfulness

> [!note]+ Religiosity
> - Hope animates account. Must try to get through to them, owe it to him as one of us.
> - Invokes contested conception of the good life
> - Required continuing hope in the face of contrary evidence
> - In tension with liberalism and proportionality

> [!note]+ Quotes
> We, as a society, lock people up for extended periods, and claim to do so in the name of autonomy














