---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Self-Propelled Semantics
Takeaway: Use of Semantic Canons
Tags:
  - Lenity
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1931
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: McBoyle v. U.S.
Status: Annotated
Date: 1931-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - McBoyle transports known stolen airplane across statle lines
> - National Motor Vehicle Theft Act states…
>     - Sec. 2: ‘motor vehicle’ includes automobile, truck, wagon, motorcycle, “or any other self-propelled vehicle not designed for running on rails”
>     - Sec 3. if you transport a ‘motor vehicle’ knowing stolen, up to 5k fine and 5 years prison

> [!note]+ Procedural History and Posture
> - At trial, sentenced to 3 years imprisonment and fined 2k

- Issue: Is an airplane a ‘self-propelled vehicle’ here?

> [!note]+ Holding (Holmes): No, it isn’t
> - Start with the dictionary
> - Then common speech
> - Ejusdem generis: after others in list, constrained
> - Legislative History
>     - Airplanes not brought up in committee reports or debates
>     - This law is based on earlier statutes from before airplanes were invented
> - Rule of Lenity: we should give fair warning, and the line should be clear
> - Disposition: Reversed
