---
base: "[[Test.base]]"
In-Text Citation: "(‘Today in the Community: November 1, 2011’, 2011)"
Authors: ""
Title: "Today in the Community: November 1, 2011"
Zotero URI: https://zotero.org/bmcanally21/items/TIFLQGV3
Takeaway: ""
Tags:
  - bad law
Category:
  - Topics in Law and Philosophy
Abstract: Today in the Community we are discussing Lafler v. Cooper and Missouri v. Frye, a pair of cases raising issues about plea offers and ineffective assistance of counsel in which the Court heard oral argument yesterday.  In both cases, the respondents received deficient advice from their trial counsel.
Type: Blog Post
URL: https://www.scotusblog.com/2011/11/today-in-the-community-november-1-2011/
Full Citation: "‘Today in the Community: November 1, 2011’ (2011) SCOTUSblog, 1 November. Available at: https://www.scotusblog.com/2011/11/today-in-the-community-november-1-2011/ (Accessed: 17 November 2024)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> Defining bad law doesn’t seem very difficult in this context. If the clinic is considering representing X client, “bad law” is that which would be contrary to that X’s interests.

> The question is not whether clinics should “not take cases where there is significant risk of making bad law.” There is always a chance of making bad law.