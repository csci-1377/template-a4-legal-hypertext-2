---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Drinking, Drugs, and Swearing
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1891
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hamer v. Sidway
Status: Annotated
Date: 1891-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - William Story Senior, uncle of Junior, promises to give him $5k if he promises not to drink, smoke, swear, or gamble
> - Junior abstains until 21, only has to until 18. 
> - Junior writes he has fulfilled, uncle agrees but says wants to keep until sure “capable of being responsible”
> - Uncle dies, estate refuses to provide money

- Issue: Was there a contract?

> [!note]+ Holding (Parker): Yes, junior should get the money
> - Because he did something he didn’t have a legal obligation to do (abstain after 18)
> - This is consideration even though there isn’t tangible benefit to the uncle
