---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Fracking Capture
Takeaway: Only trespass if material crosses onto land
Tags:
  - Trespass
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 2020
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Briggs v. Southwestern Energy Production Company
Status: Annotated
Date: 2020-01-01
Jurisdiction: Pennsylvania
---
> [!note]+ Facts
> - SEPC fracks near Briggs land
> - Briggs sues, but doesn’t specifically assert that their material is entering Briggs land
> - Fracking sends little ceramic pellets into cracks into the rock
> - They both want the same rule of capture to hold, but think the other is braking it
> - Really its a factual disagreement

> [!note]+ Procedural History and Posture
> - Superior court says it deoends on some natural/artificial flow distinction

- Issue: Can you use a pump to get oil from under another’s property?

> [!note]+ Holding (Saylor): Yes, so long as no material goes onto their land
> - Summary- You can use pumps, and there is no natural/artificial flow distinction to say fracking is trespass, so long as no material goes into their land
> - Disposition- Reversed

> [!note]+ Concurrence/Dissent (Dougherty): 
> - ?

> [!note]+ Thoughts and Questions
> - What about the slick___?
> - How should conflicts between first posession and accession be traded?
> - How is slant drilling different from hydraulic fracking?
> - Should this be a nuisance instead of a trespass claim?
