---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Unequal School District Funding
Takeaway: Wealth is not a suspect classification
Tags:
  - EPC
  - RBT
Category:
  - Con Law
Abstract: ""
Page: 1329
Type: Case
Rating: "***"
Year: 1973
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: San Antonio Independent School District v. Rodriguez
Status: Annotated
Date: 1973-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Texas school districts are funded in part by state and in part by localities
> - Districts with lower property values get way less funding.

- Issue: Does disparate funding deny EPC?

> [!note]+ Holding (Powell): No.
> - Not like our precedents
>     - There, the class was indigent
>     - No “absolute” bar to access here
>         - Relative differences aren’t prohibited.
> 
> > The equal protection clause does not require absolute equality or precisely equal advantages.
> 
> > The Constitution does not provide remedies to every social and economic ill.
> 
> - Is wealth a suspect class?
>     - No, we can’t really draw out the class clearly
>         - Some poor people don’t live in these districts
>         - This isn’t distinguishing on the basis of poverty (everyone is going to school)
>     - A suspect class is one that deserves “<u>extraordinary protection from the majoritarian political process</u>” because of 
>         - Its disabilities
>         - A history of unequal treatment
>         - Political powerlessness
>     - Also, every state does this! (SoP, Federalism)
> - Is education a fundamental right?
>     - 
> - Disposition: 

> [!note]+ Dissent (Marshall): Yes (balancing test)
> - We should be using a spectrum of standards
> - Test: how much to constitutional guaranteed rights depend on interest not mentioned?





















