---
base: "[[Test.base]]"
In-Text Citation: (Arpaly, 2002)
Priority: Recommended
Authors: Arpaly, Nomy
Title: Moral Worth
Zotero URI: http://zotero.org/users/4316906/items/QK9ZM3J5
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: |-
  Abstract
              This chapter proposes a quality-of-will based theory of moral worth. It argues that people are praiseworthy for acts of good will and blameworthy for acts of ill will or absence of good will, and the amount of praise or blame they deserve varies with the depth of their motivation or extent of their indifference. Since good will is wanting to perform actions that have whatever property it is that makes action right, a full account of moral worth is impossible until the property that makes actions right is known.
Type: Book Section
Rating: "****"
URL: https://academic.oup.com/book/12806/chapter/163001304
Full Citation: "Arpaly, N. (2002) ‘Moral Worth’, in Arpaly, N., Unprincipled Virtue. 1st edn. Oxford University PressNew York, pp. 67–116. Available at: https://doi.org/10.1093/0195152042.003.0003."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2002
---
Moral worth: when we praise or condemn some agents for actions

> [!note]+ Right Reasons
> - Quality-of-will based theory
> - Moral Responsiveness de re
> - Reasons for action must correspond with right-making features
> - Good will is responsiveness to moral reasons
> - Deficiency is lack of responsiveness
> - Bad will is responsiveness to wrong-making reasons

> [!note]+ Concern
> - Possible for those who understand morality equally well to care about it to different degrees (un-Kantian)
> - More praiseworthy the deeper the concern
> - Deficiency of perception and of motivation are hard to tell apart

> [!note]+ Character
> - Here praiseworthiness of action does not depend on character
> - Frequency or predictability of action should not matter to moral worth, unless taken to be a sign of *deep moral concern*
> - We can only ever get *evidence* of character, but what we are looking for is underlying virtue
> - If by character we meen depth of concern, not reliability or predictability, then it matters for moral worth
> - Connection between depth of concern and moral worth is an important truth aimed at by character

> [!note]+ Why are sexists etc. bad and not just confused?
> - They are excused to the extent to which their beliefs are epistemically rational
> - Usually not “honest mistakes” but motivated irrationality
> - Prejudice is when wrong beliefs are resistant to change
> - Why? nothing vicious about irrationality
>     - “I hate him because he is disgusting”
>     - No, you find him disgusting because you hate him
> - If you “simply” believe women are weaker than men, then you have no reason to systematically prevent them from doing anything, you just subject to a test.
> - This often reveals bad faith (inquisitors not “freeing” their friends to the afterlife)
> - The belief itself isn’t blameworthy, it just plays a superficial role. The primary thing is the sinister desire
> - Sometimes no sinister motive, and blameworthiness instead located in the lack of concern for morally relevant factors
> - If truth matters to you, it will take you longer to accept gossip, even if you want to

> [!note]+ Huckleberry Finn is praiseworthy for the action
> - From nonconscious awareness
> - Acting for morally significant reasons
> - He has the right reasons, even if he doesn’t *know* they are right
> - He would be *better* if he could reason about morals better, but this doesn’t mean he isn’t praiseworthy