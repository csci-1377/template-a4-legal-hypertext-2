---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Exchanging Terms
Takeaway: ""
Tags:
  - Major Questions Doctrine
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "****"
Year: 2015
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: King v. Burwell
Status: Annotated
Date: 2015-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - ACA has four components
>     - Guaranteed issue- no denial
>     - Community rating- no raising rates for preexisting conditions
>     - Coverage requirement- you have to buy in
>     - Tax credits- we’ll help you pay for it
> - Law talks about two kinds of exchanges (state created v federally created)
> - In Section 36B, tax credits go to exchanges “established by the state”
> - IRS rule says tax credits go to participants in both state and federal exchanges
> - Petitioners live in Virginia, with Federal Exchange, don’t want to purchase insurance (and don’t want to get the tax credits to help them do it…)

- Issue: Is a federal exchange an exchange “established by the State” under 36B?

> [!note]+ Holding (Roberts): Yes, it is
> - Taken by itself its clear
> - Look at words in their context. Then its ambiguous
> - Given that its ambiguous, we have to look to broader structure
> - Reductio: if it wasn’t the whole thing would collapse (death spiral)
> - Congress “would not have…” rather than best construction
> - Look finally to the purpose of the statute (improve heathcare markets, not destroy them.)

> [!note]+ Dissent (Scalia): 
> > Words no longer have meaning if…
> 
> - This makes nonsense of other parts of the act
> - Laws often include unusual or mismatched provisions
> - Pointing them out just proves statutes are flawed, not that they mean something else.
> - Also, there is a reason to do this (incentivize states to establish exchanges!)
> - Double double trap: if you really thought this other interpretation would make it collapse, then you should think that would make states adopt exchanges!
> - Substantive vs technical mistake: we only want to correct the latter.

> [!note]+ MQD Stuff
> - Quotes Brown & Williamson about hesitating to conclude implicit delegation
> - “This is one of those cases” where we dont’ assume delegation (because IRS has no expertise in crafting healthcare policy)
> - No assertion that the statute was clear, admitting it wasn’t, so embracing limit on Chevron’s domain

> [!note]+ Thoughts and Questions
> - No legislative history or express purposivism. Is this all textualism?
> - There is a tension between the holism and laser focus requirements of textualism
> - Looking at purposes too broadly is just not believing bad law is law
