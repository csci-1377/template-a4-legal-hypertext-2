---

---
> [!note]+ Running of SOL + Collapse to a single wrong 
> - Personal property SOL is 3-5 years, real property SOL is 5-40 years
> - Time-of-Conversion: very strict [[Songbyrd]] 
> - Discovery: when party discovers, or should have discovered, item missing (most common)
> - Demand: When they actually ask for it back (good faith purchase: [[Songbyrd]])

> [!note]+ Adjectival requirements [[Anderson-Tully]] 
> - Exclusive 
>     - (intention to exclude)
> - Open and notorious
>     - Give notice to O, make sure O is slothful, A active
>     - “unfurl his flag so the actual owner may see, if he will, that an enemy has invaded…”
> - Actual
>     - Depends on land context (less required for wild areas)
>     - Recreational use isn’t enough
> - Hostile/Adverse
>     - permission defeats claim
>     - If you have permission at first, then overstay, the clock starts when you overstay
> - Continuous/Uninterrupted
>     - But ok if taking a season off is customary
>     - Ensures an active A and slothful O
> - Peaceful (unusual, just Anderson-Tully)
> - Under Claim of Right…

> [!note]+ Mental State “Claim of Right/Ownership” 
> - Need Good Faith (Iowa Rule) [[Carpenter]] 
> - Need Bad Faith (Maine Rule)
> - Subjective Intent is Irrelevant (Connecticut Rule)
> - But, it turns out courts usually paint successful AP as having a good faith claim, even without explicit requirement
> - New York recently requires “reasonable basis to believe true owner” kind of objectified intent