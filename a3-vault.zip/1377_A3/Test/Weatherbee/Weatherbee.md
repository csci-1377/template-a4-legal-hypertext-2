---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Barrel Hoops
Takeaway: Relative change in value to determine ownership from accession
Tags:
  - Accession
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1871
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Weatherbee v. Green
Status: Annotated
Date: 1871-01-01
Jurisdiction: Michigain
---
> [!note]+ Facts
> - Green owns trees, Weatherbee cuts down thinking he has permission
> - Weatherbee makes barrel hoops from them, multiplying value by 28
> - Green claims replevin

> [!note]+ Procedural History and Posture
> - Jury ginds for plaintiff

- Issue: What is the limiting principle on replevin claims when property has been improved? (when does accession apply?)

> [!note]+ Holding (Cooley): It’s about relative value (owner v. improver), not identity change
> - Old standard was “conversion to something substantially different” (Roman philosophy)
> - It’s impossible to get to a satisfactory test on this
> - It does matter whether defendent acted in good faith
> - And defendant had a right to show harvest in good faith
> - Principles
>     - Mental State of Improver
>     - Degree of Transformation (*some* required)
>     - Relative Value

> [!note]+ Thoughts and Questions
> - Why does degree of transformation matter to us? Is recognizability of property psychologically important?


s










[[Elements]]

[[Policy]]

[[Against the Government]]

[[Note Tacking allows adding of AP period across different true owners]]