---

---
- England: *nullum tempus occurrit regi *(no time runs against the king: busy for public good, can’t be bothered)
- US Federal: Imported over, so up to Congress to decide what to do about squatters (generally better than AP would)
    - If AP were allowed, national parks would be at risk
- US States: Some keep rule, others just have longer SOL, others just abolished