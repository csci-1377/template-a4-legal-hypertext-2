---
base: "[[Test.base]]"
In-Text Citation: (Lawrence, no date)
Priority: Essential
Court: Supreme
Authors: Lawrence
Title: Right to Liberty Protects Sodomy
Zotero URI: https://zotero.org/bmcanally21/items/6ED3R329
Takeaway: 14A DPC RBT protects intimate private conduct (including homosexual conduct) between consenting adults. Majority morality is not a legitimate state interest.
Tags:
  - DPC
  - EPC
  - SDP
Category:
  - Crim
Abstract: ""
Page: 157.1
Type: Case
Rating: "****"
Year: 2003
Full Citation: Lawrence (no date) ‘Lawrence v Texas.pdf’.
Last edited: 2026-02-15T22:06:00
Full: Lawrence v. Texas
Status: Annotated
Date: 2003-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Police dispatched based on false report of weapons disturbance
> - They find two men having sex

> [!note]+ Procedural History and Posture
> - Lawrence and partner charged and convicted of “deviate sexual intercourse” with <u>same sex </u>partner
> - Deviate includes anal, oral, and penetration with objects
> - Fined $200, appealed, Texas appeals affirms

- Issue: Do adults have the liberty under DPC to engage in “private conduct”?

> [!note]+ Holding (Kennedy): Yes
> - Level of Generality: Privacy is an individual right, not just about marriage relation
>     - Bowers underestimated extent of liberty at stake
>     - About freedom within gay relationships, not just sex
> - “History and tradition are the starting point but not in all cases the ending point of the substantive due process inquiry.”
>     - Refutes historical premises about “anti-gay” laws (not until 1970s singled out, only nine states have done so)
>     - Reliance on European Court of Human Rights precedent
>     - **Stare decisis** is not “an inexorable command”
> - Rational Basis Test, but fails?!
>     - Majority cannot use the power of the state to enforce their moral views on the whole of society through criminal law
> - Discusses stigma and collateral consequences of conviction
> 
> > As the Constitution endures, persons in every generation can invoke its principles in their own search for greater freedom.
> 
> - Limited: not involve minors, coersion, public conduct, prostitution, or gay marriage
> - Disposition: Reversed

> [!note]+ Dissent (Scalia): No
> - This “decrees the end of all morals legislation
> - These judgments are to be made “by the people”