---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Vetoing the Veto
Takeaway: No legislative vetoes of agency decisions
Tags:
  - Nondelegation Doctrine
Category:
  - LegReg
  - Con Law
Abstract: ""
Page: 624
Type: Case
Rating: "****"
Year: 1983
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Immigration and Naturalization Service v. Chada
Status: Annotated
Date: 1983-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Chada is deportable under immigration law
> - AG suspends his deportation in his discretion
> - House vetoes the suspension

- Issue: Are legislative vetoes constitutional?

> [!note]+ Holding (Burger): No
> - There’s one way to legislate: bicameralism and presentment
>     - (But is a veto really legislating?)
> - This is legislation because
>     1. It is action by the legislature, presumed legislative
>     2. It changes the outcome
>     3. It replaces what would otherwise be legislation (otherwise, they would have to pass a law to change the outcome)
> - Objections/replies: 
> - Disposition: 

> [!note]+ Concurrence (Powell): This one isn’t, but maybe some are
> - This one is unconstitutional because it’s usurping the judicial role
> - Also no proceedural constraints or safeguards
> - We can’t just assume something is legislative if Congress does it.

> [!note]+ Dissent (White): Yes, otherwise we’re screwed
> > Without the legislative veto, Congress is faced with a Hobson’s choice (illusory free choice with only one real option)
> 
> - Refrain from delegating, or 
> - Abdicate control even more
> - Legislative veto has not been a sword, but a shield
