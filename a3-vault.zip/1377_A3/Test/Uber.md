---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Hyperlink Agreement
Takeaway: Offeree bound by terms a reasonably prudent reader would have known about
Tags:
  - Binding Arbitration
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 2017
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Meyer v. Uber Technologies, Inc.
Status: Annotated
Date: 2017-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - Client downloads Uber, rides 10 times, wants to sue for price fixing (per se violation of anti-trust law)
> - Discovers binding arbitration agreement

- Issue: Was the arbitration clause valid?

> [!note]+ Holding (Chin): Yes, reasonably clear and conspicuous
> - **Rule: **A smartphone app user has reasonably conspicuous notice of the app’s terms of service if a reasonably prudent user would have known about the terms and the conduct that would be required to assent to them.
> - Uber provided reasonably clear route to additional information, that it was available only by hyperlink doesn’t preclude