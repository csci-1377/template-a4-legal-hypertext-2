---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Murderous Inheretence
Takeaway: ""
Tags: []
Category:
  - LegReg
Abstract: Riggs v. Palmer
Type: Case
Rating: "*****"
Year: 1889
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Riggs v. Palmer
Status: Annotated
Date: 1889-01-01
Year*: 1889
Jurisdiction: New York
---
> [!note]+ Parties
> - Elmer Palmer, grandson
> - Mrs. Riggs and Preston, daughters

> [!note]+ Facts
> - Elmer Palmer poisons his grandfather Francis at 16, knowing he currently benefits and his will and that it might be changed.
> - He goes to prison, Francis’s daughters sue, arguing they should receive the inheretance.
> - Law says will shall be enforced except in cases of fraud, deceit, etc (not murder)

> [!note]+ Strongest P Argument
> No one should profit by their own wrong

> [!note]+ Strongest D Argument
> The law doesn’t make an exception for murderers not to inheret.

> [!note]+ Holding (Earl)
> - Could not have been their intention to let murderers inheret
> - Canon 1- interpret according to counterfactual legislative intent
> - Canon 2- No one should profit by his own wrong
> - So Elmer shouldn’t inheret

> [!note]+ Dissent (Gray)
> - If this were a matter of equity or conscience, then sure, but we are bound by the law. 
> - Moral and policy arguments are reasons to change the law, not about what it is.
> - The legislature explicitly says wills shall not be revoked or altered in any way other than what they describe.
> - An intent to revoke a will isn’t sufficient, they have to change the will. And they didn’t.
> 
> > The court is asked to make another will for the testator

> [!note]+ Notes/Questions
> - Another Canon- Statutes ought to be narrowly construed
>     - Might just be judicial impulse to protect against perceived legislative encroachment
> - Was there really any intention either way?
>     - Can we appeal to coherence or continuity in its absence?
>     - How do we choose among competing values if we aren’t appealing to legislative instructions?