---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Stopping the Train
Takeaway: First time political necessity defense can go to the jury
Tags:
  - Necessity
Category:
  - Crim
Abstract: ""
Page: 596
Type: Case
Rating: "*****"
Year: 2020
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State ex rel. Haskell v. Spokane County District Court
Status: Completed
Date: 2020-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Reverend George Taylor refuses to leave railroad tracks after law enforcement direction in protest of oil and coal delivery
> - Planned when no trains scheduled, notified BNSF railway
> - No trespassing signs were posted, knew private and without permission
> - All trains were stopped, no one in danger of being hurt
> - Even of those 24 protesters that engaged in civil disobedience, only three remained (1 in 8)
> - Charged with second degree trespass and delaying a train by less than an hour, both misdemeanors

> [!note]+ Procedural History and Posture
> - Expert Testimony:
>     - Dr. Running- professor of ecology, shared Nobel Peace Price
>         1. Greenhouse gasses increasing last 50
>         2. This has caused temp to rise, accelerated last 20
>         3. Reduction in emissionsis necessary to stabilize the global climate.
>     - Professor Hastings- professor of conflict resolution
>         - Nonviolent civil resistance is essential to combatting climate chnage. 
>     - Fred Millar- international analyst in nuclear waste storage
>         - Harm from crude oil train derailments, spills, or explosions is “imminent” and “grave”
> 
> > [!note]+ Taylor
> > - Already does many alternatives
> >     - Environmental education
> >     - Safer Spokane Initiative
> >     - Sierra Club Member
> >     - Voted for green candidates
> >     - Letters to US Senators and representatives
> >     - Called, sent emails, visited government offices
> >     - Peadefully expressed concerns through political process
> > - Danger to the public through transport far greater than danger of trespassing
> >     - Trains were idling, knew he was present
> 
> - District court granted motion allowing necessity defense at trial
> - Superior court reversed district court ruling, barring defense
> - Petition to Court of Appeals to reverse superior court

- Issue: Can Taylor assert necessity defense for civil disobedience violating constitutional laws?

> [!note]+ Holding (Lawrence-Berry): No
> - D must show by preponderance:
>     1. Reasonably believed the commission of the crime was necessary to avoid or minimize harm,
>     2. The harm sought to be avoided was greater than the harm resulting from a violation of the law
>     3. The threatened harm was not brought about by the defendant
>     4. No reasonable legal alternative existed.
> - Schoon court (9th Cir.) held necessity never available for indirect civil disobedience.
> 
> > There are always reasonable alternatives to disobeying constitutional laws.
> 
> - Proposed Alternatives
>     - Protest on public property
>     - Educating the public
>     - Petitioning elected officials
> - Never intended to excuse criminal activity
> - Disposition: Affirmed

> [!note]+ Dissent (Fearing): Yes
> - Call for intervetnion in inexorable increase in carbon emissions and greenhouse gases that presagea collapse of the planet’s ecosystem and human society
> 
> > seeks to prevent a conflagration resulting from a railroad oil tanker car derailing and to avert the spilling and spewing of grimy coal dust from railroad coal cars while traversing downtown Spokane. 
> 
> > The law excuses an accused’s violation of a discrete law when his or her action promotes a greater good for society.
> 
> - Legislature has taken no action altering common law defense
> - D must show
>     1. The accused acted to avoid a grave harm
>     2. The accused did not create the harm by his own conduct
>     3. The harm sought to be avoided was greater than that committed
>         1. Harms perceived far outsead those created by trespass
>     4. The accused lacked adequate legal means to avoid the harm.
>         2. Jury could conclude that this belief was objectively reasonable even with purely subjective evidence
>         3. Evidence of many attempts to achieve goal
>         4. Presented evidence of need for effective civil disobedience.
>         5. Prosletyzing government officials?
>             1. Assuming all persons have equal access to influence policy
>             2. Money buys access to power
>             3. Rev Taylor’s congresswoman refused to respond.
>         6. An ineffective method is not a reasonable alternative (Sisyphus)
> - If state’s arg works, always a nominal, abstract alternative
>     - So long as feedback forms remain on government websites, this ruling could abrogate the necessity defense.
> - This is for the jury, not judges
>     - Judges should be the last people to decide viability of civil disobedience in necessity defense.
>     - A judge benefits from the status quo, annoyed by the demonstrator.
> - Political Dissent are crucial to the US
> - Indirect and direct distinction is indefensible
>     - Black student protesters Trespassing at the Greensboro F.W. Woolworth segregated lunch counter
> - Very few people violate the criminal law out of conscience. The burden of a not-guilty verdict, even when a defense is available, is enormous, both monetary and social
> - Not one’s own judge. Submits case to the conscience of the community, who determine whether he chose well.
> - These are the voices that are most unheard.

> [!note]+ Supreme Court
> - “there may be alternatives in the abstract [but] it is ultimately a question of fact for the ‘fact finder’ to take into consideration, when determining whether the ultimate course of action was ‘reasonably necessary.’ 
> - An alternative that has repeatedly failed when attempted is not a reasonable alternative… A reasonable alternative must be effective
>     - “need not demonstrate exhaustion of every remedy”
>     - The alternative must be *reasonable*, depending on *specific facts* of the case.
>         - All three divisions of Court of appeals have held this = effective
>         - One: *Ward*- evidence of failed attempts creates a question of fact for the jury
>         - Two: State v Parker- failed because did not show “he had actually tried the alternative or had no time to try it, or that a history of futile attempts revealed the illusionary benefits of the alter- native.
>         - Three: State v Jeffrey- Called police, only because had not yet proven ineffective that held to defense unavailable.
> - Standard of review: de novo, most strongly in favor of the defense, not to weigh for yourself
>     - Challenge to sufficiency of evidence ‘‘admits the truth thereof and all inferences
> that can reasonably be drawn therefrom.’’
> *State v. Cole*, 74 Wash. App. 571, 578, 874
> P.2d 878 (1994)
>     - requires the trial and appellate courts to interpret the evidence most favorably for the defendant.’ 
> - Sixth Amendment of US Constitution and A1 S22 od Washington guarantees right to trial by jury and to defend against criminal allegations.
> 
> > [!note]+ D must show by preponderance
> > 1. [the defendant] reasonably believed the commission of the crime was necessary to avoid or minimize a harm, 
> > 2. The harm sought to be avoided was greater than the harm resulting from a violation of the law
> >     1. No need to show actuall minimized or avoided
> > 3. The threatened harm was not brought about by the defendant
> > 4. No reasonable legal alternative existed.

> [!note]+ Oral Arguments
> > [!note]+ May it please the court. I could begin…
> > - Most frogs will remain in water, slowly heated, until they boil alive. 
> > - How our collective situation is not unlike these frogs, except that we cannot jump from the pot, because there is nowhere else to go.
> > - I could begin by detailing the testimony of Dr. Running, professor of ecology, and winner of the Nobel Peace Price
> >     1. Greenhouse gasses increasing last 50
> >     2. This has caused temp to rise, accelerated last 20
> >     3. Reduction in emissionsis necessary to stabilize the global climate.
> > - I could tell you all the ways that Reverend Taylor has tried to stop this “inexorable increase in carbon emissions and greenhouse gases that presagea collapse of the planet’s ecosystem and human society”
> >     - Environmental education
> >     - Safer Spokane Initiative
> >     - Sierra Club Member
> >     - Voted for green candidates
> >     - Letters to US Senators and representatives
> >     - Called, sent emails, visited government offices
> >     - Peacefully expressed concerns through political process
> > - I could tell you how none of these have been effective, even in the relatively smaller task of preventing “a conflagration resulting from a railroad oil tanker car derailing and to avert the spilling and spewing of grimy coal dust from railroad coal cars while traversing his hometown of Spokane”, 
> > - I could try to convince you how this left Reverend Taylor with no reasonable alternative but to plan a peaceful protest on the BNSF railway tracks, with advance warning to the corporation delaying trains for less than an hour. 
> > - But I should not need to do any of these things, because the necessity defense is not a matter for this court to decide. 
> 
> > [!note]+ The question before this court is whether Reverend Taylor has a right to defend his actions before a jury of his peers.
> > - Was there evidence presented?
> >     - Professor Hastings- professor of conflict resolution
> >         - Nonviolent civil resistance is essential to combatting climate chnage. 
> >     - Fred Millar- international analyst in nuclear waste storage
> >         - Harm from crude oil train derailments, spills, or explosions is “imminent” and “grave”
> > > [!note]+ D’s own testimony of alternatives
> > > - Environmental education
> > > - Safer Spokane Initiative
> > > - Sierra Club Member
> > > - Voted for green candidates
> > > - Letters to US Senators and representatives
> > > - Called, sent emails, visited government offices
> > > - Peacefully expressed concerns through political process
> > 
> >     - If state’s arg works, always a nominal, abstract alternative
> >         - So long as feedback forms remain on government websites, this ruling could abrogate the necessity defense.
> >     - This is for the jury, not judges
> >         - Judges should be the last people to decide viability of civil disobedience in necessity defense.
> 
> > [!note]+ Reasonable Alternative?
> > An alternative that has repeatedly failed when attempted is not a reasonable alternative… A reasonable alternative must be effective
> > 
> > - “need not demonstrate exhaustion of every remedy”
> > - The alternative must be *reasonable*, depending on *specific facts* of the case.
> >     - All three divisions of Court of appeals have held this = effective
> >     - One: *Ward*- evidence of failed attempts creates a question of fact for the jury
> >     - Two: State v Parker- failed because did not show “he had actually tried the alternative or had no time to try it, or that a history of futile attempts revealed the illusionary benefits of the alter- native.
> >     - Three: State v Jeffrey- Called police, only because had not yet proven ineffective that held to defense unavailable.
> 
> > [!note]+ Standard of review: de novo, most strongly in favor of the defense, not to weigh for yourself
> > - Challenge to sufficiency of evidence ‘‘admits the truth thereof and all inferences
> > that can reasonably be drawn therefrom.’’
> > *State v. Cole*, 74 Wash. App. 571, 578, 874
> > P.2d 878 (1994)
> > - requires the trial and appellate courts to interpret the evidence most favorably for the defendant.’ 
> > - Sixth Amendment of US Constitution and A1 S22 od Washington guarantees right to trial by jury and to defend against criminal allegations.
> 
> - State’s case hangs on the claim that there “are always reasonable alternatives to disobeying constitutional laws”
> 
> > [!note]+ Overflow of Protesters?
> > - Of the thousands affected in Spokane, only 24 originally on the tracks
> > - Of those 24, only three stayed after warnings that they would be arrested.
> > - Very few people violate the criminal law out of conscience. The burden of a not-guilty verdict, even when a defense is available, is enormous, both monetary and social
> 
> > [!note]+ Nullification?
> > - No more of a risk here than other defenses.
> 
> > [!note]+ One’s Own Judge
> > - Not one’s own judge. Submits case to the conscience of the community, who determine whether he chose well.
> 
> > [!note]+ Indirect and direct distinction is indefensible
> > - Black student protesters Trespassing at the Greensboro F.W. Woolworth segregated lunch counter
> 
> > [!note]+ Posture
> > - District court granted motion allowing necessity defense at trial
> > - Superior court reversed district court ruling, barring defense
> > - Petition to Court of Appeals to reverse superior court
> > - Appeals affirms, granted review by Supreme Court
> 
> > [!note]+ Elements: D must show by preponderance
> > 1. [the defendant] reasonably believed the commission of the crime was necessary to avoid or minimize a harm
> >     1. Professor Hastings- professor of conflict resolution
> >         - Nonviolent civil resistance is essential to combatting climate chnage. 
> >     - Fred Millar- international analyst in nuclear waste storage
> >         - Harm from crude oil train derailments, spills, or explosions is “imminent” and “grave”
> > 2. The harm sought to be avoided was greater than the harm resulting from a violation of the law
> >     2. No need to show actuall minimized or avoided
> > 3. The threatened harm was not brought about by the defendant
> > 4. No reasonable legal alternative existed.
> 





















