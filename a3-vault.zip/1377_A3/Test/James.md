---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Hopi Land Rights
Takeaway: Find law through custom before finding facts
Tags:
  - Custom
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1999
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Smith v. James
Status: Annotated
Date: 1999-01-01
Jurisdiction: Hopi Tribe
---
> [!note]+ Facts
> - Smith is given property by father
> - James argues they get the land by custom since they cared for it after Smith left

> [!note]+ Procedural History and Posture
> - Complex, not important?

- Issue: Who gets the land?

> [!note]+ Holding (Sekaquaptewa): 
> - You need to find law (custom) before eliciting facts, so we don’t know
> - Community has a stake in what the custom is, so they need an opportunity to offer witnesses
> - Disposition: Reversed
