---
base: "[[Test.base]]"
In-Text Citation: (Richards, 2023)
Priority: Essential
Authors: Richards, Charlie
Title: Rescuing the Socially Deprived (CELPA)
Zotero URI: http://zotero.org/users/4316906/items/WX4JXTAL
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Richards, C. (2023) ‘Rescuing the Socially Deprived (CELPA)’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
> [!note]+ Intro
> - People need relationships to live decently
> - Harms in this area are large and non-reversible
> - People have sufficientarian social rights, which are
>     - Directed
>     - Enforceable
>     - About outcomes, not opportunites

> [!note]+ Questions
> - Is the duty conditional on others fulfilling theirs? Only to do your part or as much as is reasonable, assuming others aren’t doing theirs? Or does it disappear if others don’t do theirs, person won’t be saved from deprivation?
> - What does this actually look like? everyone do social labor or create a system where everyone gets it?
> - Assume the Gertrauds do not wish to be socially deprived. What if they don’t claim to want to be?
> - What about people who say they don’t want to interact? (Hikikomori, 700,000, average 31)
> 














