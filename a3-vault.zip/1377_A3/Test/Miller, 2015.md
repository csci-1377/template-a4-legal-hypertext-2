---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/02691728.2014.971908
In-Text Citation: (Miller, 2015)
Priority: Essential
Authors: Miller, Seumas
Title: Joint Epistemic Action and Collective Moral Responsibility
Zotero URI: http://zotero.org/users/4316906/items/TM3IQRC6
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: In this paper, I explore the relationship between joint epistemic action and collective moral responsibility. Here, we need to distinguish between the genus, joint action, and an important species of joint action which I introduced in some earlier work, namely, joint epistemic action. In the case of the latter, but not necessarily the former, participating agents have epistemic goals, e.g. the acquisition of knowledge. The notion of joint action per se is a familiar one in the philosophical literature, albeit I have provided, and defended, a particular analysis of it. However, the notion of joint epistemic action is a novel one. Nevertheless, I argue that it can be given the same kind of analysis as joint action which is not epistemic in character. The other key notion in play in this paper is that of collective moral responsibility. Over the last decade or two this notion has been receiving a good deal of attention in the philosophical literature. Two influential kinds of theory are non-individualist corporatist accounts and aggregate individualist accounts. I have argued against both of these and provided and defended a relational individualist account which I make use of in this paper according to which collective moral responsibility is to be understood as joint moral responsibility.
Type: Journal Article
Rating: "***"
URL: https://doi.org/10.1080/02691728.2014.971908
Full Citation: "Miller, S. (2015) ‘Joint Epistemic Action and Collective Moral Responsibility’, Social Epistemology, 29(3), pp. 280–302. Available at: https://doi.org/10.1080/02691728.2014.971908."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2015
---
