---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/796508
In-Text Citation: (Hutchinson, 1987)
Priority: Recommended
Authors: Hutchinson, Allan C.
Title: Indiana Dworkin and Law's Empire
Zotero URI: http://zotero.org/users/4316906/items/9U9W7QWZ
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/796508
Full Citation: "Hutchinson, A.C. (1987) ‘Indiana Dworkin and Law’s Empire’, The Yale Law Journal. Edited by R. Dworkin, 96(3), pp. 637–665. Available at: https://doi.org/10.2307/796508."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1987
---
