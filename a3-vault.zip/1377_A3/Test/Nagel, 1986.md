---
base: "[[Test.base]]"
In-Text Citation: (Nagel, 1986)
Priority: Essential
Authors: Nagel, Thomas
Title: Value
Zotero URI: http://zotero.org/users/4316906/items/45SRZBVV
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Book Section
Rating: "***"
Full Citation: Nagel, T. (1986) ‘Value’, in The View from Nowhere.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1986
---
> [!note]+ Intro
> - Objectivity is the central problem of ethics, both in theory and practice.
> - Nagel defends objectivity by showing how an objective standpoint alterns and constrains our motives.
> - Objectivity in theoretical reason: when we form a conception of reality that includes ourselves as components
> - In practical reason: when we take up a new, comprehensive viewpoint after stepping back and including our former perspective in what is to be understood.
> - Normative realism: propositions give us reasons independently of what we perceive, desire, etc. **This is compatible with constructivism.**

> [!note]+ Antirealism arguments
> - Nothing has objective value, because when you completely detach from all interests, then nothing remains (objective nihilism)
>     - Response: but we have as data the appearance of value to individuals. To understand what the world is like from the outside, we have to approach it from within (this refutes objectivity, right?)
> - Wide cultural variation and psychological influences makes objectivity implausible.
>     - Even where there is truth, it isn’t easy to discover. The process of ethical thought is one of motivational discovery.

> [!note]+ Objective badness of pain
> - Agent relative
>     - There are reasons for wanting your pain to stop if you have it.
>     - A headache deems like not just an unpleasant, but a bad thing
>     - Simplest explanation is that headaches are, in fact, bad.
>     - If you pursue pain or avoid pleasure, it is either instrumental or somehow deviant (so are dark reasons not reasons?)
>     - **But what about indifference?**
> - Agent neutral
>     - Used to claim that all reasons were neutral, since if something didn’t have motivational content when viewed objectively, then it was incompatible with a full recognition of personhood (no longer believes this)
>     - But if we limit ourselves to relative reasons, than we can’t say me wanting to avoid pain gives anyone else a reason to help me avoid it.

> [!note]+ Kinds of reasons
> - Objectivity
>     - Whether they can be understood indepentently of who has them (compatible with all other scales)
> - Neutrality
>     - (Agent) relative/personal
>     - (Agent) neutral/impersonal
> - Externaltiy
>     - Whether they are independent of the concerns of sentient beings
>     - Basically is x still important if *no one* cares?

> [!note]+ Quotes
> > If we can make judgments about how we should live even after stepping outside of ourselves, they will provide the material for moral theory (138). 
> > - **This doesn’t require objectivity, but rather intersubjectivity or perspectival flexibility.**
> 
> > We first form a conception of the world as centerless (140)
> 
> > The basic question of practical reason from which ethics begins is not "What shall I do?" but "What should this person do?" (141)
> > - **No, it is what should I do, but “I” can include many perspectives.**
> 
> > The only way to resist Humean subjectivism about desires and reasons for action is to seek a form of objectivity appropriate to the subject.
> > - Or reject the atomic conception of the individual
> 
> > ordinary process of deliberation, aimed at finding out what I should do, assumes the existence of an answer to this question [what is the right answer]
> > - I’m not sure that’s true. It really only needs to assume better and worse answers.
> 
> > The choice among normative hypotheses is difficult and there is no general method of making it, any more than there is a general method of selecting the most plausible objective account of the facts on the basis of the appearances. The only "method," here or elsewhere, is to try to generate hypotheses and then to consider which of them seems most reasonable, in light of everything else one is fairly confident of. Since we may assume that not every alternative has been thought of, the best we can hope for is a comparison among those available, not a firm solution.
> > - No, it’s to go engage with the reality and *test* your hypothesis!
> 
> > The value assigned to it [a value from the objective point of view] should be that which it overwhelmingly appears to have from the inside (161) 
> > - This is his missing premise

> [!note]+ Thoughts
> - He calls this standpoint detached, impersonal. Why not engaged and interpersonal?
> - He conflates the notion of outside the self and detachment. This seems like a very isolating epistemology.
> - There is no view from nowhere. There is deliberation among perspectives and the possibility of adopting perspectives that include the participants in the deliberation.
> - Perhaps reason is self-validating. Reasons are the source of normativity, and a ‘good’ reason has to be defined as one with the support of further reasons. So we are creating the normative world as we explore it.
> - He conflates pain and suffering














