---
base: "[[Test.base]]"
In-Text Citation: (Korsgaard, 1996)
Priority: Recommended
Authors: Korsgaard, Christine M.
Title: The Sources of Normativity
Zotero URI: http://zotero.org/users/4316906/items/2C5W2JJK
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: "Ethical concepts are, or purport to be, normative. They make claims on us: they command, oblige, recommend, or guide. Or at least when we invoke them, we make claims on one another; but where does their authority over us - or ours over one another - come from? Christine Korsgaard identifies four accounts of the source of normativity that have been advocated by modern moral philosophers: voluntarism, realism, reflective endorsement, and the appeal to autonomy. She traces their history, showing how each developed in response to the prior one and comparing their early versions with those on the contemporary philosophical scene. Kant's theory that normativity springs from our own autonomy emerges as a synthesis of the other three, and Korsgaard concludes with her own version of the Kantian account. Her discussion is followed by commentary from G. A. Cohen, Raymond Geuss, Thomas Nagel, and Bernard Williams, and a reply by Korsgaard."
Type: Book
URL: https://www.cambridge.org/core/books/sources-of-normativity/5A85034A6566FDFDE374073A015CBD2A
Full Citation: "Korsgaard, C.M. (1996) The Sources of Normativity. Cambridge: Cambridge University Press. Available at: https://doi.org/10.1017/CBO9780511554476."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1996
---
