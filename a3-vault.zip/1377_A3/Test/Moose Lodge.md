---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Whites Only Club
Takeaway: "State action test for 14A reach: (1) directly engaging (2) fosters or encourages (3) partner or joint venture"
Tags:
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1274
Type: Case
Rating: "**"
Year: 1972
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Moose Lodge No. 107 v. Irvis
Status: Annotated
Date: 1972-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Moose Lodge refuses to serve black guest.

- Issue: Does 14A capture club’s refusal?

> [!note]+ Holding (Rehnquist): No
> > Where the impetus for the discrimination is private, the State must have “significantly involved itself with invidious discrimination”
> 
> - State must either
>     1. Directly engage in discrimination
>     2. Fosters or encourages the activity
>     3. Is a “partner or even a joint venture in the club’s enterprise”

> [!note]+ Dissent (Brennan): Yes.
> - Pennsylvania is involved by offering liscense. Liscensing regulates a wide variety of moral conduct.
> - His test: “the mere efforts by the State, through legislation or otherwise, to authorize, encourage, or otherwise support racial discrimination…constitutes illegal state involvement in those pertinent private acts of discrimination that subsequently occur.





















