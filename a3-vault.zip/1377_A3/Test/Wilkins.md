---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Nickel and Dime Bags
Takeaway: When can’t conclude intent to distribute
Tags:
  - Drugs
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "**"
Year: 2010
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Wilkins
Status: Annotated
Date: 2010-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Police pull over dude with three bags of weed
> - 1.89 grams total worth $30
> - He also has $1,200 on him
> - D says $1k is to make bail in case he gets arrested

> [!note]+ Procedural History and Posture
> - Convicted for posession with intent to distribute

- Issue: Could reasonable jury have found, wrd, posession with intent to distribute?

> [!note]+ Holding (Hunter): No
> > “[T]he intent to sell or [deliver] may be inferred from…
> > (1) the packaging, labeling, and storage of the controlled substance, 
> > 
> > (2) the defendant's activities, 
> > 
> > (3) the quantity found, and
> > 
> > (4) the presence of cash or drug paraphernalia.
> 
> - Disposition: Reversed





















