---
base: "[[Test.base]]"
In-Text Citation: (Galanter, 1974)
Priority: Essential
Authors: Galanter, Marc
Title: 'WHY THE "HAVES" COME OUT AHEAD: SPECULATIONS ON THE LIMITS OF LEGAL CHANGE'
Zotero URI: http://zotero.org/users/4316906/items/NXMB4HED
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Journal Article
Rating: "*****"
Year: 1974
Full Citation: "Galanter, M. (1974) ‘WHY THE “HAVES” COME OUT AHEAD: SPECULATIONS ON THE LIMITS OF LEGAL CHANGE’, L. & SOC’Y REV., 95."
Last edited: 2026-02-15T22:06:00
Full: Galanter, 1974
Status: Annotated
Date: 1974-01-01
Year*: 1974
---
> [!note]+ Prep
> - Purpose- Understand a perspective on legal theory
> - Preview- Diagnose structural problems and suggest reform
> - Questions- What is a lawyer’s role in making change?
> - Prediction- Advocacy and impact litigation

> [!note]+ Summary
> Basically, the system is structured (necessarily) so that the advantages go to repeat players. Lawyers can make change by creating repeat players to represent one-shotters on large scale (class action, community organizing, etc)

> [!note]+ Structure


> [!note]+ Questions


> [!note]+ Thoughts


> [!note]+ Further Reading















