---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Exclusive Litigation Clauses
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1972
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: The Bremen v. Zapata Off-Shore Co.
Status: Annotated
Date: 1972-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Damage is done to a rig that was being towed by a German corp, with a contract provision saying all disputes were to be litigated in the London Court of Justice. Nevertheless, Pl brings suit in Florida (where rig was damaged).

- Issue: Are exclusive litigation clauses binding?

> [!note]+ Holding: Yes
> - If we don’t enforce, we frustrate the market between two sophisticated players
