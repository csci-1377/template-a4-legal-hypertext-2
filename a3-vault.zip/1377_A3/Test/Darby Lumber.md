---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: "Wage and Hour (And Child Labor Part 3: Success)"
Takeaway: Virtually no limit on commerce clause, 10th Amendment minimized (no more dual federalism)
Tags:
  - CC
  - NPC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 1941
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Darby Lumber Co
Status: Annotated
Date: 1941-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Darby Lumber Co refuses to comply with Fair Labor Standards Act: federal wage and hour law + no child labor
> - Regulators suspend transportation of Darby’s lumber
> - Darby sues, arguing that under [[Hammer]], no power to regulate benign goods in order to regulate how they are manufactured

- Issue: Can Congress regulate benign goods in interstate commerce? Can they regulate wages and hours?

> [!note]+ Holding (Stone): Yes and yes
> - Basically, no more of [[Ogden]]’s dual federalism: Overlap in powers is fine
>     - If there has been no federal regulation, state’s can regulate
>     - But federal regulation then preempts it, so long as…
> - Regulation extends to intrastate activities which so effect interstate commerce so as to make it “appropriate means to the attainment of a legitimate end” [[McCulloch]] (NPC)
>     - Even though some of the products never leave the states…
>     - This is sufficiently related to things that cross state lines
> - [[Hammer]] has not been followed, “long since been abandoned”
>     - Does not matter whether the goods themselves are immoral
>     - Also doesn’t matter whether the goods cross state lines
> - The 10th Amendment “states but a truism that all that  is retained which has not been surrendered”