---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Liquidating the Farm
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1954
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Wilt v. Waterfield
Status: Annotated
Date: 1954-01-01
Jurisdiction: Missouri
---
> [!note]+ Facts
> - Wilt contracts to sell farm to Waterfield for $19,000 with liquidated damages clause
>     - "If either party hereto fails or neglects to perform his part of this agreement, he shall forthwith pay and forfeit as liquidated damages to the other party a sum equal to ten percent of the agreed price of sale, except that if said agreed price is less than $2,000, said sum shall be $200".
> - Waterfield pays Wilt 1/10 of price
> - Wilt breaches and sells property to someone else
> - Waterfield sues Wilt for breach of real estate contract

> [!note]+ Procedural History and Posture
> - Jury waived, court found $7,000 principle and $700 interest 
> - Wilt appeals

- Issue: Are damages limited by the clause

> [!note]+ Holding (Dew): Nope.
> - The damages are disproportionate to the clause, so we just treat it like a penalty
> - “The plaintiffs were entitled to their bargain”
> - They get difference between remaining payment and market value ($7,000)
> - Disposition- Affirmed
