---
base: "[[Test.base]]"
In-Text Citation: (Merrill and Smith, 2010)
Priority: Recommended
Authors: |-
  Merrill, Thomas W.
  Smith, Henry E.
Title: Property
Zotero URI: http://zotero.org/users/4316906/items/SCTIQNPH
Takeaway: ""
Tags: []
Category:
  - Property
Abstract: ""
Full Citation: "Merrill, T.W. and Smith, H.E. (2010) Property. New York, NY: Oxford Univ. Press (The Oxford introductions to U.S. law)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2010
---
