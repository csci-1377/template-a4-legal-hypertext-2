---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Candle Combustion
Takeaway: Dangerous Proximity Test for Attempt
Tags:
  - Attempt
Category:
  - Crim
Abstract: ""
Page: 786
Type: Case
Rating: "**"
Year: 1901
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Commonwealth v. Peaslee
Status: Annotated
Date: 1901-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - D sets up combustibles with nearby candle
> - Offers to pay employee to go and light the candle, he refuses
> - Drives with employee to do it, then changes mind a quarter mile away.

> [!note]+ Procedural History and Posture
> - Indicted for attempt to burn building and injure insurers.

- Issue: Is D guilty of attempt?

> [!note]+ Holding (Holmes): No.
> - Core attempt is completed
> - But it is a question of degree, may vary with circumstances.
> - If indictment had alleged solicitation, would be guilty.
> - But it didn’t, so he isn’t (would then need to allege that he was just stopped from lighting it, or something similar).





















