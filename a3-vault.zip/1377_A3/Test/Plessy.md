---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Louisiana Railroad Cars
Takeaway: Separate but Equal
Tags:
  - EPC
  - SAD
Category:
  - Con Law
Abstract: ""
Page: 1244
Type: Case
Rating: "***"
Year: 1896
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Plessy v. Ferguson
Status: Annotated
Date: 1896-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Louisiana has a law banning segregation on streetcars
> - After Colfax massacre, white mob took over legislature
> - Switches from prohibiting to requiring segregation

- Issue: Does segregation legislation violate 13A or EPC?

> [!note]+ Holding (Brown): No.
> - 13 A violation?
> - EPC violation? Nope.
>     - Black and white riders are being treated equally: no one can ride in a car that belongs to someone else.
> > no tendency to destroy the legal equality of the two races.
> 
> > Object of the [14th] Amendment was undoubtedly to enforce the absolute equality of the two races before the law, but in the nature of things it could not have been intended to abolish distinctions based on color, or to enforce social, as distinguished from political equality.
> - Badge of inferiority?
>     - If so, “solely because the colored race chooses to put that construction upon it.”
> - Deprivation of property? 
>     - No, even if whiteness is property, Black people don’t have it, so can’t be deprived of it.
> - RBT applies. 
>     - Legislation is powerless to eradicate racial instincts or to abolish distinctions based on physical differences.

> [!note]+ Dissent (Harlan): No, the “constitution is color-blind”
> > There is no caste here. Our Constitution is color-blin, and neither knows nor tolerates classes among citizens. 
> 
> > The arbitrary separation of citizens… is a badge of servitude
> 
> - Also, unfair because Chinese people can ride on trains, so why not Black people?





















