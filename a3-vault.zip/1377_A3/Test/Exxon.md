---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Tuna and Oil
Takeaway: Permits adding diverse plaintiffs that don’t satisfy AIC for their claims
Tags:
  - Joinder
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 2005
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Exxon Mobil v. Allapattah Services
Status: Annotated
Date: 2005-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 9-Year-Old Girl sues Star-Kist for slicing finger on can
> - Family joins, suing for emotional distress and medical expenses
> - The parties were diverse but while Ortega’s damages were > $75,000 her family’s claims were not.
> - No rule 20 problem, question is about 1337 (it’s CNOF, so good)

> [!note]+ Procedural History and Posture
> - 1st Circuit says can’t join (opinion shared by 3rd, 8th, and 10th)
> - 11th Circuit says can

- Issue: Can you exercise supplemental jurisdiction over additional plaintiffs that don’t satisfy AIC in a diversity action?

> [!note]+ Holding (Kennedy): Yes to AIC (but no to adding nondiverse parties)
> > If the court has original jurisdiction over a single claim in the complaint, it has original jurisdiction over a "civil action" within the meaning of § 1367(a), even if the civil action over which it has jurisdiction comprises fewer claims than were included in the complaint. Once the court determines it has original jurisdiction over the civil action, it can turn to the question whether it has a constitutional and statutory basis for exercising supplemental jurisdiction over the other claims in the action.
> 
> - Reject Indivisibility Theory
> > all claims in the complaint must stand or fall as a single, indivisible "civil action”
> 
>     - If this were true, Gibbs wouldn’t work
>     - If claims were indivisible, we couldn’t only reject parts of complaint
>     - Also, you would have to assign different meanings to “civil action” in 1331 and 1332
> - Reject Contamination Theory
> > the inclusion of a claim or party falling outside the district court's original jurisdiction somehow contaminates every other claim in the complaint
> 
>     - Makes some sense regarding <u>complete diversity </u>(about if there’s a better court), but not AIC (about whether it’s worth the court’s time)
> - Removal analogy
>     - We can remove cases that have both federal and state law claims as a “civil action . . . of which the district courts of the United States have original jurisdiction”
>     - The language is so similar, we should have the same interpretation
> - No reason that we could add additional claims but not parties
> - OBJ: Why prevent Rule 19 plaintiffs (needed for just adjudication) explicitly but not Rule 20 (less important)?
>     - Basically this is wild, but not absurdity doctrine wild
>     - If that was a drafting error, not on us to fix
>     - Also, they might have wanted to prevent getting around complete diversity requirement by letting a Rule 19 plaintiff join later
> - OBJ: It’s ambiguous, so we should look to legislative history!
>     - No, it’s not
> - Disposition: 

> [!note]+ Dissent (Ginsburg): No to both
> - Basically, you created an end run around the aggregation rules (adding up claims to get to AIC)