---
In-Text Citation: ""
Authors: ""
Title: ""
Takeaway: ""
Tags: []
Category: []
Abstract: ""
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
---
> [!note]+ Before Reading
> - Purpose:
> - Preview:
> - Questions:
> - Prediction:

> [!note]+ Summary
> - (start from memory)

> [!note]+ Structure


> [!note]+ Questions


> [!note]+ Thoughts


> [!note]+ Further Reading















