---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Broke(n/r) Promises
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1909
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Muir v. Kane
Status: Annotated
Date: 1909-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - Muir promises to pay Kane $200 commission for sale of property
> - Statute of Frauds requires a written contract (oral non-enforceable)
> - Muir refuses to pay, saying unenforceable based on SOF

- Issue: Is this unwritten contract enforceable despite the law?

> [!note]+ Holding (Fullurton): Yes, there are both
> - There was no prior legal obligation to pay, but there was a bargain and exchange
> - Broker relied on the promise
> - Custom plays a role (brokers are generally payed)
> - A moral obligation alone is sufficient to sustain a promise.
