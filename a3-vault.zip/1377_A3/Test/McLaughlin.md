---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Interracial Marriage
Takeaway: Race is a “suspect” classification only constitutional when “necessary” to serve some “overriding statutory purpose”
Tags:
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1268
Type: Case
Rating: "**"
Year: 1964
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: McLaughlin v. Florida
Status: Annotated
Date: 1964-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Florida law bans interracial marriage.

- Issue: Does interracial marriage ban violate EPC?

> [!note]+ Holding (White): Yes.
> - Most classifications deserve RBT. But 
> - Is there an “overriding statutory purpose” requiring [discrimination]?
> - There is admittedly a legitimate interest, but is that enough? No.





















