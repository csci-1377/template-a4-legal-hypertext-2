---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Doorpost Reposession
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1982
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Greene v. Lindsey
Status: Annotated
Date: 1982-01-01
Year*: 1982
Jurisdiction: United States
---
> [!note]+ Parties
> - Appellant- Representatives of the county
> - Appellees- People who were evicted

> [!note]+ Facts
> - Kentucky process servers post notice of reposession on the doors of public housing projects if nobody is home
> - Tenants apparently don’t get them, and are thus evicted without warning
> 
> > [!note]+ Glenn’s
> > Kentucky law provides that in forcible entry or detainer actions, service of process may be made under certain circumstances by posting a summons on the door of a tenant's apartment. Tenants live in a housing project. In 1975, the Housing Authority of Louisville initiated detainer actions against each of appellees, seeking repossession of their apartment. Notice took the form of posting a copy of the writ of forcible entry and detainer on the door of the tenant's apartment. Appellees claim never to have seen these posted summonses; they state that they did not learn of the eviction proceedings until they were served with writs of possession, executed after default judgments had been entered against them, and after their opportunity for appeal had lapsed.

> [!note]+ Procedural History and Posture
> - Court of Appeals finds notice insufficient

> [!note]+ Strongest P Argument
> - This is a common and reliable method

> [!note]+ Strongest D Argument
> - It isn’t reasonably calculated for reliable notice. The mail would be much better

> [!note]+ Holding (Brennan)
> - Posting notices on doors is not reasonably calculated to reach those who could be easily informed by other means at hand -Mullane
> - Therefore, state deprives tenants of property without due process under the 14th amendment
> - Basically, sometimes posting works, but not here in housing projects

> [!note]+ Disposition
> Affirmed

> [!note]+ Dissent (O’Connor)
> - Court cites no real precedent or evidence that mail is better than posting
> - And their threshold is too low to overrule state legislation
