---
base: "[[Test.base]]"
In-Text Citation: (Guerrero, 2007)
Priority: Essential
Authors: Guerrero, Alexander A.
Title: "Don't Know, Don't Kill: Moral Ignorance, Culpability, and Caution"
Zotero URI: http://zotero.org/users/4316906/items/ESZ67RTY
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: This paper takes on several distinct but related tasks. First, I present and discuss what I will call the "Ignorance Thesis," which states that whenever an agent acts from ignorance, whether factual or moral, she is culpable for the act only if she is culpable for the ignorance from which she acts. Second, I offer a counterexample to the Ignorance Thesis, an example that applies most directly to the part I call the "Moral Ignorance Thesis." Third, I argue for a principle--Don't Know, Don't Kill--that supports the view that the purported counterexample actually is a counterexample. Finally, I suggest that my arguments in this direction can supply a novel sort of argument against many instances of killing and eating certain sorts of animals.
Type: Journal Article
URL: https://www.jstor.org/stable/40208767
Full Citation: "Guerrero, A.A. (2007) ‘Don’t Know, Don’t Kill: Moral Ignorance, Culpability, and Caution’, Philosophical Studies: An International Journal for Philosophy in the Analytic Tradition, 136(1), pp. 59–97."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2007
---
