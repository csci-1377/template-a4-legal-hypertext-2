---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Further
Court: Appeals
Authors: ""
Title: Logrolling Recovery
Takeaway: F1>F2
Tags:
  - Bailment
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1840
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Clark v. Maloney
Status: Annotated
Date: 1840-01-01
Jurisdiction: Delaware
---
> [!note]+ Facts
> - Clark finds logs, ties them up
> - Maloney “finds them adrift up the creek”
> - Clark wants them back

- Issue: When there are two finders, who owns the logs?

> [!note]+ Holding (Baynard): The first finder
> - Cites finder’s keepers rule (except against rightful owner)
> - But, this could cut both ways. He says finder gets “special” property that can’t be overruled by new finder. So you have to go as far up the chain as you can….?

> [!note]+ Thoughts and Questions
> - What prevents stealing the best?
> - What promotes return to rightful owner the best?
