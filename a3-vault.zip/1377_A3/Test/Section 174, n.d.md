---
base: "[[Test.base]]"
In-Text Citation: (Section 174- Duty To Exercise Reasonable Care, Skill And Diligence (Companies Act 2006), no date)
Priority: Further
Authors: ""
Title: Section 174- Duty To Exercise Reasonable Care, Skill And Diligence (Companies Act 2006)
Zotero URI: http://zotero.org/users/4316906/items/C6PI8WUT
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: Read Section 174  Duty To Exercise Reasonable Care, Skill And Diligence of Companies Act 2006 C46. Keep up to date with a comprehensive library of legislation documents on LexisNexis.
Type: Web Page
URL: https://www.lexisnexis.co.uk/legal/legislation/uk-parliament-acts/companies-act-2006-c46/part-10/section-174
Full Citation: "Section 174- Duty To Exercise Reasonable Care, Skill And Diligence (Companies Act 2006) (no date) LexisNexis. Available at: https://www.lexisnexis.co.uk/legal/legislation/uk-parliament-acts/companies-act-2006-c46/part-10/section-174 (Accessed: 4 July 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
---
