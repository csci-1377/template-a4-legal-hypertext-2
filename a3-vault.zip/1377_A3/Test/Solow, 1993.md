---
base: "[[Test.base]]"
In-Text Citation: (Solow, 1993)
Priority: Essential
Authors: Solow, Robert
Title: An almost practical step toward sustainability
Zotero URI: http://zotero.org/users/4316906/items/TK6D8V3V
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Solow, R. (1993) ‘An almost practical step toward sustainability’, p. 11.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1993
---
- Sustainability Definition
    - Not just that I’m unhappy with current consumer culture
    - preserving the productive capacity for economic wellbeing into the indefinite future
    - Some things are irreplaceable, but this can’t be everything
- Basic Argument
    - GDP doesn’t account for depriciating fixed capital resources
    - Net National Product accounts for this by roughly measuring this depreciation
    - We could do the same thing with nonrenewable resources, like clean air/water
- How it works
    - We can always substitute more labor, reproducible capital, and renewable resources for smaller direct inputs of the fixed resource
    - Each year two decisions: how much to save and invest, and how much nonrenewable resources to use
    - Assume intergenerational discounting is small
    - Economy makes decisions to generate the largest possible sum of satisfactions over future time
        - **Wait no, not really. If it did, it would invest like everything**
    - Correct charge for depletion should value each unit of resource extracted at its net price, namely, its real value as input to production minus the marginal cost of extraction
    - New NNP will be the maximum current level of consumer preferences that can be sustained forever
        - This doesn’t make any sense: prices assume technology, and technological growth is unpredictable
- Upshots
    - Most previous generations in the US have exceeded the benchmark of sustainability
    - **Seems like this advocates for us to implement Piguovian taxes to make shadow prices real market prices by removing negative externalities**
    - There is a lot to be gained by transforming questions of yes or no into questions of more or less.