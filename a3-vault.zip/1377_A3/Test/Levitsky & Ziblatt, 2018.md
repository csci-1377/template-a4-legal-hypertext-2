---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: |-
  Levitsky, Steven
  Ziblatt, Daniel
Title: How Democracies Die
Takeaway: ""
Tags: []
Category:
  - Politics
Abstract: ""
Type: Audiobook
Rating: "****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2018
---
Four Criteria of Autocrats

- Rejection of or weak commitment to Democratic rules of the game
- Delegitimizing Rivals
- Condoning or Endorsing Violence
    - Before Trump, no major party candidate has endorsed violence in the last century
- A readiness to curtail the civil liberties of rivals and critics
- Except Nixon, no pressure in last century met one, Trump met all 

Why constitutions aren’t enough:

- Nothing against appointing loyalists or limits to the presidents power in a crisis in the US Constitution
- Most important unspoken rules:
    - Mutual toleration: rivals, not enemies
    - Institutional forebearance: you don’t do everything technically in your power as an official

we have a limited ability to cope with deviation from a norm. When norms are repeatedly broken, we are too exhausted for outrage, so we desensitize, then move the norm (roughly, Daniel Patrick Moynihan)