---
base: "[[Test.base]]"
In-Text Citation: (Janis, 1982)
Priority: Recommended
Authors: Janis, Irving L.
Title: "Groupthink: psychological studies of policy decisions and fiascoes"
Zotero URI: http://zotero.org/users/4316906/items/G5HJDTUZ
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: "Groupthink - the psychological drive for consensus at any cost that suppresses disagreement and prevents the appraisal of alternatives in cohesive decision-making groups. In the first edition (Victims of groupthink), Iriving L. Janis showed how this phenomenon contributed to some of the major U.S. foreign policy fiascos of recent decades: the Korean War stalemate, the escalation of the Vietnam War, the failure to be prepared for the attack on Pearl Harbor, and the Bay of Pigs blunder. He also examined cases, such as the handling of the Cuban Missile Crisis and the formulation of the Marshall Plan, where groupthink was avoided. Here, in this revised and expanded edition, Janis applies his hypothesis to the Watergate cover-up, portraying in detail how groupthink helped to put the participants on a disastrous couurse and keep them there. In addition, he presents some fresh ideas on how and why groupthink occurs and offers suggestions for avoiding it"
Type: Book
Rating: "***"
Full Citation: "Janis, I.L. (1982) Groupthink: psychological studies of policy decisions and fiascoes. 2nd ed. Boston: Houghton Mifflin."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: To Note
Year*: 1982
---
