---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: ""
Title: "Ethics: Inventing Right and Wrong"
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Book
Rating: "****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1977
---
> [!note]+ Intro
> - There are no objective values
> - Defends subjectivism as a second order view (that there do not exist objective values) not that we should do whatever we want
> - Not a linguistic analysis. We really do talk as if there are objective values (this is why non-cognitivists and naturalists are wrong), there just aren’t. This is why it is an ‘error theory’
> - There can be objective (non-arbitrary) standards given a rubric of evaluation, these just can’t be categorical

> [!note]+ Argument from Relativity
> - Moral codes differ significiantly
> - They seem to track different ways of life, not perceptions of objective truth

> [!note]+ Argument from Queerness
> - Metaphysical: if these were part of the fabric of the world, they sure would be odd things
> - Epistemological: If we were aware of them, it would be through some very strange form of perception

> [!note]+ How we Objectify Values (Assuming they don’t exist
> - Hume: “minds propensity to project itself on the world” like the pathetic fallacy
> - Projecting wants and demands














