---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Contracting for PJ
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Jurisdiction: United States
---
> [!note]+ Facts
> BK is a Florida Corp. Rudzewicz and MacShara are Michiganders who enter into a 20 yr franchise contract with BK to operate a BK in Michigan. The franchise contract says that the franchise relationship is established in Florida and governed by Florida law, and that all required fees are paid to the Miami BK HQ and all notices sent there, too. The Miami HQ sets policies and resolves major problems with franchisees, but the day-to-day monitoring is done by regional offices that report to HQ.
> 
> Business is bad in Michigan fast food, and the franchisees fall behind in their monthly payments. BK brings a suit in Florida federal district court alleging that the franchisees breached their obligations under the franchise contract, seeking damages and injunctive relief.

Issue: There are no traditional bases for PJ. The long arm does reach it, but are the minimum contacts sufficient so that assenting to PJ would not violate constitutional due process?

> [!note]+ Proceedural History
> The court denied Rudzewicz motion to dismiss and ruled that personal jurisdiction was proper under Florida’s long arm statute. The court entered judgment in favor of Burger King and Rudzewicz appealed. 
> 
> 11th Circuit held that while Rudzewicz had sufficient contacts with the state of Florida to satisfy the state’s long arm statute, the **exercise of personal jurisdiction was fundamentally unfair** and violated due process. BK appealed.

> [!note]+ Holding ( ): Minimum cont(r)acts satisfy due process. 
> Contracts are not sufficient contacts alone. Must look at prior negotiations and contemplated future consequences, and then additionally the actual contract terms in the parties’ course of dealing
> 
> - Here, 20 year contract, carefully structured, reached out to FL to make the contract
> - **Could expect suit in Florida** because the contract made in FL, and the Miami office still in charge because all payments and notices went to Miami and the Miami office enforced he contract
> 
> A choice of law clause is not sufficient, but should not be ignored.
> 
> - It is a form of taking benefit of the jurisdiction, but is different from consent to jurisdiction.
> - More than one state can have interest in a case, and choice of law clauses can resolve this conflict.
> 
> Disparities in bargaining power should go into the FPSJ analysis.
> 
> - Here, experienced and sophisticated businessmen on both sides, and no material misrepresentations or economic duress.
> 
> If contract invalid, knocks out contacts. Fact-specific inquiry.

> [!note]+ Dissent (Stevens):
> All about fair play and substantial justice. Unfair to make franchisee defend in state of franchisor. The Court is really relying solely on the boilerplate language to find purposeful availment.
> 
> - This unfairly favors the franchisor who drafts the adhesion contract.
> - The franchisee had every reason to believe that Michigan was where BK would bring suit, and no fair notice when distant HQ sought to hail him into court in Florida.














