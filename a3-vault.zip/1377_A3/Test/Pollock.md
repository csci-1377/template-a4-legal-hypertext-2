---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Protecting Property from Majorities
Takeaway: "First instance of SC overruling itself: direct taxes must be apportioned equally,  real estate income + other nouns = unavoidable = direct"
Tags:
  - TXC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 1895
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pollock v. Farmers’ Loan & Trust Co.
Status: Annotated
Date: 1895-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - First Income Tax passed after Civil War
> - Challenged as a direct tax

- Issue: Is an income tax direct, and therefore must be apportioned per capita?

> [!note]+ Holding (Fuller): Yes
> - We need to protect private property from majority rule
> - Any unavoidable tax is direct
> - Functionallly the same as a tax on real estate
> - Distribution of Power: concerned with congressional overreach

> [!note]+ Concurrence/Dissent (White): 
> - Precedent: overthrows “long and consistent line of decisions”