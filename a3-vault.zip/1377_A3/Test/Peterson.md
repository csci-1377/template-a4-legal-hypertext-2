---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Aggressive Defense
Takeaway: "Common Law Self-Defense Requirements: Aggressor and Retreat"
Tags:
  - Intentional Homicide
  - Self-Defense
Category:
  - Crim
Abstract: ""
Page: 524
Type: Case
Rating: "***"
Year: 1973
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Peterson
Status: Completed
Date: 1973-01-01
Jurisdiction: D.C. Circuit
---
> [!note]+ Facts
> - D goes into his house and gets gun
> - V says what are you doing, gets lug wrench
> - D says don’t take another step, then shoots

> [!note]+ Procedural History and Posture
> - Indicted for second degree murder, convicted for manslaughter

- Issue: Was this justified?

> [!note]+ Holding (Robinson): No
> - Necessity
> > a defensive killing is unnecessary if the occasion for it could have been averted
> 
>     1. Aggressor rule: enough evidence that he initiated the aggression that it should be presented to the jury
>         - Aggression is an “affirmative unlawful act reasonably caclulated to produce an affray foreboding injurious or fatal consequences”
>         1. Aggressor cannot claim self-defense unless they renounce aggression
>         2. They do so by “clearly communicating” it.
>         3. You are the aggressor if you come back from a “place of relative safety” unless you are returning into your normal, lawful activities.
>     2. Retreat (Castle Doctrine): Majority rule, but doesn’t apply here because he was aggressor.
>         4. Minority: required to retreat unless they are in castle (unless agressor)
>         5. Majority: Not required to retreat, entitled to stand ground and use deadly force when reasonably necessary.
> - Proportionality
>     - Can’t use more force than what you’re faced with (can’t meet non-deadly with deadly)
> - Reasonable Belief
>     - Subjective: belief must be sincerely held
>     - Objective: belief must actually be reasonable
> - Disposition: Affirmed





















