---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Lists in Commerce
Takeaway: ""
Tags:
  - Lenity
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1971
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: U.S. v. Bass
Status: Annotated
Date: 1971-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Omnibus Crime Control and Safe Streets Act of 1968, Section 1202(a)
> > Any person who… has been convicted by a court of the United States or of a State or any political subdivision thereof of a felony… and who receives, possesses, or transports in commerce or affecting commerce… any firearm shall be fined not more than $10,000 or imprisoned for not more than two years, or both.”
> - New York interprets to ban all posession and receipt by convicted felons (no need to relate to commerce)

- Issue: Does NY Law prohibit any possession of a firearm by felon?

> [!note]+ Holding (Marshall): No, only “in commerce or affecting commerce”
> - It’s Ambiguous
>     - Absurdity: if commerce bit only applies to the last one, then “curious reach”
>     - Counter: that would make Title VII redundant, BUT not entirely (Title VII covers more than just felons)
>     - LH: Senate Floor speech implies doesn’t need commerce, but never specifically says that, or explains why the phrase is in the statute if not
>     - Counter: Yeah, they probably should have added a comma, but it’s fine without it
> - Given ambiguity, we’ll use narrower reading
>     - Lenity- Fair Warning (McBoyle)
>     - Federalism- unless “clear statement” assume Congress is not changing federal-state balance

> [!note]+ Dissent (Blackmun +1): Yes
> - It’s clear enough, so not ambiguous
> - The comma really matters
> - Purpose: Congress was clearly trying to prohibit firearm possession by felons
> - LH: Senator Long’s comments on the Senate Floor show this!
