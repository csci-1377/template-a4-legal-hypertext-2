---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/1409945
In-Text Citation: (Weaver, 1987)
Priority: Recommended
Authors: Weaver, Max
Title: Review of Law's Empire
Zotero URI: http://zotero.org/users/4316906/items/FNGCSPVA
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/1409945
Full Citation: "Weaver, M. (1987) ‘Review of Law’s Empire’, Journal of Law and Society, 14(2), pp. 266–271. Available at: https://doi.org/10.2307/1409945."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1987
---
