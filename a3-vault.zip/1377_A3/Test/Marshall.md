---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: LSD Mixtures
Takeaway: ""
Tags:
  - Pragmatism
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1991
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: U.S. v. Marshall
Status: Annotated
Date: 1991-01-01
Jurisdiction: Seventh Circuit
---
> [!note]+ Facts
> - US law sets mandatory minimums  for posession of a “mixture or substance containing a detectable amount” of LSD (5 years for >1 gram, 10 years for >2 grams)
> - Defendants have blotter paper weighing over 10 grams that is only .9% LSD

- Issue: Does weight of LSD mixture include the carrier?

> [!note]+ Holding (Easterbrook): Yes, it does
> - Ordinary parlance calls it a mixture
> - All our precedent says it counts
> - It makes the law really bad, but not completely without a rational basis (generally more weight is more doses)
> - No evidence of extreme prosecution
> - Objections/replies: But this punishes 10 years for a dose of LSD in orange juice!

> [!note]+ Concurrence/Dissent (Posner): No, it doesn’t
> - The result is absolutely absurd
> - Congress just didn’t know how LSD was sold: it counted PCP by either pure or carrier, just not this one
> - “Loony” to punish more if LSD in quart vs. pint of orange juice
> - This saves Congress from irrationality
> 
> > [The answer to this case lies in the] disagreement between the s<u>everely positivistic view</u> that the content of law is exhausted in clear, explicit, and definite enactments by or under express delegation from legislatures,
> and the <u>natural lawyer's or legal pragmatist's view</u> that the practice of interpretation and the general terms of the Constitution . . . authorize judges to enrich positive law with the moral values and practical concerns of civilized society.
> 
> > The first [positivistic view] buys political neutrality and a type of objectivity at the price of substantive injustice, while the second [natural lawyer’s or legal pragmatists view] buys justice in the individual case at the price of considerable uncertainty and, not infrequently, judicial willfulness
