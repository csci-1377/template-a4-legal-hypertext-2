---
base: "[[Test.base]]"
In-Text Citation: (Voigt, 2020)
Priority: Essential
Authors: Voigt, Kristin
Title: Relational Egalitarianism
Zotero URI: http://zotero.org/users/4316906/items/TU7GX5UD
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: '"Relational Egalitarianism" published on  by Oxford University Press.'
Type: Document
Rating: "***"
URL: https://
Full Citation: "Voigt, K. (2020) ‘Relational Egalitarianism’. Available at: https://doi.org/10.1093/acrefore/9780190228637.013.1387."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2020
---
> [!note]+ Intro
> - Other terms: social or democratic equality
> - Do requirements apply to individuals, institutions, or both?
> - Is it about treatment, attitudes, or expression?
> - Is it valuable instrumentally or impersonally, or as a deontic requirement?
> - Does it only apply within political communities?
> - Does it apply to those with severly limited cognitive capacities?
> - Is it incompatible with distributional equality?
> - It’s heavily pluralistic, ans some principles conflict

> [!note]+ What to avoid
> - Objectionable Hierarchies
>     - of domination (subjection to arbitrary control by another)
>     - of esteem (stigmatization and stereotyping)
>     - of standing (where interests are given less weight)
>     - Should focus on those that are particularly damaging and relatively easy to mitigate
> - Negative effects
>     - Lack of self-respect
>     - Emotional costs
>     - Cognitive distortions
>     - Impaired moral capacities
> - Indifference
> - Testimonial injustice
> - Institutions expressing assessment of lower worth of some citizens

> [!note]+ What to aim for
> - Feelings of…
>     - Caring and caring that others care
>     - Fraternity
>     - Civic friendship
>     - Being in the same boat

> [!note]+ Comparison with distributional equality
> - Second-person vs. third-person perspective
> - But equalizing distributions can be instrumentally valuable
> - Can also be a way of expressing appropriate attitudes

> [!note]+ Thoughts
> Implications of relational equality for deliberation: 
> 
> > For one, for equality to obtain, “others [must] recognize an obligation to listen respectfully and respond to one’s arguments” (Anderson, 1999, p. 313), and people must see themselves as having an obligation to justify certain actions to others: “democratic equality regards two people as equal when each accepts the obligation to justify their actions by principles acceptable to the other, and in which they take mutual consultation, reciprocation, and recognition for granted” (Anderson, 1999, p. 313).
> 
> - From “What is the point of equality?
> - A given institution is able to aim for increasing its legitimacy. So it can aim for fraternity and civic friendship not because these make life go well, but because they secure the preconditions of legitimacy of the institution.














