---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Van Full of Weed
Takeaway: You don’t have to be able to get away to posess
Tags:
  - Posession
  - Drugs
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "**"
Year: 2010
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Adams
Status: Annotated
Date: 2010-01-01
Jurisdiction: Seventh Circuit
---
> [!note]+ Facts
> - Police set up a reverse sting trying to sell him drugs
> - They give him a van full of marijuana but disable the battery
> - He tries to start it, fails
> - Then they arrest him

> [!note]+ Procedural History and Posture
> - Jury convicts
> - Appeal

- Issue: Did Adams posess the weed?

> [!note]+ Holding (Rovner): Yes
> > One actually possesses a thing when it is in his
> physical custody and control; he constructively possesses
> it when, although it is not within his physical possession,
> “he knowingly has the power and intention at a given time
> to exercise dominion and control over the object.”
> 
> - Unlike [[Kitchen]], Adams unequivocally assented to posession
> 
> > if he had a rolling paper he could have fashioned himself a joint; if he had a lighter he could have set the van on fire. It was not necessary for the agents to have left the battery connected in order to establish Adams’ control over the van’s contents.
> 
> - He constructively posessed once he took the keys, he actually posessed once he entered the van and tried to start it.
> - Disposition: Affirmed





















