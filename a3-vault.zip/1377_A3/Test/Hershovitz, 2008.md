---
base: "[[Test.base]]"
In-Text Citation: (Hershovitz, 2008)
Priority: Essential
Authors: ""
Title: "Exploring Law's Empire: The Jurisprudence of Ronald Dworkin"
Zotero URI: http://zotero.org/users/4316906/items/5ZAK8U4E
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Book
URL: http://www.oxfordscholarship.com/view/10.1093/acprof:oso/9780199546145.001.0001/acprof-9780199546145
Full Citation: "Hershovitz, S. (ed.) (2008) Exploring Law’s Empire: The Jurisprudence of Ronald Dworkin. Oxford University Press. Available at: https://doi.org/10.1093/acprof:oso/9780199546145.001.0001."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2008
---
> [!note]+ Introduction- Breyer
> > [!note]+ Dworkin’s Three Theses (2000)
> > 1. Law inevitably embodies standards that require a judge to make moral decisions
> > 2. It is not undemocratic because the best conception of democracy is one in which majority rule is fair. It helps to support democracy itself.
> > 3. Societies have increasingly turned to judges to separate the “social accelerator” from the “moral brake”
> 
> > [!note]+ What judges must do
> > - Offer an interpretive argument in good faith as an argument
> > - Connect decisions in particular cases to something more general and basic
> > - It must seem right to those who rely on it.
> > 
> > > Dworkin’s views also suggest that through the use of reason a constitutional judge can produce an opinion that is transparent, permitting an informed reader to criticize the opinion in light of substantive standards. The result is a system that allows the public, and the judge, to know when an opinion goes too far, thereby keeping judicial subjectivity in check. The standards are not totally objective. Indeed, they permit, perhaps sometimes require, judges to invoke their own notions of political morality. But even then they permit informed public criticism. (4)
> 
> > [!note]+ Interpersonal Reasoning
> > > a “judicial forum” helps to organize “differing fluctuating opinions for and against a particular matter. It is a place where lawyers representing differing interests publicly have to confront contrary opinions.”¹⁷ It permits “a continuous exchange of opinions,” thereby helping “the public debate along.”¹⁸ 
> > > - Judges in Contemporary Democracy: An International Conversation (R. Badinter & S. Breyer eds., 2004). 96-97
> > > > there is no place like a judicial forum for organizing differing, fluctuating opinions for and against a particular matter. It is a place where lawyers representing differing interests publicly have to confront contrary opinions. (Robert Badinter, page 96)
> > 

> [!note]+ Chapter 1- Eisgruber
> > Can Dworkin’s “moral reading” in fact accommodate historical argument and other traditional forms of legal reasoning, or does it require constitutional judges to become philosophers? (5)
> 
> > Dworkin’s arguments about moral principle and the Constitution presuppose an unarticulated, controversial theory about the purpose of written constitutions and super-majoritarian amendment procedures. (6)
> 
> > Dworkin called for “a fusion of constitutional law and moral philosophy.” (TRS 149)
> > - Equal status and equal concern got us off to the philosophical races
> 
> > Dworkin’s argument seems to make not only history, but much of the constitutional text (including the Bill of Rights, which singles out specific liberties for constitutional protection), superfluous. (7)
> 
> > History might enrich political theory in at least three ways: with examples that stimulate reflection; with data about institutional performance and human behavior; and with rhetorical resources that enhance the persuasive power of moral argument. (8)
> 
> > there is a difference between the meaning of a concept and our views about how best to apply the concept.¹⁷
> 
> > Dworkin tacitly assumes that the best framers would write abstract, sweeping moral principles into their constitutions. (15)
> 
> - Purpose of supermajoritarian amendment proceedures
>     - They prevent majorities from consolidating power at the expense of minorities. (19)
>     - establish stable political institutions. (19)
>     - create incentives that may improve the quality of institutional reform. (20)
>     - reasons why good constitution-makers might make amendment difficult even if the goal of constitution-making is to create a government that honors evolving judgments about abstract standards of justice. (21)

> [!note]+ Chapter 2- Fleming
> > Do as Dworkin says, not as he does. (35)
> 
> > Moral reading “underwrites a deliberative citizenry” by encouraging “reflection upon, and deliberation about, basic principles and constitutional essentials” (39)
> > - Big difference between the two! 
> 
> > Only under the moral reading do we have much hope of interpreting our imperfect Constitution in a manner that might deserve our fidelity. (25)
> 
> > Dworkin as a constitutional “protestant” instead of a court-centered “catholic” on the question, “Who is to interpret the Constitution?” (30)
> > - Focus on the difference between “we are, together” and “each of us, alone”
> > - S. Levinson, “The Constitution” in American Civil Religion, 1979 Sup. Ct. Rev. 123, 141 (interpreting Dworkin as a constitutional “protestant” on the question “Who is to interpret the Constitution?”); see S. Levinson, Constitutional Faith 42–44 (1988). Dworkin has also referred to his approach on this question as a “protestant” approach. See Dworkin, Law’s Empire, supra note 5, at 190, 413.
> 
> - Majoritarian premise: conflating democracy with majority rule
> - Originalist Premise: monopoly on fidelity to the constitution
>     - We can turn to history without turning to originalism
>     - It only becomes originalism if it implausibly claims no recourse to political theory.

> [!note]+ Chapter 3- Brown
> > Government must treat those whom it governs with concern, that is, as human beings who are capable of suffering and frustration, and with respect, that is, as human beings who are capable of forming and acting on intelligent conceptions of how their lives should be lived. (TRS 272)
> > - Something about this as a precondition for interpersonal reasoning
> 
> > [judges] must not deploy moral principles, no matter how much they are personally committed to such principles, that cannot be defended as consistent with the general history of past Supreme Court decisions and the general structure of American political practice.
> > - Freedom’s Law, 319.
> > - But defended to whom?
> 
> - Law’s Empire, ix (explaining that “whether we have reason to think an answer is right is different from the question whether it can be demonstrated to be right”).
> - J. Hart Ely, Democracy and Distrust 56–57 (1980) (discussing and rejecting the threepart proposition that “moral philosophy is what constitutional law is properly about, that there exists a correct way of doing such philosophy, and that judges are better than others at identifying and engaging in it.”).
> 
> > In the end, it is a question of optimism or pessimism. The schools of constitutional thought to which Dworkin has sworn eternal opposition are characterized by skepticism, cynicism, distrust, and pessimism. (67)
> > - But be optimistic about others’ reasoning, especially that of fellow members of your court!

> [!note]+ Thoughts
> - Don’t try to attribute particular views to Dworkin, but construct a Dworkin from his writings
> - Lawrence Tribe is leading constitutional theorist/litigator. Doesn’t use originalist strategy

> [!note]+ Further Reading
> - C. R. Sunstein, The Partial Constitution (1993) [hereinafter Sunstein, Partial Constitution]; 
> - Sunstein, Legal Reasoning, especially at 48–53 (criticizing Dworkin’s grand, abstract theorizing and calling instead for “incompletely theorized agreements”).
> - Dworkin, The Forum of Principle
> - M. W. McConnell, The Importance of Humility in Judicial Review: A Comment on Ronald Dworkin’s “Moral Reading” of the Constitution, 65 Fordham L. Rev. 1269 (1997).
> - Response to Vermule
>     - See L. Schultz Bressman, Beyond Accountability: Arbitrariness and Legitimacy in the Administrative State, 78 NYU L. Rev. 461 (2003) (describing the new views of the administrative state as profoundly majoritarian)