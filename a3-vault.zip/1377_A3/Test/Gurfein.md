---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Cancelled Glass
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1922
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gurfein v. Wervelovsky
Status: Annotated
Date: 1922-01-01
Jurisdiction: Connecticut
---
> [!note]+ Facts
> - Parties agree to a sale of glass, with the clause…
> > “The above cases are to be shipped within 3 months from date. You have the option to cancel the above order before shipment.
> - Gurfein asks for the glass repeatedly, but Wervelovsky refuses to sell
> - Gurfein sues for breach

- Issue: Is there a contract tp sell if the buyer could cancel before shipment?

> [!note]+ Holding (Beach): Yes, there is.
> - Defendant: “Because it appears that said instrument by reason of the uncertainty of the terms and the lack of mutuality in the obligations it purports to create, is unenforceable as a contract, and is wholly invalid, void and of no effect”
> - Plaintiff: But Wervelovsky could ship at any time, so gains a right from his promise even though he didn’t take it.
> - Disposition: Reversed
