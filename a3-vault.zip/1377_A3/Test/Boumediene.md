---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Guantanamo Bay
Takeaway: Habeas corpus cannot be be suspended unless done so formally by Congress.
Tags:
  - WP
Category:
  - Con Law
Abstract: ""
Page: 327
Type: Case
Rating: "**"
Year: 2008
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Boumediene v. Bush
Status: Annotated
Date: 2008-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 2001/2002 AUMF: Bush Administration sends 800+ people to Guantanamo Bay, detaining under horrible conditions in part due to coerced confessions
> - Congress issues DTA and MCA to prevent the President or the courts from preventing the indefinite hold of noncitizens classified as enemy combatants
> - Group of detainees challenge this arrangment as a violation of the suspension clause (habeas corpus)

- Issue: Does this act unconstitutionally deny habeas corpus?

> [!note]+ Holding (Kennedy): Yes
> - The statute does deny our jurisdiction to issue writs, so if valid case must be dismissed (no constitutional avoidance)
> - Gov: the Constitution doesn’t apply, because we don’t have formal sovereignty there!
>     - US maintains de facto sovereignty over Guantanamo Bay
> - Separation of Powers: Congress can’t decide where the constitution does and doesn’t apply. We do (Marbury)
> - Three Factors
>     1. Citizenship and status of the detainee and adequacy of process of determination
>         1. In dispute
>     2. Nature of cites of apprehension and detention
>         2. Technically outside territory, but practically not abroad
>     3. Practical obstacles inherent in resolving prisoners entitlement to writ
>         3. Costs money, but that’s not dispositive

> [!note]+ Dissent (Scalia): No, that would be crazy!
> - 





















