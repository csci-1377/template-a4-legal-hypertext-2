---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: All deliberate speed
Takeaway: Balancing test for remedy of constitutional violation
Tags:
  - Remedies
Category:
  - Con Law
Abstract: ""
Page: 1281
Type: Case
Rating: "***"
Year: 1955
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Brown v. Board of Education
Status: Annotated
Date: 1955-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Massive resistance to desegregation

> [!note]+ Procedural History and Posture
> - 

- Issue: How do districts need to desegregate?

> [!note]+ Holding (Warren): With all deliberate speed.
> - We need to make sure the authorities are implementing in “good faith”
> - Generally, we should leave specifics to the local courts
> - Use equity: practical flexibility
> - **Balance**
>     - Interests of the plaintiffs
>     - Public interest in eliminating discrimination
>     - Defendants’ burdens in compliance
> - Consider
>     - Administration problems
>     - Physical conditions
>     - Transportation
>     - Personnel
>     - Local laws and regulations
> - Burden is on defendants to establish how much time is necessary.





















