---
base: "[[Test.base]]"
In-Text Citation: "(‘2.2.The Secular Papacy: Discussion’, 2004)"
Priority: Further
Authors: ""
Title: "The Secular Papacy: Discussion"
Zotero URI: http://zotero.org/users/4316906/items/SMRQJFAJ
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: 2.2.The Secular Papacy was published in Judges in Contemporary Democracy on page 79.
Type: Book Section
URL: https://0.www.degruyter.com/document/doi/10.18574/nyu/9780814739341.003.0009/html
Full Citation: "‘2.2.The Secular Papacy: Discussion’ (2004) in 2.2.The Secular Papacy: Discussion. New York University Press, pp. 79–116. Available at: https://doi.org/10.18574/nyu/9780814739341.003.0009."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Up Next
Year*: 2004
---
