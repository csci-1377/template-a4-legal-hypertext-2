---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Data Processing Personal Time
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Kearsarge Computer, Inc. v. Acme Staple Co.
Status: Annotated
Date: 1976-01-01
Year*: 1976
Jurisdiction: New Hampshire
---
> [!note]+ Facts
> - Kearsarge contracts with Acme for data processing
> - Acme alleges breach and terminates contract
> - Kearsarge requests info regarding alleged breach
> - Both parties sue for breach

> [!note]+ Procedural History and Posture
> - Judge holds in favor of Kearsarge for full contract price plus interest and costs
> - Acme? appeals to supreme court

> [!note]+ Holding
> - Summary- Kearsarge should be awarded full contract price.
>     - They did not save significantly from breach (employees reduced salaries to keep business afloat, costs of paper and electricity don’t count)
> > If the plaintiff’s required expenditures are of cash or material, the tendency is to put the burden of allegation and proof of the amount thereof on him, but if his expenditures would be of time or labor, the burden is normally placed on the defendant.
>     - The extra money they made from other contract could have been made without the breach (data processing has some personal services, some scalable, so we assume would have been possible to render services to others without breach)
> > These businesses are deemed to be expandable.
> 
> > In a suit for breach of a personal services contract, the wages obtained by the plaintiff-employee from a substitute job are deducted from the amount of damages if the earnings of the second income would not have been possible but for the breach.
> - Disposition- Mostly upheld (but Kearsarge does need to pay for the costs incurred to fix their mistakes)

> [!note]+ Thoughts and Questions
> - So whether extra profits after breach are deducted depend on the nature of the business, a factual question. 
> - How does the court know whether they could have accepted more business?

> [!note]+ Class Notes
> - Most businesses (not just personal services) don’t allow for extra profit gained after breach (or those that could have been gained) to count against damages.
> - This is a relatively bright line, which might not be justifiable
