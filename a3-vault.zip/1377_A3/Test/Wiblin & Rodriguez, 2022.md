---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: |-
  Wiblin, Rob
  Rodriguez, Luisa
Title: 80,000 Hours
Takeaway: ""
Tags: []
Category:
  - Ethics
Abstract: ""
Type: Podcast
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
Ezra Klein

- Activism often works to get attention, and attention creates polarization, which often prevents change.

Andy Weber

- Bioweapons can be made obsolete by having rapid mRNA development, which is just slightly edited for each new protein that you want to create. You also don’t need much of it because it just gets your body to produce the real vaccine. Also at home genetic sequencing and PPE

Case Sunstein

- Preference Falsification: people don’t express some things they want or misrepresent them
- Diverse Thresholds: people have different tolerances for injustice
    - Some need 0 people to act, others 1, 2, etc.
    - Someone will only act if they see the number below them acting
    - The movement will only continue if there are enough people who perceive at their thresholds.
- Interdependencies: If one person is doing something it’s crazy, if 1000 we want to join.
- Identity relevance depends on social context, and some identities can be short-term
- Culture influences, but does not determine, our identities and belief
- False dichotomy between atomistic individualism and communal determinism
- We can discover facts that give us reasons for an identity, but this does not mean the identity is discovered. Even the facts cannot determine the adoption of the identity.
- Dam breaking happens when there are social costs for expressing opinions, then as people express them the cost diminishes
- Preferences are adaptive to what people think is possible and are aware of
- Describing norms helps to shift actions when people have mistaken beliefs about other people’s opinions
- When like minded people get talking, their opinions get extreme. Can explain this by by identity and narrative shit.
- Group polarization in echo chambers is explained by information exchange, but really story exchange is a better model for it. Information focuses on facts, and that’s often not what is happening.