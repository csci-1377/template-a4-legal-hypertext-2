---
base: "[[Test.base]]"
In-Text Citation: (Gheaus, 2023)
Priority: Essential
Authors: Gheaus, Anca
Title: Inheritance in Unjust Circumstances
Zotero URI: http://zotero.org/users/4316906/items/VFH39AXL
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: I assume that we should abolish inheritance in order to fund, amongst other justice-promoting policies, an adequate and robust safety net. But, I argue, in societies that lack such safety nets parents do no wrong in bequeathing to their children. In such societies both procreative duty and parental concern justify bequest as insurance against some forms of misfortune. The justified bequests, while limited both in size and in form, may be very substantial and therefore impede egalitarian reforms. I conclude that procreative duty and parental love provide (would-be) parents with special – and powerful – reasons to support the introduction of public safety nets.
Type: Journal Article
Rating: "**"
Full Citation: Gheaus, A. (2023) ‘Inheritance in Unjust Circumstances’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2023
---
