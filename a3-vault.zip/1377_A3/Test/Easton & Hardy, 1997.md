---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: |-
  Easton, Dossie
  Hardy, Janet
Title: The Ethical Slut
Takeaway: ""
Tags: []
Category:
  - Ethics
Abstract: ""
Type: Audiobook
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 1997
---
Agreements: positive rather than negative: things you will do rather than things you won’t (weekly date to reaffirm rather than don’t stay overnight)

If goal is to make sure no one feels taken advantage of, agreement (mode of achieving) can be making sure no one’s space, time, or belongings are being infringed on.

People who are good at sex masturbate

The last bit is about sex, why not being hard is fine.

Two is the simplest story, because the stuff of story is relation, not being. In this way, one is nothing. And while three remains three, four becomes six, five becomes eleven and so forth. Reduction to the dichotomy is therefore the most comforting destruction of reality.
