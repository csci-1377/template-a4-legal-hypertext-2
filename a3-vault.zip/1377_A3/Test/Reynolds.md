---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: One Person, One Vote (for state elections)
Takeaway: Must make an “honest and good faith effort” to draw equal population as is practicable. Straying more than de minimis must be due to compelling interest.
Tags:
  - 14A/VRAs
Category:
  - Con Law
Abstract: ""
Page: 1437
Type: Case
Rating: "***"
Year: 1964
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Reynolds v. Sims
Status: Annotated
Date: 1964-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Alabama draws voting districts for state elections like the US as a whole, so districts are different sizes.

- Issue: Is this scheme in violation of EPC?

> [!note]+ Holding (Warren): Yes
> - This is justiciable (Baker v. Carr)
> - Voting is a “fundamental political right” (Yick Wo)
> - BUT we’re just doing what the feds are doing?
>     - No, counties are just made up.
> > Legislators are elected by people, not trees or acres.
> 
> > We are cautioned about the dangers of entering into political thickets and mathematical quagmires. Our answer is this: a denial of constitutionally protected rights demand judicial protection; our oath and our office require no less.





















