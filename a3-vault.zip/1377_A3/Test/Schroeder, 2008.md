---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1747-9991.2008.00155.x
In-Text Citation: (Schroeder, 2008)
Authors: Schroeder, Mark
Title: What is the Frege-Geach Problem?
Zotero URI: http://zotero.org/users/4316906/items/RFFG64WR
Takeaway: ""
Tags: []
Category: []
Abstract: In the 1960s, Peter Geach and John Searle independently posed an important objection to the wide class of ‘noncognitivist’ metaethical views that had at that time been dominant and widely defended for a quarter of a century. The problems raised by that objection have come to be known in the literature as the Frege-Geach Problem, because of Geach’s attribution of the objection to Frege’s distinction between content and assertoric force, and the problem has since occupied a great deal of the attention both of defenders of broadly noncognitivist views, and of their critics. In this article I explain Geach and Searle’s historical objections, and put the subsequent discussion into dialectical context, paying some attention to the developments along the way and how they have enhanced our overall understanding of the problem. The article covers a lot of territory, so we will only be able to see the highlights, along the way. For further reading, see the Works Cited.
URL: https://onlinelibrary.wiley.com/doi/10.1111/j.1747-9991.2008.00155.x
Full Citation: "Schroeder, M. (2008) ‘What is the Frege-Geach Problem?’, Philosophy Compass, 3(4), pp. 703–720. Available at: https://doi.org/10.1111/j.1747-9991.2008.00155.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Year*: 2008
---
