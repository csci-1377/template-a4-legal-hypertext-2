---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Kendi, Ibram X.
Title: How to be an Antiracist
Takeaway: ""
Tags: []
Category:
  - Politics
  - Race
Abstract: ""
Type: Audiobook
Rating: "**"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2019
---
Racist: someone who supports racist policies through their action or inaction or holds racist ideas.

Antiracist: someone who supports Antiracist policies through their action or holds Antiracist ideas.

Racism: marriage of racist policies and ideas that produces and normalizes racial inequities.

There is no such thing as a race-neutral policy.

Institutional, structural, and systemic racism are redundant terms. Racism is inherently all of those.

There are no ideas that are Not racist. There are only racist and Antiracist ideas.

Racist ideas claim that one racial group is superior or inferior to another in any way.

We can unknowingly be racist but only knowingly be Antiracist

His theory of racism is based entirely on power and self interest, not ignorance or hate. The question arises, then, why race? Why not any other means of achieving power?

Apparently, he thinks that racist ideas are generated intentionally to justify racist policy to shift blame from policy to people?

In the post racial era, we looked for another term to describe racism and came up with micro aggression, turning racism from a descriptive term into a pejorative. (May be that it’s original meaning simply no longer describes what we now mean).

Human genome project determined we are 99.9% the same. This connecting of biology to behavior is the cradle of biological racism.

Ethnicity is related to ancestry, not directly to race. Ethnic groups in Western Africa are more similar to those in Western Europe than those in Eastern Africa.

Race is a mirage, or a fiction. In this way, it is like gender, used as a way to describe interactions between groups, formed by society, as differentiated from sex.

Majority of African Americans eligible for welfare are not on it.

To be an antiracist is to view the inequities between all racialized ethnic groups as a problem of policy.

7:52 remaining: black immigrants do better than black natives. Racist asks why, antiracist asks why black immigrants are doing poorer than other immigrants. The difference is because immigrants self select: usually more resourceful, educated, etc. Than natives in both countries they are leaving and going to.

Entire point is power for those at the top?

Unemployment explains most of the racial violence disparity

John McWhorter says rap retards Black success. This guy disagrees

He commits himself to complete cultural relativity, claiming that is the essence of cultural anti racism. Difference between cultures is never better, only different.

Behavioral racist: one who makes individuals responsible for group behavior and groups responsible for individuals. Antiracist must treat group behavior as fictional

Kendi admits that he is a believer, and that it is believers that are so susceptible to racist ideas. Thinkers consider. Malcom X was a believer.

During Obama presidency, only 30% of black people cited racism as the main cause of racial inequality. Over 60% cited other reasons (Kendi says this must be internalized racism). Now during Trump, those numbers are flipped. Still one third do not think racism is the biggest thing.

Every time he says something bad about black people, he says he is doing racism.

At first thought of history as a battle with black people on one side and whites and niggers on the other. African American studies course “opened” his mind to see it as a battle between racists and anti racists.

We engage in a double standard when, confronted with a Black individual that is incompetent, lazy, etc, we attribute this to the group, while when we encounter the same from a white individual, we attribute it to that individual.

Separation is not always segregation. Black people living together and away from racism can be beneficial, and is very different from white people wanting to be separate from “black inferiority.” The Brown v. Board decision misattributed the opportunity gap (not the performance gap) to feelings of inferiority that Black people must feel in separate schools, not that they were severely underfunded.

MLK was not in favor of school integration!

San Antonio school district v Rodriguez found that property tax based schooling does not violate the equal protection clause.

Integration into white culture became racial progress.

The problem of racism has always been the problem of power and not the problem of immorality

He says changing minds and showing support is not activism. You are not an activist unless you have a history of policy change....

Differentiate demonstrations and protests, like mobilization and organization. The former are temporary and polarizing, the latter longer term and uniting.

Claims that institutional racism is just as overt and attributable to specific actors as individual racism... eh? The point is that it is not hidden and unknowable

He is admirably trying to make an understanding of complicated issues accessible to those less educated by simplifying them while also highlighting that overcomplicating them is in the interest of the academics and postracialists and racialists alike.

His racism/anti racism definition is politically useful, but inaccurate, as it does not capture any distinction between those who believe one racial group is inferior to another and those who do not.

Racism is a modern disease. Began in 1500s, before that people saw color but did not group it into continental races, did not attach positive and negative attributes... (Egyptian slaves?) Racism is not even 600 years old.

Nothing in history gives him hope that we can become antiracist. Hope comes from the assertion that if we lose it, we lose the battle. Interesting. Is Hope a belief or not? If not, then we do not require it to be tied to truth, but rather as it affects action.