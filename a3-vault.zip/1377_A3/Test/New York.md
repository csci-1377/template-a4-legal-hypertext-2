---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Radioactive Restrictions
Takeaway: Congress cannot commandee/compell legislatures states to pass laws
Tags:
  - 10A
  - States' Rights
  - ACD
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "**"
Year: 1992
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: New York v. United States
Status: Annotated
Date: 1992-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress passes 3-part law to regulate radioactive waste
>     1. Monetary incentives (pay states that dispose within borders)
>     2. Access incentives (pay extra for out-of-state cites if don’t dispose within certain period)
>     3. Take tite (if they don’t have disposal site by deadline, either must take responsibility for private waste produced or legislate to provide for disposal as the feds want)

- Issue: Can Congress regulate the states like this?

> [!note]+ Holding (O’Connor): No
> > A choice between two unconstitutionally coercive regulatory techniques is no choice at all.
> 
> - 10A and Art 1 are mirror images: 10A is the tautology that points to the limits on enumerated powers
>     - “just as a cup may be half empty or half full” makes no difference which we point to
> - At founding, Virginia plan adopted, which limited federal regulation to individuals
> - So they can influence or persuade states, but not coerce
> - Accountability: this ensures state officials’ actions are accountable to the people
> - Here, the “choice” is between accepting ownership of the waste or regulating according to Congress’ instructions