---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Nicotine is not a Drug
Takeaway: Foreshadowing MQD
Tags:
  - Major Questions Doctrine
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 2000
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Brown v. Williamson
Status: Annotated
Date: 2000-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - FDA concludes that nicotine is a “drug” which it can regulate

- Issue: Defer to agency’s interpretation that nicotine is a “drug”?

> [!note]+ Holding (O’Connor): No
> > [Chevron deference] is premised on the theory that a statute’s ambiguity constitutes an <u>**implicit delegation**</u> from Congress to the agency to fill in statutory gaps…In extraordinary cases… there may be reason to hesitate before concluding that Congress has intended such an implicit delegation
> 
> > We must be guided by <u>**common sense**</u> as to the manner in which Congress is likely to delegate a decision of such <u>**economic and political significance**</u> to an agency in so cryptic a fashion
> 
> > The words of a statute must be read in their context and with a view to their place in the overall statutory scheme.
> 
> - Agency practices are “not carved in stone”
> - Disposition: 

> [!note]+ Dissent (Breyer): Yes!
> - First it works read literally
> - Then within the purpose of th estatute