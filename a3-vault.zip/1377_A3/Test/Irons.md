---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: King's Bench
Authors: ""
Title: Trover for Two Colts
Takeaway: Delivery is required to transfer gift
Tags:
  - Transfer of Venue
  - Gifts
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1819
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Irons v. Smallpiece
Status: Annotated
Date: 1819-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Father makes verbal gift of colts to son
> - Colts stay with father
> - Father agrees to sell hay to him to feed colts
> - Months later, he actually provides hay
> - A few days later, he dies
> - Executrix of will now has colts
> - Son sues to get them

- Issue: Is delivery required to transfer gift?

> [!note]+ Holding: Yes
> - Must be actual delivery
> - But maybe if thee hay was given earlier, would help show constructive delivery?