---
base: "[[Test.base]]"
In-Text Citation: (Scalia et al., 1997)
Priority: Essential
Authors: |-
  Scalia, Antonin
  Gutmann, Amy
  Amar, Akhil Reed
  Calabresi, Steven G.
Title: "A Matter of Interpretation: Federal Courts and the Law - New Edition"
Zotero URI: http://zotero.org/users/4316906/items/P8YTLTZ7
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: We are all familiar with the image of the immensely clever judge who discerns the best rule of common law for the case at hand. According to U.S. Supreme Court Justice Antonin Scalia, a judge like this can maneuver through earlier cases to achieve the desired aim-"distinguishing one prior case on his left, straight-arming another one on his right, high-stepping away from another precedent about to tackle him from the rear, until (bravo!) he reaches the goal-good law." But is this common-law mindset, which is appropriate in its place, suitable also in statutory and constitutional interpretation? In a witty and trenchant essay, Justice Scalia answers this question with a resounding negative.   In exploring the neglected art of statutory interpretation, Scalia urges that judges resist the temptation to use legislative intention and legislative history. In his view, it is incompatible with democratic government to allow the meaning of a statute to be determined by what the judges think the lawgivers meant rather than by what the legislature actually promulgated. Eschewing the judicial lawmaking that is the essence of common law, judges should interpret statutes and regulations by focusing on the text itself. Scalia then extends this principle to constitutional law. He proposes that we abandon the notion of an everchanging Constitution and pay attention to the Constitution's original meaning. Although not subscribing to the "strict constructionism" that would prevent applying the Constitution to modern circumstances, Scalia emphatically rejects the idea that judges can properly "smuggle" in new rights or deny old rights by using the Due Process Clause, for instance. In fact, such judicial discretion might lead to the destruction of the Bill of Rights if a majority of the judges ever wished to reach that most undesirable of goals.   This essay is followed by four commentaries by Professors Gordon Wood, Laurence Tribe, Mary Ann Glendon, and Ronald Dworkin, who engage Justi
Type: Book
Rating: "*****"
URL: https://www.jstor.org/stable/j.ctvbj7jxv
Full Citation: "Scalia, A. et al. (1997) A Matter of Interpretation: Federal Courts and the Law - New Edition. NED-New edition. Princeton University Press. Available at: https://doi.org/10.2307/j.ctvbj7jxv."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1997
---
> [!note]+ Preface
> > All the commentators concur with Justice Scalia’s critique of interpreting the law according to either subjective legislative intent or a judge’s favorite moral philosophy. (ix)
> 
> > Thomas Jefferson struggled, unsuccessfully, to end “the eccentric impulses of whimsical, capricious designing man” and to make the judge “a mere machine.” (ix)

> [!note]+ Introduction: Akhil Reed Amar
> - Compares the book to socratic dialogues, commends Scalia for inviting pushback
> 
> > [!note]+ Unity and Integrity in the Constitution
> > - We must read between the lines to understand the whole; for the Constitution itself was rati.ed as a whole, and not as a jumble of discrete clauses. Professor Glendon’s splendid response essay in this book reminds us of the desirability of this sort of holistic analysis, familiar in other mature legal systems;* and long before this reminder, John Marshall famously insisted in McCulloch v. Maryland that “we must never forget that it is a Constitution”—and not a word or clause or sentence—“that we are expounding.”
> > - *Pp. 99–100, 108–9, 111 (referring to “systematic” and “structural” modes of interpretation attentive to “the unity of the constitution”—“the document as a whole” and “the relationship of particular provisions to one another as well as to the overall design for government” and to “guiding principles in the structure and design of instrument” and emphasizing “a text whose parts cannot be understood in isolation from one another”). For a similar theme, see Tribe, pp. 70, 72, 86 (emphasizing the need to “look[] at the entire Constitution as amended from time to time” and “the Constitution as a whole” because “[t]he Constitution is, after all, a whole and not just a collection of unconnected parts.”) For a sustained effort to analyze the Constitution’s entire text, see Akhil Reed Amar, America’s Constitution: A Biography (2005).

> [!note]+ The Essay: Antonin Scalia
> The current practice of interpreting statutes like common law must stop, and can be solved by textualism.
> 
> > [!note]+ Civil Law System:
> > > it is the text of the law rather than any prior judicial interpretation of that text which is authoritative. Prior judicial opinions are consulted for their persuasive effect, much as academic commentary would be; but they are not binding. (7)
> 
> > [!note]+ Common Law: torts, contracts, property, criminal law
> > - Not really common (a reflection of practice) but made by judges
> > - Common law courts perform two functions: apply the law and make the law (6)
> > 
> > > why first-year law school is so exhilarating: because it consists of playing common-law judge, which in turn consists of playing kingdevising, out of the brilliance of one’s own mind, those laws that ought to govern mankind (7)
> > 
> > - Two skills: determine the “best” legal rule and distinguish cases to get there
> > 
> > > His image of the great judge—the Holmes, the Cardozo—is the man (or woman) who has the intelligence to discern the best rule of law for the case at hand and then the skill to perform the broken-field running through earlier cases that leaves him free to impose that rule: distinguishing one prior case on the left, straight-arming another one on the right, highstepping away from another precedent about to tackle him from the rear, until (bravo!) he reaches the goal—good law. (9)
> > 
> > > “What is the most desirable resolution of this case, and how can any impediments to the achievement of that result be evaded?” (11)
> 
> > [!note]+ Statutes: Almost all of federal courts docket
> > > By far the greatest part of what I and all federal judges do is to interpret the meaning of federal statutes and federal agency regulations. (13)
> > 
> > - So unclear, not only is the methodology but the objective is unclear (16)
> > - Down with Intent
> > > it is simply incompatible with democratic government, or indeed, even with fair government, to have the meaning of a law determined by what the lawgiver meant, rather than by what the lawgiver promulgated. (17)
> > 
> >     - Back to transparency
> 
> > [!note]+ Hermes’ Path
> > > I think it not contrary to sound principles of interpretation, in such extreme cases, to give the totality of context precedence over a single word. (21) - on scrivener’s error
> 
> > [!note]+ Textualism
> > > The text is the law, and it is the text that must be observed. (22)
> > 
> > > the belief that judges have no authority to pursue those broader purposes or write those new laws. (23)
> > 
> > > Words do have a limited range of meaning, and no interpretation that goes beyond that range is permissible (24)
> > 
> > - Uses canons of construction
> > 
> > > Every canon is simply one indication of meaning; and if there are more contrary indications (perhaps supported by other canons), it must yield. (27)
> > 
> > - Against legislative history (which has only been used since around the 1940’s
> > 
> > > With respect to 99.99 percent of the issues of construction reaching the courts, there is no legislative intent (32)
> > 
> > > In textual interpretation, context is everything, and the context of the Constitution tells us not to expect nit-picking detail, and to give words and phrases an expansive rather than narrow interpretation—though not an interpretation that the language will not bear. (37)
> > 
> > - Focused on original, not current meaning (38)
> > 
> > > It certainly cannot be said that a constitution naturally suggests changeability; to the contrary, its whole purpose is to prevent change—to embed certain rights in such a manner that future generations cannot readily take them away (40).
> > 
> > > [How original meaning applies to new and unforeseen phenomena] In such new fields the Court must follow the trajectory of the First Amendment, so to speak, to determine what it requires—and assuredly that enterprise is not entirely cut-and-dried but requires the exercise of judgment. (45)
> 
> > [!note]+ Living Constitutionalism
> > > a body of law that (unlike normal statutes) grows and changes from age to age, in order to meet the needs of a changing society. (38)
> > 
> > Grounded in flexibilities, but results in ultimately preventing social change through restrictions on democratic government.
> > 
> > > For the evolutionist, on the other hand, every question is an open question, every day a new day (46). 
> > > **He’s right on the first score, but wrong on the second.**
> > 
> > > Whatever he might propose, at the end of the day an evolving constitution will evolve the way the majority wishes (46). 
> > 
> > > By trying to make the Constitution do everything that needs doing from age to age, we shall have caused it to do nothing at all (47). 
> 
> > [!note]+ Thoughts
> > - interpretation is not a science, it is a practice
> > - Just because judges don’t “discover” the law doesn’t mean that they “make” it. (10)
> > - Treats common law like an art or game, while statutory interpretation is a science.
> > > It is an art or a game, rather than a science, because what constitutes the “holding” of an earlier case is not well defined and can be adjusted to suit the occasion. (8)
> > 
> >     - A game is governed by conventions, allows for entirely strategic reasoning.
> > - Overly focused on rules
> > - Policy rec: norms of interpersonal deliberation in federal courts
> > - Institutional reasoning takes the form “it’s not just up to me to decide” and can help explain vertical deference and statutory interpretation
> > - So you get that there is no intention, but you think there was general understanding? 

> [!note]+ Gordon Wood
> > [!note]+ Colonial Period
> > - Legislatures began as courts making judgments. 
> > - Judges are seen as extensions of the executive, as political authorities, not legal experts
> 
> > [!note]+ 1776
> > > Americans try to limit judicial discretion to end “the eccentric impulses of whimsical, capricious designing man” and to make the judge “a mere machine.”
> 
> > [!note]+ 1780s
> > > Americans began looking to the once-feared judiciary as a principal means of restraining these wild and rampaging popular legislatures
> > 
> > - Still with positivist notion of statutory law
> 
> > [!note]+ Early 1800s
> > - Judges withdraw from politics, develop their “mysterious science”
> > - Focus on individual rights, property, contracts
> > - Judges gain independent standing, can do things no other judges can
> > - They have always excercised undemocratic authority
> 
> > [!note]+ In England
> > - Judicial interpretation involves creation of new legal meanings, judges accused of making law just like in America
> > - Judges claim ot interpret statutes to fit them into the legal structure
> 
> > [!note]+ Takeaway
> > - Judicial power is the product of changes over the past two hundred years, not just recent developments
> > - Only way to limit power is to change the attitude of judges themselves or by appointing only those with the right attitude
> > - The separation of law and politics was hugely important.
> > 
> > > first I suppose we must reverse some of the reductio ad absurdum tendencies of legal realism and remystify some of what lawyers and judges do.
> 
> > [!note]+ Thoughts
> > - This judicial attitude is treated as distinct from an interpretive methodology. It doesn’t have to be. 
> > - Any theory of interpretation which cannot capture features which the judge must recognize reduces that theory to pragmatism. If there are exceptions to the method, then it isn’t the method.
> 
> > [!note]+ Scalia’s Response
> > - It isn’t that the concepts of legislation and adjudication weren’t distinct until modern times, but that the desirability of separating them into different departments wasn’t clear until recently
> > - It is true that legislatures sometimes adjudicate, but not that courts legislate.

> [!note]+ Lawrence Tribe
> > [!note]+ Scalia and Dworkin Departure
> > - Both convinced that we can be sure of whether certain passages of the constitution enact abstract principles or concrete rules.
> > 
> > > Nor, finally, do I agree that all constitutional provisions may be neatly classified at birth into one or the other of two distinct species, one reserved for broad and dynamic statements of abstract principle that are capable of elaboration and application only through the processes of moral philosophy, and the other reserved for dated, static, and concrete rules whose application does not engage the reader’s moral faculties in any significant way (69)
> > 
> > > The task of deciding which provisions to treat as generative of constitutional principles broader or deeper than their specific terms might at first suggest, and then of deciding just what principles such provisions, read alone or in combination with others, should be taken to enact, lies at the core of the interpretive enterprise. That task cannot properly be discharged as though it were merely an exercise, however grand, in historical reconstruction or simply a foray, however impressive, into mind reading. (71)
> > 
> > - They both fail to adhere to “these canons of candor and self-conscious humility in the face of a task about which none of us is entitled to feel too self-assured (72)
> > - Originalism can’t provide the rules of interpretation through its originalism. 
> 
> > [!note]+ Tribe’s View
> > > the text they enacted was, through their action, launched upon a historic voyage of interpretation in which succeeding generations, looking at the entire text of the Constitution as amended from time to time, would elaborate what the text means in ways all but certain not to remain static. (70)
> > 
> > > about time that I roll my legal universe into a ball and toss it into the ring as my candidate for what the final rules of the interpretive game must be. For now, and perhaps permanently, I would respectfully decline that invitation. Indeed, I am doubtful that any defensible set of ultimate “rules” exists. Insights and perspectives, yes; rules, no. But my readily confessed inability to propose a “how to” manual for the interpretive enterprise should not be confused with an inability, or a reluctance, to advance arguments of a “how not to” variety (73)
> > 
> > - But ultimately no theory about the rules of the interpretive game. 
> > - There is no way to appeal to the Constitution’s text to ask how it is to be read. It is a problem of self-referential regress. No interpretation is self-evidential
> > - Some set of principles in the Constitution reflected aspirations of the former colonists
> > 
> > > much of the Constitution simply cannot be understood as a law enacted by a particular body of persons on a specific date but must instead be comprehended as law promulgated in the name of a “people”44 who span the generations. Perhaps the most dramatic example is the Twenty-Seventh Amendment, proposed and sent to the states in 1789 and finally ratified in 1992. (84).
> > 
> > - Avoid “hyper-integration” atttibuting coherence to the constitution that ignores the compromise, and is thus false to its character (87)
> > 
> > > What the Constitution means ought to be discussed first, and how much of that meaning life-tenured judges ought to feel free to impose and in what circumstances ought to be analyzed afterward (90)
> 
> > [!note]+ The Project of the Constitution
> > - Scalia thinks it is to prevent change
> > - Tribe claims it is to assure a fixed core of rights and assure a periphery for a broader elaboration
> 
> > [!note]+ Thoughts
> > - Pretty much every legal scholar agrees we aren’t looking for intentions
> > - We must honor the compromises made rather than trying to “correct” the “flaws” of the constitution (70)
> > - There is no algorithm for consititutional interpretation. This is why it is fundamentally interpersonal.
> > - Consider for career: “I share the concerns expressed by Robin L. West, Constitutional Skepticism, 72 B.U. L. Rev. 765 (1992), about the degree to which equating the Constitution with one’s idealized conception of the moral principles that ought to constrain public power in a just society may blind one to the flaws in that document and might deflect energies of political reform into litigation efforts that are either disingenuous or futile or both.” (91)
> 
> > [!note]+ Scalia’s Response
> > > [!note]+ Aspirations
> > > - We don’t have aspirations in the controlling parts of the constitution. That wouldn’t make any sense.
> > > - And even if it did, judges shouldn’t be the ones pursuing aspirations
> > > - Some clauses in the constitution are abstract, but they refer to generalizations of current understandings.
> > 
> > > [!note]+ Rejecting Virtues Approach
> > > > Professor Tribe takes refuge in “candor and . . . self-conscious humility.” Rejecting base “certitude,” he acknowledges that he does not know the answer to either of these questions. Indeed, he is not even sure there are any answers—only “insights and perspectives.” I do not mean to disparage candor and humility, virtues that are not only admirable but also rare, particularly in intellectual circles. They would assuredly carry the day if the issue before us were quality of character, rather than soundness of interpretive theory. But they are of little use to the judge who must determine whether and whither the Constitution has wandered, and who is not permitted to render a candid and humble judgment of “Undecided.” (137)
> > > 
> > > - Hercules would have no use for these virtues, but each judge on a panel does.
> > 
> > > [!note]+ Stare Decisis
> > > > Originalism, like any other theory of interpretation put into practice in an ongoing system of law, must accomodate the doctrine of *stare decisis*; it cannot remake the world anew… The whole function of the doctrine is to make us say that what is false under proper analysis must nonetheless be held to be true, all in the interest of stability. It is a compromise of all philosophies of interpretation, his no less than mine. (138-139). 
> > > 
> > > No, it is to make us say what we believe to be false in isolated analysis must be held to be true, in the interest of interpersonal and institutional reasoning.
> > > 
> > > > stare decisis is not part of my originalist philosophy; it is a pragmatic exception to it. (140)
> > > 
> > > - Amar’s response in the introduction
> > > > Why is it okay to discard originalism in cases when it is rather inconvenient? If pragmatism ultimately determines when we do originalism, this is in the end pragmatism not originalism. (xxiii)
> > > - Calabresi’s Response to Amar in Afterword
> > > > One could perfectly well be an originalist and think that one component of the judicial power conferred on the federal courts by Article III is that one is bound to follow deeply rooted precedents. (163)
> > > > - Caveat, he thinks precedents are popularly expressed views, not majority court decisions

> [!note]+ Mary Ann Glendon
> > [!note]+ American Common Law
> > - American lawyers aren’t good at legislative drafting or interpretation. But the problem is like Igor’s “what hump?”
> > - Even statutory courses are taught through court decisions
> > - 1940s and 50s saw push for study of legislation, but foundered in part because of constitutional rights revolution making con law sexy
> > 
> > > dramatic civil rights decisions promoted the illusion that social change could be effected through litigation. (99)
> > 
> > - Constitutional law courses begin not with the constitution, but with a case.
> > - They focus not on the whole constitution, but on individual rights, the glorious fragments of a larger whole.
> > - Judges tried to harmonize the constitution with existing common law (consider Lochner and property rights)
> 
> > [!note]+ Civil Law Systems
> > - Focused on drafting and interpreting codes
> > - Four modes of interpretation
> >     - Grammatical
> >     - Systematic
> >     - Historical
> >     - Teleological
> > - But even civil law countries aren’t really based in civil law, or the civil codes (complete sets of authoritative starting points for legal reasoning) after subsequent, often contradictory legislation overruled them
> > - Their Achilles heel is in case analysis. But they tried to improve, and got better. This actually brought them up to speed with the US, which has done most of its constitutional interpretation since WWII
> 
> > [!note]+ The Grander Problem
> > - As judicial lawmaking expands, the democratic elements in our republican experiment atrophy.
> > - We lose our skills of self-government
> > - The tyranny of the majority might fade away in the face of tyranny by a powerful few.
> 
> > [!note]+ Quotes for Consideration
> > > One of the traits that most conspicuously differentiates the Bundesverfassungsgericht’s decisions from those of the American Supreme Court also helps to keep teleological interpretation from running wild. That is the practice of attending consistently to the language and structure of the entire Constitution—to the document as a whole, and to the relationship of particular provisions to one another as well as to the overall design for government. (The Court is aided, it should be noted, by the fact that the Basic Law is a more detailed, integrated, and contemporary document than the United States Constitution.)(106)
> > 
> > > Often its rulings look less like the reasoned elaboration of principle than like the products of majority vote (111)
> > 
> > > Without neglecting our rights tradition or the principles embodied in two centuries of precedent, they are attempting to restore separation of powers, federalism, and constitutional text and structure to “a central and appropriate place” in constitutional theory. (112)

> [!note]+ Ronald Dworkin 
> > [!note]+ Dworkin’s Critique
> > - Two kinds of intention. What someone intended to *say* and what *consequence* they intended to have.
> >     - Semantic originalism relies on personification
> >     - Expectation originalism relies on intention
> > - Sometimes to follow what someone says, we have to go against their expectations
> >     - “hire the most qualified applicant”
> > 
> > > It is near inconceivable that sophisticated eighteenth-century statesmen, who were familiar with the transparency of ordinary moral language, would have used “cruel” as shorthand for “what we now think cruel.” (121)
> > 
> > > key constitutional provisions, as a matter of their original meaning, set out abstract principles rather than concrete or dated rules. If so, then the application of these abstract principles to particular cases, which takes fresh judgment, must be continually reviewed, not in an attempt to find substitutes for what the Constitution says, but out of respect for what it says. (122)
> > 
> > - These clauses are semantically principled, not “aspirational” (footnote pg 123)
> > - Two concerns with principled interpretation: either it is undemocratic, with elected judges overreaching by making moral determinations, or it is too democratic, leading to the appointment of justices who reflect the changing moods of the majority.
> 
> > [!note]+ Scalia’s Response
> > - Prefers *import* to *semantic intention* because it puts the focus on reasonable understanding by listeners rather than intention by speakers. But generally, both of us follow *semantic intention*.
> > 
> > > Ultimately, of course, those two concepts chase one another back and forth to some extent, since the import of language depends upon its context, which includes the occasion for, and hence the evident purpose of, its utterance. (144)
> > 
> > > I, no less than Professor Dworkin, believe that the Eighth Amendment is no mere “concrete and dated rule” but rather an abstract principle… What it abstracts, however, is not a moral principle of “cruelty” that philosophers can play with in the future, but rather the existing society’s assessment of what is cruel.. It is, in other words, rooted in the moral perceptions of the time (145).
> > 
> > > It makes a lot of sense to guarantee to a society that “the freedom of speech you now enjoy (whatever that consists of) will never be diminished by the federal government”; it makes very little sense to guarantee that “the federal government will respect the moral principle of freedom of speech, which may entitle you to more, or less, freedom of speech than you now legally enjoy.” (148)
> > 
> > - The concern is that people now know the constitution is made to mean whatever it ought to, so will appoint judges to enforce their morality. Unpopular rights will no longer be protected.

> [!note]+ Afterword: Steven Calabresi
> > Until he died in February 2016 only three of the nine justices publically articulated and defended a theory of constitutional interpretation: Justices Scalia, Thomas, and Breyer. That none of the other six followed suit will adversely affect their legacy and how we evaluate them. (152)
> 
> > As Justice Scalia said in this book as well as in many of his speeches, judicially evolved constitutions are at least as likely to rot as they are to progress. (156)

> [!note]+ Thoughts
> - One interpretation of the constitution itself is as setting up a procedure for interpersonal reasoning. 
> - Judicial deliberations are private, but even if they weren’t, we wouldn’t know whether judges are truly reasoning interpersonally. The same process of dialogue can be pursued as a means of persuasion or as interpersonal reason, depending on the stance of its participants.
> - Meaning rests neither entirely with the speaker nor with the listener
> - What you think the constitution means, or even what it would be reasonably understood to mean by those at the time, depends on your relative optimism and pessimism for the future, or your relative trust in your own vs others convictions and reasoning.
> - The distinction between what something means and what judges should enforce is severed by humility. There is what *I think *the law means and what law *is* as the outcome of an institutional and interpersonal procedure without having to make the distinction. 
> - Books like this, based in a symposium where there are discussions and responses, is exactly the kind of process that produces better interpretations. The structure of the book is itself discursive.
> - Calls for a shift in culture are calls to pragmatically sacrifice proper interpretive methods unless the method is itself interpersonal.
> - If the facts of law are constituted by a process of interpersonal and institutional reasoning rather than internal, then compromising one’s own personal theory is part of proper interpretation.
> - Interpretation is a process, not merely its result. Any adequate theory of interpretation must pay careful attention to how the outcome is arrived at, not merely what the outcome is. 














