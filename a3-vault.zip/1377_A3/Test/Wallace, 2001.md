---
base: "[[Test.base]]"
In-Text Citation: (Wallace, 2001)
Priority: Essential
Authors: Wallace, David Foster
Title: Democracy, English, and the Wars over Usage
Zotero URI: http://zotero.org/users/4316906/items/NPEULCAT
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
Rating: "*****"
Full Citation: Wallace, D.F. (2001) ‘Democracy, English, and the Wars over Usage’, p. 21.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2001
---
> [!note]+ Democratic Spirit: 
> - “one that combines rigor and humility, i.e., passionate conviction plus sedulous respect for the convictions of others.” (41-42)
> - it is indisputably easier to be dogmatic than Democratic (42)

> [!note]+ Meaning
> - “Meaning is inseparable from some act of interpretation” (46)
> - “Language was invented to serve specific purposes” (47)
> - There is no such thing as a private language. Words have their meanings because of standards imposed by a community
> 
> > If words’ meanings depend on tranaperaonal rules and these rules on community consensus,language is not only conceptuaIly non-Private but also irreducibly *public, political*, and *ideological*.

> [!note]+ Jargon
> - arises from the urge to save time and space and to conceal meaning from the uninitiated (ADMAU miniessay on jargon)
> - Call for more readable court opinions

> [!note]+ Playground Politics
> - The kid SNOOT is deficient in the language arts, he knows only one dialect, and will get made fun of for it
> - The teacher represents SWE, and claims to learn it only make sense if you want to be part of that discourse community (powerful white men)
> - Perhaps we should be clear about why we call people to learn SWE, but it’s hard to make sound good.

> [!note]+ Politically Correct English
> - Not just silly but confused and dangerous
> - They think that modes of expression produce attitudes rather than demonstrate them
> - Vastly more helpful to conservatives but shifting the conversation and focusing on self-righteous virtue signalling rather than material change

> [!note]+ Vogue Words
> - Shibboleths, essentially, that serve primarily to present the speaker in certain lights rather than communicate substance.
> - These serve the selfish interests of the speaker rather than any of the people or groups named.
