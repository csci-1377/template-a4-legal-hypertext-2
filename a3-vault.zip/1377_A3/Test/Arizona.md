---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Complementing/Supplementing Immigration Law
Takeaway: Look to federal government’s purpose, parse provision by provision
Tags:
  - SUP
  - FCC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 2012
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Arizona v. United States
Status: Annotated
Date: 2012-01-01
Jurisdiction: United States
---
- Facts: SB 1070 is immigration bill designed to enforce immigration law in a way the federal government would not
- Issue: Are these state laws preempted by federal legislation?

> [!note]+ Holding (Kennedy): Most of them
> 1. Is the federal law constitutional? Yes
>     - Federal government authority to regulate immigration rests on…
>         - A1 §8 C4: “establish a uniform rule of naturalization”
> > “inherent power” as sovereign to control and conduct relations with foreign nations
> 2. Is there a conflict? Most of them
>     - Pragmatism: foreign governments need just one entity to talk to
>     1. State criminal law for violation of federal registration: No
>         - Purpose was a uniform way of dealing with immigration (field preemption)
>         - Can’t give states independent authority to prosecute federal laws
>     2. New criminal immigration law: no
>         - Congress chose not to criminalize applying for work as an unauthorized alien
>         - Even though this law has the same goals, its methods conflict
>     3. State officer without a warrant may arrest with probable cause to believe unauthorized alien: no
>         - Generally not a crime to remain in the United States
>         - This would give local cops power not granted to federal authorities
> > This is not the system Congress created
>     4. Make reasonable attempt to determine status, check status of those otherwise arrested: yes
>         - Congress has actually encouraged communication with ICE
>         - Doesn’t seem to conflict with the federal law, might complement…













