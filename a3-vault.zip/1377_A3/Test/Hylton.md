---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: A Carriage tax is Indirect
Takeaway: "First review of act’s constitutionality: indirect taxes do not need to be apportioned (indirect = anything but people and land = verbs)"
Tags:
  - TXC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 1796
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hylton v. United States
Status: Annotated
Date: 1796-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress taxes carriages at $10 per carriage.
> - Lawsuit created where one person pretends to own 100 carriages and challenges the act’s constitutionality

> [!note]+ Procedural History and Posture
> - Straight to SC

- Issue: Is a tax on carriages direct, and therefore necessarily apportioned?

> [!note]+ Opinion 1 (Chase): No, it’s a use tax
> - **Purpose**: would be difficult to apportion if it were direct. Important to simplify to allow government to collect revenue
> - **Empire**: Existed to prevent slave tax, which would have prevented expansion of slavery

- Opinion 2 (Paterson): No, that’s just slaves and land