---
base: "[[Test.base]]"
In-Text Citation: ""
Authors: ""
Title: Risk of Making Bad Law Discussion
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Type: Interview
Rating: "**"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
- You want to do what’s best for your client once you take them on
- Many clients understand that “this is something bigger than me”
- “The rules of ethics make decisions for you.”
- It is easier to see the risk when taking a case on appeal
- Taking a case that came to you vs. “create a case.”
- “Some of this governed by the rules of ethics, some is just ‘don’t be an asshole.’”
- Think about
    - Potential pressure on a client
    - For clinic: whether students can do it
- “Recognizing someone’s agency doesn’t five you an out [to ignore the power imbalance]”
- Non-profit industrial complex
    - Prompts irresponsible litigation
    - Serves the institution (being the first)
- Bad Examples
    - Religious freedom abortion claims post-Dobbs
        - Expands religious freedom (opt-out from society based on religion)
        - Potential for fetal personhood
    - Freedom from Religion Foundation
        - Suing speaker of the house about opening invocation
- Less Bad
    - Bladensburg (sp?) Cross (American Humanists)
        - Not just a “public display”
    - Satanic Temple
        - Good when getting voluntary change, not in litigation
        - Oral arg 7th Circ w/ Frank Easterbrook
- Good Examples
    - Marriage equality movement and Mary Bonatto (sp?)
    - You often don’t see doing well, often *not* taking cases
    - You see this when someone doesn’t bring X claim

> [!note]+ Used
> - Be suspicious of “losing forward”
>     - Bringing a case to change the narrative
>     - Often putting their own interests over those of a movement
> - BUT times when losing and likely making bad law is justified
>     - Sometimes injustice is so bad you just have to fight
>         - Establishment clause 10 Commandments?
>     - Letting chilling effect empower future wrongs














