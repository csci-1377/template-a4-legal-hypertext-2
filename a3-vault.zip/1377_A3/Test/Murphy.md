---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Sports Betting
Takeaway: "Congress Cannot issue direct orders that only affect state legislatures or officers: federal laws must regulate private actors, not states."
Tags:
  - 10A
  - States' Rights
  - ACD
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "***"
Year: 2018
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Murphy v.  Natonal Collegiate Athletic Association
Status: Annotated
Date: 2018-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress passes law prohibiting states from authorizing sports gambling (enforced by AG against states)
> - New Jersey wants to remove prohibition they currently have
> - Sues challenging constitutionality

- Issue: Can Congress tell states *not* to regulate?

> [!note]+ Holding (Alito): No
> - The ability to issue orders to state governments is “conspicuously absent” from Congress’ enumerated powers
> - This is just like if federal officers were hanging out in state legislatures “armed with the authority to stop legislators from voting on offending proposals”… really?
> - Gov test: is it compelling or prohibiting legislation (2nd ok)
>     - That’s empty. It was happenstance our prior cases were compelling
> - Real Test:
>     1. Congress must be excercising enumerated power (can’t just point to SUP)
>     2. Legislation “must be best read as one that regulates private actors”
> - Some express preemption might look like it fails the second test, but not really. It’s just ensuring that the federal regulation is what stands.