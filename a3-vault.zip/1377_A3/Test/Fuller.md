---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Burglary → First Degree Murder
Takeaway: We don’t like the felony murder rule, but it’s the law.
Tags:
  - Intentional Homicide
  - Unintentional Homicide
Category:
  - Crim
Abstract: ""
Page: 342
Type: Case
Rating: "**"
Year: 1978
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Fuller
Status: Annotated
Date: 1978-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - D engaging in daylight burglary taking tires from vans toward their car
> - Officer sees them and catches them
> - High-speed auto chase after nonviolent burglary leads to death.

> [!note]+ Procedural History and Posture
> - Trial court strikes the murder count

- Issue: Did the trial court err in striking the murder count?

> [!note]+ Holding (Franson): Yes
> - Penal Code has the felony murder rule
> - Someone died while these people were “in perpetration of” a felony.
> - Strict liability for deaths related to felonies
> 
> > [Felony murder rule] Destroys the symmetry of the law by equating an accidental killing resulting from a petty theft with a premeditated murder. 





















