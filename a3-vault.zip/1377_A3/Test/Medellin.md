---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Mexican Consular Help
Takeaway: President cannot unliaterally execute a non-self executing treaty by giving it domestic effect.
Tags:
  - A2
Category:
  - Con Law
Abstract: ""
Page: 843
Type: Case
Rating: "**"
Year: 2008
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Medellin v. Texas
Status: Annotated
Date: 2008-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - US ratifies UN Charter, which creates ICJ
> - US agrees to submit to ICJ rulings
> - US accused of ICJ violation
>     - Prosecuting Mexican nationals without letting them contact the Mexican embassy for help.

- Issue: Does the President’s power to give effect to non-self executing treaties without statutory authorization?

> [!note]+ Holding (Roberts): No
> - Start with Jackson’s “familiar tripartite scheme” as the “accepted framework” for analysis
> - We’re in Category 3
> - Obligation from UN Charter
>     - This is a non-self executing treaty
>     - President can’t convert a non-self executing treaty into a self-executing one
> - Presidential Memo Independent Power
>     - Congress isn’t just “acquiescing” or “inviting” President to act here
>     - There is no “particularly longstanding practice” of congressional acquiescence, it’s “unprecedented action”





















