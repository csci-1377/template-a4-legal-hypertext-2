---
base: "[[Test.base]]"
In-Text Citation: (Stemplowska, 2022)
Priority: Essential
Authors: Stemplowska, Zofia
Title: For Whom the Bell Tolls? Salient Commemoration
Zotero URI: http://zotero.org/users/4316906/items/7YFLAEIT
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Stemplowska, Z. (2022) ‘For Whom the Bell Tolls? Salient Commemoration’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
