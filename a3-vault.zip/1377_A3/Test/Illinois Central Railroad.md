---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Publicly Trusted Harbor
Takeaway: A public trust is subject to and revokable in public interest
Tags:
  - Public Trust
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1892
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Illinois Central Railroad Co. v. Illinois.
Status: Annotated
Date: 1892-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 1952- Congress gives title to lakefront to Illinois Central Railroad
> - 1969- Add land submerged under harbor (supposed to build docks)
> - 4 years later, attorney general files a bill in equity to determine who owns the harbor section

- Issue: Who controls the harbor?

> [!note]+ Holding (Field): The state
> - A corporation is basically monopolizing the harbor (not actually true)
> - Congress holds lands in public trust, subject to their interest
> - Any grant of this land is necessarily revokable in that interest

> [!note]+ Dissent (Shiras): The state, but not at issue here
> - They could take it back if they wanted, but they haven’t
