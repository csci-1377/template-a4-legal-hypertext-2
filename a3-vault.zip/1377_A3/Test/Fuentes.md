---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Stove in Replevin
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1972
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Fuentes v. Shevin
Status: Annotated
Date: 1972-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Company takes stove and stereo on conditional contracts through replevin
> - Only needs to post initiate a court action, claim legal ownership, and post bond (double value of items) and get determination by clerk to get replevin
> 
> > [!note]+ Glenn’s
> > Plaintiff buys gas stove from Firestone on a “conditional sales contract” (lay away), monthly payments of installments. Later buys stereo. Collectively they cost $500 with financing charge of $100 additional. Under the contract (“K”), the company has title but Fuentes gets possession unless and until she defaults on installment payments.
> > 
> > Fuentes makes her payments for more than a year, but with $200 remaining to pay away she gets into dispute with Firestone over servicing of stove. Firestone initiates a small claims court action to repossess stove and stereo saying she failed to make her payments. Simultaneously with filing the action, and before Plaintiff even gets summons to answer complaint in the small claims action, Firestone gets a “writ of replevin,” ordering sheriff to seize the disputed goods immediately (A writ of replevin is an action for the repossession of personal property wrongfully taken or detained by the defendant, whereby the plaintiff gives security for and holds the property until the court decides who owns it).
> > 
> > She sues in federal district court claiming that Florida’s pre-judgment replevin statute violates her DP Opportunity to be heard and seeking declaratory and injunctive relief against its enforcement.
> > 
> > *Fla. Statute*: All that the statute requires is that the goods be “wrongfully retained” to get replevin.
> > 
> > The statute does not require you make a convincing showing that the goods really are wrongfully detained to get replevin—just to file a complaint, initiate a court action, state in conclusory fashion that you are “lawfully entitled to the possession” and place a security bond with court. That alone authorizes a law enforcement officer to seize goods. He comes to your house and asks you for it.  If you won’t give it he can literally break down your door.
> > 
> > At the same moment you are served, they take your stuff. No notice or opportunity to be heard pre-deprivation. After your stuff is taken you get a hearing as a defendant in a trial action for repossession. In the meantime, you have some recourse. The officer has to hold it for 3 days in which time you can reclaim possession by posting a security bond of DOUBLE the value. If you don’t post such a bond, you can only get the property back after final judgment in underlying action for repossession.

> [!note]+ Procedural History and Posture
> - District court rules for defendent
> - Appealed on whether replevin violates Due Process

> [!note]+ Holding (Stewart)
> - Summary- Replevin violates due process
>     - Here the key issue is the “meaningful time” requirement of DP (meaningful time, meaningful manner).
>     - Are the requirements that Defendant post a bond, make a conclusory allegation that property is his, pay damages if he is wrong, an adequate substitute?
>         - No, because that just tests the defendent’s conviction
>     - Didn’t she waive her procedural DP rights through the conditional sales contract?
>         - No, she didn’t read them or have reason to know what they were
>     - What are the “extraordinary situations” justifying actions?
>         - Basically the wrong can’t be undone (but can’t most wrongs?)
> - Disposition- Reversed and remanded

> [!note]+ Dissent (White)
> - Not in seller’s interest to make up false default. (really?)
> - What about Creditor’s interest in property protection? (preventing deterioration)
> - Easy to circumvent by contract (they can just be clearer about replevin)
