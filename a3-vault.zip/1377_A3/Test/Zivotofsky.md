---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Jerusalem Passports
Takeaway: President cannot be restricted regarding foreign affairs (here, at least, for recognition)
Tags: []
Category:
  - Con Law
Abstract: ""
Page: 851
Type: Case
Rating: "**"
Year: 2015
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Zivotofsky ex rel. Zivotofsky v. Kerry
Status: Annotated
Date: 2015-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Executive is careful about not recognizing Jerusalem as belonging to Israel
> - Congress passes a law overriding that policy, requiring President allow for recognition of Israel on passports
> - President signs it, but says it’s “advisory”
> - Z’s parents take him to the embassy, trying to get his passport to say “Jerusalem, Israel”.

> [!note]+ Procedural History and Posture
> - 

- Issue: Can Congress require the president to recognize another country?

> [!note]+ Holding (Kennedy): No
> - We’re in Jackson’s Category 3
> - Receiving ambassadors was originally something Hamilton thought was “without consequence”.
> - But Hamilton changed his mind, and the President has a bunch of powers saying that he has “exclusive” power over recognition
>     - Unilateral powers support this
>     - Functional considerations also support this
>     - In recognition the country must “speak with one voice”
>     - This would “aggrandize” Congress. 
> - If Congress could command the President to state a recognition inconsistent with his own, Congress would have the recognition power

> [!note]+ Dissent (Roberts): Yes
> - Receiving ambassadors is an obligation not an authorization, appearing alongslide *duties*, not *powers*. 
> - So he has authority over recognition, but not “conclusive and preclusive” power to defy a legislative mandate.





















