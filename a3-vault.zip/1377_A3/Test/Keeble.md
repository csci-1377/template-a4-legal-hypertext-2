---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Queen's Bench
Authors: ""
Title: Decoy Disturbance
Takeaway: Ratione Soli and Nuisance prevent disturbance
Tags:
  - Nuisance
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1809
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Keeble v. Hickeringill
Status: Annotated
Date: 1809-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Keeble has a duck decoy on his pond
> - Hickeringill keeps shooting near it to scare off the birds
> - Keeble sues
> - (Also, Hickeringill owns a decoy nearby and Keeble just built this one near it)

> [!note]+ Procedural History and Posture
> - Trial court awarded 20 pounds to plaintiff

> [!note]+ Holding (Holt)
> - Summary- Hickeringill is liable for the disturbance, not exactly for the damages (lost wildfowl)
>     - When one hinders another from their livelihood is through malice, then he is liable
>     - But not if he hindered by participating in some similar activity nearby
>     - It’s hard to tell injury here since Post never had the birds to begin with
> - Objections/replies-
> - Disposition

> [!note]+ Thoughts and Questions
> - Distinction between the law of the land and the moral law
> - Is this about ratione soli or nuisance?
> - If nuisance, how to determine when gravity of harm outweighs value of activity?
