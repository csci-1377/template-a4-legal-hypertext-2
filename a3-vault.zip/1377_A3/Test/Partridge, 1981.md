---
base: "[[Test.base]]"
In-Text Citation: (Partridge, 1981)
Priority: Essential
Authors: Partridge, Ernest
Title: Why Care About the Future?
Zotero URI: http://zotero.org/users/4316906/items/D2QJWCKA
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Blog Post
Rating: "***"
URL: www.igc.org/gadfly
Full Citation: "Partridge, E. (1981) ‘Why Care About the Future?’, The Online Gadfly. Available at: www.igc.org/gadfly."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1981
---
> [!note]+ Can we care about the remote future?
> - Concern of stability: our moral principles need to withstand the “strains of commitment” (ought implies can)
> - Yes, and failing to has a high cost. Those who don’t should not just be blamed but pitied

> [!note]+ Moral Psychology
> - Basic need for “self-transcendence”
> - Personal, social and moral reasons 
>     - **Show why this distinction is hard**
> - We just do care about communities, locations, ideals, causes, artifacts, institutions outside ourselves
> - “no man is an island”
> - Mead and Dewey
>     - The self has origin, nurture, and sustenance in social acts
>     - Defined and identified through social experience
>     - Even alone, we employ communal meaning and simulate sociality
>     - Those who claim total psychic and moral autonomy are decieved
> - Care for posterity is obvious when thought of not abstractly, but relationally
> 
> > Self transcendence becomes, then, not a moral desideratum but a basic fact of the human condition

> [!note]+ Supernova in 200 years
> - It seems like we care, and have a *reason* to care
> - In the stream of history, we are not only recipients but builders
>     - **Metaphor here is always in story, but story itself is no metaphor but the thing**

> [!note]+ Facts
> - We now have the power to affect the life prospects of prosperity and the ability to see it
>     - **This is what means we have reasons to care**
>     - **Is this an empirical or normative claim? Not clear, it seems to be both.**
>     - **Does this mean Hume’s claim only applies to pro toto, not pro tanto duties?**
>     - **Or is the sphere of story and reason just one that breaches the distinction?**
> - We honor wills and want our honored, and this would make no sense unless we valued beyond experience

> [!note]+ Import Transference
> - If a person feels something matters to him, he will also feel that it matters objectively and intrinsically
> - Concern: partial transference, like the miser. Has to regard as an intrinsic, good and desires its wellbeing for its own sake
> - **Difference is that the money becomes part of you, but you do not become part of it. Never adopt the Thou**

> [!note]+ Alienation
> - Man Alone (Eric and Mary Josephson
>     - displaced, thrown off balance, snapped ties around us,
>     - detached from nature, old gods, work, products, leisure, institutions, community
>     - from self, through body and sex, art and love
> - Fromm: does not experience himself as the active beater of his own powers and richness
>     - Replaceable, mechanized, impersonal
>     - Loss of control, indifference, apathy
> - Kenneth Kenniston (human wholeness)
>     - capacity for commitment, dedication, passionate concern, and care

> [!note]+ Narcissism
> - Lasch
>     - emptiness, inauthenticity, devaluation of others, lacking engagement
>     - parasitic with fear of emotional dependence,  manipulative
> - Fromm
>     - failure of relatedness
>     - solipsistic
>     - Opposite of objectivity, reason, and love
>         - **Not objectivity, instersubjectivity!**

> [!note]+ Recluse
> - Not alienated, members of intellectual community
> - marching to the beat of a different drummer, but still marching

> [!note]+ Playboy
> - Self-indulgent hedonist, but apparently cares about continuing legacy
> - Playboy foundation and philosophy
> - Is this becoming a part of something larger, or more like the miser?

> [!note]+ Paradox of Morality
> - We live best for ourselves when we live for the sake of others
> - **Not a paradox, and not about morality**
> - Not accepting the moral point of view for intrumental, contractarian reasons. This we can do, but not what this is talking about
> - Kenneth Boulding: welfare of individual depends upon identifying with others in a spatially and temporally extended community
> 
> > We need the future, *now*

> [!note]+ Really About Morality?
> - No, not a contractual agreement or obligation, rather we owe it to ourselves to be duty bound to posterity