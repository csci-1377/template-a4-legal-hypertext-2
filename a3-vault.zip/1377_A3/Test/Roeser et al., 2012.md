---
base: "[[Test.base]]"
In-Text Citation: (Roeser et al., 2012)
Authors: ""
Title: "Handbook of Risk Theory: Epistemology, Decision Theory, Ethics, and Social Implications of Risk"
Zotero URI: https://zotero.org/bmcanally21/items/W5687Q6L
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
URL: https://link.springer.com/10.1007/978-94-007-1433-5
Full Citation: "Roeser, S. et al. (eds) (2012) Handbook of Risk Theory: Epistemology, Decision Theory, Ethics, and Social Implications of Risk. Dordrecht: Springer Netherlands. Available at: https://doi.org/10.1007/978-94-007-1433-5."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
---
