---
base: "[[Test.base]]"
DOI: https://doi.org/10.1086/722120
In-Text Citation: (Grant, 2023)
Priority: Essential
Authors: Grant, James
Title: Moral Worth and Moral Belief
Zotero URI: http://zotero.org/users/4316906/items/AW4QTMIZ
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Journal Article
Rating: "*****"
URL: https://www.journals.uchicago.edu/doi/10.1086/722120
Full Citation: "Grant, J. (2023) ‘Moral Worth and Moral Belief’, Ethics, 133(2), pp. 216–230. Available at: https://doi.org/10.1086/722120."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
> [!note]+ Intro
> - Moral Worth: the extent to which a right action is “to one’s credit” or “reflects well on one’s character” or “praiseworthy”
> - Can be perfect or imperfect depending on presence of flaws
> - Can be more or less independently of any flaws (an imperfect heroic act can be more praiseworthy than a perfect ordinary one)
> - Test: whether any true completion of “it is to discredit that…”
> - Doing the right thing in the wrong speret is not reducible to doing it for the wrong reasons.

> [!note]+ Conceptual Space
> - Rightness Thesis: doing the right thing has moral worth if and only if you do it because it is right.
> - Coincidence Thesis: Doing the right thing has moral worth if and only if you do it for the reasons why it is right.
> - Belief Thesis: When you do the right thing, your moral beliefs make no difference to the moral worth of your act.
> - Author’s Position: Against the belief thesis without affirming the rightness thesis (having the right beliefs helps doing the right thing to be ‘in the right spirit’)

> [!note]+ Cases
> - Father: Will takes good care of his children. But he believes he has no moral obligation to do so. He thinks it is supererogatory. He thinks only mothers have an obligation to take care of children.
> > He sees himself as a volunteer. Morality sees him as a conscript.
> 
>     - Patriarchy: Like above, but from sexist, patriarchal culture where he is not blameworthy for the false belief
>     - Judgmental: Like above, but not about sexism but judging parents too harshely
>     - So basically, the act only looses moral worth if the belief reflects badly on the person
> - Promise-Keeper: Eric is a racist slaveholder. He frees his slave because he promised his abolitionist lover that he would do so and because his slave is a person. He believes that freeing his slave is right. But he believes he has no moral obligation to his slave to free him. He believes he only has a moral obligation to his lover to do so.
> - Huck: Helps Jim escape thinking it is wrong, despite seeing himself as having an obligation to help Jim. He just thinks the obligation is outweighed by the obligation to uphold property rights
>     - So it doesn’t support the coincidence thesis
>     - But also he is a child
>     - And he does something difficult, which can have a lot of moral worth even if imperfect.

> [!note]+ Thoughts
> - Praiseworthiness vs praiseworthiness for acting rightly
> - Underdetermines act here: Will makes food in a kitchen where he has not recently changed the smoke alarm, or prepares animal products for consumption…
>     - About relevance of this statement














