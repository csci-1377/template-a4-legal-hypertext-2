---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: "Right to Rental Renewal "
Takeaway: Indefinite terms are unenforceable
Tags:
  - Definiteness
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "**"
Year: 1981
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Joseph Martin, Jr. Delicatessen, Inc. v. Shumacher
Status: Annotated
Date: 1981-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - P signs five-year rental agreement with option to renew at a rate “to be agreed upon”
> - P wants to renew, D offers $900 per month, P’s appraiser says $545
> - Can’t agree, P sues for breach, requesting specific performance (trial determines reasonable rent)

> [!note]+ Procedural History and Posture
> - Trial court dismisses action for specific performance
> - Appellate division reverses, arguing that
> > "a renewal clause in a lease providing for future agreement on the rent to be paid during the renewal term is enforceable if it is established that the parties' intent was not to [109] terminate in the event of a failure to agree".

- Issue: How to construe a lease’s agreement to agree?

> [!note]+ Holding (Fuchsberg): Indefinite, therefore unenforceable
> - There is nothing in the contract showing an intent to be bound to agree
> - Especially in leases, precedent in commercial contracts that actions can specifiy otherwise ambiguous contract doesn’t apply
> 
> > It also follows that, before the power of law can be invoked to enforce a promise, it must be sufficiently <u>certain and specific</u> so that what was promised can be ascertained. Otherwise, a court, in intervening, would be imposing its own conception of what the parties should or might have undertaken, rather than confining itself to the implementation of a bargain to which they have mutually committed themselves. Thus, <u>definiteness</u> as to material matters is of the very essence in contract law. Impenetrable vagueness and uncertainty will not do.
> 
> > The concern is with substance, not form.
> 
> - Disposition: Reversed

> [!note]+ Concurrence (Meyer): Yes, but could have been otherwise
> - Possible that actions could specify lease, like in commercial transactions

- Concurrence/Dissent (Jasen): No, not if P could show entitlement to renewal
