---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: No Building on Beachfront
Takeaway: “Total wipeout” of value is a per se taking (ad hoc to hard edges)
Tags:
  - Regulatory Takings
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1992
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lucas v. South Carolina Coastal Council
Status: Annotated
Date: 1992-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - P buys two parcels to build houses on beachfront
> - Regulation prohibits construction on lots
> - P sues as taking

> [!note]+ Procedural History and Posture
> - TC rules regulation made property “valueless” without ability to build
> - State SC reverses, upholding regulation as designed to prevent “serious public harm”

- Issue: Is the regulation a taking?

> [!note]+ Holding (Scalia): Yes
> - Two cases to find per se taking (no ad hoc test)
>     - Permanent physical invasion
>     - Denying all economically beneficial/productive use of land 
>         - Denominator is parcel, maybe all lots in the neighborhood?
> - Confine the “exception” of the police power duty to compensate to common law nuisances
>     - But “nuisance” exception balloons here
> - Disposition: Reversed

> [!note]+ Dissent (Stevens): No
> - Reciprocity of Advantage here. Regulation is general, not “singling out” specific parcels to bear a burden (unlike Penn Central, where he joined dissent)