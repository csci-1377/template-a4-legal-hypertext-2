---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Deeds in a Grip
Takeaway: Test for delivery
Tags:
  - Gifts
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1936
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gilbert v. McSpadden
Status: Annotated
Date: 1936-01-01
Jurisdiction: Texas
---
> [!note]+ Facts
> - Parents make up land deeds for kids
>     - Consideration is “1$ and love and affection”
> - Years later before Christmas, Dad goes to visit kids, bringing deeds
> - He goes to bed and dies with deeds still in grip (briefcase)

- Issue: Did the dad transfer the deeds?

> [!note]+ Holding (Alexander): No
> > A deed does not become effective until it is delivered…delivery may be effected by any act or word manifesting an unequivocal intention to surrender the instrument so as to deprive the grantor of all authority ober it or of the right of recalling it
> 
> - There was no such delivery