---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Migratory Birds
Takeaway: Congress can pass otherwise unconstitutional laws if appropriate to enforce treaties and not contravening explicit Constitutional prohibition (Covert cabins to 10A violations pg 343). Might be overruled in next few years.
Tags:
  - Interpretation
  - 10A
  - TP
Category:
  - Con Law
Abstract: ""
Page: 340
Type: Case
Rating: "***"
Year: 1920
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Missouri v. Holland
Status: Annotated
Date: 1920-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress tries to regulate migratory birds: ruled unconstitutional
> - Migratory Bird Treaty Act agrees with Canada to protect migratory birds
> - Congress passes basically the same law again

- Issue: Can Congress enforce a treaty with a law that otherwise infringes on 10A?

> [!note]+ Holding (Holmes): Yes
> > The case before us must be decided in the light of our whole experience and not merely in that of what was said a hundred years ago… We must consider what this country has become in deciding what the Amendment (10A) has reserved.
> 
> - Gov’s Arg: if Congress can’t do it unaided, a treaty can’t do it.
> - If the treaty is valid, there can be no dispute about the validity of laws necessary and proper to carry them into execution.
> - If Congress can’t enforce treaties, then the system collapses.
> 
> > The treaty in question does not contravene any prohibitory words to be found in the Constitution. (leaves open later restriction in Covert to 10A).





















