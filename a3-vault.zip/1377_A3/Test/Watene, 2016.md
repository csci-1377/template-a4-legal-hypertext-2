---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/13600818.2015.1124077
In-Text Citation: (Watene, 2016)
Priority: Essential
Authors: Watene, Krushil
Title: "Valuing nature: Māori philosophy and the capability approach"
Zotero URI: http://zotero.org/users/4316906/items/5IF3839Q
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: Can the capability approach to well-being and development capture the way nature is valued within “Mātauranga Māori” (the philosophies of the indigenous peoples of Aotearoa/New Zealand)? This paper argues that current articulations of the capability approach, despite encouraging and requiring cross-cultural dialogue, are unable to include Māori values as they apply to nature. Māori values express a relationship with nature grounded in the physical and spiritual dimensions of “whakapapa” (genealogy). Such an approach di ers markedly from that which values nature in light of human agency (as Amartya Sen’s theory does) or dignity (as Martha Nussbaum’s theory does). For the purposes of this paper, this di erence highlights the need to create space for cross-cultural conversations which open up real opportunities for new ways forward. The capability approach helps to create the space needed for these conversations, but is unable to cover the ground required for their full expression. There is not enough breadth to guarantee a Māori voice within current articulations of the capability approach. There is a need for proponents of the capability approach to think beyond its limits in order to fully engage with those values yet to be fully considered within the capability framework.
Type: Journal Article
Rating: "**"
URL: https://www.tandfonline.com/doi/full/10.1080/13600818.2015.1124077
Full Citation: "Watene, K. (2016) ‘Valuing nature: Māori philosophy and the capability approach’, Oxford Development Studies, 44(3), pp. 287–296. Available at: https://doi.org/10.1080/13600818.2015.1124077."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2016
---
> [!note]+ Intro
> - Capability Theories cannot fully engage with Maori values
>     - They are concerned with what kinds of lives people live, what they can do or be
>     - Recognizes culture is a constitutive part of well-being and a constructive factor in how life is valued
> - **They just can’t take them on their own terms.  They can engage with them, though**

> [!note]+ Sen’s Capability Theory
> - No list: 
> - Four Spaces of Advantage
>     - Well-being (circular fucking argument)
>     - Agency (being able to pursue and realize goals one values)
>     - Freedom (real opportunity to accomplish)
>     - Achievement (what one actually accomplishes)
> - Some things are valueable which don’t contribute to well-being
> - List of well-being  capabilities can only be drawn from democratic deliberation
> - More important to ask who is making the list and how than ask what should go on it

> [!note]+ Sen’s Theory and the Natural World
> - valuable because of how it contributes to well-being and agency
> - Because it plays an important role in how aspects of well-being are understood, pursued, and realized
> - We can also value the natural world for reasons that have no direct benefit to anyone
> - Spotted owl can be valuable because of its relation to human agency

> [!note]+ Nussbaum’s Capability Theory
> - Based in Aristotelian conception of dignity
> - Innate dignity: proper to a given species?
> - List of capabilities: claims intuitive understanding will get us there.
> - Resources can be substituted
>     - **But stories can’t be. That is why things are intrinsically valuable, only when they have a story**
> - Leaves the natural world and non-human beings which lack agency in what seems an extremely vulnerable position
>     - **Yes! Maybe we have reasons to value them then, those reasons are relational still though!**
>     - **What we have reasons to value is a path-dependent question**

> [!note]+ Nussbaum And The Natural World
> - List of species included directly if they have the capacity of pleasure or pain, movement, emotion and affiliation, or reason…
> - Natural world is valuable because of the way it underpins the dignity of humans and non-humans

> [!note]+ Maori Values
> - Well-being is inseperable from the natural world
> - Creation narratives place everything in a single geneology
> - Fundamentally relational: all human beings, animals, and the natural world share a common origin, history, and future
> - Interdependence of all things
> - Belonging rather than having ownership over the land: just user rights
> - Human beings are only one part of the creation story
>     - **But they are the story-tellers. So value is still an expression of agency**
>     - **Given the story, value is derived in this way, but value really comes from the story**
> - Not enough scope to guarantee that Maori voices are heard
>     - No, there just isn’t the scope to guarantee that they are heard on their own terms. This would then be no substance ot a theory at all.