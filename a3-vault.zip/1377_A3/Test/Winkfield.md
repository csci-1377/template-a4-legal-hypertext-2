---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Postmaster Castaway
Takeaway: A bailee can sue even if not liable to the bailor
Tags:
  - Bailment
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1901
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: The Winkfield
Status: Annotated
Date: 1901-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Winkfield and Mexican crash off capetown
> - Mexican holding postmaster general with mail, some lost before boarding Winkfield
> - Winkfield admits liability for damages on Mexican
> - Postmaster general sues Winkfield as bailee of lost mail

> [!note]+ Procedural History and Posture
> - Lower court dismisses Postmaster’s motion

- Issue: Can a bailee sue even when he isn’t liable to bailor for lost item?

> [!note]+ Holding (Collins): Yes
> - Alternative: only recover for what he is liable to bailor for
>     - Suit is limited to two parties. Relation to bailor inadmissable
> - Right Prinicple: “as against a wrongdoer, posession is title”
>     - Once wrongdoer pays damages to bailee, not liable to bailor 
> - Hint: Postmaster likely only holds funds subject to claims by customers
> - Disposition: Reversed
