---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/2132326
In-Text Citation: (Lefevre, 1992)
Priority: Recommended
Authors: Lefevre, Stephen R.
Title: Review of On Reading the Constitution
Zotero URI: http://zotero.org/users/4316906/items/E95WMREC
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/2132326
Full Citation: "Lefevre, S.R. (1992) ‘Review of On Reading the Constitution.’, The Journal of Politics, 54(3), pp. 904–906. Available at: https://doi.org/10.2307/2132326."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1992
---
