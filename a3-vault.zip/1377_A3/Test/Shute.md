---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Cruising for Forum Selection
Takeaway: Forum selection clauses binding even with assymetric information
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1991
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Carnival Cruise Lines, Inc. v. Shute
Status: Annotated
Date: 1991-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Washington based plaintiffs slip and fall in a carnival cruise ship while it was off the coast of Mexico. The ship was boarded in LA. The fare was paid to Carnival HQ in Florida, and the tickets were sent to Washington. The tickets had language saying that 
> 
> Mrs. Shute boards in California, and while off the coast of Mexico, she slips on a deck mat and is injured and sues in Washington state.

- Issue: Are forum selection clauses enforceable, even with unilateral contracts and assymetric sophistication?

> [!note]+ Holding: Yes
> - We presume enforcment of forum selection clauses because they make tickets cheaper
> - Safety valve as to “fundamental fairness,” or are “unreasonable under the circumstances”
