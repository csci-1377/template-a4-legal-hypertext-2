---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Reconstruction Courts-Martial
Takeaway: Congress has a lot of power over courts to protect its own legislation (including removing appellate jurisdiction mid-case)
Tags:
  - ITC
Category:
  - Con Law
Abstract: ""
Page: 360
Type: Case
Rating: "***"
Year: 1869
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ex parte McCardle
Status: Annotated
Date: 1869-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress creates military tribunals to ensure possibility of convictions for Southerners murdering Black people
> - The decisions are appealable to the Supreme Court
> - McCardle, Mississippi newspaper editor, challenges conviction for libel for opposition of Reconstruction policies, appealing denial of writ of habeus corpus to SC
> - Congress repeals law allowing McCardle to appeal to SC

- Issue: Does the Supreme Court have jurisdiction to hear this case?

> [!note]+ Holding (Chief Justice): No
> - Congress has the “power to make exceptions to the appellate jurisdiction of this court”





















