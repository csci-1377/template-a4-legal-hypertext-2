---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Raising Taxes
Takeaway: Generally applicable rules are presumed fair if P can access political process to challenge
Tags:
  - DPC
Category:
  - Con Law
Abstract: ""
Page: 1059
Type: Case
Rating: "**"
Year: 1915
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Bi-Metallic Investment Co. v. State Board of Equalization
Status: Annotated
Date: 1915-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Denver now wants to raise property taxes
> - Someone challenges the new law

- Issue: Is the new law in violation of DPC?

> [!note]+ Holding (Holmes): No
> - Efficacy: there must be a limit to [individual argument in such matters] if the government is to go on.





















