---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Watergate Burglaries
Takeaway: (Vesting and Take Care Clause) Presidential material is “presumptively priveleged,” can be overcome by “a sufficient showing to rebut” in a criminal subpoena
Tags:
  - 6A
  - 5A
Category:
  - Con Law
Abstract: ""
Page: 731
Type: Case
Rating: "***"
Year: 1974
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: US v. Nixon
Status: Annotated
Date: 1974-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Nixon campaign burgles the DNC in the Watergate hotel
> - Congress conducts hearings, discovers that his office is bugged
> - Special counsel releases judicial subpoena for the tapes too
> - Nixon argues that his information should be priveleged

- Issue: Is the president’s information priveleged?

> [!note]+ Holding (Burger): To some extent, but not absolute
> - Pro Privelege: Presumption
>     - Important that president can speak candidly (without fear of taping etc.
>     - Would be weighty if protecting diplomatic secrets
>     - If subpoena is really broad
> - Anti Privelege: Yield to “demonstrated, specific need for evidence in a pending criminal trial” (when “essential” to justice of the case)
>     - We need a “workable government”
>     - Rule of Law
>     - No explicit reference to presidential privelege
>     - 6A right to be confronted
>     - 5A right to due process
>     - Take care and vesting clause





















