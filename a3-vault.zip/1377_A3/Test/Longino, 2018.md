---
base: "[[Test.base]]"
In-Text Citation: (Longino, 2018)
Priority: Recommended
Authors: Longino, Helen E.
Title: Chapter Six- Socializing Knowledge
Zotero URI: http://zotero.org/users/4316906/items/JXS4NW26
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: Chapter Six .Socializing Knowledge was published in The Fate of Knowledge on page 124.
Type: Book Section
URL: https://0.www.degruyter.com/document/doi/10.1515/9780691187013-007/html
Full Citation: "Longino, H.E. (2018) ‘Chapter Six- Socializing Knowledge’, in The Fate of Knowledge. Princeton University Press, pp. 124–144. Available at: https://doi.org/10.1515/9780691187013-007."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Up Next
Year*: 2018
---
