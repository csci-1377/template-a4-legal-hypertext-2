---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Alien Identification Cards
Takeaway: "Preemption (express, conflict, and field) Field: and state law cannot conflict with or complement a federal “comprehensive scheme”."
Tags:
  - SUP
  - FCC
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "**"
Year: 1941
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hines v. Davidowitz
Status: Annotated
Date: 1941-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 1939 Pennsylvania requires noncitizens to recieve “alien identification card”
> - Davidowitz, Hungarian national, sues arguing the law encroaches on federal power
> - 1940: Congress passes Alien Registration Act, but it’s different:
>     - No requirement card be shown to police
>     - Only wilfull failure to register is criminalized

- Issue: Is the state registration law precluded by the federal scheme?

> [!note]+ Holding (Black): Yes
> 1. Is the federal law a valid excercise of Congress’s constitutional power
>     1. Yeah, immigration is just a sovereign power: [[Chinese Exclusion Case]] 
>     - Congress is entrusted with interaction with foreign sovereignties
> 2. Is the state law an obstacle?
>     2. What are the “purposes and objectives of Congress”?
>         - Here the legislation was made to be a “harmonious whole” trying to “steer a middle path” and state is interfering with that
> > There can be no one crystal clear distinctly marked formula
>     3. Is the state law an obstacle to those objectives? (Yes)
> > Where the federal government… has enacted a <u>complete [comprehensive] scheme </u>of regulation… states cannot, inconsistently with the purpose of Congress, <u>conflict or interfere with, curtail or complement</u>, the federal law, or enforce additional or auxiliary regulations
>     - No state can add to or take away from the force of a valid federal statute
>     - Conflicting, contrary to, occupying the field, repugnance, difference, irreconcilability, inconsistency, violation, curtailment, interference…