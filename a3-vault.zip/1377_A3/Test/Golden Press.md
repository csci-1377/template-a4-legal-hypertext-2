---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Party Wall Battle 2
Takeaway: Injunction refused for good faith encroachment
Tags:
  - Good faith
  - Equity
  - Trespass
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1951
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Golden Press, Inc. v. Rylands
Status: Annotated
Date: 1951-01-01
Jurisdiction: Colorado
---
> [!note]+ Facts
> - Footing of building projects 2 inches onto land 7 feet below ground
> - It doesn’t really harm the plaintiffs in any way
> - Again, refused permission so would have to tear down wall

> [!note]+ Proceedural History
> - Plaintiffs want injunction
> - Jury finds for defendant
> - Court rules mandatory injunction

> [!note]+ Holding
> - “De minimis” harmless encroachment?
> - Test
>     - If this were willful, they repair regardless of expense
>     - But since it’s in good faith, we “weight the circumstances to not act oppressively” 
>     - But not a “balance of convenience”
>     - About grave, disproportionate hardship
> - We assume good faith unless proven otherwise
