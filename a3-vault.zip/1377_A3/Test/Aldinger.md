---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Third Party Suit (Civil Rights)
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Aldinger v. Howard
Status: Annotated
Date: 1976-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> Pl sues municipal officers for civil rights violations under a federal statute (42 U.S.C. § 1983) but also wants to sue the county as a defendant. At the time the law was that municipalities could not be sued under the federal §1983 statute, so could only bring state law claim against the county.
> 
> Wants to also sue county in federal court through pendent jurisdiction since they have FQSMJ over officers (there is a CNOF.)

> [!note]+ Procedural History and Posture
> - 9th Circuit finds no SMJ for county

- Issue: whether pendent jurisdiction extends to a (non-diverse) party without other basis for FSMJ

> [!note]+ Holding (Rehnquist): No, or at least it’s very difficult to do
> - It’s harder to pull in a third party under only state law than to pull in a state law claim between existing parties (distinguish from Gibbs)
>     - Factual
>         - Not the same as two parties trying to litigate another issue
>         - Bringing another third party in upsets “courts of limited jurisdiction” principle
>         - The principle of efficiency applies here, but not enough to justify this. (he could have the same efficiency in state court)
>     - Legal
>         - *Gibbs* was Art III construction, in this case we have a statutory structure.
> - In doing so, one needs to make sure Congress hasn’t denied jurisdiction (express or implied)
>     - Congress clearly did not want plaintiffs to be able to sue counties under Civil Rights Act in federal courts
>         - Like Merrell Dow: Because Congress didn’t provide independent right of action, they didn’t want a pendent party brought in (bad logic)
>     - Dictum about federal exclusive jurisdiction statutes.
>         - If the feds had exclusive jurisdiction it might be different, since that would be the only court where all the claims could be tried
> - Disposition: Affirmed
