---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Is It There → Is It Fair?
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 1945
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: International Shoe Co. v. Washington
Status: Annotated
Date: 1945-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Shoe, a Delaware company, hires salespeople to sell shoes
>     - Salespeople get sent a single shoe and reimbursed to rent showrooms
>     - No stock in Washington, no consistent premise
>     - This is all an attempt to pay employment tax
> - Washington issues employment tax to Shoe to fund unemployment compensation
> - Shoe refuses to pay
> - Washington serves process to salesman and mails to primary address
> - Shoe files for dismissal, saying Washington has no jurisdiction
> 
> > [!note]+ Glenn’s
> > Def is a Delaware corporation, that has a primary place of business in St Louis Missouri, manufactures in a number of different states and sales units too, but in Washington it has only salesmen.
> > 
> > It has no office in Wash and makes no contracts either for sale or merchandise there. It has no stock in hat state and makes no delivery of goods for interstate commerce.
> > From 1937-1940 it did have in place 11-13 salesmen who resided in Wash, but under the control of the St. Louis office. Their principal function was to sell in Wash and be compensated based on how much they sold. Those commissions were more than $31,000/yr. Shoe mails them samples with one pair for a shoe, which they show to prospective customers. Sometimes they rent sample rooms in business buildings or hotels temporarily for that purpose and the cost of those rentals are reimbursed by Shoe. They are not allowed to do anything but exhibit shoes, solicit orders from buyers on terms fixed by Shoe. They send their orders to Shoe. If Shoe accepts the orders are shipped from outside Washington into state. No Salesman has authority to enter into a contract or make collections from the customer.
> > 
> > Washington tries to collect employment compensation from Shoe: a tax on employers based on the employees’ amount of service in Washington, which goes to pay for unemployment insurance in Washington. The WA tax Commissioner has power to issue an order and notice of assessment of delinquent contributions. It does personal service if the employer is found within the state, if not by mailing it to his last known address. If the money is not paid within ten days he is authorized to collect by “distraint” = “ distress” = seizure of property.
> > 
> > In this case the assessment was both served on a salesman in Washington and also mailed to St. Louis.

> [!note]+ Procedural History
> - Starts in agency in Washington, not a court

- Issue: How can we decide whether a state has personal jurisdiction over a company based out of state?

> [!note]+ Holding (Stone): Minimum Contacts and Fair Play + Substantial Justice
> - We no longer need personal service, mail works well, so it’s easier to be sued out of state
> - Pennoyer tests won’t work: No presence, domicile, agent, or consent
>     - No more “capias ad respondendum” personal service or other form of notice
> - Rejection of corporate “presence” as a test.
> 
> > [!note]+ Minimum Contact (MC) and Fair Play/Substantial Justice (FPSJ)
> > - Def must have “certain minimum contacts” with the forum state “such that maintenance of the suit does not offend ‘traditional notions of fair play and substantial justice.’”
> > - “[T]hose demands may be met by such contacts of the corporation with the state forum as **make it reasonable**, in the context of the our federal system of government to require the corporation **to defend the particular suit** which is brought there. An **estimate of the inconveniences** which would result to the corporation from a trial away from its ‘home’ or principal place of business **is relevant** in the connection.”
> 
> > [!note]+ Reciprocity (privelege of acting within the state gives rise to related responsibilities)
> > - “to the extent that a corporation exercises the privilege of conducting activities within a state, it enjoys the benefits and protections of the laws of that state. The exercise of that privilege may give rise to obligations, and so far as those obligations arise out of or are connected to the activities within the state, a procedure which requires the corporation to respond to a suit brought to enforce them can, in most instances, hardly be said to be undue.”
> 
> > [!note]+ Spectrum of possible contacts with different PJ consequences:
> > - One pole: Assertion of jurisdiction would be unconstitutional, “the casual presence of the corporate agent or even his conduct of a single isolated items of activities in a state in the corporation’s behalf are not enough to subject it to suit on causes of action unconnected with the activities there.”
> > - *In the middle*: **Specific in personam jurisdiction**, look to the “quality and nature of the activity in relation to the fair and orderly administration of the laws which it was the purpose of the due process clause to insure.”
> > - Other pole: **General in personam Jurisdiction**: “continuous corporate operations within a state were thought so substantial and of such a nature to justify suit against it on causes of action arising from dealings entirely distinct from those activities.”
> 
> - Here, there are more than enough contacts, and the obligation is sufficiently related to the privelege enjoyed (tax for hiring salespeople)

> [!note]+ Concurrence? (Black): We shouldn’t limit taxing power just because it’s more “convenient” for corporations
> - The right test is just about service of process, not convenience of suit.
> - We should be using strict rules, not elastic standards

> [!note]+ Thoughts/Questions
> - Legal Formalism to Legal Realism: this requires a judgment call, and we care about doing justice, so we need a test that reflects that
