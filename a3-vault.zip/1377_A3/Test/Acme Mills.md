---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Switching Wheat Sales
Takeaway: Cap restitution at expectation damages
Tags:
  - Efficient Breach
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1911
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Acme Mills & Elevator Co. v. Johnson
Status: Annotated
Date: 1911-01-01
Jurisdiction: Kentucky
---
> [!note]+ Facts
> - D breaches contract for sale of wheat for $1.03. Sells it to another bidder for $1.16.
> - When supposed to go to Acme, D refused to provide it, but new price of wheat is <$1, so P gets it for cheaper. 
> - But P also gave D $80 worth of grain sacks to sell the wheat.
> - P argues: Defendent made an unjust profit, and it was technically their wheat, so they should get the profit from it.
> - D Argues: We’re trying to make the plaintiff as well off as if the contract had been fulfilled. They’re actually better off, so we’ve already met expectation damages

- Issue: Expectation or Restitution for Unjust Enrichment?

> [!note]+ Holding: Expectation, so no damages
> - Both parties are better off, so why compensate?