---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Battered Spouse → shot while sleeping
Takeaway: Sellf-defense requires D to reasonably perceive imminent harm
Tags:
  - Intentional Homicide
  - Self-Defense
Category:
  - Crim
Abstract: ""
Page: 557
Type: Case
Rating: "***"
Year: 1989
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Norman
Status: Annotated
Date: 1989-01-01
Jurisdiction: United States
---
> [!note]+ Facts: Absolutely unconscionable
> - 25-year marriage, where Judy was 15 and pregnant at the time of the marriage
> - Husband constantly beats and humiliates wife, police come twice
> - June 12: angrier and more violent than usual (really fucking awful), threatens to kill
> - Judy finds a gun, returns home and shoots him in the head while he sleeps

> [!note]+ Procedural History and Posture
> - Experts testifying about battered spouse syndrome
>     - Belief escape is not possible, batterer is all-powerful
>     - Can’t 
> - Trial court witholds self-defense instruction from jury
> - 

- Issue: Did trial court properly withhold self-defense instruction?

> [!note]+ Appeals Holding (Parker): No
> - Two elements
>     - Subjective belief: “D believe it <u>necessary</u> to kill… in order to safe herself from <u>imminent </u>death”
>     - Reasonability: “objhective standard of the person of ordinary firmness under the same circumstances.”
> - Battered spouse syndrome
>     - Can’t wait untill a deadly attack occurs, would ignore realities of condition
>     - V sleep was “but a momentary hiatus in a continuous reign of terror”
> - Disposition: 

> [!note]+ Supreme Holding (Mitchell): Yes
> - Defense is to safe oneself from *imminent *death or great bodily harm.
>     - *Imminent* “cannot be guarded against by callling for the assistance of others or the protection of the law.”
> - Otherwise “homicidal self-help would become a lawful solution, and perhaps the easiest and most effective solution, to this problem.”
> - Disposition: Reversed

> [!note]+ Dissent (Martin): No
> - The question isn’t whether the danger was *in fact* imminent, but was reasonably perceived to be so by D





















