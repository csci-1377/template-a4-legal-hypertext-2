---
base: "[[Test.base]]"
In-Text Citation: (Ripstein, 2006)
Priority: Essential
Authors: Ripstein, Arthur
Title: Beyond the Harm Principle
Zotero URI: http://zotero.org/users/4316906/items/9TPW7ELJ
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://www.jstor.org/stable/3876391
Full Citation: Ripstein, A. (2006) ‘Beyond the Harm Principle’, Philosophy & Public Affairs, 34(3), pp. 215–245.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2006
---
> [!note]+ Intro
> - Harm Principle: “The only purpose for which power can be rightly exercised over any member of a civilized community against his will, is to prevent harm to others.” -Mill
> - Commitment to individual sovereignty requires that we abandon this principle. **Yeah, because the principle is exclusive.**
> - Says the only way to unseat a principle is to provide an alternative. **How about a complement?**
> - Intuition Pump: harmless tresspasser naps in your bed. We should criminalize that, right?

> [!note]+ Sovereignty Principle
> - The only legitimate restrictions on conduct are those that secure the mutual independence of free persons from each (preventing domination)
> - Based on freedom as independence: if she, rather than anyone else, gets to decide how to use her powers.
> - Powers can be interfered with by usurping or destroying
> - But taxation isn’t this, because taxation is a prerequisite for a system of equal freedom.

> [!note]+ Questions
> - What about things that are painful but don’t really destroy or usurp any of your powers?

> [!note]+ Thoughts
> - We can have shared purposes, so the interest can’t be independence. Maybe agency, participation? (237)
> - This assumes a legitimate state, right? If not, no requirement to respect property rights.














