---
base: "[[Test.base]]"
DOI: https://doi.org/10.2307/3480280
In-Text Citation: (O’Fallon, 1980)
Priority: Recommended
Authors: O'Fallon, James M.
Title: "Review of Democracy and Distrust: A Theory of Judicial Review"
Zotero URI: http://zotero.org/users/4316906/items/Y5BLB36B
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/3480280
Full Citation: "O’Fallon, J.M. (1980) ‘Review of Democracy and Distrust: A Theory of Judicial Review’, California Law Review, 68(5), pp. 1070–1092. Available at: https://doi.org/10.2307/3480280."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1980
---
