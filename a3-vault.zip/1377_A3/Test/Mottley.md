---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: No More Free Passes
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1908
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Louisville and Nashville Railroad Company v. Mottley
Status: Annotated
Date: 1908-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Mottleys are injured on the railroad
> - They agree not to sue in return for free rides for life (renewed every year)
> - Congress passes law prohibiting free passes
> - Railroad refuses to renew, citing statute prohibiting free passes
> - Mottleys sue, saying: 
>     - 1) statute doesn’t prevent provision of these free passes
>     - 2) if it did, that would violate 5th Amendment due process rights
> 
> > [!note]+ Glenn’s
> > In 1871, Pls were riding Def’s railroad and were injured by railroad’s negligence. They signed a K in which they agreed to a release of their claims against railroad in exchange for free transportation all their lives. The railroad performs until January 1907, when they decline to renew their passes. The Railroad claims its refusal to renew was because of a Congressional Act in 1906 forbidding giving free passes. Pls sue in federal court, claiming: (1) The Congressional Act does not in fact forbid giving free passes, (2) if it does prevent doing so, it violates the 5th Amendment Due Process clause because it is a taking of Pl’s property without due process of law (and without compensation, see property class). Def files a demurrer. The Circuit court overrules the demurrer [**NB**: back then, Circuit courts were the trial courts.]

> [!note]+ Procedural History and Posture
> - Railroad files demurrer
> - Circuit (trial) court overruled demurrer and awards specific performance for plaintiff
> - Railroad appeals

- Issue: Did federal circuit court have jurisdiction to hear this case?

> [!note]+ Holding (Moody): No, it didn’t
> - Neither party raised the issue, but they don’t have to. We need to check ourselves.
> - Federal circuit courts are limited by statute. "suit . . . arising under the Constitution and laws of the United States.” (August 13, 1888, c. 866, 25 Stat. 433, 434.)
> - No diversity, so only federal smj gets us here.
> - Only way “arises under” is if plaintiff states in *well pled *cause of action 
> - And federal question only comes up in anticipating defenses
> - Disposition- Reversed, directed to dismiss for lack of smj

> [!note]+ Thoughts and Questions
> - This case gets sent to state court, then goes all the way back to Supreme on merits