---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: "Tricked out of Annuity "
Takeaway: Defines unconscionability
Tags:
  - Unconscionability
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1992
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Waters v. Min Ltd.
Status: Annotated
Date: 1992-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - P injured in car accident, settles claim, purchases annuity contract
> - Becomes involved with man who takes advantage of her, convincing her to sell contract (worth $189k cash and eventually $694k) in return for $50k.

> [!note]+ Procedural History and Posture
> - 

- Issue: Was this contract enforceable?

> [!note]+ Holding (Lynch): No
> > Unconscionability must be determined on a case-by-case basis, with particular attention to whether the challenged provision could result in oppression and unfair surprise to the disadvantaged party and not to allocation of risk because of "superior bargaining power.”
> 
> > If the sum total of the provisions of a contract drive too hard a bargain, a court of conscience will not assist its enforcement.
> 
> > "[C]ourts [may] avoid enforcement of a bargain that is shown to be unconscionable by reason of gross inadequacy of consideration accompanied by other relevant factors.” 1 A. Corbin, Contracts § 128, at 551 (1963 & Supp. 1991)
> 
> > "such as no man in his senses and not under delusion would make on the one hand, and as no honest and fair man would accept on the other.”
> 
> - Disposition: Affirmed