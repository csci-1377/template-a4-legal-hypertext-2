---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: McConaughey, Matthew
Title: Greenlights
Takeaway: ""
Tags: []
Category:
  - Memoir
Abstract: ""
Type: Audiobook
Rating: "****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2020
---
Be less impressed, more involved

When mortal rewards are no longer enough to pay his rent, man becomes legend
