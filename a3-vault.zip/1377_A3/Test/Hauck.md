---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Fraudulent Mineral Deeds
Takeaway: Certain Fraud Yields Void Title
Tags:
  - Nemo Dat
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1953
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hauck v. Crawford
Status: Annotated
Date: 1953-01-01
Jurisdiction: South Dakota
---
> [!note]+ Facts
> - Two men come by P (with eighth-grade education) house and contract for lease of some property
> - In the fine print and never discussed was signing over mineral rights
> - Men sell rights to buyer D in Texas
> - P sues in quiet title (really to set aside deed)

- Issue: Does this fraud void title?

> [!note]+ Holding (Rudolph): Yes
> - Fraud in the <u>inducement</u> yields voidable title
> - Fraud in the <u>factum </u>is like theft (like here)
>     - There was no owner negligence 
>     - Basically a forged deed
> - Owner negligence would generate estoppel from denying good faith purchaser for value
