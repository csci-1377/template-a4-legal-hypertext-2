---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Bad Mortgage Auction
Takeaway: Obligation of Due Diligence and Good Faith in Lender Fiduciary Duties
Tags:
  - Mortgages
  - Fiduciary Duties
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1985
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Murphy v. Financial Development Corp
Status: Annotated
Date: 1985-01-01
Jurisdiction: New Hampshire
---
> [!note]+ Facts
> - Murphy can’t pay mortgage, so house going to gets foreclosed
> - Lenders auction but don’t publicize, they’re the only buyers there, they bid roughly amount owed on mortgage (below asking price) then resold at higher price

- Issue: Do lendors owe P for rest of home value”

> [!note]+ Holding (Douglas): Yes
> - Fiduciary duty includes<u> good faith</u> and <u>due diligence</u>
>     - Due Diligence includes, but is not limited to, abiding by the statutory requirements
> - Remedy for failure of due diligence is <u>a fair price</u> - price awarded
> - Remedy for bad faith is <u>market value</u> - price awarded
> - Here only failure of due diligence, not good faith