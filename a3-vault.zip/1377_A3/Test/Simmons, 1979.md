---
base: "[[Test.base]]"
In-Text Citation: (Simmons, 1979)
Priority: Essential
Authors: Simmons, A. John
Title: Moral Principles and Political Obligations
Zotero URI: http://zotero.org/users/4316906/items/LJLBR2IG
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: Outlining the major competing theories in the history of political and moral philosophy--from Locke and Hume through Hart, Rawls, and Nozick--John Simmons attempts to understand and solve the ancient problem of political obligation. Under what conditions and for what reasons (if any), he asks, are we morally bound to obey the law and support the political institutions of our countries?
Type: Book
Rating: "***"
URL: https://www.jstor.org/stable/j.ctvzxx97q
Full Citation: "Simmons, A.J. (1979) Moral Principles and Political Obligations. Princeton University Press. Available at: https://doi.org/10.2307/j.ctvzxx97q."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1979
---
> [!note]+ Intro
> - Is there such a thing as political obligation?
> - If so, to whome is it owed
> - what is its content, 
> - and how does one come under it?

There is more in the further chapters, but nothing immediately relevant