---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Police Exams
Takeaway: P must show gov purpose was to discriminate based on race
Tags:
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1311
Type: Case
Rating: "***"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Washington v. Davis
Status: Annotated
Date: 1976-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Black police officers do worse on promotion test
> - They sue, arguing that test classifies on the basis of race

- Issue: Is this exam subject to strict scrutiny?

> [!note]+ Holding (White): Nope
> - Test Options
>     - Disparate Impact → Strict Scrutiny X
>     - DI → Gov must prove nondiscriminatory purpose X
>         - Assumes basically like the first
>     - P must prove discriminatory purpose √
> - P can’t bear their burden here. 





















