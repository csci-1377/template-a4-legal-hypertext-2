---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Rejecting Roe
Takeaway: Return to the Glucksberg test to deny the right to an abortion
Tags:
  - SDP
Category:
  - Con Law
Abstract: ""
Page: 167.1
Type: Case
Rating: "****"
Year: 2022
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Dobbs v. Jackson Women’s Health Organization
Status: Annotated
Date: 2022-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Mississippi law has civil penalties and liscense revocation for abortion providers
> - Mississippi petitions the Supreme Court to review its own law, which is clearly unconstitutional under Roe and Casey.

- Issue: Is the relevant right protected by sub DPC or EPC?

> [!note]+ Holding (Alito): No
> - Casey was focused on precedent, but did “a fair amount of overruling”
> 
> > time to heed the Constitution and return the issue of abortion to the people’s elected representatives.
> 
> - Lets use Glucksberg’s standard!
>     - Completely ignores Obergefell
> 1. Careful description: “right to obtain an abortion”
>     - It helps us avoid “freewheeling judicial policymaking”
> 2. History:
>     1. “liberty” won’t give us guidance: Isaiah Berlin “recorded more than 200 different senses in which the term as been used!”
>     2. Blackstone, etc. said banning abortion was fine
>     3. Most states had abortion bans after 14A was passed
>     4. We care most about what people thought they were doing when they passed that amendment
> - Equal Protection Violation? Nope.
> > Inquiries into legislative motives “are a hazardous matter.”
> - Rational Basis Test
>     - Relevant Interests
>         - respect for and preservation of prenatal life
>         - mitigation of fetal pain
>         - Practices Mississippi regards as “barbaric” (rejecting Lawrence)
>     - Don’t worry, we’re not overruling Obergefell…
>         - Because abortion is different: it involves “unborn life”

> [!note]+ Concurrence (Thomas): No, because there is no sub DPC!
> > “substantive due process” is an oxymoron.
> 
> - We should reconsider Griswold, Lawrence, and Obergefell
> - I’d be down to look at priveleges and immunities, but don’t know exactly what that would do.

> [!note]+ Dissent (Breyer, Sotomayor, Kagan): Yes!
> - Slippery slope! Soon they might be 
> 
> > Either the majority does not believe its own reasoning. Or if it does, all rights that have no history stretching back to the mid-19th century are insecure.
> 
> > [stare decisis] is a doctrine of judicial modesty and humility.
> 
> > The Court reverses today for one reason and one reason only: because the composition of this Court has changed.





















