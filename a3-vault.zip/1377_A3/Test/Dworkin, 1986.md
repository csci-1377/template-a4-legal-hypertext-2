---
base: "[[Test.base]]"
In-Text Citation: (Dworkin, 1986)
Priority: Recommended
Authors: Dworkin, Ronald
Title: "A Matter of Principle:"
Zotero URI: https://zotero.org/bmcanally21/items/D28NAE59
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: |-
  This is a book about the interplay of urgent political issues and hotly debated questions of moral philosophy. The controversies it joins are old; but history has given them fresh shape. For example, whether judges should and do make law is now of more practical importance than ever before, as recent presidents have appointed enough justices to the Supreme Court to set its character for a generation.
  With forceful style, Ronald Dworkin addresses questions about the Anglo-American legal system as protector of individual rights and as machinery for furthering the common good. He discusses whether judges should make political decisions in hard cases; the balancing of individual rights versus the good of the community; whether a person has the right to do what society views as wrong; and the meaning of equality in any framework of social justice. Dworkin strongly opposes the idea that judges should aim at maximizing social wealth. It is his conviction that the area of discretion for judges is severely limited, that in a mature legal system one can always find in existing law a “right answer” for hard cases.
  Dworkin helps us thread our way through many timely issues such as the rights and privileges of the press under the First Amendment. He reviews the Bakke case, which tested affirmative action programs. These essays also examine civil disobedience, especially in nuclear protests, and bring new perspective to the debate over support of the arts.
  Above all, this is a book about the interplay between two levels of our political consciousness: practical problems and philosophical theory, matters of urgency and matters of principle. The concluding essay on press freedom expands the discussion of conflict between principle and policy into a warning. Though some defenders of the press blend the two in order to expand freedom of speech, the confusion they create does disservice to their aim and jeopardizes the genuine and fragile right of free speech. We stand in greater danger of compromising that right than of losing the most obvious policy benefits of powerful investigative reporting and should therefore beware the danger to liberty of confusing the two. The caution is general. If we care so little for principle that we dress policy in its colors when this suits our purpose, we cheapen principle and diminish its authority.
Type: Book
Full Citation: "Dworkin, R. (1986) A Matter of Principle: Cambridge, MA: Harvard University Press."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1986
---
