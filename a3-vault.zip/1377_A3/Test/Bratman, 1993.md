---
base: "[[Test.base]]"
In-Text Citation: (Bratman, 1993)
Priority: Recommended
Authors: Bratman, Michael E.
Title: Shared Intention
Zotero URI: http://zotero.org/users/4316906/items/WQ4Y94K7
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
URL: https://www.jstor.org/stable/2381695
Full Citation: Bratman, M.E. (1993) ‘Shared Intention’, Ethics, 104(1), pp. 97–113.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1993
---
