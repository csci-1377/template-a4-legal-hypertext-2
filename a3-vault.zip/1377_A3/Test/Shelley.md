---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Enforcing Restrictive Covenants
Takeaway: Judicial enforcement of racially restrictive covenants violates EPC
Tags:
  - Covenants
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1948
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Shelley v. Kraemer
Status: Annotated
Date: 1948-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - In 1911, 30 of 39 property owners sign a racially restrictive covenant for the next 50 years, agreeing to let only Caucasians buy in the area, intending it to go into effect when all sign on (5 current owners are Black)
> - In 1945, Shelley family, who are black, buy one of the houses from an owner, not knowing about the covenant.
> - Owners of houses in covenant sue in Circuit court of St. Louis trying to take title from Shelleys

> [!note]+ Procedural History and Posture
> - Trial court denies on ground that covenant was only meant to go into effect when everyone signed on
> - Supreme Court of Missouri reverses en banc
> - Shelleys appeal, arguing EP, DP, and PI of 14th

- Issues: 1) Does judicial enforcement of racially restrictive covenants constitute state action? 2) If so, does this violate the Equal Protection Clause of the 14th Amendment?

> [!note]+ Holding (Vinson): Yes to both
> 1. The covenants themselves aren’t unconstitutional, but judicial enforcement is
> > [14th] Amendment erects no shield against merely private conduct, however discriminatory or wrongful.
> 
>     - State action is equally repugnant to 14th when by judges as by statute
> 2. This deprives citizens of property rights on the basis of race, which is a precondition for other basic civil rights
> > A ***substantive*** common-law rule… may result in the denial of rights guaranteed by the Fourteenth Amendment even though the judicial proceedings in such cases may have been in complete accord with the most rigorous conceptions of ***procedural*** due process. 
> - BUT the courts are ready to exclude whites too!
>     - They’ve never done so, and even if they did that wouldn’t help
> > Equal protection of the laws is not achieved through indiscriminate imposition of inequalities
> - Disposition: Reversed
