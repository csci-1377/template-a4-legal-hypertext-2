---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Kicking Out Harlem Senator
Takeaway: No extra-constitutional qualifications for Congress
Tags:
  - NLP
Category:
  - Con Law
Abstract: ""
Page: 606
Type: Case
Rating: "**"
Year: 1969
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Powell v. McCormack
Status: Annotated
Date: 1969-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Senator from Harlem accused of corruption
> - Congress votes to exclude him from sitting in Congress
> - Sues seargent at arms for failing to give him salary
> - Argues Congress improperly excluded him

- Issue: Can Congress exclude members for suspected corruption?

> [!note]+ Holding (Warren): No
> - Reconstruction suggests that power to exclude is broad
> - But there are good democratic reasons to prevent exclusion
> - So Court will 





















