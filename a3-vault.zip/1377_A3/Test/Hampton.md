---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Executive Adding Its Two Cents
Takeaway: ""
Tags:
  - Nondelegation Doctrine
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "*****"
Year: 1928
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: J.W. Hampton Jr. & Co. v. United States
Status: Annotated
Date: 1928-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Tarriff Act, Section 315, authorizes president (Tarriff Commission) to adjust duties fixed by statute to “equalize” the differences in costs of production 
>     - Lays out 4 factors in making determination
> - Customs collector assesses barium dioxide tarrifs at 2 cents per pound higher than statute says (6, not 4)

- Issue: What can Congress Constitutionally Delegate?

> [!note]+ Holding (Taft): Specification of principles, not “legislative power”
> > If Congress shall lay down by legislative act an <u>intelligible principle</u> to which the person or body authorized to [take some regulatory action] is directed to conform, such legislative action is not a forbidden delegation of <u>legislative power.</u>
> 
> - Congress makes plan, executive carries out
> - Congress can’t transfer its “legislative power”
> - But, may leave specification of policies dependent on future conditions to executive

> [!note]+ Thoughts
> - Intelligible principle can’t be the only standard. Otherwise, a thin normative term could work (eg good policy).
