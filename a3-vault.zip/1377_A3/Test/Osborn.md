---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Constitutionality of a Bank’s Constitution
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1824
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Osborn v. Bank of United States
Status: Annotated
Date: 1824-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - States don’t like BoUS, tax punitively
> - Osborn (Ohio auditor) tries to collect tax from BoUS
> - BoUS sues in federal court, claiming tax unconstitutional

> [!note]+ Procedural History and Posture
> - BoUS receives temporary injunction
> - Osborn forcibly collects anyway
> - Court orders return of tax
> - Osborn argues they can’t, no SMJ

- Issue: What is the Constitutional maximum for FQSMJ?

> [!note]+ Holding (Marshall): Any case where plaintiff or defendant *might* argue or rely on federal law.
> - Did Congress grant it? Yes, clearly
> - Can they grant it? 
>     - Article III gives jurisdiction to all cases “arising under laws of US”
>     - Does this question do that? Because it’s mostly state law and general principles
>         - Yes, because it involves a constitutional question 
>         - And also because the Bank itself is a federal legal entity, so any questions involving it involve federal law
>         - Otherwise original jurisdiction wouldn’t mean anything: there are always other principles/laws involved.

> [!note]+ Thoughts and Questions
> - Marshall expands constitutional federal question SMJ by considering any entity created by Congress as adding **federal ingrediant** for FQSMJ. So any plaintiff or defendent relying on federal law can be given federal question SMJ by Congress, even if that law isn’t really at issue in the case.
> - Congress can confer jurisdiction over any cases where federal law *might *be an issue… but it actually prescribes more narrowly.