---
base: "[[Test.base]]"
In-Text Citation: (Hayward, 2022)
Priority: Essential
Authors: Hayward, Max Khan
Title: Yes We Can! Propaganda, Ideology, and the Rationality of Collectively Self- Rationalising Beliefs.
Zotero URI: http://zotero.org/users/4316906/items/8VYPMHA9
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: ""
Type: Journal Article
Rating: "***"
Full Citation: Hayward, M.K. (2022) ‘Yes We Can! Propaganda, Ideology, and the Rationality of Collectively Self- Rationalising Beliefs.’, p. 16.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
