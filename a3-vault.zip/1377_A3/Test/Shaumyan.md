---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Further
Court: Appeals
Authors: ""
Title: Storm Windows Attached to Home
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1993
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Shaumyan v. O’Neill
Status: Annotated
Date: 1993-01-01
Jurisdiction: Second Circut
---
> [!note]+ Facts
> - Shaumyans refused to pay increased cost of storm windows
> - Sidetex company attaches to home through prejudgment
> - Shaumyans sue, arguing unconstitutionality under Doehr

> [!note]+ Procedural History and Posture
> - District court finds constitutional (pre-Doehr)
> - Doehr is decided
> - Case is appealed
> - Remanded in light of Doehr
> - District court affirms earlier decision upholding constitutionality (against SC)

> [!note]+ Holding
> - Summary- Yeah, we distinguish
>     - About real property seeking payment for material and labor performed on that property
> - Disposition- Affirmed
