---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: District
Authors: ""
Title: Forward Coke Contracts
Takeaway: Expectation for breached forward contract is sum of individual purchases, not later forward contract
Tags:
  - Expectation
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1881
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Missouri Furnace Co. v. Cochran
Status: Annotated
Date: 1881-01-01
Jurisdiction: Pennsylvania
---
> [!note]+ Facts
> - Contract to provide coke at $1.20 per ton over a year
> - Repudiates (breaches) after providing a bit
> - Plaintiff makes new contract with 3p at $4 per ton over year for remainder
> - Price of coke falls to $1.30 per ton
> - Suit for difference between contract prices

> [!note]+ Procedural History and Posture
> - 

- Issue: How to calculate expectation for forward contracts?

> [!note]+ Holding: Sum of individual purchases, not later forward contract
> - Breach for forward contracts where there is not general necessity for such contracts is calculated at the rate for market value on each individual day rather than that of a new forward contract (only more when individual price falls rapidly)