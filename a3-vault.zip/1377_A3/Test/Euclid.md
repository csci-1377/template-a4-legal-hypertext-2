---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Land Use Hierarchy
Takeaway: Green Light to Zoning
Tags:
  - Zoning
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1926
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Village of Euclid v. Ambler Realty Co.
Status: Annotated
Date: 1926-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Ambler challenges Euclid’s zoning laws with a constitutional challenge (substantive due process and equal protection)
> - Zoning laws are cumulative (ranks of uses where higher numbers cant go in lower numbered zones)

- Issue: Is the zoning law valid?

> [!note]+ Holding (Sutherland): Yes
> - State interest in promoting safety and security
> - Apartment buildings are “parastites” (offensive and exclusionary)