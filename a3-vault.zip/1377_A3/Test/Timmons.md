---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Landlocked Lakeside
Takeaway: Easement by Implication and Necessity Denied
Tags:
  - Easements
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1999
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Schwab v. Timmons
Status: Annotated
Date: 1999-01-01
Jurisdiction: Wisconsin
---
> [!note]+ Facts
> - P owns parcel granted from US with other lakeside owners
> - P has access to a road from part of property (on bluff)
> - P sells the part with the road
> - Private road runs to D’s, but not P’s place below bluff
> - P sues for access to private road (declaration of easement by implication or necessity)

> [!note]+ Procedural History and Posture
> - TC denies on both theories

- Issue: Does P have an easement by implication or necessity?

> [!note]+ Holding (Wilcox): No
> - Implication: must be from prior transfers, and no prior transfers are relevant here (when US transferred to D, P still had access via bluff road)
> - Necessity: not applicable, since could get from tract they sold
> - Disposition: Affirmed