---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Clear, James
Title: Atomic Habits
Takeaway: ""
Tags: []
Category:
  - Self-Help
Abstract: ""
Type: Audiobook
Rating: "****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2018
---
## Four Rules

- Cue: make it obvious
- Craving: make it appealing
- Response: make it easy
- Reward: make it satisfying

Format: I will ___ at _____ in _____

Habit Stacking: After ___ (habit I already have), I will ____ (habit I want to develop)

This works with good, neutral, and bad habits. For good, try to create a solid stack. For neutral, use them as an anchor for a good stack. For bad, use desire for bad as cue, then shift to the new habit.

Create friction for bad habits (phone in another room until lunch etc) and reduce friction for good habits (journal on pillow)

### Two Minute Rule: 

Make each anchoring habit take less than two minutes (six words about the day, just tie running shoes, etc.) Stop before it feels like work. Make a firm distinction between this and what follows. This is the habit, what follows are decisions you make after. Master the former before focusing on the latter. Standardize before you optimize.

Use technology to automate your habits when possible (alarm clock).

Create an immediate reward, or an immediate contribution to a reward, that aligns the identity the habit promotes

### Never miss twice. 

Make the cost of bad habits public and painful

You have to fall in love with boredom

Atomichabits.com/cheatsheet