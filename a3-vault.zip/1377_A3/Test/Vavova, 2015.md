---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phc3.12194
In-Text Citation: (Vavova, 2015)
Priority: Recommended
Authors: Vavova, Katia
Title: Evolutionary Debunking of Moral Realism
Zotero URI: http://zotero.org/users/4316906/items/GC5LPJ8A
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: Evolutionary debunking arguments move from a premise about the influence of evolutionary forces on our moral beliefs to a skeptical conclusion about those beliefs. My primary aim is to clarify this empirically grounded epistemological challenge. I begin by distinguishing among importantly different sorts of epistemological attacks. I then demonstrate that instances of each appear in the literature under the ‘evolutionary debunking’ title. Distinguishing them clears up some confusions and helps us better understand the structure and potential of evolutionary debunking arguments.
Type: Journal Article
Rating: "***"
URL: http://0.onlinelibrary.wiley.com/doi/abs/10.1111/phc3.12194
Full Citation: "Vavova, K. (2015) ‘Evolutionary Debunking of Moral Realism’, Philosophy Compass, 10(2), pp. 104–116. Available at: https://doi.org/10.1111/phc3.12194."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2015
---
> [!note]+ Intro
> - Debunkers argument is either a reductio of realism or a scientifically backed argument for skepticism
> - Must ve empirical, targeted, and epistemological to be more like the optometrist than the skeptic in telling you you are misperceiving color
> - Skeptic puts the burden on you for saying why you are wrong, the debunker takes it upon themselves.
> - Debunker not trying to show that realist moral knowledge is impossible, just improbable

> [!note]+ The Debunking Argument
> 1. Realism: Moral truths are attitude-independent.
> 2. Influence: Evolutionary forces have influenced our moral beliefs.
> 3. Off-track: Evolutionary forces aim at fitness, not attitude-independent moral truths.
> 4. Gap: The fitness enhancing beliefs and the moral truths come apart.
> 5.  Mistaken: We have good reason to think that our moral beliefs are mistaken.

> [!note]+ Why Responses are Hard
> - We might be able to assume that there are moral truths, but it seems like maybe we can’t make substantial assumptions about their content without begging the question

> [!note]+ Minimalist Response
> - Survival is good: see Enoch 2011
> - Pain is bad: Evolutionary forces select for creatures good at surviving. Such creatures will be good at avoiding pain. But pain is bad, so evolution has selected creatures with tendencies or judgments that track this.
> - Third factor accounts can be rescued if we can show that we are entitled to certain starting assumptions

> [!note]+ Thoughts
> - 108: To reject realism is to give up. Is it?













