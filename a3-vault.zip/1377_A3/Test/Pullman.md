---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Coop Crazy Guy
Takeaway: Business Judgment Rule applied to cooperative action
Tags:
  - Cooperative
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 2003
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: 40 West 67th St. v. Pullman
Status: Annotated
Date: 2003-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - D moves into P exclusive coop, starts feud with professor and wife upstairs
> - Does a bunch of crazy stuff
> - P votes to terminate D from coop on grounds of “objectionable” behavior, more than 75% approve
> - D refuses to leave, P sues to cancel his shares and eject him

- Issue: How should we review coop decision?

> [!note]+ Holding (Rosenblatt): Deferentially (Business Judgment Rule
> - **Business judgment rule applies** to board decisions as opposed to landlord-tenant law.
>     - **Court will not reassess board’s decision unless**:
>         - (1) outside scope of authority
>         - (2) not legitimately furthering the corporate purpose
>         - or (3) in bad faith.
>     - **Note: **Burden of proof shifted from landlord to tenant
> - Disposition: 