---
base: "[[Test.base]]"
In-Text Citation: (Lemos, 2009)
Priority: Recommended
Authors: Lemos, Noah
Title: Epistemology and Ethics
Zotero URI: http://zotero.org/users/4316906/items/5JWDNSMK
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: This article suggests that moral epistemology is mainly concerned with “whether and how one can have knowledge or justi ed belief” about moral issues. It presents and replies to several problems that arise in this connection. It addresses arguments for ethical skepticism, the view that one cannot have moral knowledge or justi ed belief. Assuming that one can have moral knowledge, this article considers how the moral epistemologist and moral philosopher should begin their account of this knowledge. It favors a particularist approach whereby the instances of moral knowledge are given and used to formulate criteria for moral knowledge. It relates this approach to concerns about the nature of the epistemic justi cation of moral beliefs as dealt with by foundationalists and coherentists. Finally, this article concludes by responding to arguments against particularist approaches in moral epistemology.
Type: Book Section
Full Citation: Lemos, N. (2009) ‘Epistemology and Ethics’, in, p. 24.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2009
---
