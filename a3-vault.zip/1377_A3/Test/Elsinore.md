---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Clerical Error
Takeaway: ""
Tags:
  - Mistake
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1960
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Elsinore Union Elementary School District of Riverside County v. Kastorff
Status: Annotated
Date: 1960-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - P calls for bids for construction K
> - D makes honest clerical error in bid
>     - First plumbing bid 9k (never added)
>     - Second 6k
>     - Took 3k off price (so 9k short)
>     - Basically never included plumbing
> - P accepts 90k bid
> - D promptly rescinds
> - P takes next lowest bid (102k)
> - Sues for 12k difference
> - And surety?

> [!note]+ Procedural History and Posture
> - Trial finds for P
>     - P never knew bid was low
>     - Wouldn’t be unfair to make D responsible

- Issue: Is contract promptly recinded after discovery of honest error binding?

> [!note]+ Holding (Schauer): No
> - Under [[Drennan]] he should have been bound to follow through.
> - Unusual example of unilateral mistake allowing for decision
>     - Honest
>     - Not negligent
>     - Quickly inform
>     - No reliance
> - He didn’t neglect legal duty
> - Omission was material
> - Disposition: Reversed
