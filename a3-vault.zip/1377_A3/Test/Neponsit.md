---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Common Interest Dues
Takeaway: Covenants to pay money touch and concern the land (function over form)
Tags:
  - Covenants
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1938
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Neponsit Property Owners Association v. Emigrant Industrial Savings Bank
Status: Annotated
Date: 1938-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - P is property owners association of common interest community
> - D is bank that has aquired deed of unit, doesn’t want to pay for CIC dues
> - P sues

- Issue: Is the covenant to pay dues enforceable?

> [!note]+ Holding (Lehman): Yes
> - Use of public areas is appurtenant to ownership of the estate.
> 
> > In substance if not in form the covenant is a restrictive covenant which touches and concerns the defendant’s land, and in substance, if not in form, there is privity of estate between the plaintiff and the defendant.