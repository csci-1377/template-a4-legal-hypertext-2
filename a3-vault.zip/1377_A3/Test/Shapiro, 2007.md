---
base: "[[Test.base]]"
DOI: https://doi.org/10.2139/ssrn.968657
In-Text Citation: (Shapiro, 2007)
Priority: Essential
Authors: Shapiro, Scott J.
Title: "8.1- The Hart-Dworkin Debate: A Short Guide for the Perplexed"
Zotero URI: https://zotero.org/bmcanally21/items/S5AJ4HDL
Takeaway: ""
Tags:
  - Dworkin
  - Hart
  - Interpretation
  - Jurisprudence
  - Legal Positivism
  - Natural Law
Category:
  - Dissertation
Abstract: For the past four decades, Anglo-American legal philosophy has been preoccupied - some might say obsessed - with something called the "Hart-Dworkin" debate.  Since the appearance in 1967 of "The Model of Rules I," Ronald Dworkin's seminal critique of H.L.A. Hart's theory of legal positivism, countless books and articles have been written either defending Hart against Dworkin's objections or defending Dworkin against Hart's defenders.  My purpose in this essay is not to declare an ultimate victor; rather it is to identify precisely the core issue around which the debate is organized.  Is the Hart-Dworkin debate, for example, about whether the law contains principles, as well as rules?  Or does it concern whether judges have discretion in hard cases?  Is it about the proper way to interpret legal texts in the American legal system?  Or is it about the very possibility of conceptual jurisprudence?
Type: Preprint
Rating: "****"
URL: https://papers.ssrn.com/abstract=968657
Full Citation: "Shapiro, S.J. (2007) ‘8.1- The Hart-Dworkin Debate: A Short Guide for the Perplexed’. Rochester, NY. Available at: https://doi.org/10.2139/ssrn.968657."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2007
---
> [!note]+ Nature of the Debate
> - Relationship between legality and morality
> - Is legality determined by social facts alone, or also moral facts?
> - Dworkin: Yes
> - Hart: no, or at least not finally. 
> - Shapiro: “Moral facts cannot ultimately determine the law, as I will show, because they would unsettle the very questions that the law aims to resolve.” (6)

> [!note]+ Dworkin’s Critique: Model of Rules
> - The law is not just rules as all or nothing standards (conclusive and can’t conflict)
> - It is also principles, which have weight and require judgment
> - So strong discretion (looking beyond the law and using extralegal standards) isn’t engaged, but weak, using judgment is

> [!note]+ Positivist’s Response
> - Model of Rules
>     - I never meant rules in the way you’re talking about.
>     - But judges are employing strong discretion, because social guidance is indeterminate.
>     - Language has an open texture, so it won’t always be clear whether certain standards apply
> - Exclusive Legal Positivists
>     - these norms do have social foundations, so they aren’t ultimately moral
>     - Or, judges are under a legal obligation to apply extralegal standards, but that doesn’t bring morality into the law
> - Inclusive Legal Positivists
>     - Separability Thesis: No necessary connection between law and morality
>     - Social Fact Thesis: Legal facts are grounded in social, not moral facts

> [!note]+ Dworkin’s Second Critique: Law’s Empire
> - Legal practice is argumentative (13)
> - Argument concerns both propositions and grounds of law (4)
> - Propositions are true or false in virtue of grounds of law
> - Disagreement can be of two kinds
>     - Do grounds of law obtain (empirical)
>     - What are the grounds (theoretical)
> - Legal positivists can’t account for theoretical disagreement in the law (plain fact view)
> - Theoretical disagreements in the law are prevalent
> - Positivism is false
> - Interpretation is instead constructive (52)

> [!note]+ Positivist’s Response
> - These people are actually disagreeing about what the law ought to be
> - Concealing the legislative nature of their actions
> - But legal theorists also do this, its unclear how everyone could be mistaken
> - Need to respond not only to moral grounds of law (Model of Rules) but to disagreement about their content (Law’s Empire)
> - But said little in actual defense of the new claim

> [!note]+ Shapiro’s Response
> - Basically, reject the plain fact view and accept purposive interpretation
> - But then look for social facts to define the purpose (some kind of framer’s intent)
> - hinges on the claim that the ideological objectives of the designers of an institution must have been to settle certain questions
> 
> > deference to the ideology of designers is necessary if designers are to do their job, which is to settle questions about which specific objectives the group should pursue. (46)
> 
> - But designers create ways to structure the continual navigation of the questions, not settle them

> [!note]+ Quotes
> > a theory of law should account for the intelligibility of theoretical disagreements, not necessarily provide a resolution of them (52)

> [!note]+ Thoughts
> - No judge has strong discretion in hard cases. They are on PANELS!
> - Go to constructivism in morality as a way to explain a potential Hart/Dworkin debate solution
> - Dworkin tries to explain how the law is partially grounded in moral facts, so the best method of interpretation is whatever best approximates those grounds, and thus is instrumental.
> - But if it is grounded not in moral facts, but moral method, in particular a discursive method, then the method becomes subject to appropriate constraints.
> - Law is grounded in a social and moral process…

> [!note]+ Further Reading
> - Function of Law
>     - Law’s Empire, 93
>     - Concept of Law, 249