---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Who Gets the Farm
Takeaway: Estate system interpreted
Tags:
  - Estates
  - Numerus Clausus
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1993
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Williams v. Estate of Williams
Status: Annotated
Date: 1993-01-01
Jurisdiction: Tennessee
---
> [!note]+ Facts
> - Will of GA Williams says three daughters get farm to live on unless they marry until death. 
> - Unclear what happens to the farm after they die.

> [!note]+ Proceedural History and Posture
> - Trial court holds each daughter has 1/3 undivided fee simple
> - Appeals affirms

- Issue: What are the interests at stake?

> [!note]+ Holding (Ried): A whole bunch
> - Each named daughter has 
>     - a life estate, defeasible upon marriage
>     - An executory interest in other daughter’s interests
>     - Heirs have reversion in fee simple subject to life estates and executory interest of daughters
>     - Reversion is, at latest, when final daughter dies.
> - Disposition: Modified
