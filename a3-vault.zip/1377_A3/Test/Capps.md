---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Borrower Holdout
Takeaway: In Oregon, if its severe enough, borrower bargaining counts as duress
Tags:
  - Duress
  - Unconscionability
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1969
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Capps v. Georgia-Pacific Corp.
Status: Annotated
Date: 1969-01-01
Jurisdiction: Oregon
---
> [!note]+ Facts
> - Creditor is in a rough patch
> - borrower offers 5k on 157k debt
> - Creditor accepts

- Issue: Is this contract binding?

> [!note]+ Holding: No, it’s not
> - 
> - Disposition: 