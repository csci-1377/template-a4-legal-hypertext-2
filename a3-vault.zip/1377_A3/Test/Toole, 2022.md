---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/phc3.12885
In-Text Citation: (Toole, 2022)
Priority: Recommended
Authors: Toole, Briana
Title: Objectivity in feminist epistemology
Zotero URI: http://zotero.org/users/4316906/items/5WKQ4H2J
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: It used to be that the touchstone of objectivity was the elimination of subjective features, like our values, biases, assumptions, and so on. Part of what motivates this narrow conception of objectivity is the thought that objective reality is the way that it is regardless of our relationship to it, and that our ability to accurately describe or depict this reality is distorted by this relationship. But what if that understanding is wrong, and removing these features takes us farther away from truth and knowledge, rather than closer to them? This is the claim I advance. In this article, I trace this narrow conception to its political origins, and advance a broader understanding of objectivity that reimagines a new use for, rather than ignoring entirely, features that are thought to be subjective.
Type: Journal Article
URL: https://onlinelibrary.wiley.com/doi/abs/10.1111/phc3.12885
Full Citation: "Toole, B. (2022) ‘Objectivity in feminist epistemology’, Philosophy Compass, 17(11), p. e12885. Available at: https://doi.org/10.1111/phc3.12885."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2022
---
