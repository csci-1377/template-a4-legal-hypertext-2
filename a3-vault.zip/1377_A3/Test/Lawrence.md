---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Lending Chain
Takeaway: 3rd Party Intended Beneficiaries can Sue
Tags:
  - Beneficiary
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 1859
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lawrence v. Fox
Status: Annotated
Date: 1859-01-01
Jurisdiction: New York
---

> [!note]+ Facts
> - Lawrence lends $300 to Holly, who lends it to Fox, who agrees to pay Lawrence
> - Fox doesn’t pay Lawrence

> [!note]+ Procedural History and Posture
> - Trial Court finds for Lawrence

- Issue: Can Lawrence sue Fox?

> [!note]+ Holding (Gray): Yes
> - There was consideration
> - Could Holly even release the other guy of the obligation to pay?
> - Disposition: Affirmed

> [!note]+ Dissent (Comstock): No
> - There must be privity of contract
> - Yes, Holly could have asked for the money back to himself!