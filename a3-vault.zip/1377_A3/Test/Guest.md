---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: KKK Act
Takeaway: "*Nearly* Overruling State Action Doctrine"
Tags:
  - 14A
Category:
  - Con Law
Abstract: ""
Page: 503
Type: Case
Rating: "***"
Year: 1966
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Guest
Status: Annotated
Date: 1966-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Black military reserve officer murdered driving between states by members of the KKK. 
> - They are aquitted in Georgia by an all-white jury.
> - KKK Act of 1871 prohibits conspiracy to “injure, oppress, threaten, or intimidate any citizen” of their constitutional rights.
> - Federal government indicts these guys under the KKK Act.

- Issue: Is the KKK Act constitutional?

> [!note]+ Holding (Stewart): Yes, even if state action is “peripheral”
> - This section is just about incorporating the EPA, not looking at how it can be expanded?
> - We’re still on board with the state action doctrine
> - But the state involvement need not be either “exclusive or direct”. Could be “peripheral”
> - But here there was direct state action, so we don’t even need to go there.

> [!note]+ Concurrence (Clark +2): Yes, and overrule Civil Rights Cases
> > §5 empowers aCongress to enact laws punishing all conspiracies—with or without state action—that interfere with Fourteenth Amendment rights.

> [!note]+ Concurrence/Dissent (Brennan +2): Yes, and majority overrules here!
> > A majority of the Court today rejects [the Civil Rights Cases’] interpretation of §5





















