---
base: "[[Test.base]]"
In-Text Citation: (Alexander and Kessler Ferzan, 2019)
Authors: ""
Title: The Palgrave Handbook of Applied Ethics and the Criminal Law
Zotero URI: https://zotero.org/bmcanally21/items/EC6KW7FZ
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Type: Book Section
URL: https://link.springer.com/10.1007/978-3-030-22811-8
Full Citation: "Alexander, L. and Kessler Ferzan, K. (eds) (2019) The Palgrave Handbook of Applied Ethics and the Criminal Law. Cham: Springer International Publishing. Available at: https://doi.org/10.1007/978-3-030-22811-8."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
---
> [regarding taking on a client who wants you to help him do something immoral] If they already took the case, they will probably be found guilty of not heeding the duty of zealous representation, and if they decline to take it because of what it entails, as just not being properly respectful of the professional ideal of taking on all clients one is competent to represent. 696. 