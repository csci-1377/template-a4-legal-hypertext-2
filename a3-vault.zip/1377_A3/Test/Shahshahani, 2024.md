---
base: "[[Test.base]]"
In-Text Citation: (Shahshahani, 2024)
Authors: Shahshahani, Sepehr
Title: "When Hard Cases Make Bad Law: A Theory of How Case Facts Affect Judge-Made Law"
Zotero URI: https://zotero.org/bmcanally21/items/GFJARB8N
Takeaway: ""
Tags:
  - common law process
  - Equity
  - hard cases
  - hard cases make bad law
  - judicial lawmaking
Category:
  - Topics in Law and Philosophy
Abstract: "“Hard cases make bad law” is one of the most famous aphorisms in Anglo-American law.  Its insight is that when strict application of a generally sound law would impose a special hardship on someone, a court may be tempted to distort the law to avoid the hardship.  Scholars have long debated the meaning and truth of the aphorism, but the debate has suffered from an imprecise conceptualization of what makes a case “hard.”  This lack of precision limits our ability to disentangle and work through the important questions the aphorism raises about how the facts of a particular case affect judge-made law.This Article introduces a mathematical model of adjudication that precisely defines the different ways in which a case might be “hard” and derives the conditions under which a court confronting a hard case may make bad law.  The model helps us see that hard cases explain a surprising array of existing legal doctrines, and it shows how the institutional design of the legal system can exacerbate or ameliorate the tendency of hard cases to make bad law.Specifically, the model demonstrates how hard cases may have distorted not just discrete rules but entire fields, like trademark genericide and Fourth Amendment law.  And it shows that certain seemingly unconnected judicial practices—writing unpublished opinions, limiting and distinguishing precedent, liberally construing pleadings, and avoiding cases based on procedural technicalities—can be understood as strategies to guard against hard cases making bad law.  The analysis also has three broader institutional implications.  First, it shows that the main virtue of equity is not to protect particular parties from hardship, as conventionally supposed, but to protect the law from being distorted in order to protect parties from hardship.  Second, it demonstrates how strong remedies can backfire by leading a court to shortchange the underlying right for fear of having to apply the remedy in a hard case.  Finally, it shows that strict standing doctrine can distort substantive law by channeling lawmaking to hard cases.  In all three contexts, my theory helps us see beyond familiar tradeoffs:  given the tendency of hard cases to make bad law, the real alternative to a flexible-but-uncertain system may not be an inflexible system of generally good rules but rather an inflexible system of bad rules."
URL: https://papers.ssrn.com/abstract=4738245
Full Citation: "Shahshahani, S. (2024) ‘When Hard Cases Make Bad Law: A Theory of How Case Facts Affect Judge-Made Law’. Rochester, NY: Social Science Research Network. Available at: https://papers.ssrn.com/abstract=4738245 (Accessed: 17 November 2024)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
---
> the intuitive essence of the aphorism: when a case presents a special hardship, the court is tempted to vary a generally sound law to avoid the hardship, resulting in a law that, though perhaps fine for the case at hand, is unsound as a general rule of conduct. (6)

> Bryan Garner says the “catchphrase refers to the danger that a decision operating harshly on the
defendant may lead a court to make an unwarranted exception or otherwise
alter the law.” BRYAN G ARNER , G ARNER ’ S D ICTIONARY OF L EGAL U SAGE 403 (3d ed. 2011)

> Judicial usage, then, suggests two senses of a “hard” case:
first, a case that poses a special hardship; second, a case that is particularly
important. (9)