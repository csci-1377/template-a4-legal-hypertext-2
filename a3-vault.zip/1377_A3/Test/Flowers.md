---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Dropped in the Gutter
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 2006
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Jones v. Flowers
Status: Annotated
Date: 2006-01-01
Year*: 2006
Jurisdiction: United States
---
> [!note]+ Parties
> - Jones, Arkansas property owner
> - Flowers, purchaser of reposessed home

> [!note]+ Facts
> - Jones doesn’t pay property tax on home he doesn’t live in
> - Commissioner tries to notify by mailing letter that needs signature
> - It is returned undelivered after 3 unsuccessful attempts
> 
> > [!note]+ Glenn’s
> > Jones (petitioner) buys a house, pays off mortgage, moves to apartment. He fails to pay his property taxes on his house. State mails him a certified letter at his house, his registered address, telling him to take steps to redeem his property or it would be up for public sale in two years. In fact, Jones failed to update his registered address as per state law. No one is home to sign for certified letter and no one appears to claim it from post office within 15 days. The unopened letter is returned to state Commissioner as “unclaimed.” Two years later Commissioner publishes notice of public sale in local newspaper. No bids were submitted so state negotiates a private sale, and Flowers submits a purchase offer. Commissioner once again mails Jones to say if he does not pay back taxes the house will be sold, once again returned as “unclaimed.” After a 30 day post-sale redemption period passes, property is delivered to Flowers. Jones finds out and sues commissioner claiming a taking of property without due process of law. Trial Ct says notice was adequate. Arkansas S. Ct. affirms. Cert to U.S. S. Ct.

> [!note]+ Relief Sought
> - An opportunity to be heard regarding the house?

> [!note]+ Strongest P Argument
> - He should have looked address up in the phone book
> - Or mailed by uncertified mail

> [!note]+ Strongest D Argument
> - Jones was obligated to notify of an updated address.

> [!note]+ Holding (Roberts)
> - Failure of notice in a specific case does not establish the inadequacy of the attempt
> - Not following up on unclaimed letter is like watching one fall down stormdrain and not providing a new one to the postman.
> - They could have sent it without needing signature
> - So there were available methods that they didn’t take

> [!note]+ Disposition
> Arkansas Supreme Court reversed

> [!note]+ Dissent (Thomas)
> This is basically overturning Dunesbery, getting close to requiring actual notice.

> [!note]+ Questions
> - What is the defense for why following up on an undelivered letter is necessary, but looking them up in the phonebook isn’t?
