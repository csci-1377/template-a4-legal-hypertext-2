---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/02691728.2011.652211
In-Text Citation: (Anderson, 2012)
Priority: Recommended
Authors: Anderson, Elizabeth
Title: Epistemic Justice as a Virtue of Social Institutions
Zotero URI: http://zotero.org/users/4316906/items/S9Y53MHJ
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
  - Normative Analysis
Abstract: In Epistemic injustice, Miranda Fricker makes a tremendous contribution to theorizing the intersection of social epistemology with theories of justice. Theories of justice often take as their object of assessment either interpersonal transactions (specific exchanges between persons) or particular institutions. They may also take a more comprehensive perspective in assessing systems of institutions. This systemic perspective may enable control of the cumulative effects of millions of individual transactions that cannot be controlled at the individual or institutional levels. This is true not only with respect to the overall distribution of such goods as income and wealth, but also with respect to the goods of testimonial and hermeneutical justice. Cognitive biases that may be difficult for even epistemically virtuous individuals to correct on their own may be more susceptible to correction if we focus on the principles that should govern our systems of testimonial gathering and assessment. Hence, while Fricker’s focus on individual epistemic virtue is important, we also need to consider what epistemic justice as a virtue of social systems would require. My paper will indicate some directions forward on this front, focusing on the need for integration of diverse institutions and persons engaged in inquiry.
Type: Journal Article
URL: https://doi.org/10.1080/02691728.2011.652211
Full Citation: "Anderson, E. (2012) ‘Epistemic Justice as a Virtue of Social Institutions’, Social Epistemology, 26(2), pp. 163–173. Available at: https://doi.org/10.1080/02691728.2011.652211."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2012
---
