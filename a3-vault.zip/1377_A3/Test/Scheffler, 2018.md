---
base: "[[Test.base]]"
In-Text Citation: (Scheffler, 2018)
Priority: Essential
Authors: Scheffler, Samuel
Title: Why Worry About Future Generations
Zotero URI: http://zotero.org/users/4316906/items/VJAYWWB4
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: ""
Type: Book
Rating: "****"
Full Citation: "Scheffler, S. (2018) Why Worry About Future Generations. 1st edn. Oxford, UK: Oxford University Press."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2018
---
- Benificence: utilitarian sympathy?
- Love: direct concern for survival of humanity
- Interest: value here an now compromised by disappearance

> [!note]+ Valuation
> - The survival of so much we care about depends on it
> - Sometimes we care about tokens, sometimes types (Shiffrin)
> - Sometimes we value things that are essentially ephemeral
> - Not only will the *valuable* disappear, but also the *valuing*

> [!note]+ Reciprocity
> - Assymetrical dependance, theirs is causal, ours is evaluative
> - We depend on them because our confidence in the value of our activities impliticly depends on our confidence in their survival
> - Two ways
>     - Belief: our emotional equanimity
>     - Itself: underwrites actual value with reasons for confidence
> - Their most important contribution is not causal but rational
> - Not just terminological, we really are mutually dependent
> - We tend to assume infinite continuity of humanity even if we don’t see it

> [!note]+ What Kinds of Reasons?
> - Not necessarily moral, but might be
>     - What morality requires is far from clear
>     - Too single-minded of a focus on obligation, fail to notice the remarkable diversity of reasons we have
> - Don’t get caught up with benificence, gets us tied up in population ethics
>     - “puzzle loving discipline like philosophy” only attracted more attention to the quest for solutions
> - All that matters is we have them, and they have genuine normative force
>     - Means we can violate it and we can recognize violations of it
> - Invites us to reflect in a more open-ended way
> - Allows our politics to not only be left at the mercy of uncertain motivational power of sympathy
> - We shouldn’t allow our quest for a master principle to dictate the form our thinking should take

> [!note]+ Conclusion
> - We should not take our temporal parochialism at face value
> - Don’t suppose we are simply indifferent to the fate of future generations
> - Our values presuppose human continuity into the future
> - We already care about the survival of future generations
> - We need to allow ourselves to acknowledge this to draw the appropriate practical conclusions