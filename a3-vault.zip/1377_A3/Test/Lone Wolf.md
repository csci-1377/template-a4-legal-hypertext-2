---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Fee Simple Division
Takeaway: (Congress legislates over tribes)
Tags:
  - 5A
  - PQ
  - ICC
Category:
  - Con Law
Abstract: ""
Page: 394
Type: Case
Rating: "**"
Year: 1903
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lone Wolf v. Hitchcock
Status: Annotated
Date: 1903-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Policy divides up reservation land and sells it to individuals, bribes tribe members with US citizenship, has low consent threshold.
> - Prior treaty requires three quarters of adult men to assent
> - One of the leaders of the Kiowa objects, saying 5th Amendment violation

- Issue: 

> [!note]+ Holding (White): 
> - Treaty Issue: Last in time rule (Congress can always abrogate treaties if it wants to)
> - 5A (taking of property w/o DP): Power over tribal relations is plenary and has always been a political question





















