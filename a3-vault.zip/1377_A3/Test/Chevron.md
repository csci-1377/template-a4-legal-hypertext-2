---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Bubble Pollution
Takeaway: 2 Part Permissible Construction Test.
Tags:
  - Agency Deference
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "*****"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Chevron, U.S.A. Inc, v. Natural Resources Defense Council, Inc.
Status: Annotated
Date: 1984-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Clean Air Act Amended 1977, requires permits for “new or modified major stationary sources” of air pollution in non-attainment zones.
> - EPA regulation defines “stationary source” as a point source (each smoke stack)
> - EPA issues a new regulation redefining as all sources in the same industrial grouping, a “bubble concept”
> - Respondents file for review in DC Circuit

> [!note]+ Procedural History and Posture
> - DC Circuit sets aside regulation
> - States that the bubble concept is “innappropriate” in programs enacted to improve air quality

- Issue: What is the proper standard of review for agency interpretation?

> [!note]+ Holding (Stevens): Two-part permissible construction test
> 1. Has Congress directly spoken on the precise question at issue?
>     1. No, Congress did not address it.
>     - Statutory Language: does not decisively resolve (step 1)
>     - Legislative History: silent
> 2. If so, is the agency’s interpretation a “permissable (or reasonable) construction” of the statute?
>     2. There could be more than one, and it might not be the one we would pick
>     3. Yes, the agency balanced the economic and environmental interests contemplated in the statute
>     - Agency interprets “in the context of implementing policy decisions in a technical and complex arena”
>     - We, by contrast, are mere generalists… (humility?)
>     - Decisisions involve reconciling conflicting policies
>     - Agency may properly rely “upon the incumbent administration’s views of wise policy to inform its judgments” 
> 
> > Federal judges—who have no constituency—have a duty to respect legitimate policy choices made by those who do.
> 
> - Agency consistency test out the window (agency has consistently interpreted it flexibly)
> - Disposition: Reversed