---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Suing own state
Takeaway: 11A bars citizens to sue their own state unless they consent (including by suing you)
Tags:
  - A3
  - 11A
Category:
  - Con Law
Abstract: ""
Page: 913
Type: Case
Rating: "***"
Year: 1890
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Hans v. Louisiana
Status: Annotated
Date: 1890-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Hans (Louisianan) sues Louisiana

- Issue: Can citizen sue their own state?

> [!note]+ Holding (Bradley): No
> - ~~Text~~: Well, it reads to only prohibit suits from citizens of another state.
> - Purpose: The language here was written because of Chisholm, but it was adopted because people didn’t like the states being sued.
> - Historical Practice: There was a “shock of surprise” throughout the country when Chisholm came out.
> - Absurdity: “It is an attempt to strain the Constitution and the law to a construction never imagined or dreamed of.”
> - Alternate opportunity: you can just break the law and get prosecuted, then the state has consented to be challenged (in federal court)





















