---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: No Machine Guns in Bolivia
Takeaway: Executive has extremely broad foreign affairs powers different from domestic ones
Tags:
  - NDD
  - A2
Category:
  - Con Law
Abstract: ""
Page: 828
Type: Case
Rating: "**"
Year: 1936
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: US v. Curtiss-Wright Export Corp
Status: Annotated
Date: 1936-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - [[Panama Refining]] holds NDD
> - Congress passs law enabling President to criminalize arms dealing to Paraguay or Bolivia
> - He does
> - Export corp sells machine guns anyway, prosecuted
> - Corp lawyers argue NDD

- Issue: Can the President regulate foreign affairs without a standard?

> [!note]+ Holding (Sutherland): Yes
> - Creation Myth
>     - Internal Affairs: enumerated powers from the states
>     - Foreign Affairs: inherent sovereign powers from the Crown
> > Sovereignty is never held in suspense
> 
> > External soveriegnty did not depend on the affirmative grants of the Constitution… inherently inseperable from the concept of nationality.
> - NDD doesn’t apply to delegations of *foreign relations *because President doesn’t need statutory authority in the first place. Congress isn’t delegating anything.
> - Broad interpretation of [[Chinese Exclusion Case]] 
> - Pragmatic Concerns
>     - Avoid embarrasment through discretion
>     - President better knows the situation
>     - Country needs to speak with “one voice” which is the President
> - Historical Practice
>     - Congress “requests” furnishing info on foreign affairs, directs in all other cases
> > Unbroken legislative practice which has prevailed almost from the inception of the national government to the present day… stady stream for a century and a half
> 
> > practical construction of the constitution, as given by so many acts of Congress, and embracing almost the entire period of our national existence…





















