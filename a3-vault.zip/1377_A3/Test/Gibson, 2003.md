---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/1468-5930.00232
In-Text Citation: (Gibson, 2003)
Authors: Gibson, Kevin
Title: "Contrasting Role Morality and Professional Morality: Implications for Practice"
Zotero URI: https://zotero.org/bmcanally21/items/GUX8AAA5
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: The notion of role morality suggests individuals may adopt a different morality depending on the roles they undertake. Investigating role morality is important, since the mentality of role morality may allow agents to believe they can abdicate moral responsibility when acting in a role. This is particularly significant in the literature dealing with professional morality where professionals, because of their special status, may find themselves at odds with their best moral judgments. Here I tell four stories and draw out some distinctions. I conclude that role morality is a genuine and useful distinction. However, I suggest that the purported distinction between role morality and professional morality is over-determined. Therefore, alleged conflicts between the demands of role and profession (such as the different pressures on Pinto designers as employees and as engineers) are not conflicts between different kinds of demands, but rather conflicts arising from divergent roles that most workers will encounter regularly. Another analytical perspective is to look at moral choices at work in terms of power and the ability to bring about change. Finally, I draw the implication that we should stress moral awareness at a fairly abstract level for all employees and reinforce the moral primacy of individual choice.
Type: Journal Article
URL: https://onlinelibrary.wiley.com/doi/abs/10.1111/1468-5930.00232
Full Citation: "Gibson, K. (2003) ‘Contrasting Role Morality and Professional Morality: Implications for Practice’, Journal of Applied Philosophy, 20(1), pp. 17–29. Available at: https://doi.org/10.1111/1468-5930.00232."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
---
- One view compartmentalizes moral spheres, arguing that we can “cleanly switch” between them. 20. 
- Another view rejects any moral differentiation, and thus role morality as a project.  

> The essential nature of a profession is to provide service to individuals, but more importantly, to society as a whole [5]. Professional codes may occasionally override individual interests but this may be justified on the basis of the overall good [6]. 22. 

> They perform a “public function.” 22. 

> It is not the fault of any creed, but of the complicated nature of human affairs, that rules of conduct cannot be so framed as to require exceptions, and that hardly any kind of action can safely be laid down as either always obligatory or always condemnable . . . There exists no moral system under which there do not arise unequivocal cases of conflicting obligation. These are the real difficulties, the knotty points both in the theory of ethics and in the conscientious guidance of personal conduct. They are overcome practically, with greater or less success, according to the intellect and virtue of the individual [emphasis added] [10]. Mill. 

> Luban format:
> (a) justifies the institution by demonstrating its moral goodness (b) justifies the role by appealing to the structure of the institution (c) justifies the role obligations by showing that they are essential to the role (d) justifies the role act by showing that the obligations require it. 24. 

> The key element is that the individuals feel morally constrained by their roles, and the issue can be complicated if the individual has multiple roles. In all cases, the person has to make a personal interpretation of what is morally correct. This can be influenced by professional or employer guidelines, but ultimately the decision is the responsibility of the individual. 26. 
