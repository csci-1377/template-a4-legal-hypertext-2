---
base: "[[Test.base]]"
In-Text Citation: (Simmons, 2010)
Priority: Recommended
Authors: Simmons, A. John
Title: Ideal and Nonideal Theory
Zotero URI: http://zotero.org/users/4316906/items/8Y5MM4PY
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "***"
URL: https://www.jstor.org/stable/40468446
Full Citation: Simmons, A.J. (2010) ‘Ideal and Nonideal Theory’, Philosophy & Public Affairs, 38(1), pp. 5–36.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2010
---
The requirement that nonideal policies be "likely to be successful" requires that we know how to measure success; and that measure makes essential reference to the ultimate target, the ideal of perfect justice (34)

To dive into nonideal theory without an ideal theory in hand is simply to dive blind, to allow irrational free rein to the mere conviction of injustice and to eagerness for change of any sort (34)

In other words, which of two smaller "peaks" of justice is the higher (or more just) is a judgment that matters conclusively only if they are both on equally feasible paths to the highest peak of perfect justice. And in order to endorse a route to that highest peak, we certainly do need to know which one that highest peak is. Perhaps for a while we can just aim ourselves in the general direction of the Himalayas, adjusting our paths more finely - between Everest and K2, say - only when we arrive in India. But we need to know a great deal about where to find the serious candidates for the highest peak before we can endorse any path to them from here (35)















