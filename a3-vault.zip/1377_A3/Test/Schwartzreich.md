---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Increasing Pay
Takeaway: A contract can be modified without consideration to promisee if first is voided and new one is substituted.
Tags:
  - Modification
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1921
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Schwartzreich v. Bauman-Basch
Status: Annotated
Date: 1921-01-01
Jurisdiction: New York
---

> [!note]+ Facts
> - Employee gets better offer, 
> - Employer agrees to increase pay, giving new contract
> - Employee works for a while, then leaves
> - Employer sues to get higher pay back.

> [!note]+ Procedural History and Posture
> - TC: Modification invalid
> - Appeals: Valid, since first contract was voided

- Issue: Can a contract be modified without an increased benefit to one party?

> [!note]+ Holding (Crane): Yes
> - So long as the first contract is mutually agreed to be null and void, and a new one is made in its place.
> - Disposition: 