---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: District
Authors: ""
Title: Definition
Takeaway: Mens Rea Means We’re “Evolved”
Tags:
  - Mens Rea
Category:
  - Crim
Abstract: ""
Page: 161
Type: Case
Rating: "***"
Year: 1993
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Cordoba Hincapie
Status: Annotated
Date: 1993-01-01
Jurisdiction: New York
---
> [!note]+ Holding (Weinstein): Defining Mens Rea
> - Ancient English Law had strict liability for acts
> - Comes from the concept of moral guilt
> - Attempt to refine moral blameworthiness





















