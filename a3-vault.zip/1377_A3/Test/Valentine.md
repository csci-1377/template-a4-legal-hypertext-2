---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Don’t Do Distressing Damages
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Valentine v. General American Credit, Inc.
Status: Annotated
Date: 1984-01-01
Jurisdiction: Michigain
---
> [!note]+ Facts
> - Valentine has an employment specifying no termination without cause
> - The contract is terminated without cause
> - She sues for breach of contract, including mental distress consequential damages and exemplary damages

> [!note]+ Procedural History and Posture
> - Decided on summary judgment in district court against mental distress and exemplary damages
> - Affirmed by Circuit Court

> [!note]+ Arguments
> - Claimants- Hadley v. Baxendale says we should recover what’s reasonably foreseeable
> - Respondents- This just isn’t the actual legal standard

> [!note]+ Holding
> - Summary- You can’t generally recover mental distress damages for breach
>     - First, this is a contracts case, not torts. No general right to employment
>     - Hadley is too slippery to be useful
>     - All breaches cause some distress, the problem is it can’t be easily calculated
> > The law does not generally compensate for all losses suffered
> > - No attorney’s fees, mental anguish, cost of performance
> 
>     - Exceptions
>         - Personality (the point of the contract is made to avoid a particular annoyance or to confer enjoyment or secure protection of personal interests)
>         - Indequacy of other compensation (market value of breach can’t be measured)
>     - Also, for exemplary…
> > may not be awarded in common-law actions brought for breach of a commercial contract. (Kewin)
> - Disposition- Affirmed

> [!note]+ Thoughts and Questions


> [!note]+ Class Notes

