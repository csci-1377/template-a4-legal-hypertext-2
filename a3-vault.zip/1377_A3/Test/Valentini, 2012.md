---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1747-9991.2012.00500.x
In-Text Citation: (Valentini, 2012)
Priority: Recommended
Authors: Valentini, Laura
Title: "Ideal vs. Non-ideal Theory: A Conceptual Map"
Zotero URI: http://zotero.org/users/4316906/items/NYHABGUR
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: "This article provides a conceptual map of the debate on ideal and non-ideal theory. It argues that this debate encompasses a number of different questions, which have not been kept sufficiently separate in the literature. In particular, the article distinguishes between the following three interpretations of the ‘ideal vs. non-ideal theory’ contrast: (i) full compliance vs. partial compliance theory; (ii) utopian vs. realistic theory; (iii) end-state vs. transitional theory. The article advances critical reflections on each of these sub-debates, and highlights areas for future research in the field."
Type: Journal Article
Rating: "***"
URL: https://0.onlinelibrary.wiley.com/doi/abs/10.1111/j.1747-9991.2012.00500.x
Full Citation: "Valentini, L. (2012) ‘Ideal vs. Non-ideal Theory: A Conceptual Map’, Philosophy Compass, 7(9), pp. 654–664. Available at: https://doi.org/10.1111/j.1747-9991.2012.00500.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2012
---
- End State vs Transitional Theory
    - Ideal theory sets out a long-term goal for institutional reform, while non-ideal theory ‘asks how this long-term goal might be achieved, or worked toward, usually in gradual steps’ (Rawls 1999b: 89)
    - So some (Simmons) argue that it presupposes ideal theory
    - But others (Sen) end-state theory isn’t necessary or sufficient for transitional theory