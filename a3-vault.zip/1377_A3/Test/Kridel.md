---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Landlord Non-Mitigation
Takeaway: Landlord has the duty and burden to prove mitigation (but not in commercial leases)
Tags:
  - Leases
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1977
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Sommer v. Kridel
Status: Annotated
Date: 1977-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - D enters 2-year lease with P
> - D pays first months rent and security deposit
> - D’s marriage called off, can no longer afford, asks to be released
> - P no response, turns away interested person (D’s friend?)
> - P finally leases over year later
> - P sues D for unpaid rent ignoring OG deposit, over 5k

> [!note]+ Procedural History and Posture
> - 

- Issue: Does the landlord have a duty to mitigate damages from breach?

> [!note]+ Holding (Pashman): Yes
> - Overrules Joyce, precedent saying no duty to mitigate, now imposing landlord duty to mitigate and prove it