---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Not Bivens
Takeaway: "New Context? If so, special factors: won’t work."
Tags:
  - A3
Category:
  - Con Law
Abstract: ""
Page: 947
Type: Case
Rating: "***"
Year: 2017
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ziglar v. Abbasi
Status: Annotated
Date: 2017-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - 

> [!note]+ Procedural History and Posture
> - 

- Issue: 

> [!note]+ Holding (): 
> - 
> - Disposition: 

> [!note]+ Concurrence/Dissent (): 
> - 

- View of Bivens: Disfavored
    1. BDC only instances where Court has approved of an implied damages remedy under the Constitution
    2. Not for impact litigation: individuals who have been wronged in familiar ways
- Core value for Ct: Separation of Powers

> [!note]+ Structure of inquiry
> - Are equitable remedies enough, or do we need damages?
> - Who should decide whether to provide a damages remedy? (Usually Congress)
> 
> > the question is only whether “congressionally uninvited intrusion” is “inappropriate” action for the Judiciary to take. The factors discussed above all suggest that Congress’ failure to provide a damages remedy might be more than mere oversight .

> [!note]+ 1) New context?
> 1. Was about search and seizure
> 2. Recurrent sphere of law enforcement
> 3. “Refused to extend” for past 30 years (now disfavored)
> 
> > rank of the officers involved; the constitutional right at issue; the generality or specificity of the official action; the extent of judicial guidance as to how an officer should respond to the problem or emergency to be confronted; the statutory or other legal mandate under which the officer was operating;

> [!note]+ Claim against warden
> 1. Even a modest extension is still an extension. 
> 2. 5th, not 8th Amendment rights
>     1. Because before conviction, confinement protected by Due Process Clause
> 3. Alternate Remedy: Prison Litigation Reform Act
> 4. “New Context” is easily satisfied
> 5. Remanded for special factors

> [!note]+ 2) Special factors? (any reason to hesitate)
> > whether the Judiciary is well suited, <u>absent congressional action or instruction</u>, to consider and weigh the costs and benefits of allowing a damages action to proceed.
> 
> - Requires an assessment of its impact on governmental operations
> 1. Governmental costs (indemnification, time, admin)
> 2. Burdening <u>high-ranking</u> Executive officers with litigation
> - About probability Congress would “want the Judiciary to entertain a damages suit”
> - BUT why does Congress need to want that?
> 
> > if there are sound reasons to think <u>Congress might doubt </u>the efficacy or necessity of a damages remedy as part of the system for enforcing the law and correcting a wrong, the courts must refrain from creating the remedy in order to respect the role of Congress in determining the nature and extent of federal-court jurisdiction under Article III.

- Alt remedies (pseudo special factor): “any alternative, existing process for protecting [injured party’s] interest
- Not “Dams or nothing”: Can seek injunctive relief for large-scale policy

> [!note]+ Breyer + Ginsburg Dissent
> 1. No, this isn’t different! Civilians, prison wardens, same harm
> 2. It was damages or nothing (they couldn’t communicate)
> 3. Silence doesn’t speak for your side

- Breyer/D & BCD’s legacy (“BCD” = Bivens/Carlson/Davis)
    1. Silo’ed into their exact facts




















