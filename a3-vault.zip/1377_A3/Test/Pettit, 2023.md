---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/0020174X.2023.2208391
In-Text Citation: (Pettit, 2023)
Priority: Recommended
Authors: Pettit, Philip
Title: Five elements of group agency
Zotero URI: http://zotero.org/users/4316906/items/K55FN3AK
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Journal Article
URL: https://www.tandfonline.com/doi/full/10.1080/0020174X.2023.2208391
Full Citation: "Pettit, P. (2023) ‘Five elements of group agency’, Inquiry, pp. 1–21. Available at: https://doi.org/10.1080/0020174X.2023.2208391."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: To Note
Year*: 2023
---
