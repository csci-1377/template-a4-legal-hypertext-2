---
base: "[[Test.base]]"
In-Text Citation: (Cohen, 1989)
Priority: Recommended
Authors: Cohen, J
Title: Deliberation and Democratic Legitimacy
Zotero URI: http://zotero.org/users/4316906/items/A6PU5MX3
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Full Citation: Cohen, J. (1989) ‘Deliberation and Democratic Legitimacy’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1989
---
