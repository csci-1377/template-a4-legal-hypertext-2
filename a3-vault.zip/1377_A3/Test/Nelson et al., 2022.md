---
base: "[[Test.base]]"
DOI: https://doi.org/10.1086/714783
In-Text Citation: (Nelson, Hazelton and Hinkle, 2022)
Priority: Recommended
Authors: |-
  Nelson, Michael J.
  Hazelton, Morgan L. W.
  Hinkle, Rachael K.
Title: How Interpersonal Contact Affects Appellate Review
Zotero URI: http://zotero.org/users/4316906/items/28U7UELM
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: Prominent explanations for appellate review prioritize the ideological alignment of the lower and reviewing courts. We suggest that interpersonal relationships play an important role. The eﬀect of an appellate judge’s ideology on her decision to reverse depends on the level of interpersonal contact between the trial and appellate judge due to information provided by social and professional interactions. Relying on a dataset of all published Fourth Amendment search and seizure decisions from 1953-2010, we ﬁnd that interpersonal relationships can dampen the eﬀect of ideology in appellate review. When an appellate and trial court judge have frequent contact, the eﬀect of ideology on the appellate judge’s decision to reverse is essentially imperceptible. These ﬁndings speak to the importance of relationships in principal-agent arrangements generally and have implications for the structure of the federal judiciary and our understanding of the limits of ideological judicial decisionmaking.
Type: Journal Article
URL: https://www.journals.uchicago.edu/doi/10.1086/714783
Full Citation: "Nelson, M.J., Hazelton, M.L.W. and Hinkle, R.K. (2022) ‘How Interpersonal Contact Affects Appellate Review’, The Journal of Politics, 84(1), pp. 573–577. Available at: https://doi.org/10.1086/714783."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2022
---
