---
base: "[[Test.base]]"
In-Text Citation: (Hansson, 2013)
Authors: Hansson, Sven Ove
Title: The Ethics of Risk
Zotero URI: https://zotero.org/bmcanally21/items/UICJZM7K
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
URL: http://link.springer.com/10.1057/9781137333650
Full Citation: "Hansson, S.O. (2013) The Ethics of Risk. London: Palgrave Macmillan UK. Available at: https://doi.org/10.1057/9781137333650."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
---
