---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Divorcing Degrees
Takeaway: Degrees are considered upon divorce
Tags:
  - Marital Property
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1991
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Postema v. Postema
Status: Annotated
Date: 1991-01-01
Jurisdiction: Michigain
---
> [!note]+ Facts
> - D is husband with law degree
> - P is wife who puts degree on hold to move with H
> - D gets job, admits infidelity, divorce

> [!note]+ Procedural History and Posture
> - TC treats law degree as marital property, subject to division

- Issue: How to consider degrees upon divorce?

> [!note]+ Holding (Maher): Not property, but subject to restitution
> - Factors
>     - “sacrifices, efforts, and contributions” of non-degree spouse
>     - Length of marriage (cuts both ways)
>     - Need of support of non-degree spouse for further education
> - Disposition: Modified