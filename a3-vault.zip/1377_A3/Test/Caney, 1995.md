---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1467-9248.1995.tb01710.x
In-Text Citation: (Caney, 1995)
Priority: Recommended
Authors: Caney, Simon
Title: Anti-Perfectionism and Rawlsian Liberalism
Zotero URI: http://zotero.org/users/4316906/items/Q9ISSGQM
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This article examines the justifications of anti-perfectionism given by John Rawls in his recent work Political Liberalism. Rawls, I argue, gives one major argument in defence of anti-perfectionism (what I shall call the ‘reasonableness among free and equal persons' argument) and two subsidiary arguments (what I shall call the ‘social unity’ argument and the ‘stability’ argument). None of these arguments, I claim, are persuasive. Rawls's most recent justification of anti-perfectionism is therefore unsuccessful.
Type: Journal Article
Rating: "***"
URL: http://journals.sagepub.com/doi/10.1111/j.1467-9248.1995.tb01710.x
Full Citation: "Caney, S. (1995) ‘Anti-Perfectionism and Rawlsian Liberalism’, Political Studies, 43(2), pp. 248–264. Available at: https://doi.org/10.1111/j.1467-9248.1995.tb01710.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1995
---
