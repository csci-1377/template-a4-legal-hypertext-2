---
base: "[[Test.base]]"
In-Text Citation: (Young, 2011)
Priority: Essential
Authors: Young, Iris Marion
Title: Responsibility and Historic Injustice
Zotero URI: http://zotero.org/users/4316906/items/T72GWTIA
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: "Cases of historic injustice whose original perpetrators and victims lived generations ago present particular ontological and conceptual problems when we try to apply the liability model to them. This chapter begins with a discussion of claims for reparations for slavery in the United States to illustrate these di culties. It argues that on the whole, it does not make sense to use the language of blame, guilt, indebtedness, or compensation to talk about the responsibilities that Americans today, and particularly white Americans, may have in relation to the historic injustice of slavery. Yet the past matters to the way members of the society take up responsibility for present racialized structural injustice. The chapter concludes the discussion of responsibility in relation to structural injustice with brief considerations of two other big cases: responsibilities toward people in Africa today in relation to the historic injustices of the slave trade and colonialism, and responsibilities toward American Indians in relation to the ravages of the North American conquest by Euro-Americans."
Type: Book Section
Rating: "***"
Full Citation: Young, I.M. (2011) ‘Responsibility and Historic Injustice’, in Responsibility for Justice.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2011
---
> [!note]+ Intro
> - We shouldn’t just “put historic injustice behind us” but…
> - Don’t use the language of blame, debt, or compensation for historic injustice

> [!note]+ Liability Model
> - Makes sense when perpetrators and/or victims are still alive

> [!note]+ Social Connection Model
> - Makes sense when causation is spread across people and time to make blame inappropriate
>     - Social groups are not collective agents
> - Focuses on the future more than the past
> - But we can still be responsible for how we move forward without being blameworthy
> - An individuals position in the structure makes a difference to what and how much he ought to do.

> [!note]+ Implications
> - We need collective discussion and retelling of historical injustice for a diversity of perspectives
> - So focus on the reconstruction to show how we can backslide
> - Ultimately, reform and investment rather than payment as compensation
> - Affirming white privelege can be donw without claiming group blame or reparations
> - Our obligations are to work to transform the institutions that offer this privelege, even if that means worsening one’s own conditions and opportunities

> [!note]+ Thoughts
> - Your point about blame was tangential. She says don’t use the language of blame with respect to historic injustice, that doesn’t mean we can’t blame failures of current responsibility.














