---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Kicking a Fetus
Takeaway: An unborn fetus is not a “human being” according to California murder law
Tags:
  - Ex-Post Facto
  - Lenity
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "**"
Year: 1970
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Keeler v. Superior Court
Status: Annotated
Date: 1970-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - Ex husband knees woman in stomach to kill viable fetus
> - Penal Code section 187 provides: “Murder is the unlawful killing of a human being, with malice aforethought.”

> [!note]+ Procedural History and Posture
> - No trial yet, D argues that even if the state proves all the facts, not a crime under this law.

- Issue: Is an unborn fetus a “human being” according to California murder statute?

> [!note]+ Holding (Mosk): No
> - 1850s common law used to distinguish between killing fetus and baby
> - 1870 OG version of the statute was adopted with this understanding
> - The statute was unamended, nothing shows legislature changed intent
> - Prosecutor: science has changed, now fetus is viable so it should count.
> - Jurisdictional Argument: we shouldn’t be the ones extending criminal law, the legislature should
> - Constitutional Argument: no ex post facto laws, nothing gave notice to offender that this was murder

> [!note]+ Dissent (Burke): Yes
> - The meaning of terms can change with new scientific understanding
> - Also, this was always the understanding (quickening) roughly viability, was when a human life was understood to have begun.
> - Finally, Mr. Keller should have known that what he did was wrong