---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: No NY Ferry Monopoly
Takeaway: "If a thing (channels, people, goods, and instrumentalities) crosses state lines, Congress can regulate it: Dual Federalism Theory (Separate Spheres)"
Tags:
  - CC
  - SUP
Category:
  - Con Law
Abstract: ""
Type: Case
Rating: "****"
Year: 1824
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Gibbons v. Ogden
Status: Annotated
Date: 1824-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Ogden, NJ gov, runs ferry pier with Gibbons
> - They have a falling out
> - They feud, Gibbons wants revenge, competes with Ogden
> - Ogden gets a NY monopoly on the ferry
> - Gibbons gets federal liscense (not actually about ferries)
> - Ogden sues under NY monopoly

- Issue: Does Commerce Clause preempt NY monopoly?

> [!note]+ Holding (Marshall): Yes
> - Who says powers ought to be construed strictly?
> 
> > We know of no rule for construing the extent of such powers, other than is given by the language of the instrument which confers them, taken in connexion with the purposes for which they were conferred.
> 
> 1. **Commerce** includes *traffic, navigation, trade, intercourse, *and *voyages*
> 2. **Among the several States** means *intermingled with*, can enter state interior
> 3. **Regulate** means “to prescribe the rule by which commerce is to be governed”
>     - **Plenary** power: *plenus*, full, or *plenarius,* complete
>     - Court will be very deferential
>     - Potentially abused, accountable through elections
> 4. **State and federal powers** may conflict, but their sources **do not overlap**
>     - Taxing power might seem like it does, but not really
>     - When they do conflict, federal power supercedes (SUP)
> 5. Coasting act is valid excercise of Commerce Clause
>     1. People are potentially articles of Commerce (slavery, remember?)
> 6. New York’s monopoly interferes with valid excercise
>     2. It’s not obvious that they conflict
>     3. But because of Marshall’s zero-sum, black-and-white mindset, they do
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 