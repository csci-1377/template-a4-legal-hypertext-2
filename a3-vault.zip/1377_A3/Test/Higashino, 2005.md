---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Authors: Higashino, Keigo
Title: The Devotion of Suspect X
Takeaway: ""
Tags: []
Category:
  - Fiction
  - Mystery
Abstract: ""
Type: Book
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2005
---
