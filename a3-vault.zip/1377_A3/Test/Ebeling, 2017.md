---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/02691728.2017.1317870
In-Text Citation: (Ebeling, 2017)
Priority: Recommended
Authors: Ebeling, Martin
Title: Is moral deference reasonably acceptable?
Zotero URI: http://zotero.org/users/4316906/items/7XMGZNVA
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: Advocates of epistemic conceptions of democracy sometimes argue that democratic decision-making is a more reliable guide to getting the issues at stake right than the decision-making of individuals. Such arguments give rise to the question of whether those finding themselves in the minority should defer to democratic outcomes. In this article, I discuss the bearing of the normative criterion of reasonable acceptability on this question. I thus ask, can the demand to defer to democratic outcomes be rendered reasonably acceptable to citizens who disagree with them? Using the example of David Estlund’s epistemic proceduralism, I show that the problem of moral deference is inherent to epistemic conceptions of democracy. I then discuss the kind of reasons that would make a demand of deference reasonably acceptable to the minority, arguing that they should be independent from the reasons supporting the majority position. Subsequently, I introduce the conciliatory conception of democracy as an example of what such reasons could be. The conception’s central idea is that disagreement between citizens conceived as equal epistemic authorities carries epistemic significance. This significance makes it rational for citizens so conceived to conciliate their conflicting judgments. Because democratic decision-making has an inbuilt tendency to track such conciliatory positions, the conception offers an independent reason to accept democratic outcomes as the more reliable guide to getting the issues at stake right.
Type: Journal Article
URL: https://doi.org/10.1080/02691728.2017.1317870
Full Citation: "Ebeling, M. (2017) ‘Is moral deference reasonably acceptable?’, Social Epistemology, 31(3), pp. 296–309. Available at: https://doi.org/10.1080/02691728.2017.1317870."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2017
---
