---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Hidden in the Newspaper
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 1950
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: "Mullane v. Central Hanover Bank & Trust "
Status: Annotated
Date: 1950-01-01
Year*: 1950
Jurisdiction: United States
---
> [!note]+ Parties
> - Mullane (special guardian and attourney for all beneficiaries of the trust fund)
> - Company of trust fund

> [!note]+ Facts
> - Common trust fund used to send out alerts by mail, but now only sends out notice of settling accounts in newspaper, which is consistent with NY Banking Law.
> - Most people don’t see it.
> - Mullane appointed to represent those interested in interest, claims that this is not legitimate.
> 
> > [!note]+ Glenn’s
> > <u>Facts</u>: The Central Hanover Bank consolidates 113 trusts (worth almost 3 million dollars), half living half testamentary into a common fund, as authorized by NY banking law. That allows the bank to pool the assets of any number of estates and trusts. The various “contributors” share proportionately in the profits of the trust. But they get no say in its administration, and are not treated as owners of any particular asset in the common fund. The bank maintains control. The bank has to keep these funds separate from its own. Some of the beneficiaries of the trust fund are NY residents; others are not.
> > 
> > The NY banking law provides that banks have to do an “accounting” 12–15 months after the fund is established, and once every three years thereafter. An “accounting” is a judicial settlement of accounts, which is binding and conclusive on everyone having an interest in the common fund or in any of the estates, trusts, or funds, from which the common fund is made up. The judicial decree has the effect of settling all questions relating to the common fund’s management. It also seals and terminates any claims of improper management of the common fund that trust beneficiaries could conceivably raised.
> > 
> > Notice is given to the beneficiaries about the judicial settling of accounts in the way ordered by the NY banking law.
> > 
> > When Hanover petitions for settlement of accounts, Mullane is appointed special guardian to represent all persons known or unknown not otherwise appearing who might now or thereafter have an *interest* in the income of the trust. Vaughn is appointed same for those with an interest in the principal.

> [!note]+ Procedural History and Posture
> - Supreme (Trial) Court of New York finds notice sufficient.
> - New York Court Appeals also found that notice required to beneficiaries on judicial settlements of accounts under New York Banking law are adequate.

> [!note]+ Issue
> - Is the notice given here sufficient to meet the 14th Amendment Due Process Standard?
> - No, not for those who have known names and addresses. Mailing is a customary and feasible alternative, which we know is feasible because you used to mail it out.

> [!note]+ Holding
> > “An elementary and fundamental requirement of due process in any proceeding which is to be accorded finality is notice **reasonably calculated under all the circumstances**, to apprise interested parties of the pendency of the action and afford them the opportunity to present their objections. The notice must be of such nature as reasonably to convey the required information and it must afford a reasonable time for those interested to make their appearance.” [CB ¶30]
> 
> - Compare to other alternatives. 
> - "The fundamental requisite of due process of law is the opportunity to be heard.” *Grannis* v. *Ordean*
> - But when notice is a person's due, process which is a mere gesture is not due process.
> - So it’s ok not to reach everyone, especially those who are unknown or who have a very small stake. But when you have names and addresses, you actually need to mail something.
> - Notice is not adequate to beneficiaries with known residences, but is for those whose identities or whereabouts are unknown.
> - Because interests are basically the same, then “notice reasonably certain to reach most of those interested in objecting is likely to safeguard the interests of all” 
> - The problem is not failing to reach everyone, but in failing to be reasonably calculated to reach those who could be easily informed.

> [!note]+ Disposition
> - Reversed and remanded for further proceedings
