---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Walking Away from Fishing
Takeaway: ""
Tags:
  - Consideration
  - Modification
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1902
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Alaska Packer’s Association v. Domenico
Status: Annotated
Date: 1902-01-01
Jurisdiction: Ninth Circuit
---
> [!note]+ Facts
> - Fishing crew threatens to walk off in AK after signing contract to get better pay

> [!note]+ Procedural History and Posture
> - Trial court finds for workers

- Issue: Can you threaten to walk away unless paid more after contracting?

> [!note]+ Holding (Ross): No
> - No consideration for the modification: you already had a legal duty to do the first thing, so demanding more is unenforceable
> - Disposition: Reversed