---
base: "[[Test.base]]"
In-Text Citation: (Bowers, no date)
Priority: Essential
Court: Supreme
Authors: ""
Title: No Sodomy
Zotero URI: https://zotero.org/bmcanally21/items/BD3Q7D5K
Takeaway: "No right to homosexual sodomy: criminalization ok"
Tags:
  - DPC
  - Privacy
Category:
  - Crim
Abstract: ""
Type: Case
Rating: "****"
Year: 1986
Full Citation: Bowers (no date) ‘Bowers v Hardwick.pdf’.
Last edited: 2026-02-15T22:06:00
Full: Bowers v. Hardwick
Status: Annotated
Date: 1986-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Hardwick charged with violating Georgia statute against sodomy
> - Sodomy defined as anal or oral sex (used to specify man and man)

> [!note]+ Procedural History and Posture
> - Georgia doesn’t prosecute, but Hardwick sues to challenge constitutionality
> - Eleventh circuit finds violates 9A and DPC

- Issue: Is there a fundamental right to homosexual sodomy?

> [!note]+ Holding (White): No
> - First, distinguish from precedent: family, marriage, and procreation are not like homosexual activity
> - No textual support
> - Tests
>     - “implicit in the concept of ordered liberty” (Palko)
>     - “deeply rooted in this Nation’s history and traditions” (Moore)
> - Doesn’t meet becauser has been banned for a long time
> - Otherwise illegal conduct is not always made legal within the home (adultery, incest, other sexual crimes)
> - Rational basis: majoritarian morality provides this
> - Disposition: Reversed

> [!note]+ Dissent (Blackmun): Wrong Question
> - This is about “the right to be left alone” (privacy)
> - Not about *homosexual* anything. Law is neutral there
> - There is a problem that Georgia only enforces the law against gay people (EPC?)
> - Basically, length and passion of majority does not “withdraw legislation from this Court’s scrutiny”
> 
> > A State can no more punish private behavior because of religious intolerance than it can punish such behavior because of racial animus.