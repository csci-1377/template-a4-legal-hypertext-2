---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: VAWA Rejected
Takeaway: State Action Doctrine Returns
Tags:
  - 14A
Category:
  - Con Law
Abstract: ""
Page: 513
Type: Case
Rating: "***"
Year: 2000
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Morrison
Status: Annotated
Date: 2000-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - VAWA allows women victims of violence to sue in federal court since state remedies are inadequate.
> - Chisty Brzonkala is raped by Antonio Morrison
> - She sues for damages under VAWA
> - Morrison challenges VAWA as unconstitutional
> - Solicitor General argues that a state can violate 14A by neglecting to provide sufficient remedies for civil rights violations.

- Issue: Is VAWA constitutional?

> [!note]+ Holding (Rehnquist): No
> - 14A is limited to state action.
> 
> > [necessary prevent 14A from] obliterating the Framers’ carefully crafted balance of power between the States and the National Government.
> 
> - Civil Rights Cases and Cruikshank beat Guest 
>     - They have been “on the books” longer
>     - The members of the court had all this insight from the civil war
>     - The Civil Rights State Action holding was never really overruled (”naked dicta” of two concurrences, even if together a majority)
>     - (what about Griffin?)
> - VAWA isn’t corrective or “prophylactic”





















