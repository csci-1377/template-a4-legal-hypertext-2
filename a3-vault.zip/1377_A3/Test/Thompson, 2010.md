---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/13698230903326232
In-Text Citation: (Thompson, 2010)
Priority: Essential
Authors: Thompson, Dennis F.
Title: "Representing Future Generations: Political Presentism and Democratic Trusteeship"
Zotero URI: http://zotero.org/users/4316906/items/9Q253QK3
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: Democracy is prone to what may be called presentism—a bias in the laws in favour of present over future generations.  I identify the characteristics of democracies that lead to presentism, and examine the reasons that make it a serious problem.  Then I consider why conventional theories are not adequate to deal with it, and develop a more satisfactory alternative approach, which I call democratic trusteeship. Present generations can represent future generations by acting as trustees of the democratic process.  The general principle is that present generations should act to protect the democratic process itself over time. They should try to make sure that future citizens continue to have competent control over their collective decision making.
Type: Journal Article
Rating: "***"
URL: https://dash.harvard.edu/handle/1/9464286
Full Citation: "Thompson, D.F. (2010) ‘Representing Future Generations: Political Presentism and Democratic Trusteeship’, Critical Review of International Social and Political Philosophy [Preprint]. Available at: https://doi.org/10.1080/13698230903326232."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2010
---
> [!note]+ Intro
> - Presentism in democracy
>     - Pros: less vulnerable to idealists calling for great sacrifice, pays attention to actual citizens
>     - Cons: struggles to represent future generations
> - What we need is institutional bi-focals- We should be able to see clearly not only our own democratic needs, but those of future citizens

> [!note]+ Why we neglect the future
> - We prefer the immediate to the distant (not the same as self-interest, because we favor present over future self)
> - Representatives should be responsible to constituents
> - Government pro tempore: term limits, short cycle of press and politics
> - Older people are favored in law and public policy
> - We think its unfair to the currently worse off
> - Uncertainty: hard to know effects of our actions and what the future will want

> [!note]+ How not to represent future generations
> - Expand participation: they arent there to participate
> - Assume their interests don’t require special attention because people already care some about their children and grandchildren (argument from generational connections)
> - Assume that since they will probably be better off, we don’t need to take into account the large and irreversible harms we can cause (environment/political institurions)
> - Based on conceptions of justice
> - Put representatives in the legislature
>     - But how many, and who votes for them?
>     - Maybe as many as regular, and everyone votes for F-representatives

> [!note]+ How to do it right
> - Protect their capacity for making their own collective decisions
> - Protect something like the value of human flourishing in the future **or agency interests**
> - Don’t ask about justice or utility: it’s a prior question, who should have a voice in the decisions?
> - Represent future generations as trustees of the democratic process
> 
> > should permit only constraints that are necessary to make a majority at any particular time competent in the sense of having the capacity to express a sufficiently settled and an adequately informed judgment. (14)
> 
> - Less demanding: should provide only as much democratic sovereignty as they have **why only sovereignty?**
> - More demanding: Up to the point their own decision making begins to decrease
> - Only trustees of the democratic process, not the whole range of interests or welfare **makes sense in the role of citizen: protect the public expression of agency interests publicly.**

> [!note]+ The big quotes to grapple with
> > The course of Rawls's journey—from constrained self-interest to generational reciprocity—carries a lesson for any democrat who would seek to protect future generations. They are not adequately represented if representatives are held accountable only for pursuing the interests of current constituents and their near progeny. To be sure, if these interests are defined to include ‘moral interests’, and constituents are said to have a moral interest in the well-being of future generations, then accountability to the interests of constituents will ensure that representatives care about future generations. But this move either smuggles in a moral argument under the guise of self-interest, or treats the concern for future generations as purely contingent on the interest the current generation takes in them. We need a principle that holds representatives accountable not only for satisfying the interests of their constituents but also for acting in a way that can be justified to future generations. (11)
> 
> > However, to the extent that utilitarian goals are detached from identifiable individuals, they provide less motivation for citizens (and therefore their representatives) to pursue them. Utilitarianism undermines the reasons that most citizens find most persuasive for respecting // future generations—making individuals in the future worse off. (12-13)

> [!note]+ Tribune of the Plebs: Potential Powers
> - Can intervene in judiciary
> - enforce its own proposals
> - accountable to no one
> - Independent commissions or citizen assemblies?
> - Posterity Impact Statements
>     - Require the government to issue statements justifying any adverse effects on the (democratic) capacities of future citizens 
> - Age-differentiated political rights
> - Democratic balance sheets
> - Suspensive interventions: stop offices when they might seriously impact the democratic process of the future
> - Contingency trust fund
> - Constitutional conventions
> - International Collaboration

> [!note]+ Thoughts
> - Part of the problem is the short-sightedness of individuals. “This problem is one of prudence rather than morality.” “Problem of future citizens cannot be addressed in this way because the individuals who sacrifice are not the same as those who benefit” (5)
> - So half the problem is one of identity, thinking from the right perspective (which we need to give reasons for) and the other problem is one of prudence, more info/framing to help think better
> - So solution should not be anything that places a direct finger on the scale in decision making, but rather when and how decisions are made (more info, better process, etc.)
> - Can’t be an argument from generational connections, but one from narrative connections. This won’t change the fact that the further into the future we look, the weaker and more indeterminate the connections.
> - Use the example of how space and time don’t actually matter in our calculation (wife in Paraguay or stuck in a time machine)
> - Justice for future generations doesn’t seem to work out well
> - We have reasons to protect the agency of future generations that lead to obligations

