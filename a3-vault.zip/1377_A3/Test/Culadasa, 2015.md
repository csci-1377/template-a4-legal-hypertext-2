---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Further
Authors: Culadasa
Title: The Mind Illuminated
Takeaway: ""
Tags: []
Category:
  - Meditation
Abstract: ""
Type: Audiobook
Rating: "**"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 2015
---
Prep for meditation:

1- Motivation (why am I doing this?)

2- Goals

3- Expectations

4- Diligence

5- Distractions

6- Posture

Four steps of preparing to meditate:

1- focus on the present

2-focus on bodily sensations

3-focus on the breath

4-focus on the nostrils (alternately abdomen)

Count ten breaths

When your mind wanders, positively reinforce the re-centering rather than punishing the wandering. Punishing will make your subconscious mind not want to recenter, while rewarding it will.

Formula for success in meditation is:

Relax and look for joy, Observe, Let it come, let it be, and let it go.

Stage two is mastered when you can focus on the meditation object for minutes, while distractions last only seconds.

If you subconsciously change your breathing pattern because you are observing it, don’t make the mistake of thinking you changed your breath. It changed without you, so just notice the change and continue to observe.

Following: follow the breath closely, noticing the component sensations of each in breath and out breath.

Connecting: make comparisons between sensations (lengths of the in and out pauses, change of depth/sharpness/evenness over time and during different emotions, etc.)

Labeling: give neutral labels to distractions like “thinking, remembering, and planning.” Don’t analyze the distractions, and only label the most recent one.

Check in gently, briefly, and periodically, finding and labeling gross distractions before they cause forgetting. Check in every half dozen breaths or so, but don’t count. Make it a habit.

Don’t try to eliminate distraction, just let it come, let it be, and let it go.

If you are going to move to avoid pain, decide when and how you will move before you do, then observe the sensations as you move. Pain gives insight into the nature of desire and aversion by watching how resistance and impatience create suffering.

Four levels of mindfulness: first is recognizing conditioned responses and moderating them (dodging the thorn bush on the path) second is making a habit of it to reduce the instances of such responses (trimming back the thorn bush, but it grows back), third is exploring the subconscious programming to remove its effects at a large scale through insight experiences into the nature of consciousness and separateness (removing a whole trunk of the bush), fourth is the removal of suffering and overcoming of subconscious processes (taking the whole bush out by the root).