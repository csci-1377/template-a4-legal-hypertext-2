---
base: "[[Test.base]]"
DOI: https://doi.org/10.1086/233847
In-Text Citation: (Otsuka, 1998)
Priority: Recommended
Authors: Otsuka, Michael
Title: Incompatibilism and the Avoidability of Blame
Zotero URI: http://zotero.org/users/4316906/items/G9G934FX
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: ""
Type: Journal Article
Rating: "****"
URL: https://www.jstor.org/stable/10.1086/233847
Full Citation: "Otsuka, M. (1998) ‘Incompatibilism and the Avoidability of Blame’, Ethics, 108(4), pp. 685–701. Available at: https://doi.org/10.1086/233847."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1998
---
A new incompatibalist principle, The Principle of the Avoidability of Blame, renders no person blameworthy under determinism, as it is better able to counter Frankfurt’s counterexample.

> [!note]+ Standard Argument
> P1- One is blameworthy for performing an act of a given type only if one could have refrained from performing an act of that type. (Principle of Alternate Possibilities)
> 
> P2- If determinism is true, then one never could have refrained from performing acts of whatever types that one has performed.
> 
> C- Therefore, if determinism is true, then one is never blameworthy for performing an act of a given type.

> [!note]+ Under a Given Description
> One is blameworthy for an act if they are blameworthy for under a given description, but not every description.
> 
> How do we choose the right description/interpretation?

> [!note]+ Frankfurt’s Counterexample
> In a non-deterministic universe, does Jones’s blameworthiness for killing Smith cannot depend on whether Black was there, who would have hypnotized him to commit murder had he decided not to, because he exerted no influence whatsoever on Jones’s behavior.

> [!note]+ Principle of Avoidable Blame (new P1)
> One is blameworthy for performing an act of a given type only if one could instead have behaved in a manner for which one would have been entirely blameless.
> 
> - A necessary, not sufficient condition
> - Could have means within one’s voluntary control
> - Entirely blameless means under any description

> [!note]+ Reactive Attitudes
> - Attribution of vice doesn’t necessarily involve blame
> - Blameworthy if and only if indignation is warrented
> - Strawson Freedom and Resentment, distinction between resentment and indignation being impersonal and personal.

> [!note]+ Blameworthy definition
> - Allan Gibbard‘‘An observer thinks an act blameworthy . . . if and only if he thinks it rational for the agent to feel guilty over the act, and for others to resent the agent for it’’ (Gibbard, Wise Choices, Apt Feelings [Cambridge, Mass.: Harvard University Press, 1990], p. 47). (Otsuka 695)
> - We don’t just mean causal responsibility when we talk about blame

> [!note]+ Cases for intuition
> - When you discover that someone trod on your foot, but couldn’t have done otherwise, what happens? How do we choose the best interpretation?
> - Someone mistakenly believing they could have behaved otherwise doesn’t change our sense of blameworthiness. This is right, but not because counterfactual is required, because it is our account that matters.
> - ‘‘I realize that you could not have behaved any less badly. But how dare you treat me this badly when you had the justified but false belief that you didn’t have to.’’ This accusation lacks force. (697)
> - A viscious character need not imply a difference in blameworthiness even if implying a difference of an ethical nature. But it can, and should.

> [!note]+ Guilt vs Blame
> One might feel guilt meeting the family of the person you directed the trolley to even though you know it was the right decision.
> 
> Would the family be justified in resenting you? I think so!
> 
> (699)

> [!note]+ Thoughts
> Blameworthiness is about the best interpretation of actions, and depends on the perceiver as well as the perceived. So “blameworthy in the eyes of your family, or the state” makes sense. Reletivising to the blamer is necessary.
> 
> Best interpretation is a moral, not a metaphysical or causal question.
> 
> The principle of avoidable blame is true in the sense that the interpretation of not being able to do otherwise always fits. Determinism is true, it just isn’t always the best interpretation (Intentional, physical, instrumental stances?)
> 
> Distinguish between senses of “could not have done otherwise” (include exercise of agency in cases of moral dillemas)














