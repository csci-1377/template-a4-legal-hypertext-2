---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Garbage Dump Division
Takeaway: Prefer partition in kind over sale
Tags:
  - Partition
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1980
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Delfino v. Vealencis
Status: Annotated
Date: 1980-01-01
Jurisdiction: Connecticut
---
> [!note]+ Facts
> - Ps own 99/144 of lot, wants to develop into residential properties
> - D owns 45/144 with garbage business, wants to live there

> [!note]+ Procedural History and Posture
> - TC partitions by sale

- Issue: How to partition? In kind or by sale?

> [!note]+ Holding (Healey): In Kind
> - Partition in kind prefered if possible, unless
>     - Physical attributes make impracticably/inequitable
>     - Interest of owners better served by sale
> - TC finding interest better served by sale unsupported: ignored D’s subjective value
> - Disposition: Reversed
