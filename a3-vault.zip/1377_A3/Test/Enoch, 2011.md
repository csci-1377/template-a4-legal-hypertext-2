---
base: "[[Test.base]]"
In-Text Citation: (Enoch, 2011)
Priority: Recommended
Authors: Enoch, David
Title: Taking Morality Seriously
Zotero URI: http://zotero.org/users/4316906/items/X4P3X5GS
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: "In this chapter, Robust Realism — the metanormative view defended in the book — is characterized. The chapter then introduces the book's guiding intuition: any other metaethical and metanormative view will fail to accommodate our taking morality su ciently seriously, and describes how it is eshed out in the rest of the book. The program for the whole book is described and motivated, and the underlying philosophical methodology explicitly presented: No view is likely to beat its opponents by some kind of a philosophical knockout, and so we should settle for tallying plausibility points of competing theories. The aim of the book, then, is to show where Robust Realism earns signi cant plausibility points — in better accommodating taking morality seriously — and also that it doesn't lose too many plausibility points because of common objections to the view."
Type: Book
Rating: "****"
URL: http://www.oxfordscholarship.com/view/10.1093/acprof:oso/9780199579969.001.0001/acprof-9780199579969
Full Citation: "Enoch, D. (2011) Taking Morality Seriously. Oxford University Press. Available at: https://doi.org/10.1093/acprof:oso/9780199579969.001.0001."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2011
---
Introduction

> [!note]+ Terms
> - Normative Truths: on the ought side of the is/ought distinction, the value side of the fact/value distinction
> - Normative: used liberally to encompass evaluative as well. In contrast to non-normative (descriptive?)
> - Ethical/moral facts: interchangeable, a subset of normative facts

> [!note]+ View
> - Rosen’s minimal realism: sentences in a discourse are truth-apt and non-trivially true
> - Objectivist, response-independent normativity: does not depend on attitudes of anyone.
> - Robust Realism: there are objective, irreducibly normative truths.

> [!note]+ Motivation
> - Pre-theoretically feel that nothing short of it will vindicate our taking morality seriously
> - Without it, impermissable to stand one’s moral ground in any number of conflicts or disagreements

> [!note]+ Method
> - The game of plausibility points
> - Playing offense in chapters 2-5
> - Defense in 6-9
> - 10 try to keep score

> [!note]+ Outline
> - Chapter 2: any non-objectivist metaethical theory will have unacceptable implications
> - Chapter 3: robust realism is deliberatively indespensible
> - Chapter 4: Any metaethical view is unmotivated
> - Chapter 5: Against naturalist reduction, error theories, and fictionalist views
> - Chapter 6: defense against unacceptable metaphysics
> - Chapter 7: Epistemology
> - Chapter 8: Objection from disagreement
> - Chapter 9: Relation between morality, normative reasons, and motivation
> - Chapter 10: Summary of points

Chapter Seven

> [!note]+ The Challenge
> - If Josh has a lot of true beliefs (and few false ones) about a village in Nepal, we need some causal explanation of that correlation between his beliefs and the truths about that village
> - The price of denying this correlation is skepticism
> - Perceptual faculty won’t help, because the truths have to be causally inert

> [!note]+ The Response 
> - Well, the correlation isn’t all that shocking (we aren’t that good about forming normative beliefs) **Really?**
> - We really only need to explain the correlation in starting points, since our reliable reasoning methods seem plausibly evolutionarily helpful **This misses the idea that we can only reason well with good access to the relevant facts**
> - Third factor (that survival is good) explains why evaluative facts align with our evaluations, which are tailored to survival

> [!note]+ Thoughts
> - Since realism is compatible with skepticism (and might motivate it) it might be less good at taking morality seriously if we have good reasons to be skeptical. 
> - Ethics is about getting in touch with the ethical reality. This is inherently interpersonal.














