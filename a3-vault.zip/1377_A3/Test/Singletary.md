---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Amending to grab the Psychologist
Takeaway: “relating back” test for amendments to pleading
Tags:
  - Pleading
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 2001
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Singletary v. Penn Dept of Corrections
Status: Annotated
Date: 2001-01-01
Jurisdiction: Third Circuit
---
> [!note]+ Facts
> > [!note]+ Glenn’s
> > Singletary, mom of prisoner who commits suicide while incarcerated, sues the prison, state dept of corrections, and former superintendent of prison under 42 U.S.C. § 1983 (her theory is there was deliberate indifference by the defendants constituting cruel and unusual punishment in violation of the 8th Amendment of the Constitution) with state wrongful death claims attached. Her original complaint included as a defendant “unknown corrections officer.” The suicide occurred on Oct 6, 1996. Singletary files her action on Oct 6, 1998, the last day before the 2 yr SOL for this action would expire
> > 
> > The action is initially filed in E.D. Pa but transferred to [M.D.Pa](http://m.d.pa/) to correct a venue deficiency (§1406!). The defendants move under FRCP 12(c) for judgment on the pleadings. The district court grants it in part by dismissing the federal actions against some defendants as barred by 11th Amendment sovereign immunity, but leaves federal claims against some defendants and leaves in the state law wrongful death claims.
> > 
> > There is discovery.
> > 
> > The Defendants move for Summary Judgment, and a week later, on July 28, 2000, nearly 2 years after the SOL had run she asks to amend her complaint to change “unknown corrections officer” to “Robert Regan,” a psychologist at the prison against whom she may have a viable case, because Regan was the psychologist who evaluated the prisoner on a weekly basis and did not see the need for precautions.

> [!note]+ Procedural History and Posture
> - District court
>     1. Grants summary judgment on federal claims, some state law claims dismisses without prejudice
>     2. Denies leave to amend on grounds time barred and no relating back

- Issue: Does specifying Regan’s name relate back to OG complaint date?

> [!note]+ Holding (Becker): No
> - Standard of Review
>     - decision denying leave to amend: abuse of discretion
>     - Factual questions: clear error
>     - Interpretation of 15c3: plenary, de novo, blank slate
> - 3 Conditions for leave to amend (all must be met)
>     1. Same T&O: FRCP 15(c)(2). *Everyone agrees √*
>     2. The newly named party must have “received such <u>notice</u> of the institution of the action [within the 120 day period] that the party <u>will not be prejudiced</u> in maintaining a defense on the merits.” FRCP 15(c)(3)(A). 
>         1. Notice: lower bar, can by happenstance seeing posting that lawsuit names D you know is you, or even *constructive* by…
>             1. Shared Attorney
>                 1. Didn’t actually serve as Regan’s attorney until after rule 4m period runs out (and Regan had the option not to use him as an attorney)
>             2. Identity of Interest
>                 2. Regan wasn’t high enough up on the chain (non-management employee)
>         2. Prejudice (not addressed here)
>             3. Basically, is this leaving D with enough time for defense
>     3. The newly named party must have known, or <u>should have known</u>, (again, within the 120 day period) that “<u>but for a mistake</u>” made by the plaintiff concerning the newly named party’s identity, “the action <u>would have been brought against</u>” the newly named party in the first place. FRCP 15(c)(3)(B).
>         3. Unknown *corrections officer* not psychologist
>         4. *Varlack* precedent counts “unknown employee” as a “mistake” of identity
>             4. This is semantically odd, and all other circuits reach the opposite conclusion
>             5. But it is what the law *should be*. So please amend c3 to include “lack of information” as well as mistake!
>             6. Dictum in the Supreme Court’s opinion in *Krupski v. Costa Crociere* (S. Ct 2010) seems to favor the *Varlack* view
> - Disposition: Affirmed