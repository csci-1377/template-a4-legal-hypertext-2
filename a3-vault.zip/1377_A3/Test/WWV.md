---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Bus Crash Subsidiaries
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1980
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: WW Volkswagon Corp. v. Woodson
Status: Annotated
Date: 1980-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Robinsons buy Audi in NY, then drive through OK, where gas tank explodes. 
> - They sue everyone related to the car, including World Wide (distributor) and Seaway (regional dealer) based in NY.
> - Both these organizations are independent from Audi and do no business in OK or have agent there (only car to enter might be Robinsons)
> 
> > [!note]+ Glenn’s
> > The Robinson family lived in Massena, NY. They buy an Audi from Seaway Motors in Massena, NY. In 1977, they move to Arizona. As they pass through Oklahoma their car gets struck in the rear and its gas tank explodes. Kay Robinson and her two kids are severely burned.
> > 
> > Facts relevant to jurisdiction: World Wide is incorporated and has business offices in NY. It distributes vehicles, parts, and accessories (by contract with Volkswagen) to retail dealers in NY, NJ, and Conn. Neither Seaway nor World Wide has anything other than a contractual relation with Audi, Volkswagen or each other. They have never done any business ship or sell products to/in OK. They have no agent to receive process there. They do not buy advertising media calculated to reach OK customers. Indeed, except for this one car that exploded, there was no showing that any automobile sold by them has ever entered in OK.
> > 
> > The Robinsons bring suit in OK state court for products liability (state law tort) against Audi’s manufacturer “Audi,” its importer “Volkswagen,” its regional distributor, World Wide, and its retail dealer Seaway. Only World Wide and Seaway contest PJ.

> [!note]+ Procedural History and Posture
> - Suit is brought in OK state court
> - District court grants OK jurisdiction
> - OK supreme court denies appeal, finding authorized by “long-arm” statute

- Issue: Does OK have SIPPJ over auto distributor just because one car entered territory under DPC?

> [!note]+ Holding (White): No, MC not met
> - Minimum contacts not met
>     - Fairness analysis only kicks in after this: Even when little inconvenience, even when strong forum state interest, and even if forum state most convenient, sometimes can’t sue there
>     - Honestly, they don’t really stick to this.
> - Constitutional test has been relaxed as economy is more interconnected and burden on suit in other state decreases
> 
> > [!note]+ Two PJ Functions
> > 1. Protect defendants from litigating in distant/inconvenient forum (Like FPSJ)
> > 2. Federalism/state sovereignty, to prevent the states from exceeding their prescribed role in the federal system. (Like MC)
> 
> > [!note]+ 4 Inconvenience Factors
> > - Basically about International Shoe reasonableness/fairness
> > - Burden on Def is “primary concern,” but in “appropriate case” should be considered in light of…
> >     1. Forum state’s interests in adjudicating the dispute;
> >     2. Plaintiff’s interests in convenient and effective relief; 
> >     3. Interests of the interstate judicial system in obtaining the more efficient resolution of controversies;
> >     4. Shared interest of the states in furthering fundamental substantive social policies.
> 
> > [!note]+ Foreseeability?
> > - Not about foreseeability of product entering state
> > - Better: “[t]he defendant’s conduct and connection with the forum State are such that he should reasonably anticipate being haled into court there” ¶ 37
> > - (This is totally circular) You can be haled into the forum when it is reasonable to think you can be, which is based on lay interpretation of the common law.
> 
> > [!note]+ Aleviation?
> > - When a corporation "purposefully avails itself of the privilege of conducting activities within the forum State,” it has clear notice that it is subject to suit there, and thus it can… (alieviate risk of litigation)
> > - Purchasing insurance
> > - Passing on cost to consumers
> > - Severing connection with the state
> 
> - Disposition: Reversed

> [!note]+ Dissent (Brennan): We need *more* fairness focus (contra Black)
> - Focus less on minimum contacts, more on fairness/reasonableness (from International Shoe)
> 
> > The defendant has no constitutional entitlement to the best forum or, for that matter, to any particular forum.
> 
> - State legitimate interest in litigating (witnesses and evidence are there, they want to enforce to keep highways safe)
> - “It may be true, as the Court suggests, that each sincerely intended to limit its commercial impact to the limited territory, and that each intended to accept the benefits and protection of the laws only of those States within the territory. But **obviously these were unrealistic hopes that cannot be treated as an automatic constitutional shield**” ¶ 59
> - “Purposefully inject the vehicle into the stream of interstate commerce.”
>     - They get benefits from the fact these cars can drive elsewhere
> - Shoe may be outdated
>     - Too much attention to ensuring fairness to Defendant
>     - No seller can expect their goods to stay put
>     - Gives defendent unjust veto power over forum
