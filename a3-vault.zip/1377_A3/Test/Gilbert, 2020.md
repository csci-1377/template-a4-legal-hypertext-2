---
base: "[[Test.base]]"
In-Text Citation: (Gilbert, 2020)
Priority: Recommended
Authors: Gilbert, Margaret
Title: On Social Facts
Zotero URI: http://zotero.org/users/4316906/items/ZRJ7PMJA
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: Are social groups real in any sense that is independent of the thoughts, actions, and beliefs of the individuals making up the group? Using methods of philosophy to examine such longstanding sociological questions, Margaret Gilbert gives a general characterization of the core phenomena at issue in the domain of human social life. After developing detailed analyses of a number of central everyday concepts of social phenomena--including shared action, a social convention, a group's belief, and a group itself--she proposes that the core social phenomena among human beings are "plural subject" phenomena. In her analyses Gilbert discusses the work of such thinkers as Emile Durkheim, Georg Simmel, Max Weber, and David Lewis. "Gilbert's book aims to ... exhibit some general and structural features of the conceptual scheme in terms of which we think about social groups, collective action, social convention, and shared belief.... [It] offers an important corrective to individualistic thinking in the social sciences...."--Michael Root, Philosophical Review "In this rich and rewarding work, Margaret Gilbert provides a novel and detailed account of our everyday concepts of social collectivity. In so doing she makes a seminal contribution to ... some vexed issues in the philosophy of social science.... [An] intellectually pioneering work."--John D. Greenwood, Social Epistemology
Type: Book
URL: https://0.www.degruyter.com/document/doi/10.1515/9780691214627/html
Full Citation: "Gilbert, M. (2020) On Social Facts, On Social Facts. Princeton University Press. Available at: https://doi.org/10.1515/9780691214627."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2020
---
