---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Handbilling at the Mall
Takeaway: Constitutional Avoidance Trumps Chevron
Tags:
  - Agency Deference
  - Substantive Canons
  - Constitutional Avoidance
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "****"
Year: 1988
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: DeBartolo Corp. v. Florida Gulf Coast Building and Construction Trades Council
Status: Annotated
Date: 1988-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Labor union distributes handbills at mall asking patrons to boycott until mall promises to use contractors that pay fair wages.
> - Mall files complaint with NLRB charging union with unfair labor practices under Section 8b4 of NLRA, which describes unfair labor practice as “to threaten, coerce, or restrain ainy person engaged in commerce” except for a primary strike.
> - NLRB interprets section 8b4 to prohibit handbilling

> [!note]+ Procedural History and Posture
> - 11th Circuit denies enforcement of order, noting conflicts with the 1st Amendment

- Issue: Is the agency’s interpretation of the statute valid?

> [!note]+ Holding (White): No
> > Statutory interpretation by the board would normally be entitled to deference unless that construction were clearly contrary to the intenr of Congress.
> 
> - But their interpretation poses serious questions about the statute’s validity under the 1st Amendment
> 
> > Where an otherwise acceptable construction of a statute would raise serious constitutional problems, the Court will construe the statute to avoid such problems unless such construction is plainly contrary to the intent of Congress.
> 
> - Because of this, even if agency’s construction is permissable, “we must independently inquire whether there is another interpretation, not raising these serious constitutional questions, that may be fairly ascribed” to the statute.
> - Now look to legislative history to see if that interpretation is foreclosed (it isn’t)
> - Disposition: Affirmed
