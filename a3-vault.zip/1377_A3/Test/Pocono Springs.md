---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Can’t Leave It
Takeaway: Real property cannot be abandoned
Tags:
  - Abandonment
  - Parol Evidence Rule
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1995
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pocono Springs Civic Association, Inc. v. MacKenzie
Status: Annotated
Date: 1995-01-01
Jurisdiction: Pennsylvania
---
> [!note]+ Facts
> - Mackenzies buy property in Pocono Springs
> - They try to build on it but can’t, unable to sell it
> - Pocono Springs charges fees on property
> - Mackenzies refuse to pay, attempt to abandon
>     - Stop paying real estate tax
>     - Sign notarize statement stating desire to abandon
>     - Do not accept mail

- Issue: Did the Mackenzie’s abandon their property?

> [!note]+ Holding (Rowley): No, they can’t with perfect title to it.
> > [The Mackenzies’] intent is irrelevant. What is controlling is our law, which states that real property cannot be abandoned.
