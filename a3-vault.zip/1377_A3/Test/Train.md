---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Radioactive History
Takeaway: Use of legislative history
Tags: []
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Train v. Colorado Public Interest Research Group
Status: Annotated
Date: 1976-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - EPA can control water pollution under Federal Water Pollution Control Act, including “radioactive materials”
> - They encourage states to implement and go above the federal floor of regulation in “race to the top”
> - Atomic Energy Commission can control “source material, special nuclear material, and byproduct material”
> - AEA prevents further regulation, setting the floor and the ceiling (Supremacy Clause)

- Issue: Is nuclear material a “pollutant” under EPA regulation?

> [!note]+ Holding (Marshall): No, Congress intended it not to be
> - House Committee Report says not included
> - Floor Debate says not included
> - Evidence of Absence: A paragraph that would have explicitly included nuclear material wasn’t included (defeated by 3-1 vote in the House)
> - If nuclear material was covered, this amendment would have been superfluous
> - Ranking member of Conference Committee clarified that it’s not included
