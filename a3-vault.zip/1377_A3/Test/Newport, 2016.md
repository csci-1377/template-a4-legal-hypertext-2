---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Newport, Cal
Title: Deep Work
Takeaway: ""
Tags: []
Category:
  - Self-Help
Abstract: ""
Type: Audiobook
Rating: "***"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2016
---
- Methods
    - Monastic: cut yourself off entirely
    - Bimodal: do it sometimes in big chunks
    - Rhythmic: do it at regular intervals in your day or week
    - Journalistic: do it whenever you can, and get good at transitioning into it.
- Organizing Space and Time
    - Hub and spoke: have a central place where you engage with others (maximizing serendipitous encounters), clearly distinguished from a place of solitude (maximizing depth). Don’t try to blend them.
    - Deep work can be collaborative when you are building on the thoughts of others, anticipating their responses and generating your own
- Execution
    - Focus on the wildly important
    - Focus on lead measures (process) rather than lag measures (results). 
    - Keep a scorecard. Basically track your hours spent in deep work in a visible, visceral way.
    - Have a cadence of accountability (basically give yourself a daily/weekly performance review)
- Shutdown Ritual
    - Check email
    - Check to-do
    - Make plan for tomorrow
    - Say “shut down complete”
- Schedule time to use the internet and do not use it outside of that.
    - If you find you absolutely need it, wait at least five or ten minutes to use it to ensure there isn’t automatic distraction reward.
- Attention Interval Training
    - Set small reach goals of accomplishment for specific time blocks, with the goal of constantly increasing intensity.
- Productive Meditation
    - Don’t let yourself shift to other tempting thoughts, especially seemingly productive but unrelated ones.
    - Be careful about looping: rehashing again and again what you already know
    - Structure your deep thinking. 
- Practice Memory
    - Consider Moonwalking with Einstein
    - An important side effect is increasing concentration.
- Schedule Every Minute
    - Make a plan made of time blocks for every task
    - Have a default if you get things done early
    - Be ready to run with an insight and reschedule later
- Categorize depth of all your work
    - Ask yourself: how quickly could you train a smart, recent college grad to do the task?
- Fixed Schedule Productivity
    - Set a limit on how much you will work
    - For instance, do not work after 5:30
    - Then be more rigorous with what you will do in those hours
    - Shift your default answer to no, since you are already fully booked
- Become hard to reach
    - List specific contacts or forms with specific purposes to create a “sender filter”.
    - Say something like “I will only respond if the opportunity is a good match for my time and interests”
    - For my work, it could be something like. “We are devoting maximum energy toward our current clients…”
    - First make people go through an FAQ
    - Then have them fill out a form that will be a relatively heavy load/burden
    - Finally, maybe make people check a box saying “this is not…”
- Give process centric responses
    - For “let’s get coffee sometime” say “I’d love to, here are days and times that work for me, reply to confirm or call this number if none work.”
    - If there is some draft/feedback for comment, propose when you’ll respond by, what will be included, etc.

