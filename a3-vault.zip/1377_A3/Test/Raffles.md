---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Exchequer
Authors: ""
Title: Peerless’ Peer
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 1864
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Raffles v. Wichelhaus
Status: Annotated
Date: 1864-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - Raffles and Wichelhaus agree on sale of 125 bales of Surat cotton on ship called “Peerless”
> - Raffles gets it and prepares to sell
> - At time agreed upon, ship called Peerless comes in with no cotton
> - Then a different ship by the same name comes in with the cotton
> - Wichelhaus refuses to buy it
>     - Is it because they assumed the deal was off, or because the cotton prices dropped?
> - Raffles sues for breach

- Issue: Did defendents breach the contrat by failing to buy new cotton?

> [!note]+ Holding (Per Curiam): No, no consensus
> - The contract is ambiguous, there is a material term that is super duper ambiguous (two ships by the same name)

> [!note]+ Context
> - The cotton is a commodity, so it doesn’t matter for content which is which
> - BUT Specifying the ship matters because it allocates risk: if the ship sinks, contract is void (if either ship had sank, we would have important ambiguity)
> - BUT the ships both actually made it, so does it really matter?
> 