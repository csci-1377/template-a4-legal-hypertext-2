---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Double Insulation
Takeaway: Two layers of for-cause insulation is unconstitutional
Tags:
  - Removal
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 2010
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Free Enterprise
Status: Annotated
Date: 2010-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - PCAOB regulated accounting industry under the SEC
> - PCAOB and SEC commission both requires for cause removal 

- Issue: Is PCAOB structure unconstitutional?

> [!note]+ Holding (Roberts): Yes
> - Rejects idea that “simple disagreement with [an independent agency’s] policies or priorities could constitute ‘good cause’ for removal”
> - This level of insulation is contrary to vesting and take care clauses

> [!note]+ Dissent (Breyer): No
> - Look to “function and context, and not to bright-line rules”