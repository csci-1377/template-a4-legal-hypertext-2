---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Farm Brothers Defraud IRS
Takeaway: Parties to conspiracy are liable for crimes of others within it.
Tags:
  - Conspiracy
Category:
  - Crim
Abstract: ""
Page: 835
Type: Case
Rating: "**"
Year: 1946
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Pinkerton v. United States
Status: Annotated
Date: 1946-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Brothers conspired, one actually commits while the other is in jail.
> - They agreed to defraud IRS

> [!note]+ Procedural History and Posture
> - 

- Issue: Are both brothers liable?

> [!note]+ Holding (Douglass): Yes.
> > so long as the partnership in crime continues, the partners act for each other in carrying it forward.





















