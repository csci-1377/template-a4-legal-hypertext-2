---
base: "[[Test.base]]"
In-Text Citation: (Gupta, 2016)
Authors: Gupta, Deepak
Title: "Leveling the Playing Field on Appeal: The Case for A Plaintiff-Side Appellate Bar"
Zotero URI: https://zotero.org/bmcanally21/items/CDE42T9F
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: ""
Full Citation: "Gupta, D. (2016) ‘Leveling the Playing Field on Appeal: The Case for A Plaintiff-Side Appellate Bar’, Duquesne Law Review, 54."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
---
