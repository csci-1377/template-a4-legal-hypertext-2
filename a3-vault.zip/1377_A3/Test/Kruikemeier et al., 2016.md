---
base: "[[Test.base]]"
DOI: https://doi.org/10.1089/cyber.2015.0652
In-Text Citation: (Kruikemeier, Sezgin and Boerman, 2016)
Priority: Further
Authors: |-
  Kruikemeier, Sanne
  Sezgin, Minem
  Boerman, Sophie C.
Title: "Political Microtargeting: Relationship Between Personalized Advertising on Facebook and Voters' Responses"
Zotero URI: http://zotero.org/users/4316906/items/NJ3JDMLA
Takeaway: ""
Tags: []
Category:
  - Justice and Future Generations
Abstract: This study examines the relationship between exposure to political personalized ads on Facebook and voters' responses toward those ads and studies the mediating role of the use of persuasion knowledge in this relationship. Results from an online experiment (N = 122) demonstrate that exposure to a personalized ad from a political party activates persuasion knowledge, which in turn leads to lower intentions to engage in electronic word of mouth, but only for those participants who recall seeing the Sponsored label. We found no effects on source trustworthiness. Adding a text explaining the practice of personalized advertising did not lead to higher levels of persuasion knowledge and did not change the responses toward the message.
Type: Journal Article
URL: https://www.liebertpub.com/doi/abs/10.1089/cyber.2015.0652
Full Citation: "Kruikemeier, S., Sezgin, M. and Boerman, S.C. (2016) ‘Political Microtargeting: Relationship Between Personalized Advertising on Facebook and Voters’ Responses’, Cyberpsychology, Behavior, and Social Networking, 19(6), pp. 367–372. Available at: https://doi.org/10.1089/cyber.2015.0652."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2016
---
