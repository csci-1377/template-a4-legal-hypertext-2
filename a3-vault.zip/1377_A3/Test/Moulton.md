---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: "No Contract: Salty?"
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1884
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Moulton v. Kershaw
Status: Annotated
Date: 1884-01-01
Jurisdiction: Wisconsin
---
> [!note]+ Facts
> - Kershaw sends Moulton an “offer” by telegraph of barrels at 85p per barrel
> > DEAR SIR: In consequence of a rupture in the salt trade, we are authorized to <u>offer</u> Michigan fine salt, in full car-load lots of eighty to ninety-five bbls., delivered at your city, at 85c. per bbl., to be shipped per C. & N. W. R. R. Co. only. At this price it is a bargain, as the price in general remains unchanged. Shall be pleased to receive your order.
> - Moulton asks for $2,000 barrels
> - Kershaw refuses to sell
> - Moulton sues for breach, $800 + interest
> - Statute of frauds says contract exceeding $50 is void unless in writing

> [!note]+ Procedural History and Posture
> - Defendants demurr to complaint
> - Circuit court overrides demurrer
> - Defendants appeal

- Issue: Did the letters constitute a contract?

> [!note]+ Holding (Taylor): No, they didn’t
> - The first was not an offer, because the amount was not specified: it was an invitation to negotiate
> - Otherwise the other party could buy as much as they wanted
> - Moulton wants it construed as “amount reasonable” but this would add too much vagueness
> - But the language doesn’t talk about “selling” at all
> - No manifest intent to be bound, demurrer should be sustained.
> - Disposition: Reversed