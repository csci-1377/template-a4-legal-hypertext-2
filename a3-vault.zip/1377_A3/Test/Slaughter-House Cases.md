---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Butcher Relocation
Takeaway: POIC has no teeth (1st 14A interpretation)
Tags:
  - 14A
  - POIC
  - 13A
Category:
  - Con Law
Abstract: ""
Page: 1031
Type: Case
Rating: "****"
Year: 1873
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: The Slaughter-House Cases
Status: Annotated
Date: 1873-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - New multiracial LA legislature does a bunch
> - One of the things is to clean up NOLA streets
> - One of those methods is to create a new monopoly for slaughter-houses. Butchers have to go work there.
> - Butchers say I don’t want to go work there!
> - 1st time interpreting 14A S1

- Issue: Can LA create a monopoly for slaughter houses?

> [!note]+ Holding (Miller): Yes
> - 13A: That was about African slavery, this isn’t that.
>     - We can see that this could apply to *some* other things, but not a ton
>     - This is much more narrow than what the federal government can prohibit
> - PAIC
>     - These are citizens *of* Louisiana, so they aren’t being discriminated against because they’re from another state.
> - POIC
>     - There’s US citizenship and there’s state citizenship
>     - State citizenship comes with all kinds of rights
>     - US citizenship only comes with a few bonus things
>         - Traveling around the US (inc interstate commerce)
>         - Help from/linteraction with federal government
>         - And states can’t stop you from doing *that*
>     - Another reading: POI are the rights against the federal government!
>         - But this would seriously limit what states could do!
> - DPC: Naw, not relevant (foreshadowing)
>     - That’s just about fair procedure
> - EPC: Nope.
>     - This is *just* about discrimination against black people, or maybe race generally

> [!note]+ Dissent (Field): No!
> - Right to work is “one of the most sacred and imprescriptible rights of man”!
> - This should prevent arbitrary or unreasonable interference with this right.

> [!note]+ Dissent (Bradley): No!
> - Property is basically the same as the pursuit of happiness





















