---
base: "[[Test.base]]"
In-Text Citation: (Taylor, 1985)
Priority: Recommended
Authors: ""
Title: What's wrong with negative liberty
Zotero URI: http://zotero.org/users/4316906/items/YHAIJPLA
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: This is an attempt to resolve one of the issues that separate ‘positive’ and ‘negative’ theories of freedom, as these have been distinguished in Isaiah Berlin's seminal essay, ‘Two concepts of liberty’. Although one can discuss almost endlessly the detailed formulation of the distinction, I believe it is undeniable that there are two such families of conceptions of political freedom abroad in our civilization.Thus there clearly are theories, widely canvassed in liberal society, which want to define freedom exclusively in terms of the independence of the individual from interference by others, be these governments, corporations or private persons; and equally clearly these theories are challenged by those who believe that freedom resides at least in part in collective control over the common life. We unproblematically recognize theories descended from Rousseau and Marx as fitting in this category.There is quite a gamut of views in each category. And this is worth bearing in mind, because it is too easy in the course of polemic to fix on the extreme, almost caricatural variants of each family. When people attack positive theories of freedom, they generally have some Left totalitarian theory in mind, according to which freedom resides exclusively in exercising collective control over one's destiny in a classless society, the kind of theory which underlies, for instance, official communism. This view, in its caricaturally extreme form, refuses to recognize the freedoms guaranteed in other societies as genuine.
Type: Book Section
URL: https://www.cambridge.org/core/books/philosophical-papers/whats-wrong-with-negative-liberty/0C7EF33286425EE03B6465225D796FC8
Full Citation: "Taylor, C. (ed.) (1985) ‘What’s wrong with negative liberty’, in Philosophical Papers: Volume 2: Philosophy and the Human Sciences. Cambridge: Cambridge University Press, pp. 211–229. Available at: https://doi.org/10.1017/CBO9781139173490.009."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 1985
---
