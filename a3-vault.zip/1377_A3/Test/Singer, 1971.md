---
base: "[[Test.base]]"
In-Text Citation: (Singer, 1971)
Priority: Essential
Authors: Singer, Peter
Title: Famine, Affluence, and Morality
Zotero URI: http://zotero.org/users/4316906/items/9DVPWTGM
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Journal Article
Rating: "*****"
Full Citation: Singer, P. (1971) ‘Famine, Affluence, and Morality’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 1971
---
> [!note]+ Our Situation
> - People are dying in East Bengal from lack of food, shelter, and medical care
> - The rich nations could reduce further suffering to very small proportions
> - Rich nations, and those within them, are aware of the problem
> - Still, they do almost nothing about it

> [!note]+ Premises
> - Suffering and death from lack of food, shelter, and medical care are bad
> 
> > If I am walking past a shallow pond and see a child drowning in it, I ought to wade in and pull the child out. This will mean getting my clothes muddy, but this is insignificant, while the death of the child would presumably be a very bad thing. (pg 231)
> 
> - If it is in our power to prevent somthing bad from happening, without thereby sacrificing something of comparable moral importance, we ought, morally, to do it. 
> - No account of proximity or distance
>     - Someone being closer does not mean we *ought* to help him rather than another who happens to be further away
> - No account of how many could help
>     - Are you less obligated to pull out the child if there are ten others who could just standing there?
>     - “if everyone gave, so I only ought to give” doesn’t work because premise is hypothetical and  conclusion isn’t

> [!note]+ Conclusions
> - Traditional distinction between duty and charity cannot be drawn
> - Giving isn’t “supererogatory”
> - Strong: until we are at the level of marginal utility
> - Weak: Until we sacrifice something morally important

> [!note]+ Objections/Responses
> - Demands too much
>     - Saying it is too drastic a revision to our moral scheme doesn’t make it less true (it does if you think morals are partially empirical)
>     - This doesn’t say we have to spend all our time maximizing happiness, just reducing misery
> - Morality is supposed to help our own society, not others
>     - “The moral point of view requires us to look beyond the interests of our own society”
> - We need a code that doesn’t go too far beyond our capacities, so as not to lose adherence
>     - We don’t have reason to believe increasing expectations will decrease, rather than increase adherence
> - Allows government and noncontributing to escape responsibilities
>     - Assumes donating will disincentivize further donation, opposite more plausible
>     - If you think the opposite, then spend all your time campaigning instead
> - This will just exacerbate overpopulation
>     - Then fund population reduction instead