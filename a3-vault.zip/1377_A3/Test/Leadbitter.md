---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Exchequer
Authors: ""
Title: Kicked Out of Racetrack
Takeaway: Licenses are revokable unless they entail grants (then irrevocable until fulfilled)
Tags:
  - License
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1845
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Wood v. Leadbitter
Status: Annotated
Date: 1845-01-01
Jurisdiction: England
---
> [!note]+ Facts
> - P is notoriously crooked bookmaker
> - D is ex-policeman hired to prevent shady activities
> - P buys ticket to horserace for one guinnea
> - D is hired by owner of track, asks P to leave
> - P doesn’t leave, D takes him out without returning guinnea
> - P sues for false imprisonment

> [!note]+ Procedural History and Posture
> - Brother Rolfe says it’s fine to eject P at any time without cause
> - Jury finds for D

- Issue: Are liscenses revokable at owner’s discretion?

> [!note]+ Holding (Alderson): Yes, they are
> > No incorporeal inherittance (use rights) affecting land can either be created or transferred otherwise than by deed
> 
> - But sometimes liscenses entail grants (hunt and then take away one deer), which then make liscenses irrevocable until grant fulfilled
> - Payment for ticket doesn’t matter, that’s about breach of contract if anything
> 
