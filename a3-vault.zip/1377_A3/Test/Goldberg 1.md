---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Revoking Welfare
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1970
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Goldberg v. Kelly
Status: Annotated
Date: 1970-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Welfare scheme revoked, offered post-termination notice and hearing
> 
> > [!note]+ Glenn’s
> > Plaintiffs were NYC residents who had received financial aid under the Aid to Families with Dependent Children (“AFDC”) program or another welfare scheme, which was a federally assisted program. Plaintiffs claimed that their benefits had been terminated without prior notice and a hearing in violation of DP.
> > 
> > NY said its post-termination notice and hearing was adequate. Under NY’s process a caseworker who had doubts about a recipient’s continued eligibility for the program would first discuss it with that person and then recommend termination if still thought ineligible. At that point, notification of termination was sent to recipient along with info about the availability of a post-termination hearing before an independent officer where recipient can appear personally, offer oral evidence, confront and cross-examine witnesses against him, and have a record made of hearing. If recipient wins, then all erroneously withheld funds are returned to him. If he loses he can then seek judicial review.

> [!note]+ Procedural History and Posture
> - District Court determined pre-termination hearing required
> - New York appealed
> - Question- Is Plaintiff entitled to a pre-deprivation hearing instead? What form does it have to take?

> [!note]+ Holding (Brennan)
> - Summary- Benefits are property, and pre-termination is required
>     - People survive on these and would “suffer a grevious loss” if revoked
>     - Government interests are not overriding
>     - Also, you’re already giving post-termination hearing so why not pre?
>     - Don’t need judicial or quasi-judicial process, no complete record, but must have reasons for termination and an effective opportunity to defend and present arguments orally. 
>         - Many of these people can’t make good written arguments
>         - Able to adjust presentation to the questions asked
>         - Need to be able to appear with or without council (not your caseworker)
>         - Need a written decision
>         - Must be an impartial decision maker (can’t review own decision)
>     - must be “at a meaningful time in a meaningful manner.”
> - Disposition- Affirmed

> [!note]+ Dissent (Black)
> - We are experimenting with a welfare state
> - People go on and off the rolls all the time
> - Experiments should not be “frozen” into the Constitution
> - The legislature should be able to be flexible
> - This will hurt recipients because gov will hesitate to put people on rolls

> [!note]+ Thoughts and Questions
> - Background: “New Property” article expands notion of property
> - Four Takeaways
>     - Things can go from mere privelege to rights by convention
>     - Just outcomes depend on just processes
>     - Who gets to decide about processes? Legislature or Judiciary?
>     - We need sensitivity to different litigants having different capacities
