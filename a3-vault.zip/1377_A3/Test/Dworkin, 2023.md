---
base: "[[Test.base]]"
In-Text Citation: (Dworkin, 2023)
Priority: Essential
Authors: Dworkin, Ronald
Title: Constructivism
Zotero URI: https://zotero.org/bmcanally21/items/TKABKSU5
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: ""
Type: Document
Rating: "***"
Full Citation: Dworkin, R. (2023) ‘Constructivism’.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2023
---
> [!note]+ Rules, Principles, and Policies (Taking Rights Seriously)
> > [!note]+ Policies 
> > - a kind of standard that sets out a goal to be reached, generally an improvement in some economic, political, or social feature of the community.
> 
> > [!note]+ Principles
> > - Standard that is to be observed, not because it will advance or secure an economic, political, or social situation deemed desirable, but because it is a requirement of justice or fairness or some other dimension of morality
> > - Has weight, must be taken into account when relevant, unlike rules…
> > - Reasonable, negligent, unjust, and significant turn rules into applications of principles
> 
> > [!note]+ Rules
> > - Rules are applicable in an all-or-nothing fashion. If the facts a rule stipulates are given, then the rule is valid, in which case the answer it supplies must be accepted, or it is not, in which case it contributes nothing to the decision
> > - If two rules conflict, one of them cannot be a valid rule

> [!note]+ Discretion
> - Weak sense
>     - Standards must not be applied mechanically, but demand the use of judgment
>     - Or that an official’s decision has final authority and cannot be reversed
> - Strong sense
>     - Simply not bound by standards set by any authority
>     - Can still be criticized, to have made a mistake, but not to have deprived anyone of what they were entitled

> [!note]+ Reflective Equilibrium
> - It is the task of moral philosophy…

> [!note]+ Morality
> - “Coherence theory” of morality
> 
> > [!note]+ Natural model
> > - Objective moral reality
> > - Moral reasoning is a process of reconstructing the fundamental principles by assembling concrete judgments in the right order, as a natural historyian reconstructs the shape of the whole animal from the fragments of bones that he has found
> 
> > [!note]+ Constructive Model
> > - Does not assume that the principles of justice have some fixed, objective existence, so that descriptions of these principles must be true or false in some standard way. It does not assume that the animal it matches to the bones actually exists. It makes the different, and in some ways more complex, assumption that men and women have a responsibility to fit the particular judgments on which they act into a coherent program of action, or, at least, that officials who exercise power over other men have that sort of responsibility.
> > - Does not suppose that precedents are glimpses into moral reality… Instead, in the spirit of the constructive model, he accepts these precedents as specifications for a principle that he must construct, out of a sense of responsibility for consistency with what has gone before
> > - The constructive model does not presuppose skepticism or relativism… It does not deny, any more than it affirms, the objective standing of any of these convictions. (Consistent with, but doesn’t require moral realism)
> > - The constructive model insists on consistency with conviction as an independent requirement, flowing not from the assumption that these convictions are accurate reports, but from the different assumption that it is unfair for officials to act except on the basis of a general public theory that will constrain them to consistency, provide a public standard for testing or debating or predicting what they will do, and not allow appeals to unique intuitions that migght mask prejudice or self-interest in particular cases. The constructive model requires coherence, then for independent reasons of political morality; it takes convictions held with the requisite sincerity as given, and seeks to impose conditions on the acts these intuitions might be said to warrant. 
> > - The constructive model… is well suited to group consideration of problems of justice, that is, to developing a theory that can be said to be a theory of a community rather than of particular individuals, and this is an enterprise that is important, for example, in adjudication. … with no claim to a description of an objective moral universe.
> 
> > [!note]+ Difference
> > - Natural model submerges apparent contradiction
> > - Constructive model demands that we act on principle rather than on faith.

> [!note]+ Interpretation (LE)
> - Friends have a responsibility to treat one another as friends, and that means, put subjectively,t hat each must act out of a conception of friendship that he is ready to recognize as vulnerable to an interpretive test, as open to the objection that this is not a plausible account of what friendship means in our culture.
>     - Interpersonal test!!!
> - Chain novel: why the novel?
>     - Television soap operas span decades with the same characters and some minimal continuity of personality and plot, though they are written by different teams of authors even in different weeks.
>     - Each novelist aims to make a single novel of the material he has been given, what he adds to it, and (so far as he can control this) what his successors will want or be able to add.
> - Law is an interpretive concept. Judges should decide what the law is by interpreting the practice of other judges deciding what the law is. General theories of law, for us, are general interpretations of our own judicial practice.
> - 

> [!note]+ My Departure
> - Each reader must ask how far he would follow me along the tree of argument… If he leaves my argument early, at some crucial abstract stage, then I have largely failed for him. If he leaves it late, in some matter of relative detail, then I have largely succeeded. I have failed entirely, however, if he never leaves my argument at all.

> [!note]+ Conclusion
> - Law’s empire is defined by attitude, not territory or power or process.
> - It is a protestant attitude that makes each citizen responsible for imagining what his society’s public commitments to principle are, and what these commitments require in new circumstances. 
> - It is, finally, a fraternal attitude, an expression of how we are united in community though divided in project, interest, and conviction. That is, anyway, what law is for us: for the people we want to be and the community we aim to have.

> [!note]+ Author’s Thoughts
> - Political justification depends on the soundness of the characterization
> - Dworkin is trying to answer the question: how do we build an adequate or correct conception out of only fragmentary agreement in legal interpretation, that is, agreement about paradigm cases but not about particular cases?

> [!note]+ Further Reading
> - Taking Rights Seriously
> - Look at inclusive integrity in LE