---
base: "[[Test.base]]"
In-Text Citation: (Brucato, 2022)
Priority: Essential
Authors: Brucato, Giorgia
Title: "Justice and Peace: Children’s Political Participation Claim"
Zotero URI: http://zotero.org/users/4316906/items/X4ECH6LI
Takeaway: ""
Tags: []
Category:
  - CELPA
Abstract: This paper discusses what I call the Political Participation Claim, which is grounded on the morally weighty interests of children who experienced war in living in peaceful, just societies, and in participating in the political life towards the realization of such interests. After considering children’s political interests in general, and in post-war contexts specifically, I show that war impacts, for either better or worse, the development of children’s moral powers as well as rises their stakes in political participation in post-war efforts. I then defend the proposal that children for whom it would not be too harmful, i.e. too burdensome, to participate in political, justice- and peace-oriented processes, have a claim right to political participation, including the right to vote; while children for whom it would be too burdensome to participate have a claim to see realized their interests through a system of fiduciary representatives, and to be involved in less burdening forms of political (and non) participation. I address two worries to my proposal, grounded on the risks of (re)harm and the attribution of responsibility, and conclude by advancing the novel proposal that while it is crucial to examine what justice demands societies do for children, it is worth considering what justice demands of children, particularly when they experience unjust background conditions, like children who experienced war. I thus build a justification of children’s duty to carry the burdens of participation grounded on their morally relevant interests, and their instrumental role and liability to incur costs in the realization of such interests.
Type: Journal Article
Rating: "**"
Full Citation: "Brucato, G. (2022) ‘Justice and Peace: Children’s Political Participation Claim’, p. 24."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
