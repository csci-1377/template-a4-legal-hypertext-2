---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Topeka School Segregation
Takeaway: Seperate is not equal and cannot be made equal. Focus on harm, not tradition.
Tags:
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1257
Type: Case
Rating: "*****"
Year: 1954
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Brown v. Board of Education
Status: Annotated
Date: 1954-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Doll test illustrates the “badge of inferiority”
> - P concedes that schools might have tangibly similar education.
> - Arguments heard, deadlocked, ask for rehearing, Fred Vinson dies.
> - Warren gets a unanimous opinion.

- Issue: Can separate be equal?

> [!note]+ Holding (Warren): No.
> > Although [legislative history] sources cast some light, it is not enough to resolve the problem with which we are faced… We cannot turn the clock back to 1868.
> 
> - Can’t just look to “tangible” factors, but include “intangible considerations”
> 
> > A sense of inferiority affects the motivation of a child to learn.
> 
> > Separate education facilities are inherently unequal.
> 
> - And we’re going to leave figuring out the remedy to later (foreshadowing “with all deliberate speed”





















