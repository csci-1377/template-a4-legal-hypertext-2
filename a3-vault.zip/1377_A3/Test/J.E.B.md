---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Sex Discrimination in Jury Challenges
Takeaway: Also not allowed.
Tags:
  - Jury Trial
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1994
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: J.E.B. v. Alabama ex rel T.B.
Status: Annotated
Date: 1994-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Alabama on behalf of mother of a child seeks paternity and child support from father. 
> - The state used nine of its ten peremptories to remove male jurors, so it got a jury of only women. 

> [!note]+ Procedural History and Posture
> - Alabama courts reject the objection that this use of peremptories violates the Fourteenth Amendment. 

- Issue: Can private litigants use peremptory challenges on the basis of sex?

> [!note]+ Holding (Blackmun Plurality of 4): No
> > All persons, when granted the opportunity to serve on a jury have the right not to be excluded summarily because of discriminatory and stereotypical presumptions that reflect and reinforce patterns of historical discrimination.
> 
> - Disposition: Reversed

> [!note]+ Concurrence (O’Connor): I’m Concerned
> - Basically, we’re eliminating the litigant’s ability to statistically discriminate.
> - Does this prevent a battered woman from trying to get other women on the jury?
> 