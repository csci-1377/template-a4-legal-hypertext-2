---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: The law of all people at all times
Takeaway: No deference to state judicial decisions
Tags:
  - Vertical Choice of Law
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "****"
Year: 1842
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Swift v. Tyson
Status: Annotated
Date: 1842-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> The actual case turns on the available defenses in the law of negotiable instruments. Tyson says, under NY law I have a good defense: the speculators deceived me into believing they owned the land when in fact they didn’t, and that fraud taints the whole transaction and gives me a defense to Swift’s action to collect on my note. But there is another set of decision emerging out of England saying that if Swift accepted the instrument without knowing about the fraud, why should he suffer, there should be no defense *as to* **What is important** is that Tyson says, under NY law I have a good defense in this action, you need to apply NY law in this diversity actions because of the Rules of Decision Act.

- Issue: Does “laws of the several states” mean only statutes passed by a state, or does it also mean “the decisions of the local tribunals” as well?

> [!note]+ Holding: Only statutes, not judicial decisions
> > In the ordinary use of language, it will hardly be contended, that the <u>decisions of courts </u>constitute laws. They are, at most, o<u>nly evidence of what the laws are, and are not, of themselves, laws.</u> They are often re-examined, reversed and qualified by the courts themselves, whenever they are found to be either defective, or ill-founded, or otherwise incorrect. The l<u>aws of a state are more usually understood to mean the rules and enactments promulgated by the legislative authority</u> thereof, or long-established local customs having the force of laws. In all the various cases, which have hitherto come before us for decision, this court have uniformly supposed, that the true interpretation of the 34th section limited its application to state laws, strictly local, that is to say, to the positive statutes of the state… Undoubtedly, the decisions of the local tribunals upon such subjects are entitled to, and <u>will receive, the most deliberate attention and respect of this court; but they cannot furnish positive rules, </u>or conclusive authority, by which our own judgments are to be bound up and governed. The law respecting negotiable instruments may be truly declared in the languages of Cicero, adopted by Lord Mansfield in *Luke v. Lyde*, 2 Burr. 883, 887, to be in a great measure, <u>not the law of a single country only, but of the commercial world.</u> Non erit alia lex Romae, alia Athenis; alia nunc, alia posthac; sed et apud omnes gentes, et omni tempore una eademque lex obtinebit. [“not just the law of Rome or Athens or any one place, but <u>the law of all people at all times.</u>”] It becomes necessary for us, therefore, upon the present occasion, to express our own opinion of the <u>true result</u> of the commercial law upon the question now before us.”