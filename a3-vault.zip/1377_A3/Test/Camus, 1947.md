---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Camus, Albert
Title: The Plague
Takeaway: ""
Tags: []
Category:
  - Fiction
Abstract: ""
Type: Audiobook
Rating: "****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
Year*: 1947
---
“However, it is not the narrator’s intention to ascribe to these sanitary groups more importance than their due. Doubtless today many of our fellow citizens are apt to yield to the temptation of exaggerating the services they rendered. But the narrator is inclined to think that by attributing overimportance to praiseworthy actions one may, by implication, be paying indirect but potent homage to the worse side of human nature. For this attitude implies that such actions shine out as rare exceptions, while callousness and apathy are the general rule. The narrator does not share that view. The evil that is in the world always comes of *ignorance*, and good intentions may do as much harm as malevolence, if they lack understanding. On the whole, men are more good than bad; that, however, isn’t the real point. *But they are more or less ignorant, and it is this that we call vice or virtue;* the most incorrigible vice being that of an ignorance that fancies it knows everything and therefore claims for itself the right to kill. The soul of the murderer is blind; *and there can be no true goodness nor true love without the utmost clear-sightedness*.”