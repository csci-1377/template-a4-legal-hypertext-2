---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Boomtown on the Tracks
Takeaway: Four ways to calculate Fair Market Value
Tags:
  - Eminent Domain
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1943
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Miller
Status: Annotated
Date: 1943-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Us condemns strip of land for railroad tracks 
> - Some of the land includes a town
> - US files eminent domain action, paying estimated just compensation to court
> - US wants to calculate fair market value at earlier time to pay less.

- Issue: How to calculate fair market value?

> [!note]+ Holding (Roberts): Four ways to calculate
> - Examine **recent transactions** in which property was sold, adjust for general market price change
> - Examine recent transactions of other similar parcels in area and adjust for differences
> - Estimate the rental value and capitalize to reach a purchase price using standard rate of return
> - Determine the replacement cost and adjust downward to reflect depreciation
> 