---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Hold Harmless Battle
Takeaway: ""
Tags:
  - Definiteness
  - Acceptance
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 2002
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Richardson v. Union Carbide Industrial Gases, Inc.
Status: Annotated
Date: 2002-01-01
Jurisdiction: New Jersey
---
> [!note]+ Facts
> - Rage provides parts to H for converting furnace from iron to steel
> - The offer and acceptance for sale of parts include two conflicting indemnification agreements (both hold each other harmless)
> - H pays Rage and uses the furnace for a few years
> - A worker is injured when furnace explodes and sues both R and H

> [!note]+ Procedural History and Posture
> - Rage sues H according to its indemnification, H moves to dismiss
> - Motion granted in summary judgment

- Issue: What do we do with conflicting terms?

> [!note]+ Holding (Braithwhite): Knock ‘em out!
> - Three options
>     - Knock-out rule (majority)
>     - Offer’s terms control
>     - Offeror’s terms prevail if the terms in acceptance are materially different
> - Other options are inequitable and less used
> - Disposition: Affirmed