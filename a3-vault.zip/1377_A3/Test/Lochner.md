---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Baking Contracts
Takeaway: "Skeptical means-ends test for state police powers (leaning heavily on pretext), Harlan/D: use data, Holmes/D: deferential means-ends test"
Tags:
  - SDP
Category:
  - Con Law
Abstract: ""
Page: 1107
Type: Case
Rating: "*****"
Year: 1905
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Lochner v. New York
Status: Annotated
Date: 1905-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Baking 
> - NY imposes 10-hour maximum on baker working hours
> - Lochner convicted for breaking law
> - Defend by challenging constitutionality of conduct

> [!note]+ Procedural History and Posture
> - 

- Issue: Does this law unconstitutionally deprive liberty of contract under 14A DPC?

> [!note]+ Holding (Peckham): Yes
> - Liberty in DPC protects the “liberty of contract”
> - Precedent: There is nothing in *Holden* (miner maximum hours) that covers this.
>     - There, real safety concerns were at issue.
> - Valid as labor law? No, bakers are not “wards of the state” (anti-paternalism)
> - And this is not really a health or morals law, so on the whole it’s invalid.
>     - No connection between number of baker hours and the “healthful quality of the bread made by the workmen.”
>     - This is a *pretextual* law, passed for other motives.
> - Disposition: 

> [!note]+ Dissent (Harlan): No, this is *clearly* a health law!
> - I have statistics from Germany!
> - Don’t hold invalid unless it is “beyond question, plainly and palpably in excess of legislative power”
> 
> > Whether or not this be wise legislation is not the province of the court to inquire.
> 
> - There is at least room for debate and for an honest difference of opinion here.

> [!note]+ Dissent (Holmes): No, the constitution does not embody any particular economic theory.
> > The Fourteenth Amendment does not enact Mr. Herbert Spencer’s Social Statics… a constitution is not intended to embody a particular economic theory… it is made for people of fundamentally differing views
> 
> - Test should be whether it would infringe “fundamental principles as they have been understood by the traditions of our people and our law.”
> 
> > the right of a majority to embody their opinions in law





















