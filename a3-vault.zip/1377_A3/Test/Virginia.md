---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Rats on a muddy hill
Takeaway: Functionally balancing sex discrimination
Tags:
  - EPC
  - IS
Category:
  - Con Law
Abstract: ""
Page: 1351
Type: Case
Rating: "***"
Year: 1996
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: US v. Virginia
Status: Annotated
Date: 1996-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Virginia Military Institute (VMI) only admits men
> - They made another, different, one for women that doesn’t use the same “adversative” method (hazing)

> [!note]+ Procedural History and Posture
> - 

- Issue: Does VMI violate EPC?

> [!note]+ Holding (Ginsburg): Yes.
> - “Inherent differences” between men and women “remain cause for celebration”, but “may not be used to create perpetuate the legal, social, and economic inferiority of men.”
> - Does pedogogical “diversity” getting single-sex educational institutions justify this?
>     - Nope, that’s post hoc (skeptical examination of interest)
>     - And the women’s school doesn’t help: it’s not doing the same thing as VMI, and some women want VMI
> - Would this “destroy” VMI’s program?
>     - Nope, VMI’s goal is to create “citizen-soldiers”, not just men, and your *real* goal is compatible with admitting women (recharacterize at higher level of generality)





















