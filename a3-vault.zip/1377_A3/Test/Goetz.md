---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Subway Vigilante
Takeaway: "Statutory Self-Defense: Justification is “objective” but considers all the circumstances"
Tags:
  - Intentional Homicide
Category:
  - Crim
Abstract: ""
Page: 536
Type: Case
Rating: "****"
Year: 1986
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Goetz
Status: Annotated
Date: 1986-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - Four young black men (18-19) in a subway car
> - Two of them go up to D and say “give me $5”
> - D stands up, pulls out his gun, and shoots
> - Shoots two on right, then aims for left.
> - Checks on right, sees shot, goes to left
> - “I said ‘[y]ou seem to be all right, here’s another’,” to one on bench
> - D had bought a gun illegally aftere mugging
> - Twice warded off by just displaying gun

> [!note]+ Procedural History and Posture
> - Went to grand jury, not yet trial
> - Prosecutor instructs jury to ask whether Goetz’s conduct was that of a “reasonable man in [Goetz’s] situation” (objective)
> - D files motion to dismiss in trial court, granted, appeals affirms on grounds that grand jury instruction was wrong.
> - Actual test is Penal Law § 35.15(1) sets forth the general principles governing all such uses of force: “[a] person may * * * use physical force upon another person when and to the extent he reasonably believes such to be necessary to defend himself or a third person from what he reasonably believes to be the use or imminent use of unlawful physical force by such other person” (emphasis added).
> - “A person may not use deadly physical force upon another person under circumstances specified in subdivision one unless (a) He reasonably believes that such other person is using or about to use deadly physical force * * * or (b) He reasonably believes that such other person is committing or attempting to commit a kidnapping, forcible rape, forcible sodomy or robbery” (emphasis added).

- Issue: Was the justification defense met?

> [!note]+ Holding (Wachtler): No.
> - The proper test is objective.
>     - Statutory Interpretation: NY legislature was trying to reject the subjective test
>     - Normativity: It would be really bad if we adopted a subjective test
> > To completely exonerate such an individual, no matter how aberrational or bizarre his thought patterns, would allow citizens to set their own standards for the permissible use of force. It would also allow a legally competent defendant suffering from delusions to kill or perform acts of violence with impunity, contrary to fundamental principles of justice and criminal law.
> - This can, however, take into account the “situation” including…
>     - Any relevant knowledge the defendant had
>     - The “physical attributes of all involved”
>     - “any prior experience he had which could provide a reasonable basis for a belief that another person’s intentions were to injure or rob.”
> - Disposition: Reversed


















