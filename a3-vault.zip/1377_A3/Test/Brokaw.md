---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Wasting Away in a Mansion
Takeaway: Act of destruction is waste even if ultimately improving
Tags:
  - Waste
  - Estates
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1929
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Brokaw v. Fairchild
Status: Annotated
Date: 1929-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - Father leaves four children adjacent mansions for life, then to their heirs if they have them, if not to other children
> - One son, P, wants to scrap his mansion and build an apartment complex
> - Other children with executory interest don’t want him to
> - P files for declaration that he has right to destroy

- Issue: Can one destroy a life estate if ultimately adding value?

> [!note]+ Holding (Hammer): Not if the estate is valuable!
> > Any act of the life tenant which does permanent injury to the inheritance is waste
> 
> - First off, it’s a nice house
> - P says he’s losing money, apartment would improve
> - D says it’s waste, they have a right to object
> - D might be selfish and unwise, but they’re right
> - Fortunately, this doesn’t condemn P to a decrepit, worthless house (he might be able to tear it down if it did). This is a nice mansion we’re talking about! If and when it’s really useless, we’ll talk again.
> - Objections/replies: 
> - Disposition: 
