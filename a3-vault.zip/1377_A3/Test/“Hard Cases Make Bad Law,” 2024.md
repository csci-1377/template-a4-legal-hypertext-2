---
base: "[[Test.base]]"
In-Text Citation: (‘Hard cases make bad law’, 2024)
Authors: ""
Title: Hard cases make bad law
Zotero URI: https://zotero.org/bmcanally21/items/MTUEMD63
Takeaway: ""
Tags: []
Category:
  - Topics in Law and Philosophy
Abstract: |-
  Hard cases make bad law is an adage or legal maxim meaning that an extreme case is a poor basis for a general law that would cover a wider range of less extreme cases. In other words, a general law is better drafted for the average circumstance as this will be more common.
  The original meaning of the phrase concerned cases in which the law had a hard impact on some person whose situation aroused sympathy.
  The expression dates at least to 1837. It was used in 1904 by US Supreme Court Justice Oliver Wendell Holmes Jr. Its validity has since been questioned and dissenting variations include the phrase "Bad law makes hard cases", and even its opposite, "Hard cases make good law".
Type: Web Page
URL: https://en.wikipedia.org/w/index.php?title=Hard_cases_make_bad_law&oldid=1253876530#Bad_law_makes_hard_cases
Full Citation: "‘Hard cases make bad law’ (2024) Wikipedia. Available at: https://en.wikipedia.org/w/index.php?title=Hard_cases_make_bad_law&oldid=1253876530#Bad_law_makes_hard_cases (Accessed: 17 November 2024)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Completed
---
[Oliver Wendell Holmes Jr.](https://en.wikipedia.org/wiki/Oliver_Wendell_Holmes_Jr.) made a [utilitarian](https://en.wikipedia.org/wiki/Utilitarian)[[*clarification needed*](https://en.wikipedia.org/wiki/Wikipedia:Please_clarify)] argument for this in his judgment of [*Northern Securities Co. v. United States*](https://en.wikipedia.org/wiki/Northern_Securities_Co._v._United_States) (1904):[[4]](https://en.wikipedia.org/wiki/Hard_cases_make_bad_law#cite_note-Cip-4)

> Great cases like hard cases make bad law. For great cases are called great, 
not by reason of their importance ... but because of some accident of 
immediate overwhelming interest which appeals to the feelings and 
distorts the judgment.
