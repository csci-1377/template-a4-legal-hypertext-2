---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Pulling Pipes
Takeaway: Substantial performer can recover expectation damages minus defects in performance
Tags:
  - Cardozo
  - Substantial Performance
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1921
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Jacob & Youngs, Inc. v. Kent
Status: Annotated
Date: 1921-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - P builds house for D
> - Construction contract specifies Reading pipes
> - 75% of the pipes are not Reading 
>     - This was a matter of subcontractor oversight, not willful disregard or fraud
> - D doesn’t complete payment for the house, claiming P had breached
> - P sues for breach?

> [!note]+ Procedural History and Posture
> - Trial court finds for D, excluding purported evidence that pipes were identical
> - Appellate reverses, grants new trial

- Issue: What is the proper measure of damages for incomplete, substantial performance?

> [!note]+ Holding (Cardozo): Only difference in market value, not cost of replacement
> - The contractor has “substantially performed”, all that is needed to be owed money
> - So there was a “constructive condition” on having to pay on the basis of using those pipes, but that’s flexible
> - Rules in favor of P, granting only difference in market value, which is nothing
> - Disposition: Reversed

> [!note]+ Dissent (McLaughlin): 
> - 