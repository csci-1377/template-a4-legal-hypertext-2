---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Lawyers Pay Doctor
Takeaway: Now even informal assignment is super binding
Tags:
  - Assignment
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "****"
Year: 1991
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Herzog v. Irace
Status: Annotated
Date: 1991-01-01
Jurisdiction: Maine
---
> [!note]+ Facts
> - Jones injured in car crash, sues X
> - Doctor Herzog P treats Jones, Jones promises to pay using settlement with X (and tells lawyer)
> - Jones says never mind, I’ll pay the doctor, lawyers pay Jones directly
> - Jones doesn’t pay doctor
> - Doctor sues lawyers

- Issue: Can the doctor recover on the assigned obligation to pay?

> [!note]+ Holding: Yes
> - Client couldn’t rescind the request, so lawyers didn’t owe him money, so shouldn’t have paid him