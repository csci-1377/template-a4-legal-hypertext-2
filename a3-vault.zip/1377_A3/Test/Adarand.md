---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Give it to Gonzales
Takeaway: All race-based classifications (including federal remedial legislation) warrent strict scrutiny
Tags:
  - EPC
  - SS
Category:
  - Con Law
Abstract: ""
Page: 1388
Type: Case
Rating: "**"
Year: 1995
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Adarand Constructors, Inc. v. Peña
Status: Annotated
Date: 1995-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Congress pays contractors to hire subcontractors run by “socially and economically disadvantaged individuals”
> - And says racial minorities are presumed to be disadvantaged.
> - Contractor selects a higher bid from Gonzales over Adarand for guardrails on highway.

- Issue: Does federal affirmative action program abridge 5A EPCish?

> [!note]+ Holding (O’Connor): Yes
> - 5A and 14A protect the same interests (Bolling)
> - Important Principles
>     - Skepticism: we shouldn’t be distinguishing between remedial and subordinating legislation
>         - Strict scrutiny *is* the test to tell whether the law is remedial for a compelling purpose.
>     - Consistency
>     - Congruence
> - Metro Broadcasting (holding affirmative action to IS) was a weird turn abdidging these principles
> - There isn’t really a stare decisis problem:
> > Remaining true to an “intrinsically sounder” doctrine established in prior cases better serve the values of *stare decisis* than would following a more recently decided case inconsistent with the decision sthat came before it.
> - Not true that it’s “strict in theory, but fatal in fact”

> [!note]+ Concurrence (Thomas): Yes, and affirmative action is paternalistic
> > Government cannot make us equal; it can only recognize, respect, and protect us as equal before the law.
> 
> - So “benign” discrimination isn’t really benign: it promotes resentment and a badge of inferiority.

> [!note]+ Dissent (Stevens): No, burden and benefit aren’t the same thing!
> - Also, this creates a weird distinction between gender and race discrimination
> - Finally, the federal government should have had a longer leash.





















