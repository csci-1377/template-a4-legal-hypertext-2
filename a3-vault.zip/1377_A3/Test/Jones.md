---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Clinton Assaulting
Takeaway: President is not immune from civil suit for unofficial acts (bad predictions)
Tags: []
Category:
  - Con Law
Abstract: ""
Page: 748
Type: Case
Rating: "**"
Year: 1997
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Clinton v. Jones
Status: Annotated
Date: 1997-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Jones claims Governor Clinton invited her inside and sexually assaulted her.
> - Article comes out describing the encounter as consensual
> - She sues, claiming defamation under §1983, 14AEPC

- Issue: Is president immune from suit for unofficial acts?

> [!note]+ Holding (Stevens): No
> - Rationale for immunity is inapplicable to unoffcial conduct
> - If the judiciary may significantly burden the executive by reviewing legality of acts, why not here?
> - Predictions:
>     - Civil suits for personal acts won’t occupy a significant amount of the President’s time
>     - There is “unlikely to be a deluge of such litigation”





















