---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Towel Snap → Neck Stab
Takeaway: Distinguishes 1st and 2nd degree murder
Tags:
  - Intentional Homicide
Category:
  - Crim
Abstract: ""
Page: 282
Type: Case
Rating: "***"
Year: 1995
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Guthrie
Status: Annotated
Date: 1995-01-01
Jurisdiction: West Virginia
---
> [!note]+ Facts
> - Coworker snaps towel at D
> - D stabs coworker in neck
> - D has panic attacks, body dysmorphia, etc.

> [!note]+ Procedural History and Posture
> - Jury finds first degree murder based on instruction that premeditation can occur “at the time of the killing”
> - Sentenced to life in prison

- Issue: Was the jury instruction faulty?

> [!note]+ Holding (Cleckley): Yes
> - That was based on our old precedent, now we’re going to do something better!
> - Premeditation has to have some “period of time of prior consideration… of sufficient duration for the accused to be fully concscious of what he intended”
> - Disposition: Reversed





















