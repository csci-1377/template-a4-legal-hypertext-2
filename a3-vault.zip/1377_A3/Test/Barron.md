---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Sandy Wharf
Takeaway: The Bill of Rights (inc 5A) does not apply to the states
Tags:
  - 5A
Category:
  - Con Law
Abstract: ""
Page: 1025
Type: Case
Rating: "****"
Year: 1833
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Barron v. Mayor of Baltimore
Status: Annotated
Date: 1833-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Maryland is causing sand to buiild up near his wharf
> - He argues his property is being “taken” without just compensation from 5A

- Issue: Does 5A apply to Baltimore?

> [!note]+ Holding (Marshall): No
> - Purpose: Bill of rights was from a concern for federal power
> - Structure: A1S9 has restrictions with general wording, but then repeats some of those as applying to states in S10. So when they wanted limits on states, they had clear statements!
> - Absurdity: Why would the states go through this whole rigamarole if they could have done it easier on their own.





















