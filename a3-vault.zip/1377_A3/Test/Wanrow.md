---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Shooting a Child Molester
Takeaway: Semi-Subjective standard accounting for past history and gender (masculine pronouns unfair), but not culture.
Tags:
  - Self-Defense
  - Intentional Homicide
Category:
  - Crim
Abstract: ""
Page: 549
Type: Case
Rating: "***"
Year: 1977
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Wanrow
Status: Annotated
Date: 1977-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - D’s kids with friend, one tells friend that man tried to assault him, and friend’s daughter had been assaulted
> - Police say they can’t get V until monday morning
> - Everyone comes to house, husbands go threaten V
> - Drunk V enters house, refuses to leave. 
> - D trying to get help, turns around, shoots V by reflex

> [!note]+ Procedural History and Posture
> - Jury instructed only to take account of events “at or immediately before” the killing.
> - Instructed with male pronouns for objective reasonableness, implying should be judged as between men.

- Issue: Was the jury properly instructed regarding justification?

> [!note]+ Holding (Utter): No
> > the defendant’s actions are to be judged against her own subjective impressions and not those which a detached jury might determine to be objectively reasonable.
> 
> - Using male pronouns and objective standard violates Equal Protection
> - Jury can consider D’s perceptions in light of the country’s “long and unfortunate history of sex discrimination.”
> - But can’t submit evidence about the effects of culture on perception (native american).
> - Disposition: Reversed



















