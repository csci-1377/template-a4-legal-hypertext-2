---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Cherokee Missionary
Takeaway: States need federal permission to regulate tribal land (tribal sovereignty)
Tags:
  - SUP
  - TP
  - ICC
Category:
  - Con Law
Abstract: ""
Page: 385
Type: Case
Rating: "****"
Year: 1832
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Worcester v. Georgia
Status: Annotated
Date: 1832-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Missionary prosecuted for violating Georgia law preventing white people from living within Cherokee nation without a liscense

> [!note]+ Procedural History and Posture
> - 

- Issue: Can Georgia assert power over Cherokee nation despite Congressional treaties to the contrary?

> [!note]+ Holding (Marshall): No
> - Is the treaty constitutional? Yeah, with foreign nations, this is one.
> - Is there a conflict? Yes, Georgia is directly rejecting
> - Disposition: 





















