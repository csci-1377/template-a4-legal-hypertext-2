---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Named Donation
Takeaway: ""
Tags:
  - Promisory Estoppel
  - Gratuitous Promise
  - Cardozo
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "*****"
Year: 1927
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Allegheny College v. National Chautaqua County Bank of Jamestown
Status: Annotated
Date: 1927-01-01
Jurisdiction: New York
---
> [!note]+ Facts
> - D is executor of Mary Yates Johnon’s will
> - MYJ promises Allegheny 5k for “Mary Yates Johnson Memorial Fund” to be paid 30 days after death
> - She pays 1k, giving option to add to endowment or her scholarship. then repudiates
> - P sues  for breach 30 days after death

> [!note]+ Procedural History and Posture
> - Trial court dismissed complaint
> - Appellate affirms

- Issue: Was there consideration?

> [!note]+ Holding (Cardozo): Yes, activism for promissory estoppel!
> - Consideration is naming the fund after her and putting it to scholarship
> - Acceptance is implied by taking the first installment of the money
> - Law changes, and at least in the case of charitable subscription, we have promissory estoppel as an exception to consideration requirement
> - But of course we won’t do that here… (just want to go there generally)
> - Gets to the same outcome another way, through (kind of) consideration
> - Disposition: Reversed

> [!note]+ Concurrence/Dissent (Kellogg): No, gift
> - This was a gift, not a trade. It says so on the paper
> - Even if it was K, unilateral, fulfilled when Allegheny names scholarship
> - They couldn’t have named, since repudiated before death
> - Request to name “merely expressed an expectation or wish” not adequate consideration
