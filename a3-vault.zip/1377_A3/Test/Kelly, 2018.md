---
base: "[[Test.base]]"
In-Text Citation: (Kelly, 2018)
Priority: Essential
Authors: Kelly, Erin I.
Title: "The Limits of Blame: Rethinking Punishment and Responsibility"
Zotero URI: http://zotero.org/users/4316906/items/NDY2GYFJ
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
  - Topics in Moral and Political Philosophy
Abstract: A just society would not prosecute criminal wrongdoing for the sake of retribution. Its criminal justice system would have a different rationale and other priorities. When people break criminal laws, they would be liable to criminal punishment, when and because criminal sanctions help to protect the equal basic rights of all members of society. The rationale for punishment in a just society would be harm reduction. The practice of punishment would be used only to prevent and to redress the harms caused by criminal wrongdoing, especially the criminal violation of individual rights. It would also be subject to other restrictions.
Type: Book
Rating: "***"
URL: https://www.jstor.org/stable/j.ctvckq5sh.8
Full Citation: "Kelly, E.I. (2018) The Limits of Blame: Rethinking Punishment and Responsibility. Harvard University Press (Rethinking Punishment and Responsibility). Available at: https://www.jstor.org/stable/j.ctvckq5sh.8 (Accessed: 30 November 2022)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2018
---
> [!note]+ Intro
> - Rembert: stole a car fleeing a civil rights protest, beaten, falsely charged, then forced to work on a chain gang: people who make criminal law have to rethink themselves, because the impacts punisment are for life in the US
> - Blame: moral condemnation of the person, not just the action
>     - Implication: voluntary, wrongful criminal actions reveal lasting aspects of character and personhood, marking someone as defective, tainted, inferior
> - Retributivists: deal in the language of blame and responsibility, that criminal conviction justifies condemnation, stigmatization, incarceration, and exclusion from full membership in society (second-class citizenship)
>     - P.F. Strawson: certain reactive attitudes are apt, ideally accepted by wrongdoers themselves
>     - T.M. Scanlon: moral judgments are warranted by personal qualities, giving good reasons for mistrust, distance, etc.
> - Legal criteria of guilt do not match moral criteria for blame. Criminal law does not (and cannot effectively) take into account mitigating moral considerations
> - American criminal justice system (blame industry)
>     - Insists on individual responsibility
>     - Ignores social and psychological context
>     - Aggregates results through mass “accountability”
> - Alternative
>     - Imprisonment for violation and continued threat of basic rights as a last resort without revoking membership in the community. 
>     - No place for “deserved suffering”
>     - Opens up space for compassion
>     - Allows optional, individual blame, while public coercive action avoids

> [!note]+ Rethinking Punishment
> - Harm Reduction: affirmation of moral importance of violated rights and attempt to incapacitate, deter, and reform offenders. Does not presuppose capacity to have avoided the crime
> - Punishment: court ordered sanctions depending on criminal conviction

> [!note]+ Daniel Ferrel’s Theory
> - Expanded right of self-defense justifies punishment along the lines of distributive justice
> - Just as we can retaliate, we can threaten to harm in advance, and we can make this threat credible through systems of punishment imposed by the state
> - But if someone steals your bicycle, can you lock him in your garage?

> [!note]+ Deterrence
> - Specific: sanctioning someone to prevent *that* person from doing a bad thing again
> - General: sanctioning them to deter *other *people (seems to involve “using” people
> - But the law should default to rational address, threatening an agressor without knowing all his individual psychology. 
> - This is to treat like crimes alike, for “minimal moral content” (Hart) or “integrity” (Dworkin)
> - So punishing the severly mentally ill makes no sense
> - It also won’t work if people expect to be punished whether they make a good effort to comply or not

> [!note]+ In Defense of Moderation
> - Devestating effects on those punished
> - Societal costs
> - Innefectiveness in deterence

> [!note]+ Proportionality Problem
> - But if harm of punishment can’t greatly exceed harm caused, then you need perception of near perfect enforceability if you don’t assume moral motivation of a rational actor. 
> - Could have been avoided: good reasons and reasonable opportunity to avoid
>     - Do you have good reason to avoid breaking the law if there is a 5% chance of getting caught (134)
>     - Reasonable opportunity (behavior justifiably criminalized and penalties generally effective) if they simply don’t provide good reason? (135-136)
> - Line of defense should be open to some defendants for whom punishment doesn’t provide a rational incentive to comply (sufficient or just any amount? 136) Claims self-interested calculations are enough, so it must just be any reason.
> - Penalties should be implemented only if effective (harm reduction has to work) so very possibly this means no punishment at all in hard to detect crimes (child pornography) (143)
> - Uniform evidence of failure of deterrence for members of a marginalized social group would by symptomatic of a loss of institutional legitimacy (148)









