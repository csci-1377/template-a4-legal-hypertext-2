---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Foreclosure Extensions
Takeaway: Even debt relief is ok in an economic emergency
Tags:
  - KC
Category:
  - Con Law
Abstract: ""
Page: 1003
Type: Case
Rating: "***"
Year: 1934
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Home Building & Loan Ass’n v. Blaisdell
Status: Annotated
Date: 1934-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Minnesota has a rule forcing bank to wait a year before foreclosing
> - Then Depression hits, and Blaisdell says people can extend the amount of time they need to repay

- Issue: Does this foreclosure protection law breach the KC?

> [!note]+ Holding (Hughes): No
> - It’s ok if the law is a “use of reasonable means to safeguard the economic structure upon which the good of all depends”
> - It’s not like they’ve cancelled mortgages *obligations*, just changed the *remedy*
> - Emergency doesn’t create power, but time does!
>     - Expand the “reserved power” doctrine to “all essential attributes of the sovereign power”
>     - The state must be able to just do stuff in the public interest
> - Anti-Originalism
>     - Can’t be that “what the provision of the Constitution meant to the vision of that day it must mean to the vision of our time”
>     - To guard against such a narrow conception that Marshall said… “we must never forget it is a *constitution* we are expounding”- McCulloch
> - Disposition: 





















