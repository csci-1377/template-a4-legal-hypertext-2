---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Paid Funeral Guest
Takeaway: ""
Tags: []
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1892
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Earle v. Angell
Status: Annotated
Date: 1892-01-01
Jurisdiction: Massachusetts
---
> [!note]+ Facts
> - Nephew agrees to go to aunt’s funeral for $500
> - Aunt dies, nephew attends funeral, goes to collect cash
> - Testatrix denies, nephew sues

- Issue: Was this verbal contract enforceable after death?

> [!note]+ Holding (Holmes): Yes, it was
> - We can verbal enforce contracts after death, there just has to be evidence they took place
> - Here there was evidence
