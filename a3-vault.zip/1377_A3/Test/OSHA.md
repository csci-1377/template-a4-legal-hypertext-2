---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Vaccine/Testing Mandates
Takeaway: Defining statute to exclude agency authority without deference
Tags:
  - Major Questions Doctrine
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "***"
Year: 2022
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: National Federation of Independent Business v OSHA
Status: Annotated
Date: 2022-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Statute authorizes emergency temporary health standards to “protect employees from grave dangers in the workplace”
> - Workers either get vaccinated or undergo weekly testing under “Emergency Temporary Standard”

> [!note]+ Procedural History and Posture
> - Sixth Circuit says “major questions doctrine” not applicable because not “enormous expansion of regulatory authority”

- Issue: Can OSHA mandate vaccines/testing?

> [!note]+ Holding (Per Curiam): No
> - outside authority because COVID is not distinctly a “workplace hazard” (again, doesn’t mention Chevron)
> - Disposition: Reversed
