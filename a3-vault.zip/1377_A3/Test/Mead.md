---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Setting Tarrifs for Diaries
Takeaway: Only give Chevron deference for decisions with the force of law
Tags:
  - Agency Deference
Category:
  - LegReg
Abstract: ""
Type: Case
Rating: "*****"
Year: 2001
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: United States v. Mead Corp.
Status: Annotated
Date: 2001-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Customs service is authorized to set tarrifs for certain goods
> - It interprets “diaries” at first not to include Mead’s planners, then includes them
> - Mead sues

- Issue: Chevron deference for tarrif ruling letters?

> [!note]+ Holding (Souter): No, only Skidmore respect
> 1. Did Congress delegate the power to speak with “the full force of law”?
> 2. Is the agency interpretaion made in *excercise *of that authority?
>     1. Was it issued through Notice and Comment?
>     2. Other circumstances “reasonably suggesting that Congress ever thought of [ruling] as deserving” Chevron?
> > Sometimes found reasons for *Chevron* deference even when no such administrative formality [Notice and Comment] was required and none was afforded
> - Disposition: 

> [!note]+ Dissent (Scalia): Yes, Skidmore is bullshit
> - Skidmore deference is an empty truism (be persuaded by the persuasive)
> - Ambiguity means Congress intended agency discretion