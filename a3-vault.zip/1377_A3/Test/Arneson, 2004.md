---
base: "[[Test.base]]"
In-Text Citation: (Arneson, 2004)
Priority: Recommended
Authors: Arneson, Richard
Title: Democracy is not Intrinsically Just
Zotero URI: http://zotero.org/users/4316906/items/5EACZGX8
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Book Section
Rating: "***"
URL: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=266629
Full Citation: "Arneson, R. (2004) ‘Democracy is not Intrinsically Just’, in Justice and Democracy: Essays for Brian Barry. Cambridge, UNITED KINGDOM: Cambridge University Press. Available at: http://ebookcentral.proquest.com/lib/warw/detail.action?docID=266629 (Accessed: 17 January 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2004
---
> [!note]+ Intro
> - We should judge systems of governancy by their consequences, by the standard of best results
> - So democracy is only conditionally valuable and extrinsically just

> [!note]+ Defining Democracy
> - A system with elections, where all adults vote, everyone can run for office, majority determines outcome, political freedoms are protected, etc.
> - Scales
>     - More or less direct
>     - Greater or lesser scope of authority
>     - More or less equal opportunity for political influence;

> [!note]+ The Moderate Postition
> - We should judge institutions by the outcoms they promote *and* their intrinsic fairness
> - Maybe we have a right to an equal say in the political process? Something that comes from a right to self-authorship and agency, given our collective identities?
> - A: there isn’t such a right, since that would be a right to excercise power over others (atomic understanding of individuals). Thus, only rights to capabilities are basic rights
> - Ok, but “rights to capabilities (real freedom to achieve important human functionings” (48) includes to deliberate and decide together: collective agency

> [!note]+ Against satisfizing
> - A: We could have a right to an equal say from a right to equal concern and respect, but we show concern and respect by respecting their rights.
> - And we determine this by seeing what ideal reasoners would agree to. We shouldn’t settle for non-ideal reasoners
> - There is such a thing as ideal rationality (all irrationality is like a mathematical error that can be corrected for), and this ideal rationality would maximize rights
> - We should look for maximal rationality to decide how to maximize fulfillment of rights (**begging the question with consequentialist appeal**)
> - **Perhaps we are the only standard of reasonability it makes sense to appeal to**

> [!note]+ Publicity
> - First, publicity is not an intrinsic component of justice
> - Non democratic regimes might be able to better fulfill this standard if they can make manifest that rights are being respected and have public standards for who rules
> - The symbolism of democracy (one person, one vote) can also play this role, but it isn’t required














