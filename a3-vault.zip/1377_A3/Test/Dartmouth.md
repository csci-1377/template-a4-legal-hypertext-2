---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: A Small School’s Charter
Takeaway: If the contract forming a “private corporation” is “violently altered” (unless there’s a reservation clause), KC violated
Tags:
  - KC
Category:
  - Con Law
Abstract: ""
Page: 991
Type: Case
Rating: "**"
Year: 1891
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Trustees of Dartmouth College v. Woodward
Status: Annotated
Date: 1891-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Dartmouth is incorporated under a New Hampshire charter
> - State agrees that this organization is allowed to manage property in a certain way
> - But the structure was proposed and drafted by private funders

- Issue: Does changing board structure violate KC?

> [!note]+ Holding (Marshall): Yes
> - Public Corporations: that would be absurd
>     - If the grant of incorporation is a grant of political power (state agencies)
> - Private Corporations: KC applies
>     - Just because it is a corporation doesn’t mean it’s inherently governmental
>     - These are contracts “respecting the rights of property”
>     - Basically begging the question
> - Dartmouth is a private corporation
>     - The donors and trustees weren’t trying to serve a public purpose.
>     - It was funded and is managed by private parties with private purposes.
> - The law impairs the obligation
>     - The system is totally changed
> > converted from literary institution…into a machine entirely subservient to the will of government.
> - Disposition: 

> [!note]+ Concurrence (Story): Yeah, but the states can do *some* stuff
> - The gov can put in “gov can change terms” in the contract: reservation clause





















