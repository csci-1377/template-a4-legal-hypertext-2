---
base: "[[Test.base]]"
In-Text Citation: (Anderson, 2022)
Priority: Further
Authors: Anderson, Elizabeth
Title: Knowledge , Human Interests, and Objectivity in Feminist Epistemology
Zotero URI: http://zotero.org/users/4316906/items/667H3R54
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
Full Citation: Anderson, E. (2022) ‘Knowledge , Human Interests, and Objectivity in Feminist Epistemologi/’, p. 33.
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2022
---
