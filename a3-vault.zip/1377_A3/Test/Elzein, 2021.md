---
base: "[[Test.base]]"
DOI: https://doi.org/10.1007/s10670-021-00479-6
In-Text Citation: (Elzein, 2021)
Priority: Recommended
Authors: Elzein, Nadine
Title: Undetermined Choices, Luck and the Enhancement Problem
Zotero URI: http://zotero.org/users/4316906/items/TE8RHETS
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
Abstract: "If indeterminism is to be necessary for moral responsibility, we must show that it doesn’t preclude responsibility (the Luck Problem) and that it might enhance it (the Enhancement Problem). A ‘strong luck claim’ motivates the Luck Problem: if an agent’s choice is undetermined, then her mental life will be causally irrelevant to her choice, whichever way she decides. A ‘weak luck claim’ motivates the Enhancement Problem: if an agent’s choice is undetermined, then even if her mental life is causally relevant to her choice, whichever way she decides, we cannot explain how she settles her choice. Only the weak luck claim is plausible. However, its plausibility depends on our accepting that we could only settle our choices if they are settled by additional exercises of agency. If we instead understand the process of settling decisions in procedural terms, we can begin to sketch a solution to the Enhancement Problem."
Type: Journal Article
URL: https://0-link-springer-com.pugwash.lib.warwick.ac.uk/article/10.1007/s10670-021-00479-6
Full Citation: "Elzein, N. (2021) ‘Undetermined Choices, Luck and the Enhancement Problem’, Erkenntnis, pp. 1–20. Available at: https://doi.org/10.1007/s10670-021-00479-6."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2021
---
