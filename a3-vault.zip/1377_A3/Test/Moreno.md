---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Food Stamp Households
Takeaway: "Rational Basis with Bite: Skeptical (or balancing?) with Animus"
Tags:
  - EPC
Category:
  - Con Law
Abstract: ""
Page: 1226
Type: Case
Rating: "***"
Year: 1973
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: USDA v. Moreno
Status: Annotated
Date: 1973-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Food stamp “household” originally includes related and non-related individuals
> - Then they amend it to only include *related* individuals in a household.

- Issue: Does this classification deny equal protection?

> [!note]+ Holding (Brennan): Yes
> - Preventing “hippies” from participating in the program
>     1. Is this a “legitimate” interest? No.
> > a bare congressional desire to harm a politically unpopular group cannot constitute a *legitimate* governmental interest.
>     2. So doesn’t matter if it’s rationally related.
> - Preventing fraud
>     1. Is this a “legitimate” interest? Yes.
>     2. Is this (really, really) *rationally related* to that interest? No.
>         - It won’t actually help eliminate fraud
>         - It’s not just “imprecise,” it is wholly without any rational basis.
>         - Can think of this closer to a balancing test.

> [!note]+ Dissent (Rehnquist): No
> - Majority opinion would make a great congressional committee report, but not a court opinion.
> - This is for Congress to decide.





















