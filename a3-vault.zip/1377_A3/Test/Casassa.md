---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Unrequited Love → Stabbing
Takeaway: Extreme Emotional Disturbance Defense
Tags:
  - Intentional Homicide
  - EED
Category:
  - Crim
Abstract: ""
Page: 312
Type: Case
Rating: "**"
Year: 1980
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Casassa
Status: Annotated
Date: 1980-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - D & V briefly date, then she says she doesn’t love him
> - He does some weird shit, including breaking into her apartment and laying down naked
> - He brings wine to her apartment, she refuses it, he stabs her with a steakknife
> - Law says defense to second degree murder is extreme emotional disturbance

> [!note]+ Procedural History and Posture
> - Defense calls an expert saying this guy was really disturbed
> - Trial court held that the test is whether the fact finder could understand how a person might have his reason overcome. Not necessarily just from the viewpoint of the defendant.
> > The reaction… was so peculiar to him that it could not be considered reasonable so as to reduce the conviction to manslaughter…

- Issue: Was Casassa experiencing an extreme emotional disturbance?

> [!note]+ Holding (Jasen): No
> - Extreme emotional disturbance has two parts
>     1. Threshold- was this guy actually disturbed?
>     2. Is there a reasonable excuse for why he is disturbed?
>         1. MPC commentary says to consider “the actor’s situation” including “personal handicaps and some external circumstances” but excludes “idiosyncratic moral values”
> - The question is not whether the homicide was reasonable, but whether this reasonably sent him into a rage.





















