---
base: "[[Test.base]]"
DOI: https://doi.org/10.1007/s11098-013-0227-2
In-Text Citation: (Weatherson, 2014)
Priority: Recommended
Authors: Weatherson, Brian
Title: Running risks morally
Zotero URI: http://zotero.org/users/4316906/items/QYJEIIMR
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: I defend normative externalism from the objection that it cannot account for the wrongfulness of moral recklessness. The defence is fairly simple—there is no wrong of moral recklessness. There is an intuitive argument by analogy that there should be a wrong of moral recklessness, and the bulk of the paper consists of a response to this analogy. A central part of my response is that if people were motivated to avoid moral recklessness, they would have to have an unpleasant sort of motivation, what Michael Smith calls “moral fetishism”.
Type: Journal Article
Rating: "****"
URL: https://0-link-springer-com.pugwash.lib.warwick.ac.uk/article/10.1007/s11098-013-0227-2
Full Citation: "Weatherson, B. (2014) ‘Running risks morally’, Philosophical Studies, 167(1), pp. 141–163. Available at: https://doi.org/10.1007/s11098-013-0227-2."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2014
---
> [!note]+ Intro
> - Externalism: what you should do or believe is independent of what the evidence tells you

> [!note]+ Non-normative uncertainty
> - Often morally relevant: knowing what has moral significance, but not how serious some harm is for them
> - Is cake syrup sweetener or arsenic?

> [!note]+ Normative uncertainty
> - Not knowing moral status
> - Is eating meat or abortion permissable?

> [!note]+ ProbWrong
> - Definition: If an agent has a choice between two options, and one might be wrong, while the other is definitely permissible, then it is wrong to choose the first option.
> - Incompatible agent
>     - She is sure that ProbWrong is true.
>     - She is almost, but not completely, sure that eating meat is permissible for her now.
>     - She is sure that eating vegetables is permissible for her now. 
>     - She is sure that she has states 1–3.

> [!note]+ Fetishism
> - Desire to do right de dicto is problematic (Smith 1994)
> - Sensitivity to moral risk entails this kind of fetishism














