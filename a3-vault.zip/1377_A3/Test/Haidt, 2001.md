---
base: "[[Test.base]]"
In-Text Citation: (Haidt, 2001)
Priority: Essential
Authors: Haidt, Jonathan
Title: "The Emotional Dog and Its Rational Tail: A Social Intuitionist Approach to Moral Judgment"
Zotero URI: http://zotero.org/users/4316906/items/LM5NSJNC
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
Rating: "*****"
Full Citation: "Haidt, J. (2001) ‘The Emotional Dog and Its Rational Tail: A Social Intuitionist Approach to Moral Judgment’, p. 21."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2001
---
> [!note]+ Intro
> - Intuitionism: “refers to the view that there are moral truths that wehen people grasp these truths they do so not by a provess of reflection but rather by a process more akin to perception” (1)
> - Moral Judgements: “evaluations (good vs. bad) of the actions or character of a person that are made with respect to a set of virtues held to be obligatory by a culture or sub-culture” (817)
> - A kind of cognition, but not reasoning
> - Social part means we try to change the judgements of other people (not yourself?)
> - Reason is the lawyer, not the judge
> - History of reason and emotion on first few pages

> [!note]+ Two cognitive processes
> - Reasoning
>     - Intentional, effortful, controlable, aware
>     - The ‘cold’ system
>     - Motivated, post-hoc, rarely causes moral judgement
> - Intuition
>     - Quick, easy, unaware
>     - The ‘hot’ system
>     - Like aesthetic judgement: instant approval or disapproval
> - Comparing the Two
>     - We should look for the roots of rationality and virtue in what the mind does best: quick, effortless judgement

> [!note]+ The Model
> 1. Intuitive Judgement
> 2. Post-hoc Reasoning
>     1. Justifies judgement in preparation for social interaction
> 3. Reasoned Persuasion
>     2. Works not by argument but by triggering intuitions
> 4. Social Persuasion
>     3. We are in turn infkuenced by the judgements of others
>     4. Rarely are we doing this with ourselves
> 5. Reasoned Judgement
>     5. Sheer force of logic
>     6. Intuitive intuition weak, processing capacity high
> 6. Private Reflection
>     7. Role taking
>     8. Inner dialogue
>     9. (Why can’t we do this with others?)

> [!note]+ Factors Determining
> - Halo effect (nonmoral bleeds into moral, like attractiveness)
> - Principle of least effort (heuristic used unless special need)
> - Relatedness motives: we want to get along well with others
> - Coherence motives: we don’t like cognitive dissonance
> - (This is really just a desire to be whole)

> [!note]+ Moral judgements entail cultural worldview
> - Most people give anecotes or examples instead of evidence (they tell stories) when asked to defend their view.

> [!note]+ Post-Hoc
> - (People search for explanations that seem plausible, not just ‘making up’ explanations)
> - People search for *a priori moral theories* that support their explanations
> - (Really, these are stories, not theories)
> - Tail appears to be wagging the dog here

> [!note]+ Moral argument
> - Feels bitter and futile because both sides believe their positions are based in reasoning about facts and issues and expect other side to be responsive. When they aren’t, each side concludes closed off or incensere.
> - (But storytelling isn’t this way, hence effective dialogue facilitation)
> - Reasons and arguments can circulate and affect people, even if individuals rarely engage in private moral reasoning

> [!note]+ Psychopaths
> - What can we learn about normal moral reasoning from these people
> - Do they read fiction?

> [!note]+ Chimpanzees
> - They seem to havre morality
> - We should assume continuity
> - Do they have metaphor? 
> - Are they limited to individual/inflexible communal hedonism

> [!note]+ Moral foundations
> - Autonomy, community, divinity
> - From custom complexes
> - Seems to be non-verbal learning, which undermines my view