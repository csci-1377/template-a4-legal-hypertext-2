---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Adverse Driveway
Takeaway: Bad faith precludes adverse posession
Tags:
  - Equity
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1982
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Carpenter v. Ruperto
Status: Annotated
Date: 1982-01-01
Jurisdiction: Iowa
---
> [!note]+ Facts
> - Carpenters see that land north of them isn’t planted with corn like before
> - They know it’s not theirs, but clear it, grade it, plant grass on it, and use it as theirs (propane tank and driveway later on)
> - At one time Carpenters even go see plat of neighbors and confirm it’s not theirs
> - Defendants try to settle, but plaintiffs refuse, suing.

> [!note]+ Procedural History and Posture
> - Trial court holds claim of right not established (bad faith)
> - But they order “equity” to give driveway and pay to move propane tank
> - Plaintiff appeals

- Issue: Does bad faith preclude adverse posession?

> [!note]+ Holding (McCormick): Yes, it does
> - You need a good faith claim, and you can’t have this if you know you have no title.
> - We don’t want to endorse squatters’ rights. This isn’t about confusion or miskake.
> - Objections/replies: This is inconsistent. How then could we have a claim of right without color of title?
> - No, because you can make a good faith claim without a title (how?)
> - Disposition: Affirmed
