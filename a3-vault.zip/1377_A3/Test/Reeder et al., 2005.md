---
base: "[[Test.base]]"
DOI: https://doi.org/10.1177/0146167205277093
In-Text Citation: (Reeder et al., 2005)
Priority: Recommended
Authors: |-
  Reeder, Glenn
  Pryor, John
  Wohl, Michael
  Griswell, Michael
Title: On Attributing Negative Motives to Others Who Disagree With Our Opinions
Zotero URI: http://zotero.org/users/4316906/items/5QB5NS7T
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: The research explores the tendency for people to attribute negative motives to others who hold an attitude position that is discrepant from their own. In Studies 1 and 2, American and Canadian respondents indicated their perceptions of U.S. President Bush's motives for initiating war in Iraq. Consistent with the proposed bias, respondents who disagreed with the war attributed more selfish motivations than did those who supported the war. Study 3 revealed a similar bias when respondents rated the motives of the general citizenry concerning their attitudes about the war, and Study 4 provided evidence of the bias on different attitudinal issues (e.g., abortion and gay marriage). Study 4 also indicated that biased attributions of motive were primarily confined to respondents who were highly involved in the attitude issue. Discussion centers on naïve realism, social identity concerns, and attitude justification as relevant underlying theoretical factors.
Type: Journal Article
Full Citation: "Reeder, G. et al. (2005) ‘On Attributing Negative Motives to Others Who Disagree With Our Opinions’, Personality & social psychology bulletin, 31, pp. 1498–510. Available at: https://doi.org/10.1177/0146167205277093."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: To Note
Year*: 2005
---
