---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Pouring Gasoline
Takeaway: Two intents required for attempt
Tags:
  - Attempt
Category:
  - Crim
Abstract: ""
Page: 773
Type: Case
Rating: "**"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: People v. Gentry
Status: Annotated
Date: 1987-01-01
Jurisdiction: Illinois
---
> [!note]+ Facts
> - D pours gasoline on V
> - V lights when going near the stove
> - D tries, and succeeds, to put out V.

> [!note]+ Procedural History and Posture
> - Jury instructed that Gentry could be convicted of attempted murder without a specific intent to kill
> - Convicted of attempted murder
> - Challenge that jury instruction on attempt was prejudicial

- Issue: Was the jury misinstructed?

> [!note]+ Holding (Linn): Yes.
> - Attempted murder requires specific intent to cause the completed offense (murder)





















