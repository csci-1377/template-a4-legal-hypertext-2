---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Don’t Live in your Car
Takeaway: Law found to be unconstitutionally vague (notice and discretion problems)
Tags:
  - Interpretation
Category:
  - Crim
Abstract: ""
Page: 118
Type: Case
Rating: "**"
Year: 2014
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Desertrain v. City of Los Angeles
Status: Annotated
Date: 2014-01-01
Jurisdiction: Ninth Circuit
---
> [!note]+ Facts
> - Los Angeles municipal code Secion 85.02 prohibits use of a vehicle “as living quarters either overnight, day-by-day, or otherwise.”
> - Town Hall on Homelessness addresses complaints about trash and human waste on city streets
> - LAPD creates Venice Homelessness Task Force to cite and arrest people violating code
> - Four people, none of whom sleep in their cars, were arrested for various reasons all having to do with having stuff in their car.

> [!note]+ Procedural History and Posture
> - Affirmative civil suit challenging the law

- Issue: Is Section 85.02 unconstitutionally vague under 14A DPC?

> [!note]+ Holding (Pregerson): Yes
> - Test: “if it is so vague and standardless that it leaves the public uncertain as to the conduct it prohibits”
> 1. Notice: It does not provide notice that will enable ordinary people to understand what it prohibited
>     1. Unclear what “living quarters” or “otherwise” means
>     2. Normal people will have no idea if they are violating the law
> 2. Discretion: It authorizes and encourages arbitrary and discriminatory enforcement.
>     3. It arbitrarily and discriminatorily targets the homeless
>     4. Incompatible with even-handed administration of the law to the poor and rich that is fundamental to a democratic society





















