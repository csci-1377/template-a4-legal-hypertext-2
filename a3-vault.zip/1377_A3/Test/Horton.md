---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Boonshaft Selling Drugs
Takeaway: Material lease clauses are dependant, tenant remedies
Tags:
  - Leases
Category:
  - Property
Abstract: ""
Type: Case
Rating: "*****"
Year: 1942
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Medico-Dental Building Co. v. Horton and Converse
Status: Annotated
Date: 1942-01-01
Jurisdiction: California
---
> [!note]+ Facts
> - P leases section of building to drugstore D with clause promising will not rent to another tenant to sell drugs
> - P rents to Boonshaft who sells drugs with clause saying he promises not to sell drugs “except in regular course of treatment of his own patients”
> - Boonshaft originally gets drugs from D, then switches
> - D tries to get P to stop Boonshaft, P unhelpful
> - D says will leave, P says “use your own judgment”, D leaves
> - P sues for unpaid rent

> [!note]+ Procedural History and Posture
> - TC finds for drugstore

- Issue: What, if anything, does tenant owe landlord?

> [!note]+ Holding (Curtis): Nothing
> - Was there a dependant covenant? Yes
>     - Material clauses are dependant
> - Was it breached? Yes
> - Was the breach substantial? Yes
> - Was it waived? No
> - Tenant Options
>     1. Rescind lease, no obligation to pay
>     2. Remain in posession and sue for damages
>     3. Rescind and sue for damages on lost profits
>     - (But lost profits are hard to prove)
> - This tenant took option 1, so no obligation