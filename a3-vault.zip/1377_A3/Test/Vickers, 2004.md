---
base: "[[Test.base]]"
In-Text Citation: (Vickers, 2004)
Priority: Recommended
Authors: Vickers, Brian
Title: Identifying Co-Authors
Zotero URI: http://zotero.org/users/4316906/items/VDX893JD
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This chapter reviews some of the methods currently used, focusing on the canon of two dramatists who frequently took part in collaborations, John Fletcher and Thomas Middleton. Their work is especially relevant since they both collaborated with Shakespeare. It also includes John Ford, because some interesting work has been done on his co-authored plays. However, it occasionally cites some evidence for his authorship of the Funerall Elegye for William Peter. It begins with the techniques used for identifying co-authors with the oldest method, which takes its origin from when a reader familiar with the verse styles used in Elizabethan drama recognizes two or more different styles in a play. The second approach to authorship studies that is discussed derives from the familiar experience of reading or seeing a play and being reminded of some other work. While verbal parallels, including rare words or words used in special senses, remain a valid tool in authorship studies, much help can he derived from large-scale studies of a writer's vocabulary.
Type: Book Section
URL: https://doi.org/10.1093/acprof:oso/9780199269167.003.0002
Full Citation: "Vickers, B. (2004) ‘Identifying Co-Authors’, in B. Vickers (ed.) Shakespeare, Co-Author: A Historical Study of Five Collaborative Plays. Oxford University Press, p. 0. Available at: https://doi.org/10.1093/acprof:oso/9780199269167.003.0002."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2004
---
