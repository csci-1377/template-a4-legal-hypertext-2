---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Stream of Tires
Takeaway: ""
Tags: []
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Asahi Metal Industry v. Superior Court of California, Solano County
Status: Annotated
Date: 1987-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Zurcher lost control of his motorcycle in California Interstate highway and his passenger wife dies and he is injured. 
> - He alleges that accident was caused by tire blowing out, and tire, tube, and sealant were defective.
> - Files products liability action in California Superior Court
> 
> > [!note]+ Glenn’s Jurisdictional Facts
> > Asahi is a Japanese corp, makes tire valve assemblies in Japan and sells the assemblies to Cheng Shin and other tire manufacturers for use in finished tires. It ships them from Japan to Taiwan. It ships substantial number of tires to Cheng Shin, and Chen Shin represents about 1.24% of Asahi’s business in 1981 and 0.44% in 1982. Cheng Shin in turn sells 20% of its tire tubes to the U.S. market (although Cheng Shin also purchases valve assemblies from companies other than Asahi). There is evidence (an informal survey of one cyclery in the Solano county) in the record that in the motorcycle shop in the town where Zurcher had his accident a significant number of tires had Asahi valve assemblies (out of 115 tires, 21 had Asahi valve stems, and of those 12 were in Cheng Shin tires). A Cheng Shin manager’s affidavit said that he had every reason to think Asahi knew that valve assemblies sold to this company and others by Asahi would end up in the U.S. and California. Asahi’s President’s affidavit, on the other hand, says the company never contemplated that its limited sales to Cheng Shin in Taiwan would subject it to suit in California. There is no contract in the record between Asahi and Cheng Shin.
> > 
> > Zurcher sues Cheng Shin, the Taiwanese manufacturer of the tube, and others including Asahi (a Japanese corporation), who makes the tube’s valve assembly. Cheng Shin files a cross-complaint (aka “cross-claim”) seeking indemnification from Asahi (and other co-defendants). Zurcher settles and dismisses all of his claims, so all that is left is the action of Cheng Shin v. Asahi seeking indemnification.

> [!note]+ Procedural History and Posture
> <u>State Trial Ct</u>: Asahi does business on an international scale, not unreasonable to make them defend products liability internationally.
> 
> <u>Intermediate Appellate Ct: </u>unreasonable to make them defend in Cali just because it was foreseeable that their product might be built into another product that would be sold all over the world including Cali.
> 
> <u>Cal S. Ct.</u>: Reverses, based on knowledge and indirect benefit (reciprocity)

- Issue: Does mere awareness by foreign company that widget would reach forum state constitute MC to not offend FPSJ?

> [!note]+ Holding (O’Connor: 4): Stream of Commerce+ No, it doesn’t
> > [!note]+ Part II-A (with Chief, Powell, and Scalia): Stream of Commerce+
> > - MC = Stream of Commerce + “an action of the defendant purposefully directed toward the forum state.” What is the plus factors?
> >     - Designing, advertising, marketing, or channels for advice to customers in the state
> > - “But a defendant’s awareness that the stream of commerce may or will sweep the product into the forum State does not convert the mere act of placing the product into the stream into an act purposefully directed toward the forum state.”
> 
> > [!note]+ Part II-B (Unanimous but no Scalia?)
> > - Putting to one side minimum contacts analysis, what result under FPSJ “reasonableness” approach? (aka WWV Factors)
> >     1. Forum state’s interests in adjudicating the dispute?
> >         1. Little, in part because injured party settled. This is just between two foreign companies
> >         2. So long as Cal tort law governs the purchasers of components which sell in California, we’re covered
> >         3. Plaintiff residency is a factor, but not dispositive
> >     2. Plaintiff’s interests in convenient and effective relief?
> >         4. Again small, Cheng Shin is Taiwanese…
> >     3. Interests of the interstate judicial system in obtaining the more efficient resolution of controversies?
> >         5. This is about *nations*, not states
> >         6. Be more skeptical about lassoing in other countries
> >     4. Shared interest of the states in furthering fundamental substantive social policies?
> >         7. Count against, IR policy (we should be careful extending jurisdiction)
> 
> - Disposition: Reversed

> [!note]+ Concurrence (Brennan: 4): Stream of commerce. Just doesn’t show FPSJ
> - With White, Marshall, and Blackmun
> - Stream of Commerce is enough to show MC
> - This is just one of those cases where MC isn’t enough for FPSJ
>     - Then what role does MC play, here?
> - MC like here establishes reciprocity to make them take the bitter
> - WWV says not about anticipating entry of product, but likelihood of suit. They said while transport by consumer isn’t enough, *sale* is.

> [!note]+ Concurrence (Stevens): Volume, Value, is it Hazardous Metric
> - With White and Blackmun
> - MC isn’t necessary
> - No clear line between *mere awareness * and *purposeful availment*
> - Look to the volume, the value, of components, whether they are hazardous. (aligning MC with FPSJ?)
> - Rule of Thumb?
