---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Shooting Dying Father
Takeaway: Considerations for 1st Degree
Tags:
  - Intentional Homicide
Category:
  - Crim
Abstract: ""
Page: 289
Type: Case
Rating: "**"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Forest
Status: Annotated
Date: 1987-01-01
Jurisdiction: North Carolina
---
> [!note]+ Facts
> - Father in bed in hopital, recovering slowly. 
> - Son comes in with pistol, gets really sad 
> - Shoots his father four times in the head”

> [!note]+ Procedural History and Posture
> - Convicted of fist degree murder

- Issue: Could a reasonabl juror have found 1st degree?

> [!note]+ Holding (Meyer): No
> Factors to consider for premeditation/deliberation
> 
> 1. want of provocation on the part of the deceased;
> 2. the conduct and statements of the defendant before and after the killing; 
> 3. threats and declarations of the defendant before and during the course of the occurrence giving rise to the death of the deceased; 
> 4. ill-will or previous difficulty between the parties; 
> 5. the dealing of lethal blows after the deceased has been felled and rendered helpless; and
> 6. evidence that the killing was done in a brutal manner. 
> - Disposition: Reversed





















