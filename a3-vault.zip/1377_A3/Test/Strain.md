---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Fixture Fiasco
Takeaway: Test for what goes with property
Tags:
  - Accession
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1946
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Strain v. Green
Status: Annotated
Date: 1946-01-01
Jurisdiction: Washington
---
> [!note]+ Facts
> - Greens sell house to Strains
> - They leave with a lot of stuff they probably shouldn’t
> - Strains sue to get some back

> [!note]+ Procedural History and Posture
> - Trial court holds hot water tank and venetian blinds are fixtures and must be returned.

- Issue: Are light fixtures and mirrors fixtures?

> [!note]+ Holding (Robinson): Yeah, unless they hang on a nail
> - This is a mixed question of law and fact
> - Law relating to fixtures changes with the times
> - Criteria
>     - Whether it fits specifically to the property (higher value there than elsewhere)
>     - If it’s generic class is customarily left
>     - Intention to make it permanent (objectified)
>         - Greens replaced chandeleirs, so that doesn’t help their case
>     - Attachment, including damage to remove it

> [!note]+ Thoughts and Questions
> - How much is intuitionism at play here?
> - The same object is less likely to be ruled the fixture of a tenant than owner (why would you custom make a bookshelf for your landlord?)
