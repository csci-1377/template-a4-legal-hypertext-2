---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/0020174X.2022.2135823
In-Text Citation: (McKenna, 2022)
Priority: Essential
Authors: McKenna, Robin
Title: Is knowledge a social phenomenon?
Zotero URI: http://zotero.org/users/4316906/items/PLNQHFDY
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: In this paper, I offer some reasons for thinking that knowledge is a social phenomenon. My argument is based on Helen Longino’s work on scientific knowledge, in particular her 2002 book The Fate of Knowledge. Longino’s basic idea is that a scientific hypothesis or theory is justified when it emerges (relatively) unscathed from social interactions between scientists. If we accept – as Longino and many others do – that knowledge requires justification, it follows that scientific knowledge is a social phenomenon. I argue that much the same goes for other forms of empirical knowledge, such as historical knowledge, various forms of collective knowledge and our knowledge of the ‘social world’. But does it go for empirical knowledge in general? I offer some – admittedly far from conclusive – reasons for thinking that it might. I also argue that, even if it doesn’t, we still need to distinguish between two kinds of knowledge, one of which is constitutively social and the other of which isn’t. Scientific knowledge is a paradigm example of the former and simple perceptual knowledge is a paradigm example of the latter. The end result is a form of pluralism about knowledge.
Type: Journal Article
Rating: "****"
URL: https://doi.org/10.1080/0020174X.2022.2135823
Full Citation: "McKenna, R. (2022) ‘Is knowledge a social phenomenon?’, Inquiry, 0(0), pp. 1–25. Available at: https://doi.org/10.1080/0020174X.2022.2135823."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2022
---
> [!note]+ Intro
> - Helen Longino (The Fate of Knowledge): 
>     - Cited in philosophy of science but not more broadly
>     - The processes that generate justification for scientific hypotheses and theories are social processses
>     - Specifically, emerging unscathed from critical interactions between those in the relevant community
> - Responding to two kinds of concerns
>     - Sociologists of knowledge want to know the kinds of social conditions in which knowledge is produced
>         - What a community *takes* to be knowledge
>     - Epistemologists want to know about the normative use of the term
>         - What it is like to *actually have* knowledge
>     - Both are half right and half wrong: epistemologists are insufficiently interested in actual scientific practice, but right to distinguish between good and bad practice

> [!note]+ The Argument
> - Observation and reasoning are both social practices that produce justification
>     - Observation is theory laden, and interaction determines what the observational data are
>         - Status of activity is based on relations with others
>     - Reasoning is social too
>         - A theory is always underdetermined by the evidence
>         - Identification of good reasons is context-dependent
>         - We are located in particular, complex interrelationships, and do purely logical constraints never compel us to accept a particular theory
>     - In interaction, background asssumptions are identified, criticized, and defended, and the assumptions that have survived critical scrutiny can bridge the gap between observation and theory
>     - Two claims here: 
>         - This is how science is actually practiced
>         - This is a good thing

> [!note]+ Clarifications
> - Scientific knowledge is social in that it is produced by social interaction, not in that it is in the possession of the community rather than the individual
> - Individuals can generate ideas and beliefs, but this is not the same as producing knowledge
> - Two senses in which scientific knowlege can be produced by social interaction
>     - Causal result
>     - Gains normative status
> - Knowledge is an unnatural (product of human activities) status which certain kinds (beliefs, etc) may have.
> - Can be a difference between knowledge and what a community takes to be knowledge because the community might not satisfy one of the norms.
> - Adopts pluralism about knowledge because plutalism about justification
>     - Social knowledge is justified by a process of critical scrutiny that satisfies certain norms
>     - Non-social knowledge is justified by some other non-social property

> [!note]+ Norms of epistemologically effective cognitive communities
> 1. Venues: There must be publicly recognised forums for the criticism of evidence, of methods, and of assumptions and reasoning (129).
> 2. Uptake: There must be uptake of criticism in the sense that dissent is not merely tolerated but that a community’s beliefs and theories change over time in response to it (129–130).
> 3. Public Standards: There must be publicly recognised standards by reference to which theories, hypotheses and observational practices are evaluated and by appeal to which criticism is made relevant to the goals of the inquiring community (130–131).
> 4. Tempered Equality: Communities must be characterised by tempered equality of intellectual authority (131–134).

> [!note]+ Related Views
> - knowledge is distinctively normative (Linda Zagzebski)
> - Knowledge is a social phenomenon (Haslanger 1999, Kusch 2002, Williams 2015, Craig 1990)
> - Justification is about meeting the objections raised in one’s present context (David Annis 1978, Michael Williams 2008)
> - Reliabilism: we just look at whether these processes generally produce true beliefs
> - Animal and reflective knowledge (Sosa)
> - Animal and objective knowledge (Boor)

> [!note]+ Concerns
> - Some forms of knowledge can be had in splendid social isolation
>     - Perception
>     - Some forms of reasoning are individual (deductive, inferential)
>         - But not analogical!
> - This relativises knowledge to communities “because knowledge requires justification and justification arises from the social interactions within a community” (Really?) 
>     - Why can’t we relativise to a person, ask how effective their interactions are?

> [!note]+ Further Reading
> Code (1991) for feminist critique of treating knowledge in isolation as the paradigmatic case of knowledge
> 
> - Haslanger, Sally. 1999. “What Knowledge is and What it Ought to be: Feminist Values and Normative Epistemology.” Philosophical Perspectives 13 (s13): 459–480.
> - Williams, Michael. 2015. “What’s so Special about Human Knowledge?” Episteme 12 (2): 249–268.
> -  Annis, David B. 1978. “A Contextualist Theory of Epistemic Justification.” American Philosophical Quarterly 15 (3): 213–219.
> - Brandom, Robert B. 1994. Making It Explicit: Reasoning, Representing, and Discursive Commitment. Cambridge, MA: Harvard University Press.
> - Code, Lorraine. 1991. What Can She Know? Feminist Theory and the Construction of Knowledge. Ithaca, NY: Cornell University Press.
> - Goldman, Alvin. 1999. Knowledge in a Social World. Oxford: Oxford University Press.
> - Sosa, Ernest. 2007. A Virtue Epistemology: Apt Belief and Reflective Knowledge, Volume I. Oxford: Oxford University Press.

> [!note]+ Quotes
> > the social processes that produce scientific beliefs and cause the acceptance of scientific theories are what constitutes their justification. (8)
> 
> > the key claim in Longino’s argument is that collaboration is integral to all stages of the knowledge-production process. (12)
> 
> > plausible that Longino’s argument can be extended to other forms of knowledge production that are deeply collaborative. (12)
> 
> > The choice of paradigms is important because one’s choice of the paradigm informs the ‘direction’ of one’s theory in that you will generally try to assimilate other cases to your chosen paradigm. (18-19)
> 
> > Consider the huge amount of knowledge of the social world we need to navigate our way around it (knowledge about how social institutions function, knowledge about the relations we stand in to these institutions and to others). Insofar as collaboration is as integral to the production of these forms of knowledge as it is to scientific knowledge – and it is very plausible that it is – Longino’s argument applies to them too (13)
> 
> > Reliability is a norm that we are not only responsible to but, in certain applications, responsible for. (Williams 2015, 267–268)
> 
> > The (justificatory) activities of knowledge construction as distinct from belief formation (a generative process) are the activities of individuals in interaction, of individuals in certain relations (of criticism and response) with others. The cognitive abilities of individuals are both necessary and sufficient for the generation of ideas, but idea or belief generation is not the same as knowledge production, which involves processes of validation as well as generation. The account of cognitive agency as involving interdependence means that individuals know to the extent they interact critically with others in cognitive communities. The context-bound character of validation and the characterization of cognitive agents as interdependent does not deny the importance of individual agents in the construction of knowledge. It does mean that attributing knowledge to them is attributing to them some relation to their cognitive communities, as well as to the objects and content of knowledge. (Longino TFK 122–123)









