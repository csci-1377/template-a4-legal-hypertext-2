---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Unnecessary Martial Law
Takeaway: "No martial law when courts are open: need “active and present” necessity"
Tags:
  - WP
Category:
  - Con Law
Abstract: ""
Page: 310
Type: Case
Rating: "**"
Year: 1866
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ex parte Milligan
Status: Annotated
Date: 1866-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - After Civil War, white vigilantes are killing black people, tried by white juries who set them free.
> - Milligan, citizen of Indiana, arrested and tried by military without jury and sentenced to death
> - The law required that he be turned over to a civil trial, but wasn’t.

- Issue: When can a military tribunal legally try and sentance a citizen?

> [!note]+ Holding (Davis): When there is “active and present” necessity in the presence of a “real invasion”: courts actually closed
> - OG question: was *this* illegal?
>     - Yes, Congress didn’t permit it. Military did not have right to override that.
> 
> > No graver question was ever considered by this court
> 
> - 4, 5, 6 A
> - It was unneccessary here
>     - The civil courts were open
> - Right to jury was violated
> - But can’t a military commander suspend civil rights in his district?
> > If true, republican government is a failure
> 
> > Martial law can never exist where the courts are open… confined to the locality of actual war





















