---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Bees!
Takeaway: Bees go to the landowner (against custom)
Tags:
  - Accession
  - Custom
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1804
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Fisher v. Stewart
Status: Annotated
Date: 1804-01-01
Jurisdiction: New Hampshire
---
> [!note]+ Facts
> - Fisher (or maybe Stewart’s family) finds bees
> - Fisher marks tree and tells Stewart
> - Stewart gets bees
> - Fisher sues for trover (conversion) for bees

> [!note]+ Procedural History and Posture
> - Trial court unable to determine who found the bees

- Issue: If the plaintiff found the bees, would they be his?

> [!note]+ Holding (Anonymous): Nope
> - Based on some combination of psychological salience and practical utility
> - Dismisses opportunity to prove a custom that bees go to finder because it doesn’t hold in all of the state
