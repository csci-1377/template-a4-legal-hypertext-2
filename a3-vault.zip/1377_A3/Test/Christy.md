---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Swindling Rebates
Takeaway: Corporations can be prosecuted
Tags:
  - Corporations
Category:
  - Crim
Abstract: ""
Page: 949
Type: Case
Rating: "****"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: State v. Christy
Status: Annotated
Date: 1984-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Phil Hesli, salesman, forges rebates by backdating for car sales
> - Purchasers complain to James Christy, dismissed
> - Only returned rebates after AG reached out.

> [!note]+ Procedural History and Posture
> - Hensli found guilty of theft
> - Corporation also indicted and convicted of theft and fraud.

- Issue: Can a corporation be convicted of theft and forgery? 

> [!note]+ Holding (Simonett): Yes
> - Corporations haven’t been excluded explicitly, so why not
> - When are actions fairly attributable to the corporation?
>     - Course and scope of employment
>     - Furthering orgs interest (corp got the money, not him)
>     - Authorized, tolerated, or ratified by management.
>         - Another corporate officer signed the forged order
>         - President tried to negotiate with customers to keep it on the DL




















