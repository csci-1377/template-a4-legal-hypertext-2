---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Disability Termination
Takeaway: Law/econ balancing test for DPC
Tags:
  - DPC
Category:
  - Con Law
Abstract: ""
Page: 1067
Type: Case
Rating: "***"
Year: 1976
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Mathews v. Eldridge
Status: Annotated
Date: 1976-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - US terminates disability benefits without a pre-termination hearing
> - There are some different people on the court now

- Issue: Is the disability removal without a hearing constitutional?

> [!note]+ Holding (Powell): Yes
> 1. Weigh the private interest *times*
>     - Less than in Goldberg, because the disabled are not necessarilu destitute.
> 2. Probability of decreasing the risk of erroneous deprivation by adding additionals safeguards.
>     - Les likely (this is mostly medical reports
> 3. Against the governmental interest in the additional burden
> > would not be insubstantial.





















