---
base: "[[Test.base]]"
In-Text Citation: (Shklar, 1989)
Priority: Essential
Authors: Shklar, Judith
Title: The Liberalism of Fear
Zotero URI: http://zotero.org/users/4316906/items/CAGNHBG7
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: ""
Type: Book Section
Rating: "****"
URL: https://philarchive.org/rec/SHKTLO
Full Citation: "Shklar, J. (1989) ‘The Liberalism of Fear’, in N.L. Rosenblum (ed.) Liberalism and the Moral Life. Available at: https://philarchive.org/rec/SHKTLO (Accessed: 12 February 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 1989
---
