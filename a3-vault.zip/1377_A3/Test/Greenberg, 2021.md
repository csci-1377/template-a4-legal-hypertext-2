---
base: "[[Test.base]]"
In-Text Citation: (Greenberg, 2021)
Priority: Recommended
Authors: Greenberg, Mark
Title: Legal Interpretation
Zotero URI: http://zotero.org/users/4316906/items/GKWESHKB
Takeaway: ""
Tags: []
Category:
  - Dissertation
Abstract: Legal interpretation involves scrutinizing legal texts such as the texts of statutes, constitutions, contracts, and wills. This chapter introduces the foundational question of what legal interpretation, by its nature, seeks – and competing answers to that question. It goes on to canvas leading substantive theories of legal interpretation and examines in greater depth a few influential theories and difficulties they encounter. Finally, the chapter considers how theories of legal interpretation should be defended and evaluated.
Type: Book Section
URL: https://plato.stanford.edu/archives/fall2021/entries/legal-interpretation/
Full Citation: "Greenberg, M. (2021) ‘Legal Interpretation’, in E.N. Zalta (ed.) The Stanford Encyclopedia of Philosophy. Fall 2021. Metaphysics Research Lab, Stanford University. Available at: https://plato.stanford.edu/archives/fall2021/entries/legal-interpretation/ (Accessed: 23 June 2023)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2021
---
