---
base: "[[Test.base]]"
In-Text Citation: (Fagenblat and Erdur, 2019)
Priority: Recommended
Authors: ""
Title: "Levinas and analytic philosophy: second-person normativity and the moral life"
Zotero URI: http://zotero.org/users/4316906/items/MYT7UWQC
Takeaway: ""
Tags: []
Category:
  - Topics in Moral and Political Philosophy
  - Dissertation
Abstract: "\"This volume examines the relevance of Emmanuel Levinas's work to recent developments in analytic philosophy. Contemporary analytic philosophers working in metaethics, the philosophy of mind, and the metaphysic of personal identity have argued for views similar to those espoused by Levinas. Often disparately pursued, Levinas's account of \"ethics as first philosophy\" affords a way of connecting these respective enterprises and showing how moral normativity enters into the structure of rationality and personal identity. In metaethics, the volume shows how Levinas's moral phenomenology relates to recent work on the normativity of rationality and intentionality, and how it can illuminate a wide range of moral concepts including accountability, moral intuition, respect, conscience, attention, blame, indignity, shame, hatred, dependence, gratitude and guilt. The volume also tests Levinas's innovative claim that ethical relations provide a way of accounting for the irreducibility of personal identity to psychological identity. The essays here contribute to ongoing discussions about the metaphysical significance and sustainability of a naturalistic but nonreductive account of personhood. Finally, the volume connects Levinas's second-person standpoint with analogous developments in moral philosophy\"--"
Type: Book
Rating: "****"
Full Citation: "Fagenblat, M. and Erdur, M. (eds) (2019) Levinas and analytic philosophy: second-person normativity and the moral life. New York: Taylor & Francis Group (Routledge Research in Phenomenology, 15)."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2019
---
Read and Annotated

> [!note]+ 1) Crowell- Second Person Reasons
> - Performative attitudes (participant)
>     - Strawson’s reactive attitudes based on normative expectation
>     - Moral intuitions only available in this second-person standpoint
>     - Nothing necessary about adopting these within their context, but we are socialized into playing
> - Objectivating attitudes (nonparticipant observer)
> - Personhood
>     - The ability to be moved by second-personal reasons

> [!note]+ 4) Meindl et al.- I-Thou Relation
> > [!note]+ Buber
> > - A dialogician trying to overcome subject-object dichotomy to explore relations between things
> > - I-It: experience, monologue, one active and one passive, unidirectional
> > - I-Thou: relation, dialogue, active and passive, reciprocal
> >     - Allows for meeting, including non-linguistic interaction
> >     - Requires recognition of the difference of the other
> > - Three Forms
> >     - Abstract mutual inclusion: like people in argument
> >     - Concrete one-sided inclusion: like teacher or therapist
> >     - Concrete mutual inclusion: friendship
> 
> > [!note]+ Levinas
> > - Encountering the Other
> >     - Focusing on the face of the other
> >     - Radical passivity and assymetry
> >     - Responsibility is unconditional, non-reciprocal
> >     - Vertical relation rather than horizontal
> > - Critique of I-Thou
> >     - Extended too far, including inanimate objects
> >     - Can’t be reciprocal and symmetrical, that compromises the distance and difference of the other
> 
> > [!note]+ Shutz
> > - Thou-orientation is pre-reflective
> > - Can be non-reciprocal and unilateral
> > - But changes when reciprocal in “we-relationship”
> > - Reciprocity changes the experience of those involved, so does not betray second person perspective
> > 
> > > According to Schutz, a we-relationship is a subject-subject relation. It is a relationship constituted by me and at least one co-subject. But for me to relate to another as a co-subject is for me to relate to somebody who not only has a perspective of his or her own on the world of objects, but on me as well. In short, from my first-person perspective, there is a quite salient difference between a unilateral and a bilateral Thou-orientation. There is a difference between talking to and talking with somebody, between watching someone unobserved and realizing that one’s attention is being noticed and reciprocated. (90)
> 
> > [!note]+ Young
> > - Reciprocity is not symmetry or reversability
> > - Self-projection is just transforming into universal sameness
> > - If this was all the second-personal was, we wouldn’t need another person for it
> > - “Assymetrical Reciprocity”
> >     - In fact, often such an imaginative perspective taking amounts to nothing but a form of self-projection, a mere imposition of one’s own view upon the other, which transforms everything that is truly different about the other into bland sameness. (91)
> >         - “Asymmetrical Reciprocity. On Moral Respect, Wonder, and Enlarged Thought,” Constellations 3, no. 3 (1997): 346.
> >     - Had this simply been a question of mere reversibility, had it simply been a question of perspective shifting, I would not have had to await the encounter with the other, I could have accomplished it all on my own *82. * (91)
> > 
> 
> > [!note]+ All
> > - Second-personal not best understood as mirroring or self-projection
> > - Not just using one’s experience to understand others through simulation, imagination, etc.
> > - Opposing sociality as fusion or uniformity. Not bundling to stand next to, but facing others
> > - Addressing as a Thou and being addressed as such by others is essential to the life of a community
> > 
> > > ammunition against those who have suggested that second-person engagement is simply a question of using one’s own experiences to understand other subjects, i.e., who argue that it is a question of simulating, replicating, or imagining the mental states of another *88*. (93)
> > 
> > > Addressing another as a Thou and being in turn addressed as a Thou by the other(s) are consequently essential to the life of a community, which rather than being a mere side-by-side, is a with-one-another. (93)

> [!note]+ 7) Houser- Levinas and Free Will
> > [!note]+ Primary Points
> > - We are not duped by morality, but we are by freedom
> > - We are not morally responsible because we are free, but free because we are morally responsible
> > - Freedom is not a property or posession, but a social process
> > - To be free, we must be free from our own nature, which requires distance from oneself.
> > - This cannot be created merely by reflection, as Korsgaard claims, but rather by the other
> > - Love is the best model of Levinasian freedom
> 
> > [!note]+ Kant/Korsgaard (Categorical Imperative)
> > - From freedom and rationality as axiom to morality
> > - We can’t help but desire freedom, so must want it for others
> > - (Maybe this makes morality possible, but it doesn’t require it)
> > - Fundamentally an ethics of will and power
> > - Korsgaards internal reason starts to look interpersonal (one must be two…)
> 
> > [!note]+ Levinas (Ethics as First Philosophy)
> > - From moral relation to conciousness and freedom
> > - Original distance arises as socialy induced reluctance to identify with ourselves (shame)
> > - Inability to posess freedom securely a product of distance created by facing another (we are given freedom by those around us)
> > - We cannot form an identity without another
> 
> > [!note]+ Love
> > - A call away from self-concern, to decenter oneself
> > - Does not bring an absence, but a fullness
> > - “love’s eccentricities are expressions of my own ex-centricity” (157)
> > - No question of whether you are free to answer the call, because there is no you to be free prior to doing so

> [!note]+ 10)  Morgan- On Sociality and Morality
> > [!note]+ Levinas
> > - Ethical: face-to-face, second-personal
> > - Political: domain of our everyday lives and interpersonal relations (with concepts, reason, etc.)
> > - The ethical critiques, but does not reject the political
> 
> > [!note]+ Tomasello
> > > [!note]+ Second-person morality
> > > - Adoption of the “we”
> > > - Second-personal responsibility is the original “ought”
> > 
> > > [!note]+ Then group morality
> > > - Self-equivalence and localized universality
> > > - Shift to morality is just a matter of degree after this (fully inclusive group)
> > 
> > - Both evolutionarily and in individual lives
> 
> > [!note]+ Strawson
> > - We have participant reactive attitudes (indignation etc)
> > - Then generalized, impersonal versions
> 
> > [!note]+ Wallace
> > - Reactive attitudes are implicitly relational
> > - 

> [!note]+ 13) Levinasian “Ethics as First Philosophy”
> > all fundamental questions regarding ethics (or morality) are themselves substantive ethical questions and that there is no standpoint external to ethics from which the existence, the significance, or the authority of ethical claims can be evaluated. (269)
> 
> > [!note]+ Blackburn (Expressivism)
> > - Denies moral facts, so charged with relativism
> > - Defends with distinction between expression and reporting an attitude
> >     - Only the latter is reducible to factual claims, so suceptible to relativism
> > - There are no non-ethical grounds on which ethics depends
> > 
> > > only one proper way to take the question “On what does the wrongness of wanton cruelty depend?”: as a moral question, with an answer in which no mention of our actual responses properly figures. There would be an external reading if realism were true. For in that case there would be a fact, a state of affairs (the wrongness of cruelty) whose rise and fall and dependency on others could be charted. But [expressivism] acknowledges no such state of affairs and no such issue of dependency. (Blackburn 1993:173)
> 
> > [!note]+ Hume (Is-Ought Distinction)
> > - Ethical questions must be answered from the ethical point of view
> > - This establishes the autonomy of ethics
> 
> > [!note]+ Dworkin
> > > there is no Archimedean point outside of morality from which we can undermine or vindicate morality because all fundamental questions concerning morality are substantive moral questions themselves, which need to be answered within the moral domain. *4 *(273)
> > 
> > > The great Scottish philosopher David Hume is widely understood to have declared that no amount of empirical discovery about the state of the world—no revelations about the course of history or the ultimate nature of matter or the truth about human nature—can establish any conclusions about what ought to be without a further premise or assumption about what ought to be. Hume’s principle . . . is often taken to have a stark skeptical consequence, because it suggests that we cannot discover, through the only modes of knowledge available to us, whether any of our ethical or moral convictions is true. In fact, I argue . . . [that] his principle has the opposite consequence. It undermines philosophical skepticism, because the proposition that it is not true that genocide is wrong is itself a moral proposition, and, if Hume’s principle is sound, that proposition cannot be established by any discoveries of logic or facts about the basic structure of the universe. Hume’s principle, properly understood, supports not skepticism about moral truth but rather the independence of morality as a separate department of knowledge with its own standards of inquiry and justification. (Dworkin 2011:17) *5*
> > 
> 
> > [!note]+ Erdur’s Defense
> > - Traditionally, defenses of the is-ought distinction are factual ones
> >     - They play radically different roles in action: only the latter can motivate
> >     - It is logically impossible to derive an ought from an is
> >     - Ethical properties would be too metaphysically queer
> > 
> > > the essential problem with [these defenses] is that they hold the morally crucial idea of the autonomy of ethics/morality hostage to some logical, metaphysical, or psychological facts (274)
> > 
> > - Justifications of the distinction therefore ought to be ethical
> >     - There *ought to be* such a distinction, or it is *good* to think of it this way.
> > - Otherwise, facts would be too coercive
> > - This is ethics as first philosophy
> > 
> > > Only those, therefore, who are already ethical to some extent can see that they have ethical obligations. (277)
> 
> > [!note]+ Further Reading
> > - Dworkin
> >     - Justice for Hedgehogs
> >     - Objectivity and Truth: You’d Better Believe It.

Read Eventually (Personal)

> [!note]+ 8) Chapell- Personal Knowledge


> [!note]+ 14) Overgaard- Against a Clear Conscience














