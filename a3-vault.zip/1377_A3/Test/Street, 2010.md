---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/j.1747-9991.2009.00280.x
In-Text Citation: (Street, 2010)
Priority: Recommended
Authors: Street, Sharon
Title: What is Constructivism in Ethics and Metaethics?
Zotero URI: https://zotero.org/bmcanally21/items/IEJD5K8I
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: "Most agree that when it comes to so-called ‘first-order’ normative ethics and political philosophy, constructivist views are a powerful family of positions. When it comes to metaethics, however, there is serious disagreement about what, if anything, constructivism has to contribute. In this paper I argue that constructivist views in ethics include not just a family of substantive normative positions, but also a distinct and highly attractive metaethical view. I argue that the widely accepted ‘proceduralist characterization’ of constructivism in ethics is inadequate, and I propose what I call the ‘practical standpoint characterization’ in its place. I then offer a general taxonomy of constructivist positions in ethics. Since constructivism’s standing as a family of substantive normative positions is relatively uncontested, I devote the remainder of the paper to addressing skeptics’ worries about the distinctiveness of constructivism understood as a metaethical view. I compare and contrast constructivism with three other standard metaethical positions with which it is often confused or mistakenly thought to be compatible: realism; naturalist reductions in terms of an ideal response; and expressivism. In discussing the contrast with expressivism, I explain the sense in which, according to the constructivist, the distinction between substantive normative ethics and metaethics breaks down. I conclude by distinguishing between two importantly different debates about the mind-dependence of value. I argue that a failure to make this distinction is part of what explains why the possibility of constructivism as a metaethical view is often overlooked."
Type: Journal Article
Rating: "****"
URL: https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1747-9991.2009.00280.x
Full Citation: "Street, S. (2010) ‘What is Constructivism in Ethics and Metaethics?’, Philosophy Compass, 5(5), pp. 363–384. Available at: https://doi.org/10.1111/j.1747-9991.2009.00280.x."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2010
---
