---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Software Lies
Takeaway: ""
Tags:
  - Misrepresentation
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1984
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Rio Grande Jewler’s Supply v. Data General Corp
Status: Annotated
Date: 1984-01-01
Jurisdiction: New Mexico
---
> [!note]+ Facts
> - D makes (potentially misrepresentative) statements about its software to P
> - P signs contract for software disclaiming all prior statements by D
> - NMSA says “Unless displaced by the particular provisions of this act, the principles of law and equity, ... principal and agent, estoppel, fraud, misrepresentation, ... shall supplement its provisions.”
> - UCC 2-316 allows for disclaimers in integrated contracts

- Issue: Is negligent misrepresentation prior to integrated contract disclaiming prior representations actionable?

> [!note]+ Holding (Walters): No
> - Conflicts directly with UCC 2-316 and freedom of contract
>     1. Contract was integrated 
>     2. Effective Disclaimer (in bold-face type)
>     3. Representations are same as those in breach of express/implied warranties
>     4. No argument of fraud
> - This is just trying to get around New Mexico UCC allowing for integration/disclaimers

> [!note]+ Dissent (Riordan): Yes!
> - This basically protects fraud by boilerplate
