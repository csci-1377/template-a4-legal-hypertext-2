---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Supreme
Authors: ""
Title: Conversion Square(foot)ed
Takeaway: C1>C2
Tags:
  - Conversion
Category:
  - Property
Abstract: ""
Type: Case
Rating: "***"
Year: 1892
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Anderson v. Gouldberg
Status: Annotated
Date: 1892-01-01
Jurisdiction: Minnesota
---
> [!note]+ Facts
> - Anderson cuts down trees on anothers’ property
> - Gouldberg takes the logs
> - Anderson wants them back

- Issue: Does the property go to Converter 1 or Converter 2?

> [!note]+ Holding (Mitchell): Converter 1 (cites de Lamerie)
> - Anything else would lead to long strings of theft
>     - Would it really? No property among thieves might discourage
> - This is really broader than de Lamerie. Includes not only legal finding, but unlawful taking.
