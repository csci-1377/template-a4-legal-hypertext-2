---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Authors: Parker, Priya
Title: The Art of Gathering
Takeaway: ""
Tags: []
Category:
  - Community
Abstract: ""
Type: Audiobook
Rating: "*****"
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Annotated
Year*: 2018
---
The art of gathering notes: important elements specificity, uniqueness, Disputability

Move from the white to the Y: Zoom out, drill down, Focus on the outcome rather than the process

Avoid multitasking, use your purpose as a bouncer, (like in club,) If you aren’t willing to change the structure of the meeting to adhere to that purpose, that it isn’t serving as a bouncer.

Close doors/exclude with purpose. Barack Obama is aunt: is everyone is family, no one is family. Similarly: syndrome sad if everyone and when everyone is super, no one will be.

Venue: choose the venue that promotes actions that fulfill your purpose and please down actions that do not open parentheses château principal). Try to achieve displacement through the choice of venue, or at the very least, through the questions asked. 

Platinum photographers white box: the famous photographer makes everyone who takes portraits of sit on that white box in order to disrupt their environment, even if it’s in your own office. The box is a printed white falling apart pallet.

Instead of talking about charged political issues with established terminology, talk about what it is you are concerned about what it is you are passionate about what makes you afraid or excited or worried in your own district and also in the country. What is it that you think the country could do for you.

Be conscious of parameters. Close doors both metaphorical and physical in a conversation. If you have a table, have everyone sit around the table, don’t leave the ends open.  Put down a blanket and sit on the floor? Particularly think about having pine sit on the floor a direct opposite to the raised pedestal.  Have different phases occur in different spaces. New rooms for different parts of the event.

Area: create a smaller area and then you think you need, especially when you’re trying to create a sense of community and intimacy. It’s actually good to have few were tears and you need, especially when you are demonstrating the possibility of sitting on the ground. It causes people to come closer together and create a sense of both informality and a pact kind of energy, given the impression it more people came in expected. Be a large venue should certainly be avoided, it does just the opposite of this. Home coming at the big venue in Jacksonville as an example. If the room is too big, create partitions come at for example at the opening of the presidio flip charts were used to cordon off the room by a quick thinking architect, thus making the area significantly more intimate and happy.

Event density: dinner party sophisticated square feet per person 20 wifely 15

Werewolf was created by a Russian psychology professor to create community in groups. How cool is that?

Chill: while chill is popular in that it would seem to, by abdicating a powerful position as host, leave a an environment free of power structure, in reality, the power vacuum is filled by others, which whose purpose is maybe contrary to yours. Enforcing power as a host should not be done nearly once in early on, but instead enforced regularly. Without that others will, once again, enforce their own possibly contrary purposes. Example: the Alamo theater. Use: when someone is not adhering to the dialogue norms one must be willing to eject them from the group despite conflict that it could create.

One can create two different gatherings for two different purposes, especially if exclusion one group is a problem, create another gathering for that group. Secondly in consideration of order of events and gatherings, having a portion of her possibly having attendees speak earlier then I would demonstrate the people dialogue first principle although we would need someone to set the norms, so tired pie or someone else could speak first, but not give his pitch, but rather engage everyone in a dialogue, then give his pitch and add questions at the end. Or even questions at the beginning possibly it would be interesting to look at how that would slit the dialogue. Protect guests by having a very strict rules for questions, for example dBrief to the point and end a question with a?, 

Then when someone violates those rules, have someone other than Pai in force that interrupting the question asked her repeatedly. What this does, rather than being mean and interrupting, protects the rest of those at the event. This would be most effective if prefaced very clearly and enforced very clearly. It is about elevating the right of each of your guests to have a good experience over the right of anyone to ruin that experience.  Equalize your guests as well. This can be through seating or assuring an equal voice. Obama asked for questions to be asked in a male female male female order, so that one he would equalize the tendency of men to speak over women. This would need to be adapted to encompass other gender identities, but it could be accomplished fairly easily.

She has size rolls, with six, 12 to 15, 30, and 150 being her size rolls, Vi being the most intimate 12 to 15 doing something else, 30 creating a party like atmosphere, with 100 being big and exciting yet still possible for interaction between everyone. We may want to look at limiting the size of these dialogs for that reason.

Tanner: maybe don’t allow people to show up late encourage so that you protect those show up on time. Possibly stay at one time doors will close on, then have a separate exit or other room where conversation with someone other than Pai and for possibly a final portion post the main question question those who showed up late for attended based on signs could meet and greet and possibly ask Pai if you questions in a separate encounter. Do things like getting people to serve food to one another or assign roles to people or encourage dialogue and some other explicit way with reasonable goals, for example meet and learn the names of two people you hadn’t met before.

Someone named above state a BUSTARIT, new that she wanted to separate couples for her wedding, so she did and enforce that rule removing the way sitting on her husband’s work. I want

Focus on generous authority. Ungenerous authority can become domineering.  The Obama administration, when opening the office of social impact or something like that, rather than creating an open unscripted dialogue between 100 leaders in social innovation and the president, did a more safe approach of a classroom style scripted dialogue, because they were worried about what the president might say if things were unscripted. Avoid this. Make sure the authority that you impose is always to the benefit of your guests. Also I don’t remember.

Emphasize the creation of a new small world and it will occur only once in your gathering. This can begin with your invitations.

Think about the rules that can be imposed to create this alternate world. For example leave your phones out of the room, or do not talk to the person next to you only talk to the whole group, or only use first names, or do not describe your profession etc.  These rules are not authoritarian and imposing structure where there was not before, but rather trying to subvert change previously established Cleashal rules of etiquette. Explicit, pop-up rules are more accommodating for diverse groups, because the rules of etiquette will not signal just separation and dictate hierarchy.  Etiquette is about fixed and complicated and exclusionary rules while pop-up rules create a changing engaging and democratic environment

For finishing the lesions lighthearted and funny and often physical things like push-ups make people feel comfortable with and direction behind the group even those rule violators to the temporary. Example 2 feet either learning more basically finding it, use your tooth. I can’t stay survey presentation presentation, which illuminates hey more organic conference at it.

People fill out questions answer this could be this would you least need to be primed self in order to those questions to send, because one would not have to put control over the kind of question for me, but still participants to contribute, particularly names and situations are you just in the discussion. Use quotes from the workbooks in the opening presentation. These workbooks become an invitation to engage, and also a good self selector. By returning the workbooks one is excepting the invitation to engage.

White House office of social innovation and civic participation

Ushering example, waiting 30 minutes in silence with noise canceling headphones before a musical performance or with Abramovich coming in where women are holding your hand mirrors and hold foil and you place gold foil over your lips before the show begin. This does not have to be as elaborate, but could include a entryway in which some garage is taken or left behind and such as a phone or a name tag with specific intentionality to it

The importance of pregaming: example Bernie Sanders rally there are three hours of ushering in which people come into the stadium and there is no programming. This is a missed opportunity, what could be done with it?  Small group dialogs break out smaller speakers turn to the person next to you and talk about why you’re here etc. they could’ve created it, and instead they waited. We will Matt.

Remember the peak and rule of remembering the first 5% the last 5% and the peak moment in any dialogue and focus on those moments make them even above the others memorable. Certainly don’t start with logistics or throat clearing. Example minister chose to discuss parking difficulties at the beginning of a future a funeral when others were in need of consoling and important words. While we may think that one can build up to a memorable beginning this isn’t necessarily the case.  Don’t start with “let’s first get business out of the way“. This includes thankyouse.

Because of the connotations to come with the term host, I think we should change the description from host a dialogue to something like welcome a dialogue in your home or hold a dialogue in your home, or something like that, because we, in fact, will want to be the ones hosting. Do a Saturday night live cold open they do the skit before revealing that it’s the show or introducing all of the members of the show. While it is clearly important to tell people where bathrooms are what time food will be served and even the rules of the dialogue itself, it is most important to give that hook just like when writing any good section.

Do you want to honor and all guests at the same time make them feel both welcome and simultaneously unworthy.

The next step after honoring and mine. Too few participants, make them acknowledge their own presents and the others in the room in someway, as well as recognizing a common purpose. This can be done through creative introductions or other means even through a pledge. Example: the tough mutter challenge pledge to help others as opposed to focusing on Soli your own time as it’s done and marathons.

During the meeting: when individual is asked or ask a question is asked a question, you should include others by looking out and asking how many others have the same issue part, particularly if you think others have had the same issue or many.

15 ways to make your gathering subclass: I’ll overview:

If you are trying to get people to do something and get all of them to do it, one potential way to do it is make the last person to do it do it in some silly or mildly embarrassing manner, which by which point everyone will be anticipating to the extent that it will be funny and inclusive. For example at the world economic forum‘s preparation conference in Abu Dhabi, Freya Parker got everyone to give a toast with a small personal anecdote, and the last person had to sing theirs. These became called 15 toaster dinners.

Sprout speeches over stump speeches: stumps are the most durable old part of the tree, and speech is that come from that area or our well rehearsed are what we most often give it when we went to impress. But to impress is to make an impact to leave an impression on the mind and the new Rado the sprout rather than the stump is what tends to do this. I recommend that Pai use more sprout and stump speeches

Emphasize stories over ideas because it fosters both connection and what we really want to know,. We think in stories, and so should we communicate in them. Make space for the dark and the dangerous, not solely focusing on the happy. While seemingly counterintuitive, this creates vulnerability and fosters dialogue more than purely positive experiences.

Adding space and Heat: warmth and togetherness is good, but sometimes making good use of controversy is as useful as focusing on the things that we have in common. Don’t avoid sex politics and religion. Rather navigate ways to talk about them in which a conversation does not become an argument or even worse a fight. Example, a mark Keach fight between two architects representing two signs of an argument on where to move forward with the architecture firm. A way to replicate this without evolving into an attack is one having everyone can send to being moderated or having your Waze taken if they break these are agreed-upon norms and 0.5 possibly having to people make the norms them selves and to having people argue for positions they don’t necessarily hold.

One way to facilitate good controversy is to very clearly make a section of the dialogue for that controversy in which the pop-up rules and norms have changed so that one people feel old right to express their feelings without burning any bridges or anything like that, and then afterword return to the previous norms.

Ending: don’t let the clock be the only thing in the determines the end. Do not close without closing. You need to summarize what people have heard and give them an opportunity to continue. In the dialogs, give an opportunity to stay in touch, and opportunity to host, and opportunity not to just give money but time and opportunity to believe.  Except the mortality, the impermanence of any gathering that you host. While you can courage some clear defined formative continuation, the chat group was created to keep up the spirit never do what the intent. Recognize that this is over, and yet something new can begin because of that, not nearly a continuation of what is already occurred. Do not turn away from finitude, like the monks to encourage never pushing away anything and teach classes on death he must the recognition of an end.

The last call: often it’s difficult to determine when to go and party, whether it be once a significant my already wants to leave or when there are only a few final stragglers. A good middle ground is a kind of soft and moving the event into another room or, potentially, outside, (maybe where the other were late arrivals are waiting) but leave the original room allowing some to go on their way while others may continue the discussion.

The actual close: this has two components looking inward and looking out. Looking inward reflect on what you have learned and experienced, while looking outward determines next steps and initiate a transition back into the normal world. Reimagine the party favor or other device as a way of turning an ephemeral experience into a lasting memory. Don’t end on thank youse either, rather put thank youse second to last

Don’t give your thank you‘s in the traditional form either. Particularly, don’t mention the roles of each person when thinking them. Thank them as people rather than as their role might suggest.

One idea for closing is to read aloud “not given from the preparation workbooks but from the day itself for the event itself which makes people recognize both the progress that they have made through the event through reading them from the logically and that they were listens to and listens to carefully during experience.