---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Appeals
Authors: ""
Title: Destroying Your House
Takeaway: Must give reasons for will clause against public policy
Tags:
  - Destruction
  - Public Policy
Category:
  - Property
Abstract: ""
Type: Case
Rating: "****"
Year: 1975
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Eyerman v. Mercantile Trust Co.
Status: Annotated
Date: 1975-01-01
Jurisdiction: Missouri
---
> [!note]+ Facts
> - Louise Woodruff Johnstson instructs to destroy her house (#4 Kingsbury Place) in her will
> - Property owners don’t like this, file to get the area designated as a historic preservation district to prevent destruction
> - Nearby property owners claim this is an actionable nuisance and is contrary to public polity

> [!note]+ Procedural History and Posture
> - Trial court denies injunction to prevent destruction

- Issue: Can you destroy your house after you die?

> [!note]+ Holding (Rendlen): No, not without expressing reasons
> - No reason is suggested in the will
> - Wills are not absolute rights, weighted against public policy
> - Disposition: Reversed

> [!note]+ Concurrence/Dissent (Clemens): Yes
> - We might like this place aesthetically, but that shouldn’t limit rights
> - The standard of review is plain error
