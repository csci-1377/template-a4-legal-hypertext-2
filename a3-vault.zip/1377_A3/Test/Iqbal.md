---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Frankensteins Monster
Takeaway: Plausibility pleading is transubstantive, even in civil rights cases
Tags:
  - Pleading
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "*****"
Year: 2009
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Ashcroft v. Iqbal
Status: Annotated
Date: 2009-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - Iqbal is a Pakistani Muslim, claiming constitutional rights violated while in federal custody
> - Ashcroft is former AG, alleged with Muller (FBI Director) to have adopted unconstitutional policy discriminating on the basis of “race, religion, or national origin”
> 
> > [!note]+ Glenn’s
> > Iqbal, a Pakistani Muslim was arrested and detained in wake of Sept 11. More specifically he alleges he was designated a person of “high interest” to the FBI’s Sept 11 investigation and put in a maximum security prison, locked down 23 hrs a day with one hour spent escorted in handcuffs and leg irons. He sues John Ashcroft (former AG) and Robert Mueller (FBI director). He claims his constitutional rights were violated because he was subjected to harsh conditions of confinement on the basis of his race, religion, or national origin in violation of 1st and 5th amendments. Specifically, complaint alleges that “the [FBI], under the direction of Defendant MUELLER, arrested and detained thousands of Arab Muslim men ... as part of its investigation of the events of September 11.” And “[t]he policy of holding post-September-11th detainees in highly restrictive conditions of confinement until they were ‘cleared’ by the FBI was approved by Defendants ASHCROFT and MUELLER in discussions in the weeks after September 11, 2001,” and posits that petitioners “each knew of, condoned, and willfully and maliciously agreed to subject” respondent to harsh conditions of confinement “as a matter of policy, solely on account of [his] religion, race, and/or national origin and for no legitimate penological interest.” The pleading names Ashcroft as the “principal architect” of the policy, and identifies Mueller as “instrumental in [its] adoption, promulgation, and implementation.”

> [!note]+ Procedural History and Posture
> - District court denies motion to dismiss (on the basis of qualified immunity) under the Conley standard
> - Then Twombly is decided
> - Second Circuit assumes can be appealed because it’s a qualified immunity thing under collateral order doctrine (favors groups with qualified immunity)
> - Then affirms, asserting Twombly calls for a “flexible plausibility standard”

- Issue: Does the complaint meet *Twombly’s *pleading standard?

> [!note]+ Holding (Kennedy): No
> > The plausibility standard is not akin to a “<u>probability</u> requirement,” but it asks for more than a sheer possibility that a defendant has acted unlawfully. Ibid. Where a complaint pleads facts that are “merely consistent with” a defendant's liability, it “stops short of the line between <u>possibility</u> and <u>plausibility</u> of ‘entitlement to relief’.
> 
> > [!note]+ Twombly 2-Step
> > 1. Separate factual allegations and legal conclusions: We give deference to factual allegations, not legal conclusions
> > > First, the tenet that a court must accept as true all of the allegations contained in a complaint is inapplicable to legal conclusions.
> > 2. A complaint needs to be plausible on the basis of its (non-conclusory) factual allegations
> > > Second, only a complaint that states a plausible claim for relief survives a motion to dismiss. Determining whether a complaint states a plausible claim for relief will, as the Court of Appeals observed, be a context-specific task that requires the reviewing court to draw on its <u>judicial experience and common sense</u>.
> 
> > [!note]+ Result
> > > As between that "obvious alternative explanation" for the arrests, *Twombly, * and the purposeful, invidious discrimination respondent [1952] asks us to infer, <u>discrimination is not a plausible conclusion</u>.
> > 
> > - Again, didn’t "nudg[e]" his claim of purposeful discrimination "across the line from conceivable to plausible.”
> 
> > [!note]+ 3 Objection Responses: We’re not getting off this train
> > - ***Obj****:* Limit *Twombly* to Antitrust cases. ***Reply:*** No, Rule 8 assumed to be transubstantive
> > - ***Obj*****:** Limit *Twombly* to worrisome discovery cases. ***Reply: ***No
> > - ***Obj*****:** Contrast with FRCP 9 lets me plead generally. ***Reply: ***No
> > > ‘generally’ is a relative term (compare to elevated pleading standards fro fraud, etc)
> 
> - Disposition: Reversed

> [!note]+ Dissent (Souter +3): Yes, kill my Frankenstein’s Monster
> - With Stevens, Ginsburg, and Breyer
> - Hyper-technical, fails to read the room
> 
> > Iqbal does not say merely that Ashcroft was the architect of some <u>amorphous discrimination</u>, or that Mueller was instrumental in an <u>ill-defined constitutional violation</u>; he alleges that they helped to create the discriminatory policy he has described. Taking the complaint as a whole, it gives Ashcroft and Mueller "`fair notice of what the . . . claim is and the grounds upon which it rests.'”
> 
> - So “agreement” was a legal conclusion in Twombly, but “discrimination” is a factual conclusion here
>     - Really? These sure look very similar to the Twombly allegations
> 
> > a court must take the allegations as true, no matter how skeptical the court may be… The sole exception to this rule lies with allegations that are sufficiently fantastic to defy reality as we know it: claims about little green men, or the plaintiff's recent trip to Pluto, or experiences in time travel.
> 
> - The Court dismisses one allegation as conclusory that isn’t: 

> [!note]+ Dissent (Breyer): Yes
> - Write separately to also call out Twombly
> - Basically, there are other tools to constrain discovery through ‘case-management tools’

> [!note]+ General Notes
> - Background problem 1: what is the proper standard for racial discrimination? Court insists on active animosity, not disparate impact
> - Background problem 2: what should the proper standard for vicarious liability be for racial discrimination? (court insists on higher standard than even defendants concede)