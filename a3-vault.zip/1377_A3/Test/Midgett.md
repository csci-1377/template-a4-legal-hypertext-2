---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: "Second Degree Child Abuser "
Takeaway: First Degree requires object to kill
Tags:
  - Intentional Homicide
Category:
  - Crim
Abstract: ""
Page: 287
Type: Case
Rating: "***"
Year: 1987
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Midgett v. State
Status: Annotated
Date: 1987-01-01
Jurisdiction: Arkansas
---
> [!note]+ Facts
> - Father physically abuses child
> - Eventually kills him, takes to hospital
> - They discover beatings and starvation lead to his death

> [!note]+ Procedural History and Posture
> - Jury convicts of first-degree murder

- Issue: Was there sufficient evidence to convict of first degree murder?

> [!note]+ Holding (Newberrn): No
> - He wasn’t trying to kill him, he wanted to keep him alive to keep abusing him.
> - Also he was drunk, so no deliberation
> - Disposition: Modified to 2nd Degree and Remanded

> [!note]+ Dissent (Hickman): Yes. and this is for the jury to decide.
> - This guy deliberately starved and beat his kid. How can we not convict him for murder?





















