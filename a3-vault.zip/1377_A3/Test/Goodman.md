---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Recommended
Court: Appeals
Authors: ""
Title: Relying on Radios
Takeaway: ""
Tags:
  - Promisory Estoppel
Category:
  - Contracts
Abstract: ""
Type: Case
Rating: "***"
Year: 1948
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Goodman v. Dicker
Status: Annotated
Date: 1948-01-01
Jurisdiction: D.C. Circuit
---
> [!note]+ Facts
> - D are local distributors for Emerson Radio
>     - Not really making promise, they weren’t in position to actually give the franchise
> - P applied for a “dealer franchise” to sell products at D’s encouragement and confirmation that application was accepted
> - P prepares by hiring employees and soliciting orders for radios
> - No radios come, D says looks like no franchise

> [!note]+ Procedural History and Posture
> - Trial court says no K, but promisory estoppel lends equitable relief because of reliance on promise
> - They award $1150 for costs in reliance and $350 for expectation of profits from radios

- Issue: Does Promissory Estoppel provide equitable relief?

> [!note]+ Holding (Proctor): Yes
> - D- can’t award, since franchise would have not required any sale of radios
> - That misses the point, since they were promised franchise (really?)
> - Yes to 1150 in costs, no to 350 expected profits
> 
> > The true measure of damage is the loss sustained by expenditures made in reliance upon the assurance of a dealer franchise.
> 
> - Disposition: Affirmed
