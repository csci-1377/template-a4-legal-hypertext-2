---
base: "[[Test.base]]"
In-Text Citation: (Koskenniemi, 2006)
Priority: Recommended
Authors: Koskenniemi, Martti
Title: "From Apology to Utopia: The Structure of International Legal Argument"
Zotero URI: http://zotero.org/users/4316906/items/NQRWQHIV
Takeaway: ""
Tags: []
Category:
  - Normative Analysis
Abstract: This book presents a critical view of international law as an argumentative practice that aims to 'depoliticise' international relations. Drawing from a range of materials, Koskenniemi demonstrates how international law becomes vulnerable to the contrasting criticisms of being either an irrelevant moralist Utopia or a manipulable façade for State interests. He examines the conflicts inherent in international law - sources, sovereignty, 'custom' and 'world order' - and  shows how legal discourse about such subjects can be described in terms of a small number of argumentative rules. This book was originally published in English in Finland in 1989 and though it quickly became a classic, it has been out of print for some years. In 2006, Cambridge was proud to reissue this seminal text, together with a freshly written Epilogue in which the author both responds to critiques of the original work, and reflects on the effect and significance of his 'deconstructive' approach today.
Type: Book
URL: https://www.cambridge.org/core/books/from-apology-to-utopia/146C2D8967B109E959E651A5583EED54
Full Citation: "Koskenniemi, M. (2006) From Apology to Utopia: The Structure of International Legal Argument. Cambridge: Cambridge University Press. Available at: https://doi.org/10.1017/CBO9780511493713."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2006
---
