---
base: "[[Test.base]]"
DOI: https://doi.org/10.1080/02691728.2016.1270364
In-Text Citation: (Hedden, 2017)
Priority: Further
Authors: Hedden, Brian R.
Title: Should Juries Deliberate?
Zotero URI: http://zotero.org/users/4316906/items/X8J2DEMP
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: ""
Type: Journal Article
Full Citation: "Hedden, B.R. (2017) ‘Should Juries Deliberate?’, Social Epistemology, 31(4), pp. 368–386. Available at: https://doi.org/10.1080/02691728.2016.1270364."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Skimmed
Year*: 2017
---
