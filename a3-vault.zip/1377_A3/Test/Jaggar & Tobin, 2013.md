---
base: "[[Test.base]]"
DOI: https://doi.org/10.1111/meta.12048
In-Text Citation: (Jaggar and Tobin, 2013)
Priority: Recommended
Authors: |-
  Jaggar, Alison M.
  Tobin, Theresa W.
Title: "Situating Moral Justification: Rethinking the Mission of Moral Epistemology"
Zotero URI: http://zotero.org/users/4316906/items/IUUJBWNR
Takeaway: ""
Tags: []
Category:
  - Moral Epistemology
Abstract: This is the first of two companion articles drawn from a larger project, provisionally entitled Undisciplining Moral Epistemology. The overall goal is to understand how moral claims may be rationally justified in a world characterized by cultural diversity and social inequality. To show why a new approach to moral justification is needed, it is argued that several currently influential philosophical accounts of moral justification lend themselves to rationalizing the moral claims of those with more social power. The present article explains how discourse ethics is flawed just in this way. The article begins by identifying several conditions of adequacy for assessing reasoning practices designed to achieve moral justification and shows that, when used in contexts of cultural diversity and social inequality, discourse ethics fails these conditions. It goes on to argue that the failure of discourse ethics is rooted in its reliance on a broader conception of moral epistemology that is invidiously idealized. It concludes by pointing to the need to rethink both the mission and the method of moral epistemology.
Type: Journal Article
URL: https://0.onlinelibrary.wiley.com/doi/abs/10.1111/meta.12048
Full Citation: "Jaggar, A.M. and Tobin, T.W. (2013) ‘Situating Moral Justification: Rethinking the Mission of Moral Epistemology’, Metaphilosophy, 44(4), pp. 383–408. Available at: https://doi.org/10.1111/meta.12048."
Last edited: 2026-02-15T22:06:00
Full: ""
Status: Someday
Year*: 2013
---
