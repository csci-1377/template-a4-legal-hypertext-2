---
base: "[[Test.base]]"
In-Text Citation: ""
Priority: Essential
Court: Supreme
Authors: ""
Title: Different Fraud Bonds
Takeaway: Collateral estoppel doesn’t bar similar issues not actually litigated (importance of defining scope of issue)
Tags:
  - Issue Preclusion
Category:
  - Civil Procedure
Abstract: ""
Type: Case
Rating: "***"
Year: 1876
Full Citation: ""
Last edited: 2026-02-15T22:06:00
Full: Cromwell v. County of Sac
Status: Annotated
Date: 1876-01-01
Jurisdiction: United States
---
> [!note]+ Facts
> - P sues to recover on some bonds he claims to have purchased for value in good faith, but doesn’t prove that fact and loses
> - P sues to recover on other bonds where he does show that. Can county get issue preclusion regarding whether bond was fraudulent and GFP?
> 
> > [!note]+ Glenn’s
> > County of Sac wants a new courthouse. It authorizes the issuance of bonds of $10,000 to pay for the courthouse. Those bonds are delivered to the county judge, who delivers them to Meserey, a contractor with whom the judge contracts to build the courthouse. The contractor gives one of the bonds to the judge immediately as a “gratuity.” The courthouse never gets built. The bond in question turns out to be a “coupon bond”: a bond with attached interest coupons that the holder may present to receive interest payment. Before the bonds matured, Cromwell acquired 25 coupons of the bond.
> > 
> > Under the law of negotiable instruments, the city would not have to pay out on a bond if the bond issuance was fraudulent, with one exception: the “holder in due course” rule. You *do* have to pay a holder in due course, which is someone who paid value for the bond and was unaware of the fraud (holders in due course are sometimes called “bona fide purchasers”).
> > 
> > Case 1: Smith sues on behalf of Cromwell to recover on some but not all of the bonds. The county defends the case by saying it was defrauded, the bonds were fraudulent. Cromwell does not try to show he was a holder in due course. The county wins.
> > 
> > Case 2: Cromwell sues on a different set of bonds and coupons, Cromwell now wants to prove that he acquired the coupons for value before their maturity and in ignorance of the fraud: that he was a holder in due course.

> [!note]+ Procedural History and Posture
> - District Court: no, the issue of your entitlement to recover on these coupons was decided in the Case 1, issue preclusion.

- Issue: Was the GFP issue litigated in case 1?

> [!note]+ Holding (Field): No
> - no issue preclusion, because the issue of whether he was a holder in due course was never actually litigated in Case 1.
> - Disposition: Reversed and remanded