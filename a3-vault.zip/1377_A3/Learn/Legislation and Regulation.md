---

---

# Regulation

> [!note]+ ### Agency Structure
> - Types of Agencies
>     - Executive Branch: Single head fireable at will by President
>     - Independent: Mutli-member boards, President names board members *and* chair
> - Appointment
>     - From Appointments clause of the Constitution
>     - <u>**Officers**</u> are those who excercise “significant authority” (others <u>**employees**</u>)
>     - <u>**Principle**</u> officers must be appointed by pres w/ advice and consent of Senate ([[Buckley]] )
>     - <u>**Inferior **</u>officers appointed by president, courts, or department heads (Perkins CB 736?)
> - Removal ([[Seila Law]] )
>     - Concerning the Vesting and Take Care Clauses
>     - President has plenary removal power for purely executive positions ([[Myers]] )
>         - Executive: enforcement
>         - Legislative: reports to Congr
>     - 2 Exceptions: Congress can constrain 
>         1. nonpartisan, multimember commission of experts to perform legislative and judicial, but not “exercise any executive power” ([[Humphrey’s Executor]] ) BUT the FTC doesn’t meet those criteria anymore and maybe never did
>             1. But Seila says “wields substantial executive power”
>         2. Removal of <u>**inferior officers**</u> ([[Morrison]] )
>             - Subordinate (subject to removal by another agency head) and limited in time and tenure (duties and jurisdiction)
>         3. Another possible exception? Seila refuses to extend (but we could!)
>     - Also, No Double (For-Cause Removal) Insulation ([[Free Enterprise]] ) even if inferior
>     - Note: Outdated Tests: Unduly Trammels ([[Morrison]] ), Aggrandizement

> [!note]+ ### Delegation
> - No legislative veto of agency decisions ([[Chada]] )
> - Intelligible Principle Test ([[Hampton]])
>     - [[Schechter]] (One Good Year: Exception Proves Rule)
>     - [[Whitman]]  (Back to Nonenforcement)
>     - Clauses upheld since Whitman
>         - Regulate “in the public interest”
>         - Ensure a “fair and equitable process”
>         - Set “just and reasonable rates”
>         - Create “standards requisite to protect public health”
>     - Phrases that make delegation ok
>         - Power to execute
>         - Fill in the gaps
>         - Carry out
>         - Implement
>         - Policymaking discretion
> > [!note]+ But delegation might be construed narrowly, or Hampton overruled ([[Gundy]] )
> > - Kavanaugh has come on as 5th vote likely against 
> > - Cited Gorsuch’s dissent in statement to deny hearing “I’ll reconsider per Gorsuch”
> > - Now Barrett is likely sixth vote

> [!note]+ ### Procedure
> Standard: De Novo
> 
> > [!note]+ Notice and Comment Requirements §553
> > - Only consider reasons given by agency at the time of their decision ([[Chenery I]] )
> > 
> > > [!note]+ Notice published in Fed Register: 553b
> > > **(b) **General notice of proposed rule making shall be published in the Federal Register, unless subject thereto are named and either personally served or otherwise have actual notice thereof in accordance with law. The notice shall include—
> > > 
> > > **(1) **a statement of the time, place, and nature of public [rule making](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-663839537-1277204887&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) proceedings;
> > > 
> > > **(2) **reference to the legal authority under which the [rule](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-3512060-1277204886&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) is proposed; and
> > > 
> > > **(3) **either the terms or substance of the proposed [rule](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-3512060-1277204886&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) or a description of the subjects and issues involved.
> > > 
> > > Except when notice or hearing is required by statute, this subsection does not apply—
> > > 
> > > **(A) **to interpretative [rules](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-3512060-1277204886&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553), general statements of policy, or [rules](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-3512060-1277204886&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) of [agency](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-1419699195-1277204883&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) organization, procedure, or practice; or
> > > 
> > > **(B) **when the [agency](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-1419699195-1277204883&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553) for good cause finds (and incorporates the finding and a brief statement of reasons therefor in the[ rules ](https://www.law.cornell.edu/definitions/uscode.php?width=840&height=800&iframe=true&def_id=5-USC-3512060-1277204886&term_occur=999&term_src=title%3A5%3Apart%3AI%3Achapter%3A5%3Asubchapter%3AII%3Asection%3A553)issued) that notice and public procedure thereon are impracticable, unnecessary, or contrary to the public interest.
> > 
> > - Opportunity for Comment? 553c
> >     - Disclosed studies relied on? ([[Nova Scotia]] )
> >     - Logical Outgrowth? ([[Chocolate Manufacturers]] )
> >         - at least a ‘germ’ of outcome in proposal
> >         - New round wouldn’t provide 1st opportunity to provide criticism
> >         - Reasonably anticipated
> >         - Not a “guessing game”
> >         - Not a “surprise switcharoo”
> >         - Not “completely changed positions”
> > - Concise Statement of Basis and Purpose §553c
> >     - Respond to proposed alternatives/specific claims? ([[Nova Scotia]] )
> >     - Addresses “vital” questions of “cogent materiality”
> >     - Addresses “all relevant factors”
> > - Adequate record for judicial review §706
> 
> > [!note]+ Notice and Comment Exceptions
> > - Military or foreign affairs. § 553(a)(1)
> > - Agency management or personnel, or public property, loans, grants etc. § 553(a)(2)
> >     - Non-Legislative Rules: <u>Interpretive rules</u>, general statements of policy, or rules of agency organization, procedure, or practice § 553 (b)(1)(A)
> > - Good Cause:  if N&C is impracticable (<u>emergency</u>), unnecessary (<u>no controversy</u>), or contrary to the public interest (<u>undesireable anticipatory behavior</u>) § 553 (b)(3)(B)
> >     - Direct Final Rulemaking (Adopted as interrim without N+C, then later implementing similar final rule. If interrim invalid, don’t need to start over)
> 
> > [!note]+ Interpretive Rules
> > Note: Agency might claim it’s interpretive but I think legislative. Do analysis for both
> > 
> > - Test for Legislative Rule ([[AMC]])
> >     1. Without rule, no basis for enforcement
> >     2. Published in Federal Register
> >     3. “explicitly invokes its general legislative authority” - it claims legislative rule
> >     4. It amends/is irreconcilable with a prior N+C rule
> > - Some clues to support the test ([[Hoctor]])
> >     - Greater public interest
> >     - More specific the rule
> >     - More arbitrary
> >     - “Flatter”
> > - Alternate Tests
> >     - Goes beyond the text
> >     - The legal right did not exist before
> >     - Grounded in judgment, not statutory provisions
> > 
> > Note: finding it was interpretive doesn’t mean it was correct interpretation
> > 
> > Note 2: If interpretive, not subject to arbitrary and capricious review
> 
> > [!note]+ Sources of Agency Procedure
> > - Constitution
> > - The Administrative Procedure Act
> >     - Governs unless “expressly” overriden by a statute
> > - Organic Statute (the one creating the agency)
> > - Other Statutes
> > - Executive Orders/Presidential Memos
> 
> > [!note]+ Rule or Adjudication?
> > - Rule (legislative/policy/future-oriented): “an agency statement of** **<u>**general**</u><u> or particular </u>applicability and future effect, designed to implement, interpret, or prescribe law or policy”
> > - Adjudication (judicial/fact/past-oriented): Whatever isn’t a rule, Only binds present parties
> > - Rarely litigated, usually deferred to agency to characterize
> 
> > [!note]+ Formal v Informal
> > |   | Rules | Adjudication |
> > | --- | --- | --- |
> > | Formal | Mostly Gone: Notice, adversarial hearing, on-the-record decision on the issue | Notice, Hearing, on-the-record decision |
> > | Informal | Notice in Federal Register (553b) Comment and Explanation (553c) | Nothing specific, but some generic requirements for all agency action |
> > 
> > - Formal: “required by statute to be made on the record after opportunity for an agency hearing”
> > - Informal: Notice and Comment for rules, whatever for adjudication
> > - Sometimes clearly stated in statute, sometimes not
> 
> - Formal adjudication, generally defer ([[Chenery II]])
> 
> > [!note]+ Interpretation or Policy?
> > - Interpretation
> >     - “legally permissible” or “legal authority” 
> >     - Definitions in statutes
> > - Policy
> >     - Setting levels, deciding exemptions

> [!note]+ ### Agency Policy
> > [!note]+ Standard: Arbitrary and Capricious under APA §706(2)(A)
> > 1. Hold unlawful action found to be
> >     1. “Arbitrary and capricious, an abuse of discretion, or otherwise not in accordance with law”
> >     2. Unconstitutional
> >     3. Beyond statutory authority/jurisdiction
> >     4. Without observance of procedure required by law
> >     5. Unwarranted by facts to extend subject to trial de novo
> 
> Conduct a review of the whole record, but not post-hoc rationalizations ([[Chenery I]])
> 
> > [!note]+ [[State Farm]] Test: “hard look” review to ensure “reasoned analysis”
> > 1. Relied on factors Congress did not intend (like political popularity)
> > 2. Failed to consider important aspect of problem or <u>**alternative solution**</u>
> > 3. Explanation runs counter to the evidence
> > 4. (Bad Faith) So implausible can’t be attributed to reasonable disagreement or expertise.
> > 
> > Note: Same for implementing and recinding rules
> 
> > [!note]+ Pretext
> > - Usually, only look to *stated* reasons for policy ([[Chenery I]])
> > - Rebuttable presumption of good faith, judging agency actions by reasons provided (Overton Park), except in cases where there has been a “strong showing of bad faith or improper behavior by the agency”
> > 
> > > [even when stated reasons would have been enough, invalid if] Evidence tells a story that does not match the explanation the Secretary gave for his decisions ([[DOC]])
> > 
> > - Was the decision on the basis of “post hoc rationalizations ([[Regents]]) quoting Overton Park)
> > - When this exists, can get extra discovery to explore if stated reasons were pretextual
> 
> - Don’t require any more procedure than APA or statute requires ([[Vermont Yankee]])

> [!note]+ ### Agency Interpretation
> > [!note]+ MQD
> > > [!note]+ Versions of MQD
> > > - Non-Delegation Doctrine ([[NOTION_PAGE:3634252e-1c58-4fd3-af50-78630146268a]])
> > >     - Even if agency interprets correctly, they still lose (don’t have the authority)
> > >     - Default, since this is modern court ([[NOTION_PAGE:3634252e-1c58-4fd3-af50-78630146268a]], [[NOTION_PAGE:e4cb300c-65ca-4e2d-b63c-8b929db2406f]], and [[NOTION_PAGE:ba438969-1b35-4e0d-8ed1-4ed4ecc47426]])
> > > - At Step O: Congress didn’t intend to delegate these decisions ([[NOTION_PAGE:abf170cf-1beb-41d7-b75e-ca9cd997ff22]])
> > >     - No agency deference, but court can independently reach same conclusion
> > > - At Step 1: The statute clearly precludes decisions of this significance ([[NOTION_PAGE:28994c13-a2fc-462d-8fae-d239dfd925e1]] )
> > > - At Step 2: The interpretation isn’t reasonable (MCI)
> > 
> > Note: all involved legislative rules (but note some courts might extend to interpretive rules)
> > 
> > 1. Major? 
> >     1. Is the relevant section of the statute a “<u>wafer-thin reed</u>” on which to rest such sweeping power? ([[Alabama Realtors]])
> >     2. Or is it “an obscure, never-used section of the law”? ([[West Virginia]])
> >     3. Is the agency an expert in this kind of thing? ([[King]])
> >     4. Regulation of a different kind than previous? ([[West Virginia]])
> >     - If no, Mead. If yes…
> > 2. Clear Statment? 
> >     5. Need  “clear congressional authorization” (Utility Air)
> >     - Don’t do full statutory interp: 
> > - If no…
> >     - NDD Version: Not within agency authority, reject interpretation ([[OSHA]])
> >     - De Novo Review ([[King]])
> 
> > [!note]+ [[Mead]] 
> > 1. Did Congress delegate the power to speak with “the full force of law”?
> > 2. Is the agency interpretaion made in *excercise *of that authority?
> >     1. Was it issued through Notice and Comment?
> >     2. Other circumstances “reasonably suggesting that Congress ever thought of [ruling] as deserving” Chevron?
> > > Sometimes found reasons for *Chevron* deference even when no such administrative formality [Notice and Comment] was required and none was afforded
> > “plausible case” that “Congress would want Chevron to apply”
> > 
> > If passed, legislative rule deserving <u>Chevron</u> deference rather then <u>Skidmore</u> respect.
> 
> > [!note]+ [[Chevron]] 
> > Defer to an agency’s reasonable interpretation of ambiguous statutes
> > 
> > > [!note]+ Step 1: Ambiguity (never say it’s ambiguous)
> > > - “Congress has directly spoken to the precise question at issue” as measured by the traditional tools of statutory interpretation.
> > > - Do full <u>**Statutory Interpretation **</u>(all but substantive canons)
> > > - If Ambiguous
> > >     - Is the decision one of “such economic and political significance” we should hesitate to conclude Congress intended an implicit delegation? [[NOTION_PAGE:28994c13-a2fc-462d-8fae-d239dfd925e1]] If yes reject interp.
> > >     - If not, Step 2
> > > - If unambiguous, de novo
> > 
> > > [!note]+ Step 1.5: Check for Substantive Canons
> > > - Constitutional Avoidance: Raises serious constitutional issues
> > >     - If can avoid by alternate interpretation doesn’t raise, go with that
> > > - Like a clear statement rule
> > > 
> > > [[NOTION_PAGE:f8848501-dc84-4568-9efa-70ed33abc477]] 
> > > 
> > > [[NOTION_PAGE:0e912f38-8551-4f1d-b7d8-5632b5255ade]]
> > > 
> > 
> > > [!note]+ Step 2: Reasonableness (if however I’m wrong)
> > > - Can either
> > >     1. Look at statutory materials again ([[NOTION_PAGE:7036df19-db43-438c-aaaf-6afe7a80460f]])
> > >     2. Examine the Reasoning Process (like ArbCap)
> > >     3. Decide so big it’s not reasonable (MCI)
> > > - Reasons to defer
> > >     - The regulatory scheme is technical and complex
> > >     - Agency considered the matter in a detailed and reasoned fashion 
> > >         - Don’t care about consistency like in Skidmore
> > >     - Decision involves reconciling conflicting policies.
> > >     - May properly rely “upon the incumbent administration’s views of wise policy to inform its judgments” 
> 
> > [!note]+ [[Skidmore]] 
> > - Factors
> >     - Consistent
> >     - Relative Expertise
> >     - Formality
> >     - Degree of Care
> >     - Power to Persuade
> > - If yes, respect 
> > - If no, de novo
> > - Either way, jump to <u>**Statutory Interpretation**</u>
> 
> Note: always argue in alternative (do all these)

# Statutory Interpretation

> [!note]+ ### Text
> - Dictionary definition ([[Smith]])
> - Common Speech ([[McBoyle]], [[Babbit]])
> - Legal terms of art ([[Casey]], [[Moskal]])
> - Specialized/expert meaning if available ([[Nix]])
> - Literal Meaning over Expectations (Literal dynamism) ([[Bostock]])
> - Congress can be specific when it wants to ([[Marshall]])
> 
> Semantic Canons
> 
> > [!note]+ Ejusdem generis ([[Yates]], [[McBoyle]]): A **catch-all** at the end of a list is limited to things of a similar type
> > - But underdetermined what shared characteristic is
> 
> > [!note]+ Expresio unius est exclusio alterius
> > - Translation: inclusion of one implies the exclusion of others)
> > - Except for… is a good indicator
> 
> - Noscitur a sociis (known by its associates) ([[Babbit]])
> - Rule against surplusage ([[Babbit]], [[Yates]], [[Moskal]])
> - Presumption of consistent meaning ([[Marshall]])

> [!note]+ ### Context/Structure
> > The words of a statute must be read in their context and with a view to their place in the overall statutory scheme. ([[Brown]])
> 
> - If ambiguous, construe to fit with broader corpus juris ([[Casey]])
> - Can be ambiguous in context even if clear by itself ([[King]])
> - Interpret according to what Congress would have intended ([[Palmer]])
> - Look to purpose when text (in context) is ambiguous ([[Moskal]], [[Kasten]])
> - Other sections ([[Babbit]])
> - Title/Caption ([[Yates]])
> - Position in Law ([[Yates]])
> - Don’t hide an elephant in a mousehole ([[King]])
> - Consider whether the consequence of an interpretation would undermine the “design” of the statute ([[King]])
> - Not only what a statute sets out to change, but what “it resolves to leave alone” ([[Casey]])
> - BUT not the job of the court to make a statute internally consistent if unambiguous ([[TVA]])
> 
> > a thing may be within the letter of the statute and yet not within the statute, because not within its spirit or the intention of its makers. [[Holy Trinity]] 

> [!note]+ ### Legislative History
> Generally: evidence of evil Congress trying to remedy ([[Cline]])
> 
> (In rough order of reliability)
> 
> > [!note]+ 1) Committee Reports ([[TVA]], [[Train]], [[Blanchard]], [[Babbit]])
> > - Most reliable, by House, Senate, and Conference Committee
> > - Most members don’t read the bills, they accept interpretations of these committees
> > - BUT does this give a perverse incentive for statutory ambiguity
> > - OR is it just the lesser of two evils, between relying on it and relying on statutory text and conjecture about purpose?
> 
> > [!note]+ 2) Successive Versions
> > 1. Removed qualifying language, indicating broad intent ([[TVA]])
> > 2. Proposed (but failed) amendment ([[Train]])
> > - Passed amendment should have real effect ([[Babbit]])
> > - BUT we can never really know why that version didn’t pass
> 
> > [!note]+ 3) Statements of Individual Legislators
> > - Floor Statements ([[Train]], [[TVA]])
> >     - Some never actually spoken on the floor, inserted into the record afterward
> > - Sponsor Statements: Maybe they know more about the bill, other members defer to their interpretation?
> >     - BUT these are even more susceptible to manipulation
> > - Conference Reports ([[Train]])
> >     - Often “cooked” or prepared for the event
> 
> > [!note]+ 4) Evidence of Absence: “The Dog That Didn’t Bark” ([[Train]], [[McBoyle]])
> > - Taken as informative that some issue wasn’t controversial
> > - BUT Hazardous, since proposition that if it really meant Y someone would have said something is questionable
> > - ALTHOUGH if one interpretation would have a drastic consequence, the fact that no one discussed that should mean something
> 
> > [!note]+ 5) Subsequent Legislative Action: Continued ([[TVA]] ), Rejected by [[Casey]] 
> > - Acquiescence is often the evidence here. If they didn’t overturn an interpretation, does that mean they supported it?
> > - How important is it that enacting new legislation is really hard?
> 
> > [!note]+ 6) What About the President?
> > - Often issues “signing statements” that could be characterized as interpretive
> > - BUT using these would inappropriately expand presidential power
> > - Fortunately? judges rarely reference these, and when they do it’s to confirm other evidence of legislative history

> [!note]+ ### Substantive Canons
> A thumb on the scale/tipping point when a statute is ambiguous ([[Smith]])
> 
> > [!note]+ Constitutional Avoidance [[NLRB]], [[DeBartolo]] 
> > - Classical: avoid constructions that are *actually* unconstitutional (decide constitutional question)
> > - Modern Avoidance Canon ([[NOTION_PAGE:8043c0d4-510a-42ce-a206-c3e2fcdd61ee]]): avoid when there is a *serious doubt or question* (avoid constitutional question) 
> >     - Strong (Burger majority) require clear statement from Congress
> >     - Weak (Brennan dissent) only when two plausible readings
> >     - It replaces drawing a clear line and making sure it isn’t crossed with pointing to a blurry cloud and keeping everything away
> >     - This will actually allow the court to further trim legislation
> 
> > [!note]+ Federalism  [[SWANCC]] (MAYBE [[Ashcroft]] but she said be careful)
> > - What starts with constitutional avoidance becomes desire to safeguard a constitutional *value *(commitment to federalism)
> > - Is this a coherent freestanding norm, or just an expression of the balance struck in the Constitution?
> > 
> > > [!note]+ Pros (Why state gov is better)
> > > - Responsiveness
> > > - Participation
> > > - Innovation (laboratories of Democracy)
> > > - Competition (race to the top)
> > > - Vertical Division of Power (checking abuse?)
> > 
> > > [!note]+ Cons
> > > - Really? This is local government stuff, if anything
> > > - And do you remember the 1950s? States aren’t great at civil rights
> > > - Often more like a race to the bottom
> > > - And most importantly, what’s at issue here isn’t the abstract principle, but whether the specific regulation will help or hurt the balance of power
> > 
> > - Federalism canon helps “improve the legislative drafting process” by forcing clear writing?
> > - It’s not clear whether Congress is responsive to this, or any, canon.
> 
> - Lenity [[Bass]], [[McBoyle]], [[Yates]] )
> - Disfavor repeals by implication [[TVA]] 
> - No one should profit by his own wrong [[Palmer]] 
> - Narrowly construe statute derogating common law [[Palmer]] 
> - Read remedial statutes broadly (maybe avoid) [[Casey]] 
> 
> > [!note]+ Absurdity (it’s gotta be crazy: odd doesn’t count) [[Kirby]] 
> > - Inconceivability?
> > - Extreme departure from commonly accepted moral principles?
> > - Disturbingly unlikely?
> > - Not reasonable given tradeoffs?
> 
> - Also look to “social history”
> - Or common Sense as to how Congress is likely to delegate [[Brown]] 

# Policy

> [!note]+ ### Legislation
> > [!note]+ Theories of Interpretation
> > > [!note]+ Mine?
> > > - Raz: There was often no real intention, so we have to construct an “objectified intent”: what a reasonable person would gather from context
> > >     - Assume Congress intended us to interpret according to legal conventions (ultimately self-referential)
> > 
> > > [!note]+ Textualism (all kinds)
> > > - Assumptions
> > >     - Legislation is the result of compromise
> > > 
> > > > [!note]+ Different forms of textualism
> > > > - Ordinary Meaning (Scalia in [[NOTION_PAGE:e8b1dd49-d7af-4521-af2a-364f8a23846c]] ): when the text is clear, it controls – statutory text is the best method of discerning Congressional intent (Scalia)
> > > > - Literalism (Gorsuch dissent in [[NOTION_PAGE:f7d3c320-c189-48a3-9e90-4518d38eadb4]] ): mechanical, “literal” textualism stripped of time and place – words have plain meaning irrespective of what they may have meant to authors at the time 
> > > > - Original expectations/intentionalism (Alito dissent in [[NOTION_PAGE:f7d3c320-c189-48a3-9e90-4518d38eadb4]] ): what the words meant to the Congress at the time 
> > > > - Ordinary meaning (Kavanaugh, *Bostock*): what the words meant to the ordinary person at the time 
> > > > - Structural/contextual textualism (Roberts, *King*): making structural inferences to honor and make sense of the legislative plan 
> > > > - Wood-style textualism/dynamic statutory interpretation (Wood, *Hively*):
> > > >     - Is the text plain on its face?
> > > >     - If not à “best source for disambiguation” is the broader context of statute passed
> > > >     - Legislative history “notoriously malleable” or unreliable
> > > >     - Meaning in light of legal developments
> > > >         - Congress may not have realized the “full scope” words it chose 
> > > 
> > > > [!note]+ Claimed Benefits
> > > > - Based in legislative compromise rather than coherence
> > > > - Recognizes laws are often unprincipled due to this compromise, which must be respected.
> > > > - Trying to derive a statutory purpose then doesn’t respect legislative supremacy
> > > > - If we don’t assume congress picks its words with care, we don’t allow them ability to specify their policies (useful fiction)
> > > > - Statutes are about both ends and *means*. For instance, the choice whether to rely on rules or standards. Purposivism will end up being too standard-like.
> > > 
> > > > [!note]+ Counterarguments
> > > > - “Plain” text is a trecherous footing for interpretation
> > > > - Congress members often vote for broad purposes rather than exact language
> > > > - When text conflicts with purpose, either way threatens legislative supremacy
> > > > - The choice is sometimes between a more rational and just outcome and one that respects the rights of legislative minorities
> > > > - Narrow readings of statutes from textualism might result from policy-based desire to limit the scope of federal law
> > > > - Congressional committees are ‘islands’, rejecting “whole code” doctrine to compare use of language across the law
> > 
> > > [!note]+ Intentionalism
> > > - Try to construct legislative intent
> > > - Assumes legislatures contemplated, or fiction useful
> > 
> > > [!note]+ Purposivism
> > > - Assumptions
> > >     - Legislatures are rational
> > > - Claimed Benefits
> > >     - Better fit with reality
> > >     - Better able to accomodate evolving norms
> > >     - More hospitable to justice
> > >     - More honest about the judicial role
> > >     - Reasonable people acting reasonably is a “useful fiction” leading to better outcomes
> > 
> > > [!note]+ Originalism
> > > - Original Expectations [[NOTION_PAGE:eb0a236c-b06b-4ab5-ba57-e111b6205b19]], [[NOTION_PAGE:f7d3c320-c189-48a3-9e90-4518d38eadb4]]: Alito Dissent
> > 
> > > [!note]+ Diane Wood’s “Dynamic Statutory Interpretation” [[Hively]] 
> > > - Assumes relational agent
> > > - Most convincing when:
> > >     - statute is old
> > >     - textual argument could go either way
> > >     - history not illuminative
> > >     - nature of problem has changed
> > >     - legal and social context has changed
> > 
> > - Posner’s Pragmatism [[Marshall]] 
> > 
> > > [!note]+ Dotson Talk
> > > - 90-95% of committee reports reflect the point of the bill
> > > - Sometimes Congress doesn’t want clarity, they want to compromise on vagueness
> > > - Often the text is just gesturing/signaling to agencies
> > 
> > - Real Judges: an eclectic mix
> 
> > [!note]+ Tools of Interpretation
> > > [!note]+ Legislative History
> > > > Congress is a they, not an it
> > > > -Ken Shepsky
> > > 
> > > - Does this become more legitimate when it is part of the practice, or does it become less effective because of incentives to manipulate, or both?
> > > - Interpretation of “reasonably”
> > >     - Cost/benefit
> > >     - Standards of the practice
> > >     - A “normal” person
> > > 
> > > > [!note]+ Kinds of Legislative History
> > > > (In rough order of reliability)
> > > > 
> > > > > [!note]+ 1) Committee Reports
> > > > > - Most reliable, by House, Senate, and Conference Committee
> > > > > - Most members don’t read the bills, they accept interpretations of these committees
> > > > > - BUT does this give a perverse incentive for statutory ambiguity
> > > > > - OR is it just the lesser of two evils, between relying on it and relying on statutory text and conjecture about purpose?
> > > > 
> > > > > [!note]+ 2) Successive Versions
> > > > > - Tempting, especially if language favoring one interpretation of the current law was rejected
> > > > > - BUT we can never really know why that version didn’t pass
> > > > 
> > > > > [!note]+ 3) Statements of Individual Legislators
> > > > > - Floor Statements: Some never actually spoken on the floor, inserted into the record afterward
> > > > > - Sponsor Statements: Maybe they know more about the bill, other members defer to their interpretation?
> > > > >     - BUT these are even more susceptible to manipulation
> > > > > - Statements Made During Hearings: Colloquies
> > > > >     - Often “cooked” or prepared for the event
> > > > 
> > > > > [!note]+ 4) Evidence of Absence: “The Dog That Didn’t Bark”
> > > > > - Taken as informative that some issue wasn’t controversial
> > > > > - BUT Hazardous, since proposition that if it really meant Y someone would have said something is questionable
> > > > > - ALTHOUGH if one interpretation would have a drastic consequence, the fact that no one discussed that should mean something
> > > > 
> > > > > [!note]+ 5) Subsequent Legislative Action (or Inaction)
> > > > > - Acquiescence is often the evidence here. If they didn’t overturn an interpretation, does that mean they supported it?
> > > > > - How important is it that enacting new legislation is really hard?
> > > > 
> > > > > [!note]+ 6) What About the President?
> > > > > - Often issues “signing statements” that could be characterized as interpretive
> > > > > - BUT using these would inappropriately expand presidential power
> > > > > - Fortunately? judges rarely reference these, and when they do it’s to confirm other evidence of legislative history
> > > 
> > > > [!note]+ The History of Legislative History
> > > > - Pre-1850: Generally disfavored
> > > >     - Especially no floor statements
> > > >     - Grab bag of other interpretive methods
> > > > - 1860-1940: Somewhat more frequent
> > > >     - Still little use of floor statements
> > > >     - Resisting legislative innovation (Lochner Era starting 1905)
> > > >     - “When aid to construction of the meaning of words, as used in the statute, is available, there certainly can be no ‘rule of law’ which forbids its use, however clear the words may appear on ‘superficial examination’ (United States v. American Trucking Assns. (1940)
> > > > - 1940-1980: Golden Age of Legislative History
> > > >     - New Deal Statutes, more open-ended
> > > >     - Government lawyers make more legislative history arguments
> > > >     - Refer now to statement even in committee hearings
> > > >     - “The legislative history… is ambiguous… Because of this ambiguity it is clear that we must look primarily to the statutes themselves to find the legislative intent” (Citizens to Preserve Overton Park v. Volpe (1971)
> > > > - 1980-2000s: Textualist Critique
> > > >     - Purpose and legislative history give too much discretion
> > > >     - The text represents a deal
> > > > - 2000s to Present: Reacting to Textualism
> > > >     - No dictionaries in the legislature!
> > > >     - Compromises are political, not grammatical
> > 
> > > [!note]+ Semantic Canons
> > > Helpful tools or window dressing?
> > 
> > > [!note]+ Substantive Canons
> > > How heavy is the thumb on the scale? How ambiguous does statute need to be?
> > > 
> > > > [!note]+ Constitutional Avoidance
> > > > - It replaces drawing a clear line and making sure it isn’t crossed with pointing to a blurry cloud and keeping everything away
> > > > - This will actually allow the court to further trim legislation
> > > > 
> > > > See [[NOTION_PAGE:8043c0d4-510a-42ce-a206-c3e2fcdd61ee]] 
> > > 
> > > > [!note]+ Federalism
> > > > > [!note]+ Pros (Why state gov is better)
> > > > > - Responsiveness
> > > > > - Participation
> > > > > - Innovation (laboratories of Democracy)
> > > > > - Competition (race to the top)
> > > > > - Vertical Division of Power (checking abuse?)
> > > > 
> > > > > [!note]+ Cons
> > > > > - Really? This is local government stuff, if anything
> > > > > - And do you remember the 1950s? States aren’t great at civil rights
> > > > > - Often more like a race to the bottom
> > > > > - And most importantly, what’s at issue here isn’t the abstract principle, but whether the specific regulation will help or hurt the balance of power
> > > > 
> > > > - What starts with constitutional avoidance becomes desire to safeguard a constitutional *value *(commitment to federalism)
> > > > - Is this a coherent freestanding norm, or just an expression of the balance struck in the Constitution?
> > > > - Federalism canon helps “improve the legislative drafting process” by forcing clear writing?
> > > > - It’s not clear whether Congress is responsive to this, or any, canon.
> > > 
> > > > [!note]+ Lenity
> > > > - Fair Notice: Doesn’t this just help sophisticated defendants?
> > > > - Nondelegation: Legislatures should carefully define criminal policy
> > > > - Overcriminalization: “pathological politics” of criminal law
> > > > - Oldie: It’s been around a while, so it’s part of the law
> 
> > [!note]+ Theories of The Judge’s Role (RudyDapper)
> > - Faithful agent
> >     - Competing views of this ([[TVA]]) – executing instructions by interpreting/updating them
> > - Corrective/accountability partner of Congress
> >     - Posner’s Judicial Interpretive Updating ([[Hively]])
> >     - Courts and legislature are in a partnership.
> >     - Interpret statutes on the basis of present need and understanding
> > 
> > > [!note]+ Relational Agent Theory
> > > - William Eskridge
> > > - Calls on creativity in implementation
> > > - Relies on the legislature having intents at multiple levels of generality, as well as meta-intents about how to make trade-offs among them
> > > - Risks
> > >     - Mistakes about meta-intent
> > >     - Allows the law to adapt too quickly
> > >     - Undermines stability and predictability
> > 
> > - Updater (Posner) 

> [!note]+ ### Regulation
> > [!note]+ Governmental Roles
> > > [!note]+ Formalism [[Chada]] (Burger Majority)
> > > > [!note]+ Characteristics
> > > > - “Hermetically sealed” (derogatory)
> > > > - Meaning is fixed by historical understanding: no reassignment of powers even if actual balance preserved
> > > > - Rule-like
> > > > - Pseudo-textualist
> > > > - Overstates determinacy
> > > 
> > > > [!note]+ Evidence
> > > > - Minimal role of branches in selection of others
> > > > - Ability of some to remove others limited and cumbersome
> > > > - Limited control of salaries
> > > > - Noncompatibility (no legislative position with other branch position, but you can be on the Court and in Executive office)
> > > 
> > > > The [purpose of the] doctrine of the separation of powers was… not to avoid friction, but, by means of the inevitable friction incident to the distribution of the governmental powers among three departments, to save people from autocracy. -*Myers v. United States*, Brandeis (dissenting)
> > 
> > > [!note]+ Functionalism [[Chada]] (White’s Dissent)
> > > > [!note]+ Characteristics
> > > > - We can have some reassignment as long as the core functions are preserved
> > > > - Standard-like
> > > > - Purposivist
> > > > - Overstates indeterminacy
> > > 
> > > > [!note]+ Evidence
> > > > - Veto: executive has legislative role
> > > > - Impeachments: legislative and judicial role in trying executive
> > > > - Advice and Consent in appointing judges
> > > > - 2/3 Senate approval for treaties
> > > > - Vice President is President and tiebreaker of Senate
> > > 
> > > > [The Constitution] enjoins upon its branches separateness but interdependence, autonomy but reciprocity. -*Youngstown v. Sawyer*, Jackson (concurrence)
> > 
> > > [!note]+ Congressional Control over Agencies
> > > - Appropriations (power of the purse)
> > >     - More likely to be passed bc needed to keep gov open
> > >     - Blunt Instrument
> > > - Hearings, Investigation, and Oversight 
> > >     - The threat of these often works as passive force.
> > > - Amedments 
> > >     - New law updating the old
> > 
> > > [!note]+ Presidential Control over Agencies
> > > - Regulatory Review 
> > > - Executive Orders
> > > - Jawboning (convincing/persuading)
> > > - Incentives
> > > - Norms
> 
> > [!note]+ Agency Delegation
> > > [!note]+ Technocratic Expertise
> > > - But why in the *executive*? Couldn’t we just beef up Congress?
> > > - Maybe, but that might not happen, making real alternative increased Court discretion (more interpretation of sweeping standards)
> > 
> > > [!note]+ Efficiency: Congress doesn’t have the time
> > > - Or sometimes they can’t reach agreement, for good reason
> > > - Also this allows them to avoid passing legislation
> > 
> > > [!note]+ Flexibility: Legislative process is slow, bad for quick reactions to changing circumstances
> > > - Yeah, but that’s kind of the point
> > 
> > > [!note]+ Partisan process (pork barell politics) makes this hard
> > > - Agency officials are more centrist
> > > - But isn’t this all a bit anti-democratic?
> > > - Maybe, but also these agencies do have 
> > >     - statutory restrictions
> > >     - oversight
> > >     - elected reps role in selecting personnel
> > 
> > > [!note]+ Constitutionality?
> > > > [!note]+ Article I Vesting Clause?
> > > > - vests *all *legislative power in Congress
> > > > - But *necessary and proper* might give authority to delegate
> > > > - but *proper* might be term of art limiting action to what’s otherwise permissible
> > > > - But *vests* might allow *transfer* 
> > > 
> > > > [!note]+ Bicameralism and Presentment?
> > > > - These processes prevent bad law by slowing it down
> > > > - But delegation itself has to go through this process
> > > > - But does that really prevent bad law in the same way?
> > > > - Incentives to delegate to say “doing something” without actually determining
> 
> > [!note]+ MQD
> > - Incentive to downplay the significance of regulation
> > - Because post enactment history matters now, there is an incentive to lobby Congress to consider an issue, then get it not to pass, to preclude agency consideration
> 
> > [!note]+ Arbitrary and Capricious
> > > [!note]+ History
> > > - 1935- Little scrutiny, “any state of facts” (Pacific States Box & Basket)
> > > - Late 60s- Leventhal’s “hard look” review
> > > - 1971- Overton Park: both “searching and careful” but also “narrow”
> > > > must consider whether a decision was based on a <u>consideration of the relevant factors</u> and whether there has been a <u>clear error of judgment</u>
> > > - Early 70s- Bazelon’s procedures conducive to “reasoned decision-making”
> > 
> > > [!note]+ Policy
> > > - Are courts the best to police this? They’re not democratic either
> > > - Under vs over proceduralization
> > > - Invokes questions of judicial activism
> > > - Are courts more qualified to review substance or procedure?
> > > - Which allows in more unconcious decisions based on policy preferences?
> > 
> > [[Ethyl Corp]] for back and forth argument
> 
> > [!note]+ Agency Procedure
> > > [!note]+ History
> > > - Dems seeking to prevent rollback of New Deal regulation by making it hard to change
> > > - Republicans seeking to block future expansion
> > > - So the act is historically a mix of procedural protection and anti-action
> > 
> > > [!note]+ Pros
> > > - Accuracy: Can improve the resulting decisions
> > > - Accountability: Facilitates judicial review by establishing record
> > > - Legitimacy: Facilitates public participation/Deliberative Democracy
> > > - Political Control: Allows“Fire alarm” over “police patrol” oversight: cheaper, only triggered at signal something’s wrong
> > > - Insulation/Independence: also prescribes default upper-limit of oversight
> > 
> > > [!note]+ Cons
> > > - Can “ossify” decision-making
> > > - Can reduce effective oversight by preventing Congress to engage
> > 
> > > [!note]+ Effects
> > > - Mostly benefits well-resourced issue groups (like trade organizations) that can participate
> > > - Enhances court control over agencies
> > > - Strengthens Congressional over executive control
> 
> > [!note]+ Chevron
> > > [!note]+ Analysis
> > > - Look at consistency with 706c standard
> > > - Stevens viewed as no more than a “restatement of existing law”
> > > - What’s the overlap between State Farm’s hard look review and Chevron’s test?
> > > - Equates statutory silence/ambiguity with explicit delegation
> > 
> > > [!note]+ Effects
> > > - Short-term boost in agency win rates
> > >     - Because the courts adjusted and no longer defer as much?
> > >     - Or because the agencies adjusted and make more aggressive arguments now? (interview evidence it’s this)
> > > - Dampened effect of judges’ political ideology on votes
> > 
> > > [!note]+ Defenses
> > > Political
> > > 
> > > - Democratic accountability: can be removed by president (but independent agencies also get it)
> > > - Pragmatism: when there is no intent, as a matter of policy it is better to allocate interpretive authority this way.
> > > 
> > > Legal
> > > 
> > > - Constitution: Perhaps the constitution mandates a clear statemt rule. 
> > > - Positivism: This is just a recognition that the law has run out when a statute is ambiguous, and that agencies are better positioned to make policy
> > > - Congressional Intent: Congress rarely tries to alter by statute, so myaybe they like it?
> > > 
> > > Pragmatic
> > > 
> > > - Expertise: issue area familiarity vs generalist judges
> > > - Uniformity: different appeals courts are more likely to defer, allowing supreme court to resolve fewer discrepencies
> > > - Economy: Prevents churn/litigation
> > 
> > > [!note]+ Objections
> > > - Executive Power: overly concentrated
> > > - Democratic Accountability: makes delegation more attractive
> > > - Level of deference independent of agency’s expertise or the technical nature of the issue
> > > - Isn’t step 1 just a special case of step 2?
> > > - Chevron doesn’t require that agencies demonstrate that they use a valid interpretive method (Why not? we remand for improper policy consideration, would seem even more qualified to remand for improper method of interpretation?)
> > > - Basically judicial abdication of the responsibility to interpret the law
> > 
> > > [!note]+ Pre-Chevron Status (where we will be if Chevron overruled)
> > > - Pure questions of law: de novo review [[Hearst]] 
> > > - Mixed questions in legally binding rule: deference if reasonable
> > > - Mixed questions in informal statement: no deference, but special respect
> > > - Extra Considerations
> > >     - Contemporaneous regulation to statute?
> > >     - Longstanding (like consistency)?
> > >     - Binding rule or informal?
> > >     - Important or “interstitial”?
> > >     - Technical expertise?
> > >     - Signs of Congressional approval or discontent?

