---

---
## Introduction

> [!note]+ ### Week 1: Moral Knowledge and Moral Action
> > [!note]+ Overview
> > - Does acting morally presuppose moral knowledge?
> > - What is moral knowledge? 
> > - How does moral knowledge relate to moral action?
> 
> > [!note]+ Moral Worth Notes
> > - When is an action praisworthy (when does it reflect on the agent?)
> > - Not all morally right actions have moral worth
> > - It can’t just be an accident so that it can reflect on the agent
> > 
> > > [!note]+ Kantian View (Sliwa)
> > > - It is only right if done out of duty, requiring both motivation by and knowledge of the right thing
> > 
> > > [!note]+ Right Reasons (Arpaly)
> > > - Is morally worthy if done for the relevant reasons
> > > - Has more or less depending on how much moral concern motivates
> > 
> > > [!note]+ Coincident Reasons (Markovits)
> > > - If the reason why I do it is the same reason that the moral law requires it, then it has moral worth
> > > 
> > 
> > > [!note]+ De Re vs De Dicto
> > > - Motivation de re is motivation by the thing itself (Huck has the right de re motivation)
> > > - Motivation de dicto is by the belief that its the right thing (Huck has the wrong de dicto motivation)
> 
> > [!note]+ Readings
> > [[Arpaly, 2002]] 
> > 
> > [[Markovits, 2010]] 
> > 
> > [[Sliwa, 2016]]  
> > 
> > [[King, 2020]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > - What is knowledge?
> > - Moral knowledge seems like other knowledge of social constructs “that’s a bad chess move”
> > - Why do we insist on comparing morality to science?
> > - Primary response to Sliwa: pg 400, would judge chess player differently, case for character
> > - Her account is sufficient but not necessary. The other way of achieving counterfactual robustness is through character
> >     - Insists on principled way of determining by knowledge, but really just punts a difficult question to others: how is knowledge counterfactually robust?
> > - Perhaps certain kinds of moral praise require knowledge and others don’t
> >     - Doctor prescribing supplement vs jumping in to save the drowning child
> > - Not just *evidence* of good character, but an instance of it
> > - Kantian moral worth: you have to act for the sake of doing the right thing

## Acquiring Moral Knowledge

> [!note]+ ### Week 2: Reflective Equilibrium
> > [!note]+ Overview
> > Many philosophers think that reflective equilibrium is the best method for moral inquiry. What is reflective equilibrium? And can we rely on reflective equilibrium to generate moral knowledge?
> 
> > [!note]+ Lecture Notes
> > > [!note]+ Intro
> > > - From Rawls’ Theory of Justice
> > > - Essentially, we can bracket objective right and wrong while still making progress
> > > - From a pessimism about appeals to moral truth
> > >     - Not metaphysical, but epistemological skepticism
> > >     - These truths might exist, but we can’t seem to know them
> > >     - Or, we keep arguing about them, with is a pragmatic skepticism
> > > - Moral theory should focus on moral conceptions people hold, rather than on moral truths
> > >     - Or, at least, the ones people would hold
> > >     - We should look for some kind of overlapping consensus after some idealized reflection
> > > - Problem of Induction
> > >     - How can we have knowledge of things we can’t see
> > >     - Nelson Goodman- inductive beliefs are justified by inferential principles
> > >     - Inferential principles are justified in a process of bringing principles and beliefs into agreement
> > >     - Rawls applies this to the moral sphere
> > > - We don’t…
> > >     - Start top down with principles, identify judgements
> > >     - Start bottom up with judgements, identify principles
> > 
> > > [!note]+ Elements
> > > - Judgements (intuitive and considered): about a particular circumstance
> > > - Principles: generalized assertions that support (or don’t) judgements
> > > - Theories: consistent set of moral principles
> > 
> > > [!note]+ How to do it (a full, wide, reflective equilibrium)
> > > - Reflective: No element is independently normative
> > > - Wide: We have to be prepared to examine our background theories for a wide equilibrium
> > > - Full: We can’t just do it ourselves, we have to have interpersonal agreement
> > 
> > > [!note]+ Constructivist (Rawls)- ignores moral truth, but asks about justification
> > > - Method of creation, a political project. NOT commiting to moral constructivism
> > > - Asks for public justification, if it is endorsed in a full, wide reflective equilibrium
> > > - Does not commit to moral constructivism, nor does constructivism commit to this method, but they are mutually compatible
> > > - Moral Constructivism
> > >     - Constructivism is a meta-normative commitment: truth is some domain in virtue of acceptance under certain idealized conditions
> > >     - Metaphysical claim: outcomes of practical reasoning
> > >     - Coherentism: determined by following constructivist method
> > >     - Not all constructivists need reflective equilibrium
> > > - Moral Realism
> > >     - Moral truths are objective, existing attiude independently
> > >     - Foundationalism: justification of moral judgements depends on how well they track these truths
> > > - This debate involves two elements
> > >     - Metaphysical (where is this grounded)
> > >     - Justificatory (how do we get to the right answers)
> > > - Rawls doesn’t take a stand on the metaphysical issue, but does on the justificatory, saying reflective equilibrium is necessary and sufficient (at least about distributive justice)
> > 
> > > [!note]+ Realist (Scanlon, Parfit)- uses as a tool to discover moral truths
> > > - Method of discovery
> > > - RE is necessary, but it is not sufficient because justification doesn’t get to truth
> > > - Justification does in fact depend on tracking truth, we can’t just bracket the question
> > > 
> > > > Normativity is not created by our will. What is normative about what we have reasons to want, or will, or do (Parfit 2011)
> > > 
> > > > Mere consistency among our judgements (unreflective equilibrium) might be attained too easily, simply by throwing out conflicting judgements one way or another (Scanlon 2014)
> > > 
> > > - Error matters
> > > - A moral or political judgement agreed on in a full, wide reflective equilibrium may be incorrect
> > > - There could be normative answers that are not just errors in following the constructivist method
> > > - How to approach
> > >     - Rawls started with a psychological starting point about “strongly held” beliefs
> > >     - Instead, we can start with a normative point, with our “best” beliefs about moral truths
> > >     - RE is the best way of doing this (Scanlon)
> > >     - It is the only defensible method (Parfit)
> > 
> > > [!note]+ Problem for Realists
> > > - If they start with a psychological starting point, then this can’t yield moral knowledge (garbage in/garbage out): Can’t on its own account for truth-tracking
> > > - If we have a normative starting point, then we need an independent epistemological account of what justifies our beliefs: Something else is required
> 
> > [!note]+ Readings
> > [[Daniels, 1979]] 
> > 
> > [[Scanlon, 2002]] 
> > 
> > [[Kelly & McGrath, 2010]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > > [!note]+ Three distinct moral questions
> > > - What *is* moral?
> > >     - This is not a thin question, like what is good. It asks of us empirical facts as well as normative ones.
> > > - How can we *justify* moral beliefs?
> > > - What *should be* moral?
> > >     - This can only be expressivist
> > 
> > - How do we judge our intuitions? 
> >     - By telling stories about them, fitting them into narrative structure
> > - Motivational priority of judgements
> >     - Judgements are most intuitive, and our reasons for editing one or the other will be by gut.
> >     - At best, it is our *judgements *about moral theory that will win out over our more basic judgements
> >     - Yeah, I get that your system *theoretically allows for *revision, but why would we?
> >     - Also, if our judgements have supporting reasons, wouldn’t these often take the general form of principles?
> > - Deeper (more basic theoretical) disagreements may be easier to resolve than initial judgements?
> > - Scanlon Process
> >     - Person whose considered judgements are in question has to be involved
> >     - Something we must each carry out for ourselves
> >     - (Second does not follow from the first. What follows is that we have to *participate)*
> > - Can an individual maintain a perfectly coherent set of beliefs and be completely unresponsove to changes in her environment?
> > - (Does the source of the data itself depend upon the process?)
> > - Seems merely to paint portraits of possible conceptions, not to justify them
> >     - (Unless there is normative force in saying that this one is *ours*)
> > - No, we ask if their inputs were as good, and if their process was, and this process of comparison can change my own
> >     - (This is why relativism is too early or too late. This is an important part of the process though!)
> > - You can be rational without bering reasonable

> [!note]+ ### Week 3: Moral Intuition
> > [!note]+ Overview
> > A key claim of intuitionist moral epistemology is that some moral propositions are self-evident and can be known intuitively. What does self-evidence mean? Do we have intuitive knowledge of moral duties?
> 
> > [!note]+ Lecture Notes
> > > [!note]+ David Ross *The Right and the Good*
> > > - Intuitive basis for moral thought
> > > - Moral convictions of thoughtful and well-educated people are the data of ethics as sense-perceptions are data of natural science
> > > - Plurality of mid-level moral duties justified from these
> > > - Fundamental duties (or at least reasons)
> > >     - Fidelity (duty to keep a promise)
> > >     - Reparation (correct wrong)
> > >     - Gratitude (reciprocate)
> > >     - Beneficence (do good)
> > >     - Non-maleficence (do not harm)
> > 
> > > [!note]+ Primary Claims
> > > - We have intuitve knowledge of certain moral principles
> > > - The justification of judgements is grounded in this intuitions
> > > - Any good theory must be consistent with these
> > 
> > > [!note]+ What are moral intuitions?
> > > - A non-inferentially justified belief (does not depend on some other belief)
> > > - In reflective equilibrium, all are inferentially justified
> > 
> > > [!note]+ Possible sources
> > > - Perception
> > > - Introspection
> > > - Memory (I just remember I stayed in this house)
> > > - Emotion (I am hungry just means I feel hungry)
> > > - Intuition? an intellectual seeming
> > 
> > > [!note]+ A priori or posteriori
> > > - Most non-inferentially justified beliefs are the former
> > > - Intuition appears to be the latter
> > 
> > > [!note]+ How is this possible?
> > > - Some propositions are self-evidently true
> > > - Anyone who sees this can be true without needing further evidence
> > > - (Commits you to calling all who disagree with you irrational)
> > 
> > > [!note]+ Argument for Intuitionism
> > > - Step 1
> > >     - If we have any moral knowledge, either inferential or not
> > >     - Foundationalism: Any inferential knowledge ultimately based on inference from some other knowledge non-inferential
> > >     - If we have some moral knowledge, then some non-inferential
> > > - Step 2
> > >     - Non-inferential either a posteriori or a priory
> > >     - If a posteriori, then perceptual
> > >     - Anti-perceptualism: moral facts can’t be perceived like other facts
> > >     - Therefore, non-inferential is *a priori*, arrising from intuitive apprehension of self-evident propositions
> > 
> > > [!note]+ Self-evidence and moral uncertainty
> > > - Ross argues not just that these are true, but that we can be confident these are true
> > > - Because these propositions cannot be proved but need no proof
> > > - Objection
> > >     - Moral knowledge is not like that, morality is hard
> > > - Response
> > >     - This theoretical certainty is compatible with concrete uncertainty
> > >     - One thing can be both *prima facie* right and wrong
> > >     - You might also overlook other duties
> > >     - Long-term consequences are uncertain
> > > - Fallibility: implies that we run moral risks in concrere cases
> > 
> > > [!note]+ Moral Psychology and Reliability
> > > - Framing Effects (Kahneman and Tversky)
> > >     - The idea is that they can’t focus on the *real* problem, but rather the story
> > >     - Emphasis on loss encourages risk aversion
> > > - Moral Dumbfounding (Haidt)
> > >     - People tend to stick to their moral judgements, even without reason
> > >     - Reasons seem not to get a grip on the justification
> > > - We shouldn’t be Intuitionists (Singer)
> > >     - Child in the pond disanalogy means we have unreliable intuitions
> > >     - Minimize intuitions, insist on a single core principle, then derive everything else intuitively
> > 
> > > [!note]+ Self-Evidence
> > > - Objection: Justification comes too easily to the intuitionist
> > >     - Even apprehension is a result of our conditoning
> > >     - We can’t be certain just by considering
> > > - Then maybe no moral knowledge is a priori
> 
> > [!note]+ Readings
> > [[Audi, 1998]] 
> > 
> > [[Haidt, 2001]] 

> [!note]+ ### Week 4: Moral Perception
> > [!note]+ Overview
> > Can we just see that torturing a cat is morally wrong? How can we perceive moral facts?
> 
> > [!note]+ Lecture Notes
> > > [!note]+ Intro
> > > - Moral perception and intuition are not mutually exclusive
> > > - Can’t we just *see* that things are wrong?
> > > - What is the experience of perceiving moral facts?
> > > - Can we appeal to this experience without moral facts?
> > 
> > > [!note]+ Motivating moral perceptualism
> > > - It’s often how we come to know empirical facts
> > >     - We evolved perception mechanisms for the empirical world
> > >     - (But we can’t have done the same with the moral)
> > > - You see an elderly couple struggling and elbow your friend to help
> > >     - Your friend doesn’t see anything wrong, he isn’t attuned to the moral characteristics of the environment
> > > - Murdoch, *The Sovereignty of the Good*
> > >     - We can change our “perspective” on an issue, which seems to be a result of our perception
> > > - Seeming isn’t like an intellectual seeming or inferring a wrong
> > > - You can gradually come to see some moral fact, like being gay isn’t really wrong, without inferential reasoning
> > 
> > > [!note]+ Harman’s objection to moral perceptualism
> > > - Are we perceiving a moral fact, or appealing to one to justify the belief?
> > > - Contrast with Science
> > >     - In science, an hypothesis is justified because, if true, would best explain what is going on
> > >     - Proton passing through a cloud chamber helps to best explain the physicist’s judgement
> > >     - Do we need to appeal to moral facts to justify our beliefs?
> > >     - Moral theories tested by thought experiments, and these explain our judgements, not facts
> > >     - We don’t appeal to whether your intuitive judgement is right or wrong to explain the perception
> > 
> > > [!note]+ Possible response to Harman’s objection
> > > - Sarah McGrath: Harman assumes if we have knowledge, it is an inference trying to explain our judgements
> > > - We don’t judge that a snowball is white becvause this hypothesis best explains our judgement it is white, it just *looks* that way.
> > 
> > > [!note]+ High and Low-Level Perceptual Experiences
> > > - Lower level is just “this is green”
> > > - Higher level is that you see a green heron, might require other knowledge
> > > - This isn’t just limited to how things look, like seeing the hidden side of a tomato
> > > - Maybe moral perception is necessecarily high-level
> > 
> > > [!note]+ Primary and Secondary ََQualities
> > > - Primary is really out there, secondary depends on experience
> > > - Morality may or may not be like color perception. 
> > 
> > > [!note]+ Modality (Looks Objection)
> > > - Concerns
> > >     - There just isn’t a way that a moral thing *looks*
> > >     - Only a tenuous connection to experience
> > > - Responses
> > >     - Reject directly (no, it *does* look a certain way)
> > >         - Pulls from higher-level claim
> > >     - Accept, argue an indirect link from senses to moral knowledge
> > >         - They aren’t directly percieving (like seeing a track in the vapor chamber) and judge that there is a proton there.
> > >         - non-moral observations can confirm or disconfirm moral instances
> > >         - **Seems clearly true of instances, but false of the underlying theories**
> > >         - So can you come to see that Bob and Chuck’s relationship is right, or is there a non-moral perception leading to a moral inference about rightness?
> > >     - Accept, argue it is affective, not sense-based
> > >         - Your emotions give you some information about the moral world
> > >         - So you might feel fear at an oncoming dog, which tells you that the dog is dangerous
> > >         - So can you feel anger at how you are being treated and have that anger be apt, telling you there is injustice?
> 
> > [!note]+ Readings
> > [[McGrath, 2004]] 
> > 
> > [[Harman, 2012]] 

> [!note]+ ### Week 5: Moral Testimony
> > [!note]+ Overview
> > Can we gain moral knowledge based on others’ testimony? Are there moral experts?
> 
> > [!note]+ Lecture Notes
> > - What is moral testimony?
> >     - Non-moral testimony in a moral context (fish feel pain)
> >     - (Pure) moral testimony (eating fish is wrong)
> >     - Can it…
> >         - satisfy an epistemic aim?
> >         - satisfy a practical name?
> >         - Pessimists reject one or both
> >     - Can’t be a foundational route to knowledge, but only transmission
> >         - **But my interpersonal account has to be**
> > - Moral knowledge from others
> >     - Education
> >         - We require most non-moral from others (like geography)
> >         - Seems like children can acquire moral knowledge from others in this way
> >     - Advice
> >         - If relying on advice is fine, then we can get moral knowledge from others
> >         - Especially when we seem to be biased or are upset
> > - Worries about moral testimony
> >     - Epistemic
> >         - Testimony can’t trasmit moral knowledge because moral knowledge is a form of knowing how
> >         - There are no moral experts, if there are we can’t know who they are
> >     - Practical
> >         - Hills: might transmit knowledge, but won’t transmit understanding
> >         - Lack of understanding isn’t a problem non-morally
> >         - But with the moral, there is a problem for moral worth and justification
> >         - You can’t explain what you are doing
> >             - **This is important and my account solves. You will be able to engage in storytelling**
> >         - Your action don’t have moral worth: Worth needs understanding
> > - Are there moral experts?
> >     - Bernard Williams: no
> >     - Singer: yes
> >     - **No, so long as expertise involves primarily explict, analytical understanding**
> >     - **There are people who have more or less understanding, but this is about being conneted in the right way**
> > - Who is an expert?
> >     - Practical expert: Superior skills, like an expert violinist
> >     - Cognitive expert: superior theoretical knowledge, like a historian
> >         - more beliefs in true propositions and/or fewer beliefs in false propositions
> >         - And has skills that can successfully deploy this knowledge
> >         - People would have more true moral beliefs and be able to employ them well
> >     - Are we looking for knowing how or knowing that?
> >     - Driver: a moral expert needs both
> > - The case against moral experts
> >     - Epistemic
> >         - Who would they be? Moral philosophers?
> >         - Moral philosophers don’t seem to be able to solve moral problems better than other people
> >         - Are advisors experts? no, but
> >     - Practical
> >         - If there were moral experts, we should defer to them
> >         - We shouldn’t morally defer, so there aren’t experts
> >     - A good track record
> >         - Maybe there are people with superior track records, and that knowing that people have a better track record might help us identify them
> >         - Not just chance, it must be some additional understanding or connection
> >     - Ability to explain? Driver
> 
> > [!note]+ Readings 
> > [[Hills, 2009]] 
> > 
> > [[Driver, 2013]] 

## Limits of Moral Knowledge

> [!note]+ ### Week 7: Moral Disagreements
> > [!note]+ Overview
> > What explains our tendency to disagree on moral issues? And how should we respond to moral disagreements?
> 
> > [!note]+ Lecture Notes
> > > [!note]+ Monday
> > > - Intro
> > >     - Disagreements involve incompatible attitudes
> > >     - Some disagreements involve matters of fact and belief, but not all do
> > >     - Some don’t, like subjective attitudes
> > >     - What are moral matters? like tastes or about objective facts?
> > >         - Something in between, like that’s a bad move, or that is rude.
> > > - Metaphysical explanation (Mackie)
> > >     - If there were objective facts, we would have convergence
> > >     - In the moral case, we don’t have convergence
> > >     - There are no objective moral facts
> > >     - These are about ways of life rather than objective values
> > >     - This doesn’t prove that the problem is metaphysical, not epistemological
> > > - Epistemological explanation
> > >     - Costly acceptance of moral beliefs (impermissability of eating meat)
> > >     - Wishful thinking
> > >     - Social bias (your beliefs are especially shaped by your culture
> > >     - Problems with empathy and moral attention
> > 
> > > [!note]+ Tuesday
> > > > [!note]+ Intro
> > > > - Sidgwick’s View: Seems to be NIRF
> > > > - In some cases there is an unequal epistemic relationship
> > > > - But sometimes you have a peer, how should we respond to those?
> > > > - Peer definitions
> > > >     - Evidence Peer: access to the same information
> > > >     - Cognitive Peer: they are rougly equal at reasoning
> > > 
> > > > [!note]+ Steadfastness
> > > > - Disagreements with peers should not undermine your belief
> > > > - You are entitled to retain confidence instead
> > > > - Motivating
> > > >     - Imagine you have a disagreement on an issue where you hold firm beliefs
> > > >     - It seems rational to retain your confidence here. The question is whether these people are your peers
> > > > - Arguments
> > > >     - Permissiveness of Evidence
> > > >         - Observation is theory-laden, so evidence does not determine belief
> > > >         - If this is true, then you might reasonably come to different conclusions despite evidence and cognitive peers
> > > >         - In the moral case, it seems like permissiveness can’t be tolerated because the questions involved really matter
> > > >     - Asymmetry in trust
> > > >         - When trying to decide what we should believe, we rely on our own reasoning, but when we do this for others we still rely on our own reasoning
> > > >         - Might be rational to have a foundational trust in one’s own intuitions but isn’t even possible to have that sort of trust in others (Wedgewood)
> > > >         - But this allows for a kind of question-begging thing that we don’t want to have to tolerate, so we need an argument for why disagreement itself can provide an argument that the other person is wrong
> > > >         - Not just a Truth-o-Meter (Enoch)
> > > 
> > > > [!note]+ Conciliationism
> > > > - When in disagreement with an epistemic peer, you lose justification for your belief and so should reduce confidence.
> > > > - Equal Weight View: You should suspend belief in peer disagreement
> > > > - Justificationism: You don’t have to reduce confidence if you have really good reasons for the belief
> > > > - Kieran Setiya: We should condemn moral mosters, not reduce confidence in our own beliefs
> > > > - 
> > > 
> > > - Skepticism
> 
> > [!note]+ Readings
> > [[Vavova, 2014]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > - What should we do in cases of partial peerhood or partial confidence? Seems like it boils down to cognitive virtues like believing truth vs. avoiding error
> > - What should we do in the case of peer disagreement? We should engage with them! An odd focus on what is lost if you cease to engage rather than what could be gained if you continue to talk. We usually don’t know whether the person we are talking to is a peer.

> [!note]+ ### Week 8: Moral Ignorance
> > [!note]+ Overview
> > We often lack moral knowledge. What does that mean for moral action? If you believe, falsely, that supporting your friend is the right thing to do in a given situation, are you doing something wrong? Does your false belief give you an excuse?
> 
> > [!note]+ Lecture Notes
> > - De Dicto vs De Re
> >     - De dicto: not knowing that sexism is wrong
> >     - De re: not knowing that one’s behavior is sexist
> > - Rosen
> >     - Our responsibility for what we do from ignorance is always a matter of derivative responsibility
> >     - Therefore, akrasia is the only locus of original moral responsibility
> > - Johnson King
> >     - A belief about a relevant moral fact is a way of caring about what is morally significant
> >     - Failighto hold a correct moral belief is (sometimes) failing to care about that moral fact
> >     - Failing to care about a moral fact is morally blameworthy
> >     - So moral ignorance only exculpates if it is not from failure to care about a moral fact.
> 
> > [!note]+ Readings
> > [[Harman, 2011]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > Process vs procedure
> > 
> > Belief vs orientation
> > 
> > - ‘these procedural obligations are always obligations to do (or to refrain from doing) certain things: to ask certain questions, to take careful notes, to stop and think, to focus one’s attention in a certain direction, etc. The procedural obligation is not itself an obligation to know or believe this or that. It is an obligation to take steps to ensure that when the time comes to act, one will know what one ought to know’ (301).
> > - Ought might imply some form of ‘can’ that doesn’t reject determinism: can is not a counterfactual but a question of whether the belief is compatible with continuity and integrity at an agent.

> [!note]+ ### Week 9: Moral Uncertainty
> > [!note]+ Overview
> > What should you do when you’re unsure about what the right thing to do is? Suppose you’re unsure about whether eating meat is always wrong. Should you be morally risk adverse?
> 
> > [!note]+ Readings
> > Essential
> > 
> > [[Moller, 2011]] 
> > 
> > Recommended
> > 
> > [[Weatherson, 2014]] 
> > 
> > [[Bykvist, 2017]] 
> > 
> > Further
> > 
> > [[Arpaly, 2000]] 
> > 
> > [[Sapielli, 2009]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > Topics
> > 
> > - Infinite regress
> > - Intertheoretic comparisons
> > - Fetishism
> > - Moral manual vs description
> >     - Fact vs evidence vs belief (global and local) relative oughts
> > 
> > Relevance of the belief relative moral ought: like hypocrisy?
> > 
> > Is there a de re moral consideration that could argue for taking uncertainty seriously? Something like care?
> > 
> > Does it have to be second-level moral reasoning, or just a first-level consideration that affects our deliberation?
> > 
> > Weatherson always asserts what actually is right and wrong. 
> > 
> > Rationality as a description can’t function as a manual

> [!note]+ ### Week 10: The Evolution of Moral Beliefs
> > [!note]+ Overview
> > What if our moral beliefs are best explained as a product of evolutionary processes? Does that imply that our moral beliefs do not track moral facts?
> 
> > [!note]+ Lecture Notes
> > Evolutionary Debunking Arguments
> > 
> > - Realist premise: 
> >     - Moral judgments are truth-apt
> >     - A moral proposition may be true without anyone recognising it or reflectively endorsing it
> > - Empirical Premise: 
> >     - Our moral beliefs are explained by evolutionary forces selecting for fitness
> >     - Nagel’s dogmatist response to evolutionary debunking arguments: reject evolution’s effect on our moral beliefs
> > - Epistemic Premise: 
> >     - The evolutionary process doesn’t track attitude-independent moral truths
> >     - Isserow’s response: evolution selected for the preconditions for tracking moral truth (empathy, impulse control, anticipating the consequences of our actions). But there is no robust non-debunking account available for why this tracks truth
> >     - Parfit: argues that we might just have been selected for our ability to respond to reasons. But why would we have been? Also question-begging
> > - Third-factor strategy
> >     - Certain fundamental moral truths are in line with evolution
> >     - The moral truth is that survival is good
> > - Conceptual Truths Strategy (Russ Shafer-Landau)
> >     - Since evolution doesn’t select for pain, it is compatible with pain being bad
> >     - **…But evolution does select for pain (leprosy)**
> 
> > [!note]+ Readings
> > Essential
> > 
> > [[Street, 2006]] 
> > 
> > Recommended
> > 
> > [[Enoch, 2011]] 
> > 
> > [[Vavova, 2015]] 
> 
> > [!note]+ Thoughts/Remaining Questions
> > - The thought isn’t just that we have access to moral judgments, but moral reasons. Even if there is a third factor explanation, then our moral reasons can’t be right.
> >     -  We can only be justified in our beliefs about the value of actions that impact survival, and not the reasons for this value (We might be right that torture is wrong, but not *why* it is wrong, eg it is disrespectful)
> > - Only non-skeptical moral realism will help us take morality seriously, and evolutionary debunking arguments make this kind of realism very hard. So it isn’t clear why realism is the most plausible on Enoch’s own account
> > - Vavova: To reject realism is to give up. Is it?
> > 
> > > [!note]+ Street Quotes to Grapple With
> > > > Where antirealists part ways with realists is in denying that there are evaluative truths which hold independently of the whole set of evaluative judgements we make or might make upon reflection, or independently of the whole set of other evaluative attitudes we hold or might hold upon reflection. (111) **implausible assumption of inner process**
> > > 
> > > > In rational reflection, one does not stand completely apart from one's starting fund of evaluative judgements: rather, one uses them, reasons in terms of them, holds some of them up for examination in light of others. The widespread consensus that the method of reflective equilibrium, broadly understood, is our sole means of proceeding in ethics is an acknowledgment of this fact: ultimately, we can test our evaluative judgements only by testing their consistency with our other evaluative judgements, combined of course with judgements about the (non-evaluative) facts. (124) **Again, too individualistic**

